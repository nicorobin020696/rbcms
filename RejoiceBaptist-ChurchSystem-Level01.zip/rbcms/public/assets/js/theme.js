// Applies the saved theme before the page paints to avoid a flash of the wrong colours.
(function () {
  var root = document.documentElement;
  var pref = root.getAttribute('data-theme-pref') || 'system';
  try { if (!root.hasAttribute('data-user-theme')) { var local = localStorage.getItem('rbcms-theme'); if (local && pref === 'system') pref = local; } } catch (e) {}
  var dark = pref === 'dark' || (pref === 'system' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  root.setAttribute('data-theme', dark ? 'dark' : 'light');
})();
