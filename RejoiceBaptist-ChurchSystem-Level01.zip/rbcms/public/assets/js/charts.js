/*
 * Lightweight SVG charts (no external library, works offline).
 * Usage: <div class="chart" data-chart='{"type":"bar"|"line"|"hbar","labels":[],"series":[{"name":"","values":[]}],"money":false}'></div>
 */
(function () {
  'use strict';
  var PALETTE = ['#3b74e8', '#22a061', '#e0a100', '#d9423a', '#8b5cf6', '#14a39a', '#ec7a1c', '#7b8491'];
  var NS = 'http://www.w3.org/2000/svg';

  function el(name, attrs, parent) {
    var e = document.createElementNS(NS, name);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }
  function fmt(v, money) {
    if (money) return '₱' + Number(v / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return Number(v).toLocaleString();
  }
  function short(v, money) {
    var n = money ? v / 100 : v;
    if (Math.abs(n) >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
    if (Math.abs(n) >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'k';
    return String(Math.round(n * 100) / 100);
  }
  function niceMax(v) {
    if (v <= 0) return 4;
    var p = Math.pow(10, Math.floor(Math.log10(v))), n = v / p;
    var step = n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10;
    return step * p;
  }

  function render(box) {
    var cfg;
    try { cfg = JSON.parse(box.getAttribute('data-chart')); } catch (e) { return; }
    box.innerHTML = '';
    var series = cfg.series || [];
    var labels = cfg.labels || [];
    var total = 0;
    series.forEach(function (s) { (s.values || []).forEach(function (v) { total += Math.abs(v); }); });
    if (!labels.length || total === 0) {
      box.innerHTML = '<div class="empty small" style="padding:40px 10px">' + (cfg.empty || 'No data for this period yet.') + '</div>';
      return;
    }
    var tip = document.createElement('div'); tip.className = 'chart-tip'; box.appendChild(tip);
    function showTip(evt, html) {
      var r = box.getBoundingClientRect();
      tip.innerHTML = html; tip.style.display = 'block';
      tip.style.left = (evt.clientX - r.left) + 'px'; tip.style.top = (evt.clientY - r.top) + 'px';
    }
    function hideTip() { tip.style.display = 'none'; }

    if (cfg.type === 'hbar') return hbar(box, cfg, showTip, hideTip);

    var W = Math.max(box.clientWidth, 280), H = cfg.height || 220;
    var pad = { l: 40, r: 10, t: 12, b: 28 };
    var svg = el('svg', { viewBox: '0 0 ' + W + ' ' + H, height: H, role: 'img' }, box);
    var max = 0;
    if (cfg.stacked) {
      labels.forEach(function (_, i) { var t = 0; series.forEach(function (s) { t += s.values[i] || 0; }); max = Math.max(max, t); });
    } else {
      series.forEach(function (s) { s.values.forEach(function (v) { max = Math.max(max, v); }); });
    }
    max = niceMax(max);
    var cw = W - pad.l - pad.r, ch = H - pad.t - pad.b;
    var grid = el('g', { 'class': 'grid' }, svg), axis = el('g', { 'class': 'axis' }, svg);
    for (var g = 0; g <= 4; g++) {
      var y = pad.t + ch - ch * g / 4;
      el('line', { x1: pad.l, x2: W - pad.r, y1: y, y2: y }, grid);
      var t = el('text', { x: pad.l - 6, y: y + 3, 'text-anchor': 'end' }, axis); t.textContent = short(max * g / 4, cfg.money);
    }
    var n = labels.length, step = cw / n;
    var every = Math.ceil(n / Math.max(1, Math.floor(cw / 46)));
    labels.forEach(function (lab, i) {
      if (i % every !== 0) return;
      var tx = el('text', { x: pad.l + step * i + step / 2, y: H - 9, 'text-anchor': 'middle' }, axis); tx.textContent = lab;
    });

    if (cfg.type === 'line') {
      series.forEach(function (s, si) {
        var color = s.color || PALETTE[si % PALETTE.length];
        var pts = s.values.map(function (v, i) { return [pad.l + step * i + step / 2, pad.t + ch - (v / max) * ch]; });
        el('path', { d: 'M' + pts.map(function (p) { return p.join(','); }).join('L'), fill: 'none', stroke: color, 'stroke-width': 2, 'stroke-linejoin': 'round' }, svg);
        pts.forEach(function (p, i) {
          var c = el('circle', { cx: p[0], cy: p[1], r: n > 20 ? 2 : 3.2, fill: color }, svg);
          var hit = el('rect', { x: p[0] - step / 2, y: pad.t, width: step, height: ch, fill: 'transparent' }, svg);
          hit.addEventListener('mousemove', function (e) { showTip(e, '<b>' + RBCesc(labels[i]) + '</b><br>' + series.map(function (ss) { return RBCesc(ss.name) + ': ' + fmt(ss.values[i], cfg.money); }).join('<br>')); });
          hit.addEventListener('mouseleave', hideTip);
        });
      });
    } else {
      var groups = cfg.stacked ? 1 : series.length;
      var bw = Math.min(34, (step * 0.7) / groups);
      labels.forEach(function (lab, i) {
        var x0 = pad.l + step * i + (step - bw * groups) / 2, acc = 0;
        series.forEach(function (s, si) {
          var v = s.values[i] || 0, h = (v / max) * ch, color = s.color || PALETTE[si % PALETTE.length];
          var x = cfg.stacked ? x0 : x0 + si * bw;
          var y = pad.t + ch - h - (cfg.stacked ? acc : 0);
          if (cfg.stacked) acc += h;
          var r = el('rect', { x: x + 1, y: y, width: Math.max(1, bw - 2), height: Math.max(0, h), rx: 2, fill: color }, svg);
          r.addEventListener('mousemove', function (e) { showTip(e, '<b>' + RBCesc(lab) + '</b><br>' + (s.name ? RBCesc(s.name) + ': ' : '') + fmt(v, cfg.money)); });
          r.addEventListener('mouseleave', hideTip);
        });
      });
    }
    if (series.length > 1 || cfg.legend) {
      var lg = document.createElement('div'); lg.className = 'legend';
      lg.innerHTML = series.map(function (s, si) { return '<span><i style="background:' + (s.color || PALETTE[si % PALETTE.length]) + '"></i>' + RBCesc(s.name) + '</span>'; }).join('');
      box.appendChild(lg);
    }
  }

  function hbar(box, cfg, showTip, hideTip) {
    var s = cfg.series[0], max = Math.max.apply(null, s.values) || 1;
    var html = cfg.labels.map(function (lab, i) {
      var pct = Math.round(s.values[i] / max * 100);
      return '<div class="bar-row"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + RBCesc(lab) + '</span>' +
        '<span class="num mono">' + fmt(s.values[i], cfg.money) + '</span><div class="progress"><span style="width:' + pct + '%;background:' + (s.color || PALETTE[0]) + '"></span></div></div>';
    }).join('');
    box.insertAdjacentHTML('beforeend', html);
    box.style.minHeight = '0';
  }
  function RBCesc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  function renderAll() { Array.prototype.forEach.call(document.querySelectorAll('[data-chart]'), render); }
  document.addEventListener('DOMContentLoaded', renderAll);
  var t; window.addEventListener('resize', function () { clearTimeout(t); t = setTimeout(renderAll, 150); });
})();
