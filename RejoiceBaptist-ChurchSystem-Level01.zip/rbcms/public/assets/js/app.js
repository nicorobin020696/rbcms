/* Rejoice Baptist Church Management System — interface behaviour (no external libraries). */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var root = document.documentElement;
  var meta = function (n) { var m = $('meta[name="' + n + '"]'); return m ? m.content : ''; };
  var BASE = meta('base-url');
  var CSRF = meta('csrf-token');
  window.RBC = { $: $, $$: $$, base: BASE, csrf: CSRF };

  function post(url, data) {
    var body = new URLSearchParams(data || {});
    body.append('_token', CSRF);
    return fetch(BASE + url, { method: 'POST', body: body, headers: { 'Accept': 'application/json', 'X-CSRF-Token': CSRF }, credentials: 'same-origin' })
      .then(function (r) { return r.json(); });
  }
  window.RBC.post = post;

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  window.RBC.esc = esc;

  function toast(msg, type) {
    var box = $('#toasts'); if (!box) return;
    var t = document.createElement('div');
    t.className = 'toast ' + (type || 'success');
    t.innerHTML = '<span>' + esc(msg) + '</span><button class="icon-btn" type="button" data-dismiss aria-label="Dismiss">×</button>';
    box.appendChild(t);
    setTimeout(function () { t.remove(); }, 5000);
  }
  window.RBC.toast = toast;

  // ---------------------------------------------------------------- theme
  function syncThemeIcon() {
    var dark = root.getAttribute('data-theme') === 'dark';
    $$('.theme-icon-light').forEach(function (e) { e.classList.toggle('hidden', dark); });
    $$('.theme-icon-dark').forEach(function (e) { e.classList.toggle('hidden', !dark); });
  }
  syncThemeIcon();
  document.addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-theme-toggle]');
    if (!btn) return;
    var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    root.setAttribute('data-theme-pref', next);
    syncThemeIcon();
    try { localStorage.setItem('rbcms-theme', next); } catch (e) {}
    if (CSRF) post('/profile/theme', { theme: next }).catch(function () {});
  });

  // ---------------------------------------------------------------- sidebar
  var app = $('#app');
  try { if (app && localStorage.getItem('rbcms-collapsed') === '1') app.classList.add('collapsed'); } catch (e) {}
  document.addEventListener('click', function (ev) {
    if (ev.target.closest('[data-collapse-toggle]')) {
      app.classList.toggle('collapsed');
      try { localStorage.setItem('rbcms-collapsed', app.classList.contains('collapsed') ? '1' : '0'); } catch (e) {}
    }
    if (ev.target.closest('[data-nav-toggle]')) { app.classList.toggle('nav-open'); ev.stopPropagation(); return; }
    if (app && app.classList.contains('nav-open') && !ev.target.closest('#sidebar')) app.classList.remove('nav-open');
  });

  // ---------------------------------------------------------------- dropdowns
  document.addEventListener('click', function (ev) {
    var toggle = ev.target.closest('[data-dropdown-toggle]');
    $$('[data-dropdown].open').forEach(function (d) {
      if (!toggle || d !== toggle.closest('[data-dropdown]')) { if (!ev.target.closest('.dropdown-panel') || !d.contains(ev.target)) d.classList.remove('open'); }
    });
    if (toggle) {
      var dd = toggle.closest('[data-dropdown]');
      dd.classList.toggle('open');
      if (dd.classList.contains('open') && dd.hasAttribute('data-notifications')) loadNotifications();
    }
  });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') $$('[data-dropdown].open').forEach(function (d) { d.classList.remove('open'); }); });

  // ---------------------------------------------------------------- notifications
  function setUnread(n) {
    $$('[data-unread]').forEach(function (b) { if (n > 0) { b.textContent = n > 99 ? '99+' : n; } else { b.remove(); } });
  }
  function loadNotifications() {
    var list = $('[data-notif-list]'); if (!list) return;
    fetch(BASE + '/notifications/feed', { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data.items || !data.items.length) { list.innerHTML = '<div class="empty small" style="padding:28px">You are all caught up.</div>'; return; }
        list.innerHTML = data.items.map(function (n) {
          return '<a class="notif' + (n.read ? '' : ' unread') + '" href="' + BASE + '/notifications/' + n.id + '/open">' +
            '<span class="ni">' + (n.icon || '') + '</span><span><div class="nt">' + esc(n.title) + '</div>' +
            (n.body ? '<div class="nb">' + esc(n.body) + '</div>' : '') + '<div class="nm">' + esc(n.ago) + '</div></span></a>';
        }).join('');
        setUnread(data.unread);
      }).catch(function () { list.innerHTML = '<div class="empty small">Could not load notifications.</div>'; });
  }
  document.addEventListener('click', function (ev) {
    if (!ev.target.closest('[data-mark-all]')) return;
    post('/notifications/read-all').then(function () { setUnread(0); $$('.notif.unread').forEach(function (n) { n.classList.remove('unread'); }); });
  });

  // ---------------------------------------------------------------- toasts
  document.addEventListener('click', function (ev) { var d = ev.target.closest('[data-dismiss]'); if (d) d.closest('.toast').remove(); });
  $$('.toast').forEach(function (t) { if (!t.classList.contains('error')) setTimeout(function () { t.remove(); }, 6000); });

  // ---------------------------------------------------------------- modals
  document.addEventListener('click', function (ev) {
    var open = ev.target.closest('[data-open-modal]');
    if (open) { var m = document.getElementById(open.getAttribute('data-open-modal')); if (m) { m.showModal(); $$('[data-dropdown].open').forEach(function (d) { d.classList.remove('open'); }); } }
    var close = ev.target.closest('[data-close-modal]');
    if (close) { var dlg = close.closest('dialog'); if (dlg) dlg.close(); }
    if (ev.target.tagName === 'DIALOG') ev.target.close();
    if (ev.target.closest('[data-back]')) { if (history.length > 1) { ev.preventDefault(); history.back(); } else if (window.opener || !document.referrer) { ev.preventDefault(); window.close(); } }
    if (ev.target.closest('[data-print]')) { ev.preventDefault(); window.print(); }
  });

  // Confirmation before destructive actions: <form data-confirm="Message"> or <button data-confirm>
  var pendingForm = null;
  document.addEventListener('submit', function (ev) {
    var form = ev.target;
    var msg = form.getAttribute('data-confirm') || (ev.submitter && ev.submitter.getAttribute('data-confirm'));
    if (!msg || form.dataset.confirmed === '1') { lockSubmit(form, ev.submitter); return; }
    ev.preventDefault();
    pendingForm = { form: form, submitter: ev.submitter };
    var dlg = $('#confirm-modal');
    if (!dlg) { if (confirm(msg)) { form.dataset.confirmed = '1'; form.requestSubmit(ev.submitter); } return; }
    $('[data-confirm-text]', dlg).textContent = msg;
    $('[data-confirm-title]', dlg).textContent = form.getAttribute('data-confirm-title') || (ev.submitter && ev.submitter.getAttribute('data-confirm-title')) || 'Please confirm';
    var ok = $('[data-confirm-ok]', dlg);
    var danger = form.hasAttribute('data-danger') || (ev.submitter && ev.submitter.hasAttribute('data-danger'));
    ok.className = 'btn ' + (danger ? 'btn-danger solid' : 'btn-primary');
    ok.textContent = form.getAttribute('data-confirm-ok') || (ev.submitter && ev.submitter.getAttribute('data-confirm-ok')) || 'Confirm';
    dlg.showModal();
  });
  document.addEventListener('click', function (ev) {
    if (!ev.target.closest('[data-confirm-ok]') || !pendingForm) return;
    $('#confirm-modal').close();
    pendingForm.form.dataset.confirmed = '1';
    if (pendingForm.submitter && pendingForm.submitter.name) {
      var h = document.createElement('input'); h.type = 'hidden'; h.name = pendingForm.submitter.name; h.value = pendingForm.submitter.value; pendingForm.form.appendChild(h);
    }
    pendingForm.form.submit();
    pendingForm = null;
  });
  // Prevent double submission.
  function lockSubmit(form, submitter) {
    if (form.hasAttribute('data-no-lock') || form.method.toLowerCase() !== 'post') return;
    setTimeout(function () { $$('button[type=submit]', form).forEach(function (b) { b.disabled = true; }); if (submitter) submitter.classList.add('disabled'); }, 0);
    setTimeout(function () { $$('button[type=submit]', form).forEach(function (b) { b.disabled = false; }); }, 8000);
  }

  // ---------------------------------------------------------------- clickable rows / auto-submit filters
  document.addEventListener('click', function (ev) {
    var row = ev.target.closest('tr[data-href]');
    if (row && !ev.target.closest('a, button, input, select, label, form')) window.location = row.getAttribute('data-href');
  });
  $$('[data-autosubmit]').forEach(function (el) {
    el.addEventListener('change', function () { el.form.submit(); });
  });

  // ---------------------------------------------------------------- searchable select
  // <select data-search> becomes a type-to-filter combobox while keeping the native select for submission.
  function enhanceSelect(sel) {
    if (sel.dataset.enhanced) return;
    sel.dataset.enhanced = '1';
    var wrap = document.createElement('div'); wrap.className = 'combo';
    var input = document.createElement('input'); input.type = 'text'; input.className = 'combo-input'; input.autocomplete = 'off';
    input.placeholder = sel.getAttribute('data-placeholder') || 'Type to search…';
    if (sel.required) input.required = false;
    var list = document.createElement('div'); list.className = 'combo-list';
    sel.parentNode.insertBefore(wrap, sel); wrap.appendChild(input); wrap.appendChild(list); wrap.appendChild(sel);
    sel.style.display = 'none';
    if (sel.classList.contains('is-invalid')) input.classList.add('is-invalid');
    var hl = -1;
    function current() { var o = sel.options[sel.selectedIndex]; return o && o.value !== '' ? o.text : ''; }
    input.value = current();
    function render(q) {
      q = (q || '').toLowerCase();
      var opts = Array.prototype.slice.call(sel.options).filter(function (o) { return !o.disabled && (o.value === '' ? !q : (o.text + ' ' + (o.dataset.sub || '')).toLowerCase().indexOf(q) !== -1); });
      hl = -1;
      if (!opts.length) { list.innerHTML = '<div class="combo-empty">No matches</div>'; return; }
      list.innerHTML = opts.slice(0, 200).map(function (o) {
        return '<div class="combo-opt' + (o.selected && o.value !== '' ? ' sel' : '') + '" data-v="' + esc(o.value) + '">' + esc(o.value === '' ? (o.text || '— None —') : o.text) + (o.dataset.sub ? '<small>' + esc(o.dataset.sub) + '</small>' : '') + '</div>';
      }).join('');
    }
    function choose(v) { sel.value = v; input.value = current(); wrap.classList.remove('open'); sel.dispatchEvent(new Event('change', { bubbles: true })); }
    input.addEventListener('focus', function () { input.select(); render(''); wrap.classList.add('open'); });
    input.addEventListener('input', function () { render(input.value); wrap.classList.add('open'); });
    input.addEventListener('keydown', function (e) {
      var items = $$('.combo-opt', list);
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); hl = Math.max(0, Math.min(items.length - 1, hl + (e.key === 'ArrowDown' ? 1 : -1))); items.forEach(function (i, k) { i.classList.toggle('hl', k === hl); }); if (items[hl]) items[hl].scrollIntoView({ block: 'nearest' }); }
      else if (e.key === 'Enter') { if (wrap.classList.contains('open')) { e.preventDefault(); var t = items[hl >= 0 ? hl : 0]; if (t) choose(t.dataset.v); } }
      else if (e.key === 'Escape') { wrap.classList.remove('open'); input.value = current(); }
    });
    list.addEventListener('mousedown', function (e) { var o = e.target.closest('.combo-opt'); if (o) { e.preventDefault(); choose(o.dataset.v); } });
    input.addEventListener('blur', function () { setTimeout(function () { wrap.classList.remove('open'); if (input.value.trim() === '' && !sel.required) { sel.value = ''; } input.value = current(); }, 120); });
  }
  window.RBC.enhanceSelect = enhanceSelect;
  $$('select[data-search]').forEach(enhanceSelect);

  // ---------------------------------------------------------------- image preview for file inputs
  $$('input[type=file][data-preview]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      var img = document.getElementById(inp.getAttribute('data-preview'));
      if (img && inp.files && inp.files[0] && inp.files[0].type.indexOf('image/') === 0) { img.src = URL.createObjectURL(inp.files[0]); img.classList.remove('hidden'); }
    });
  });

  // ---------------------------------------------------------------- list filtering (attendance marking, member pickers)
  $$('[data-filter-list]').forEach(function (inp) {
    var target = document.getElementById(inp.getAttribute('data-filter-list'));
    inp.addEventListener('input', function () {
      var q = inp.value.toLowerCase().trim();
      $$('[data-text]', target).forEach(function (row) { row.style.display = row.getAttribute('data-text').indexOf(q) !== -1 ? '' : 'none'; });
    });
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') e.preventDefault(); });
  });

  // Mark all visible rows with one status.
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-mark-all-status]');
    if (!b) return;
    var status = b.getAttribute('data-mark-all-status');
    $$('#' + b.getAttribute('data-target') + ' .mark-row').forEach(function (row) {
      if (row.style.display === 'none') return;
      var r = $('input[type=radio][value="' + status + '"]', row); if (r) r.checked = true;
    });
    updateMarkCounts();
  });
  function updateMarkCounts() {
    var box = $('[data-mark-counts]'); if (!box) return;
    var c = { present: 0, absent: 0, excused: 0 };
    $$('.mark-row input[type=radio]:checked').forEach(function (r) { if (c[r.value] !== undefined) c[r.value]++; });
    box.textContent = c.present + ' present · ' + c.absent + ' absent · ' + c.excused + ' excused';
  }
  document.addEventListener('change', function (ev) { if (ev.target.closest('.mark-row')) updateMarkCounts(); });
  updateMarkCounts();

  // ---------------------------------------------------------------- dynamic rows (songs, team members, signatories)
  function renumber(container) {
    $$('.dyn-row', container).forEach(function (row, i) {
      var n = $('.order-num', row); if (n) n.textContent = i + 1;
      $$('[data-name]', row).forEach(function (el) { el.name = el.getAttribute('data-name').replace('__i__', i); });
    });
  }
  document.addEventListener('click', function (ev) {
    var add = ev.target.closest('[data-add-row]');
    if (add) {
      var container = document.getElementById(add.getAttribute('data-add-row'));
      var tpl = document.getElementById(add.getAttribute('data-template'));
      var frag = tpl.content.cloneNode(true);
      container.appendChild(frag);
      var row = container.lastElementChild;
      $$('select[data-search]', row).forEach(enhanceSelect);
      renumber(container);
      var first = $('input:not([type=hidden]), select', row); if (first) first.focus();
      var empty = container.parentNode.querySelector('[data-rows-empty]'); if (empty) empty.classList.add('hidden');
      return;
    }
    var rm = ev.target.closest('[data-remove-row]');
    if (rm) { var r = rm.closest('.dyn-row'), c = r.parentNode; r.remove(); renumber(c); return; }
    var up = ev.target.closest('[data-move-up]'), down = ev.target.closest('[data-move-down]');
    if (up || down) {
      var row2 = (up || down).closest('.dyn-row'), cont = row2.parentNode;
      if (up && row2.previousElementSibling) cont.insertBefore(row2, row2.previousElementSibling);
      if (down && row2.nextElementSibling) cont.insertBefore(row2.nextElementSibling, row2);
      renumber(cont);
    }
  });
  $$('.rows-editor').forEach(renumber);

  // ---------------------------------------------------------------- copy-to-input helpers
  document.addEventListener('click', function (ev) {
    var c = ev.target.closest('[data-insert]');
    if (!c) return;
    var ed = $('[data-rte]');
    if (ed) { ed.focus(); document.execCommand('insertText', false, c.getAttribute('data-insert')); }
  });
})();

// ------------------------------------------------------------------ calendar day popup
(function () {
  var cal = document.querySelector('[data-calendar]');
  var modal = document.getElementById('day-modal');
  if (!cal || !modal) return;
  var base = (document.querySelector('meta[name="base-url"]') || {}).content || '';
  function esc(s) { return window.RBC ? RBC.esc(s) : String(s); }
  var SVG = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
  var ICON_CLOCK = SVG + '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>';
  var ICON_PIN = SVG + '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg>';
  function open(date) {
    var body = document.getElementById('day-modal-body');
    document.getElementById('day-modal-title').textContent = date;
    body.innerHTML = '<div class="empty small">Loading…</div>';
    modal.showModal();
    var q = '?date=' + encodeURIComponent(date) + (cal.dataset.category ? '&category=' + encodeURIComponent(cal.dataset.category) : '');
    fetch(base + '/calendar/day' + q, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        document.getElementById('day-modal-title').textContent = d.label;
        var add = document.getElementById('day-modal-add');
        add.classList.toggle('hidden', !d.canAdd);
        add.href = base + '/events/new?type=schedule&date=' + d.date;
        if (!d.items.length) { body.innerHTML = '<div class="empty"><strong>None</strong>No events scheduled for this date.</div>'; return; }
        body.innerHTML = d.items.map(function (i) {
          return '<a class="day-item c-' + esc(i.color) + '" href="' + esc(i.url) + '">' +
            '<div class="day-item-top"><strong' + (i.cancelled ? ' class="strike"' : '') + '>' + esc(i.title) + '</strong>' +
            (i.cancelled ? '<span class="badge badge-red">Cancelled</span>' : '') + '<span class="tag"><span class="cat-dot c-' + esc(i.color) + '"></span>' + esc(i.category) + '</span></div>' +
            '<div class="day-item-meta"><span>' + ICON_CLOCK + '<span>' + esc(i.time) + (i.recurring ? ' · weekly' : '') + '</span></span>' + (i.location ? '<span>' + ICON_PIN + '<span>' + esc(i.location) + '</span></span>' : '') + '</div>' +
            (i.description ? '<p>' + esc(i.description) + '</p>' : '') + '</a>';
        }).join('');
      })
      .catch(function () { body.innerHTML = '<div class="empty small">Could not load this day. Please try again.</div>'; });
  }
  cal.addEventListener('click', function (ev) { var d = ev.target.closest('[data-day]'); if (d) open(d.getAttribute('data-day')); });
  cal.addEventListener('keydown', function (ev) { if ((ev.key === 'Enter' || ev.key === ' ') && ev.target.matches('[data-day]')) { ev.preventDefault(); open(ev.target.getAttribute('data-day')); } });
})();

// ------------------------------------------------------------------ event form: recurrence fields + overlap warning
(function () {
  var form = document.querySelector('[data-event-form]');
  if (!form) return;
  var base = (document.querySelector('meta[name="base-url"]') || {}).content || '';
  var rec = form.querySelector('[name=recurrence]');
  function toggle() { form.querySelectorAll('[data-show-when]').forEach(function (el) { el.classList.toggle('hidden', el.getAttribute('data-show-when') !== rec.value); }); }
  rec.addEventListener('change', toggle); toggle();
  var box = form.querySelector('[data-overlap-box]'), txt = form.querySelector('[data-overlap-text]'), timer;
  function check() {
    var d = form.querySelector('[name=start_date]').value, s = form.querySelector('[name=start_time]').value, e = form.querySelector('[name=end_time]').value;
    if (!d || !s) { box.classList.add('hidden'); return; }
    fetch(base + '/events/check?start_date=' + d + '&start_time=' + s + '&end_time=' + e + '&id=' + form.dataset.eventId, { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (r) {
        if (!r.conflicts || !r.conflicts.length) { box.classList.add('hidden'); return; }
        txt.innerHTML = '<strong>Heads up:</strong> overlaps with ' + r.conflicts.map(function (c) { return RBC.esc(c.title) + ' (' + RBC.esc(c.time) + ')'; }).join(', ') + '.';
        box.classList.remove('hidden');
      }).catch(function () {});
  }
  ['start_date', 'start_time', 'end_time'].forEach(function (n) { form.querySelector('[name=' + n + ']').addEventListener('change', function () { clearTimeout(timer); timer = setTimeout(check, 250); }); });
})();

// ------------------------------------------------------------------ simple rich-text editor (documents & templates)
(function () {
  var ed = document.querySelector('[data-rte]');
  if (!ed) return;
  try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) {}
  document.querySelectorAll('.rte-toolbar [data-cmd]').forEach(function (b) {
    b.addEventListener('mousedown', function (e) { e.preventDefault(); });
    b.addEventListener('click', function () { ed.focus(); document.execCommand(b.getAttribute('data-cmd'), false, null); });
  });
  // Paste as plain text to keep formatting clean.
  ed.addEventListener('paste', function (e) {
    e.preventDefault();
    var t = (e.clipboardData || window.clipboardData).getData('text/plain');
    document.execCommand('insertText', false, t);
  });
  var form = ed.closest('form');
  form.addEventListener('submit', function () { form.querySelector('[data-rte-input]').value = ed.innerHTML; });
})();

// ------------------------------------------------------------------ transaction form: show fields for income / expense
(function () {
  var f = document.querySelector('[data-txn-form]');
  if (!f) return;
  function sync() {
    var t = (f.querySelector('[name=txn_type]:checked') || {}).value || 'income';
    f.querySelectorAll('[data-when]').forEach(function (el) { el.classList.toggle('hidden', el.getAttribute('data-when') !== t); });
    f.querySelectorAll('#category_id optgroup').forEach(function (g) { var on = g.getAttribute('data-kind') === t; g.hidden = !on; g.disabled = !on; });
    var sel = f.querySelector('#category_id'), opt = sel.options[sel.selectedIndex];
    if (opt && opt.parentNode.tagName === 'OPTGROUP' && opt.parentNode.disabled) sel.value = '';
  }
  f.addEventListener('change', function (e) { if (e.target.name === 'txn_type') sync(); });
  sync();
})();

// ------------------------------------------------------------------ report period inputs
(function () {
  var sel = document.querySelector('[data-period]');
  if (!sel) return;
  function sync() { document.querySelectorAll('[data-for]').forEach(function (el) { var on = el.getAttribute('data-for') === sel.value; el.classList.toggle('hidden', !on); el.disabled = !on; }); }
  sel.addEventListener('change', sync); sync();
})();

// ------------------------------------------------------------------ user form: show the role's default for each permission
(function () {
  var f = document.querySelector('[data-user-form]');
  if (!f) return;
  var map = JSON.parse(f.getAttribute('data-role-perms') || '{}');
  var sel = f.querySelector('#role_id');
  function sync() {
    var opt = sel.options[sel.selectedIndex], sa = opt && opt.getAttribute('data-code') === 'super_admin';
    var perms = map[sel.value] || [];
    f.querySelector('[data-sa-note]').classList.toggle('hidden', !sa);
    f.querySelectorAll('.perm-group').forEach(function (g) { g.classList.toggle('hidden', sa); });
    f.querySelectorAll('[data-perm]').forEach(function (row) {
      var on = perms.indexOf(row.getAttribute('data-perm')) !== -1;
      row.querySelector('[data-role-state]').textContent = on ? 'allowed' : 'not allowed';
      row.classList.toggle('is-on', on);
    });
  }
  sel.addEventListener('change', sync); sync();
})();


// ------------------------------------------------------------------ password fields: show / hide eye
// Every <input type="password"> in the system gets the same eye button, including fields added later.
(function () {
  var SVG = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
  var EYE = SVG + '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';
  var EYE_OFF = SVG + '<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.53 13.53 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><path d="M2 2l20 20"/></svg>';

  function enhance(input) {
    if (input.dataset.pwEnhanced || input.hasAttribute('data-no-toggle')) return;
    input.dataset.pwEnhanced = '1';
    var wrap = document.createElement('span');
    wrap.className = 'pw-field';
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pw-toggle';
    btn.setAttribute('aria-label', 'Show password');
    btn.setAttribute('aria-pressed', 'false');
    btn.title = 'Show or hide password';
    btn.innerHTML = '<span class="pw-on">' + EYE + '</span><span class="pw-off">' + EYE_OFF + '</span>';
    wrap.appendChild(btn);
    btn.addEventListener('click', function () {
      var show = input.type === 'password';
      var pos = null;
      try { pos = [input.selectionStart, input.selectionEnd]; } catch (e) {}
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-pressed', show ? 'true' : 'false');
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      input.focus();
      try { if (pos && pos[0] !== null) input.setSelectionRange(pos[0], pos[1]); } catch (e) {}
    });
    // Never leave a password visible when the page is restored from history or the form is submitted.
    if (input.form) input.form.addEventListener('submit', function () { if (input.type !== 'password') { input.type = 'password'; btn.setAttribute('aria-pressed', 'false'); } });
  }
  function scan(root) { Array.prototype.forEach.call((root || document).querySelectorAll('input[type=password]'), enhance); }
  scan(document);
  if (window.MutationObserver) {
    new MutationObserver(function (muts) {
      muts.forEach(function (m) { Array.prototype.forEach.call(m.addedNodes, function (n) { if (n.nodeType === 1) { if (n.matches && n.matches('input[type=password]')) enhance(n); else scan(n); } }); });
    }).observe(document.body, { childList: true, subtree: true });
  }
})();

// ------------------------------------------------------------------ validation messages
// Browser validation bubbles are replaced by the same inline message style the server uses (.field-error).
(function () {
  function holder(el) { return el.closest('.field') || el.parentNode; }
  function clear(el) {
    el.classList.remove('is-invalid');
    var h = holder(el), m = h && h.querySelector('[data-js-error]');
    if (m) m.remove();
  }
  document.addEventListener('invalid', function (ev) {
    var el = ev.target;
    if (!el.form || el.form.hasAttribute('data-native-validation')) return;
    ev.preventDefault();
    var h = holder(el);
    if (!h || el.type === 'hidden') return;
    var msg = h.querySelector('[data-js-error]');
    if (!msg) {
      msg = document.createElement('p');
      msg.className = 'field-error';
      msg.setAttribute('data-js-error', '');
      msg.setAttribute('role', 'alert');
      var anchor = el.closest('.pw-field, .combo') || el;
      anchor.insertAdjacentElement('afterend', msg);
    }
    msg.textContent = el.validationMessage || 'Please check this field.';
    el.classList.add('is-invalid');
    var first = el.form.querySelector(':invalid');
    if (first === el) { el.focus(); if (el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  }, true);
  ['input', 'change'].forEach(function (t) {
    document.addEventListener(t, function (ev) { if (ev.target.classList && ev.target.classList.contains('is-invalid') && ev.target.checkValidity()) clear(ev.target); });
  });
})();

// ------------------------------------------------------------------ image field (profile pictures, posters, logo)
// Markup comes from app/Views/partials/image_field.php. The visible control wraps a normal <input type="file">,
// so the form submits exactly as before. Cropping / resizing / rotating can plug in later through
//   RBC.ImageField.editor = function (file, field) { return Promise.resolve(editedFileOrNull); };
// The editor receives the chosen file and returns the file to keep (or null to cancel). Nothing else has to change.
(function () {
  var $ = function (s, r) { return (r || document).querySelector(s); };
  function size(bytes) { return bytes >= 1048576 ? (bytes / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(bytes / 1024)) + ' KB'; }

  function init(field) {
    if (field.dataset.ready) return;
    field.dataset.ready = '1';
    var input = $('[data-if-input]', field), img = $('[data-if-img]', field), empty = $('[data-if-empty]', field);
    var pick = $('[data-if-pick]', field), clearBtn = $('[data-if-clear]', field), removeBtn = $('[data-if-remove]', field);
    var removeInput = $('[data-if-remove-input]', field), note = $('[data-if-note]', field), err = $('[data-if-error]', field);
    var original = img ? (img.getAttribute('data-original') || '') : '';
    var defaultNote = note ? note.innerHTML : '';
    var maxBytes = (parseFloat(field.getAttribute('data-max-mb')) || 10) * 1048576;
    var types = (input.getAttribute('accept') || '').split(',').map(function (t) { return t.trim(); }).filter(Boolean);
    var objectUrl = null, removed = false;
    var pickIconEl = pick ? pick.querySelector('svg') : null, pickIcon = pickIconEl ? pickIconEl.outerHTML : '';
    function esc(t) { return String(t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

    var fallback = img ? (img.getAttribute('data-fallback') || '') : '';
    function show(src) {
      var shown = src || fallback;
      if (img) { if (shown) img.src = shown; img.classList.toggle('hidden', !shown); }
      if (empty) empty.classList.toggle('hidden', !!shown);
      field.classList.toggle('has-image', !!src);
    }
    function revoke() { if (objectUrl) { URL.revokeObjectURL(objectUrl); objectUrl = null; } }
    function setError(msg) { if (!err) return; err.textContent = msg || ''; err.classList.toggle('hidden', !msg); }
    function sync() {
      var chosen = input.files && input.files.length > 0;
      if (clearBtn) clearBtn.classList.toggle('hidden', !chosen);
      if (removeBtn) {
        removeBtn.classList.toggle('hidden', chosen || (!original && !removed));
        removeBtn.textContent = removed ? 'Undo remove' : 'Remove';
      }
      if (pick) pick.innerHTML = pickIcon + ' ' + esc((chosen || (original && !removed)) ? (field.getAttribute('data-change-label') || 'Change image') : (field.getAttribute('data-pick-label') || 'Upload image'));
    }
    function reset() {
      revoke(); input.value = ''; setError('');
      removed = false; if (removeInput) removeInput.checked = false;
      show(original); if (note) note.innerHTML = defaultNote; sync();
    }
    function accept(file) {
      if (!file) return;
      if (types.length && types.indexOf(file.type) === -1) { input.value = ''; setError('Choose a JPG, PNG or WebP image.'); return; }
      if (file.size > maxBytes) { input.value = ''; setError('That image is ' + size(file.size) + '. The limit is ' + (maxBytes / 1048576) + ' MB.'); return; }
      setError('');
      var editor = window.RBC && RBC.ImageField && RBC.ImageField.editor;
      if (typeof editor === 'function') {
        Promise.resolve(editor(file, field)).then(function (out) { if (out) apply(out); else reset(); }).catch(function () { apply(file); });
      } else { apply(file); }
    }
    function apply(file) {
      if (file !== (input.files && input.files[0])) {
        try { var dt = new DataTransfer(); dt.items.add(file); input.files = dt.files; } catch (e) {}
      }
      revoke(); objectUrl = URL.createObjectURL(file);
      removed = false; if (removeInput) removeInput.checked = false;
      show(objectUrl);
      if (note) note.innerHTML = '<strong></strong> · ' + size(file.size);
      if (note) note.firstChild.textContent = file.name;
      sync();
      field.dispatchEvent(new CustomEvent('imagefield:change', { bubbles: true, detail: { file: file, input: input, field: field } }));
    }

    if (pick) pick.addEventListener('click', function () { input.click(); });
    input.addEventListener('change', function () { if (input.files && input.files[0]) accept(input.files[0]); else reset(); });
    if (clearBtn) clearBtn.addEventListener('click', reset);
    if (removeBtn) removeBtn.addEventListener('click', function () {
      removed = !removed;
      if (removeInput) removeInput.checked = removed;
      show(removed ? '' : original);
      if (note) note.innerHTML = removed ? 'The current image will be removed when you save.' : defaultNote;
      sync();
    });

    ['dragenter', 'dragover'].forEach(function (t) { field.addEventListener(t, function (e) { if (e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') !== -1) { e.preventDefault(); field.classList.add('dragover'); } }); });
    ['dragleave', 'dragend'].forEach(function (t) { field.addEventListener(t, function (e) { if (!field.contains(e.relatedTarget)) field.classList.remove('dragover'); }); });
    field.addEventListener('drop', function (e) {
      field.classList.remove('dragover');
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) { e.preventDefault(); accept(e.dataTransfer.files[0]); }
    });
    if (input.form) input.form.addEventListener('reset', function () { setTimeout(reset, 0); });
    sync();
  }

  window.RBC = window.RBC || {};
  RBC.ImageField = { init: init, editor: null };
  Array.prototype.forEach.call(document.querySelectorAll('[data-image-field]'), init);
})();
