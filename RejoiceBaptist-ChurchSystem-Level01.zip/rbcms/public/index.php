<?php
declare(strict_types=1);

/*
 * Front controller. Every request goes through here.
 * When using PHP's built-in server, existing static files under /assets are served directly.
 */
if (PHP_SAPI === 'cli-server') {
    $file = __DIR__ . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if (is_file($file) && str_starts_with(realpath($file), __DIR__ . DIRECTORY_SEPARATOR . 'assets')) {
        return false;
    }
}

require dirname(__DIR__) . '/app/bootstrap.php';

$router = new App\Core\Router();
require APP_PATH . '/routes.php';
$router->dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $_SERVER['REQUEST_URI'] ?? '/');
