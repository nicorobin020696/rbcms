# Technology and security design

## Stack

| Part | Choice | Why |
|---|---|---|
| Server language | **PHP 8.1+** with no framework | Runs on any Windows PC or XAMPP with no build step. A small codebase that a future IT volunteer can read. |
| Database | **SQLite 3** (PDO) | One file and no database server to manage, so backups are simple. More than enough for a church's data volume. |
| Web server | PHP built-in server (`start-server.bat`) or Apache | Simple LAN deployment |
| Front end | Plain HTML, CSS and JavaScript; no external libraries or CDNs | Works fully offline on the local network |
| Charts | Small in-house SVG chart script (`public/assets/js/app.js`) | No internet needed |
| PDF | In-house PDF writer (`app/Core/Pdf.php`, `PdfReport.php`) | Letters, certificates and reports without extra installs |

## Code layout

```
public/index.php          front controller: every request enters here
app/bootstrap.php         config, sessions, security headers, auto-migration
app/routes.php            every URL, with the permission it requires
app/Core/                 Router, Auth, Permissions, Database, Csrf, Upload, Audit, Notify, Pdf, Csv…
app/Controllers/          one controller per module
app/Services/             Backup, Calendar, Stats, DocumentRenderer, RichText, SampleData
app/Views/                HTML templates (escaped output by default via e())
database/migrations/      SQL schema
storage/                  data: database, uploads, backups, sessions, logs (blocked from the web)
```

## Security measures

- **Passwords:**
  - Argon2id hashing (bcrypt if Argon2 is unavailable), with automatic rehashing
  - minimum 10 characters, letters and numbers, must not contain the username
  - plain-text passwords are never stored or logged
- **Sign-in protection:**
  - a per-account lockout after N failures (configurable), plus a per-IP limit
  - the error messages do not reveal whether a username exists
  - the session ID is regenerated at sign-in
- **Sessions:**
  - HttpOnly and SameSite=Lax cookies, strict mode, and an idle timeout
  - `session_version` signs out all of a user's sessions after a password reset, deactivation or restore
- **Access control on the server:**
  - every route declares the permission it needs, and the Router checks it before the controller runs
  - controllers check again for record-level rules: confidential documents, ministry leaders limited to their own ministries, Super Admin-only actions
  - hiding menu items is only cosmetic, never the protection
- **Finance confidentiality:**
  - finance data is loaded only for users with `finance.view`: dashboard widgets, notifications, receipt files and exports all check it
  - direct URLs return 403 and are logged as `denied`
  - financial PDFs are marked CONFIDENTIAL
- **CSRF:** a per-session token is required on every POST, including logout.
- **SQL injection:** every query uses PDO prepared statements; sorting and filter values are checked against allowlists.
- **XSS:**
  - all output is escaped with `e()`
  - rich text in documents and templates goes through an allowlist sanitiser (`RichText::sanitize`)
  - the Content-Security-Policy is `script-src 'self'`, with no inline scripts
- **Uploads:**
  - the real file type is checked (finfo) and images are re-encoded
  - files get random names, are stored outside `public/`, and are served through a controller that checks permissions
  - size limits apply
- **Headers:** X-Frame-Options, X-Content-Type-Options and Referrer-Policy.
- **Errors:** users see friendly messages; details go to `storage/logs/php-error.log`. Debug mode is off by default.
- **Audit:** sign-ins, failures, every create, edit, archive, void, export, backup and restore, and denied access are all recorded.
- **No secrets in the browser:** there are no database credentials at all (SQLite), and no API keys.
- **Backups:**
  - the integrity of each backup is checked before restore (checksum, allowlisted files, required tables, `PRAGMA integrity_check`, an active Super Admin)
  - a safety backup is always made first
