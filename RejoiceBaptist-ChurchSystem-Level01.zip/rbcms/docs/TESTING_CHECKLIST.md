# Testing checklist

Use this before going live, after updates, and after restoring a backup.

## Automated test

With the server running, from the `rbcms` folder:

```
python3 tests/http_test.py http://localhost:8080 <superadmin-username> '<password>'
```

The test covers:

- sign-in and CSRF protection
- members, ministries, attendance, morning prayer, events and the calendar pop-up
- announcements (XSS escaping), music lineups and documents (HTML sanitising)
- finance (exact amounts, voiding) and upload validation
- users, and role access for every role
- per-user permission overrides, account lockout, the audit log, and backup validation

It creates records named `ZZTEST…`. **Run it on a practice copy, not the live database.**

## Manual checklist

### Sign-in and security

- [ ] First visit shows the setup page; after creating the Super Admin, `/setup` returns "not found"
- [ ] Wrong password 5 times locks the account; the message does not reveal whether the username exists
- [ ] Idle longer than the timeout signs you out
- [ ] A deactivated user is signed out at their next click
- [ ] A new user is forced to change their password at first sign-in
- [ ] Light, dark and system themes work, and the choice is remembered

### Roles (sign in as each one)

- [ ] **Secretary**: no Finance menu; `/finance` shows Access denied; can open confidential documents
- [ ] **Treasurer**: sees Finance; cannot open `/members`
- [ ] **Music encoder**: can add lineups; cannot add members
- [ ] **Attendance encoder**: can record attendance and morning prayer; cannot add lineups
- [ ] **Viewer**: read-only; no Add/Edit buttons
- [ ] For each non-finance role:
  - [ ] the dashboard shows no fund balance or finance chart
  - [ ] the notifications include no finance items
  - [ ] receipt image links return Access denied
  - [ ] finance CSV/PDF addresses show Access denied
- [ ] Each denied attempt appears in **Audit log** (action: denied)

### Members and attendance

- [ ] A new member gets the next ID automatically, in the configured format
- [ ] A duplicate name and birth date shows a warning
- [ ] The Active / Inactive / Active-unbaptized / Baptized tabs show the correct counts
- [ ] CSV and PDF exports match the filtered list
- [ ] Archive, then restore, a member
- [ ] Record attendance; the totals on the dashboard and attendance charts update
- [ ] Morning prayer: ticked members are present, unticked members are absent

### Calendar and events

- [ ] Click a day with events: the pop-up lists them with times
- [ ] Click an empty day: the pop-up says nothing is scheduled
- [ ] Weekly ministries repeat on the correct weekday
- [ ] An overlapping event asks for confirmation
- [ ] A cancelled event shows as cancelled; completed events appear in Church Information → Past events

### Music team

- [ ] Create a lineup with songs, artists, song leader, instrumentalists, backups and a photo
- [ ] A second lineup for the same date and service is refused
- [ ] Copy from a previous lineup works
- [ ] The most lined-up songs appear on the dashboard and the Statistics page

### Documents

- [ ] Each document type opens its template; placeholders fill in
- [ ] The logo, letterhead and signatures print correctly (Print and PDF)
- [ ] A final document cannot be edited; Duplicate works
- [ ] A confidential document is hidden from users without permission, in the list, search and by direct address

### Finance

- [ ] Income and expense amounts with centavos are saved exactly
- [ ] A voided entry is excluded from totals and shows its reason
- [ ] Going over a budget notifies finance users
- [ ] Each report type produces a PDF and CSV for month, quarter, year and custom periods

### Backup and restore

- [ ] *Back up now* creates a zip; Download works
- [ ] Restoring a random zip is rejected and nothing changes
- [ ] Restoring a valid backup (after typing RESTORE) brings back data and photos, and a before-restore safety backup exists
- [ ] Restoring on a second computer works (practise this once)

### Other devices

- [ ] Open from another computer and a phone on the same Wi-Fi
- [ ] The layout works on a phone (menu button, tables scroll sideways)
