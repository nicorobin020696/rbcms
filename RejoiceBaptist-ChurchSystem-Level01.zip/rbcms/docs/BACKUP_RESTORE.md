# Backup and restore guide

All church data is in the `storage/` folder:

- `database.sqlite`: every record
- `uploads/`: photos, posters, receipts and signatures

A backup is one `.zip` file containing both, plus a `manifest.json` with a checksum.

## Automatic backups

- The first time someone opens the dashboard each day, the system makes an **automatic daily backup**.
- The newest 30 backups are kept (change this in Settings → General). Older ones are removed automatically.
- If no backup has been made for several days, the Super Admin gets a notification.

## Manual backup

- In the system: **Settings → Backup & restore → Back up now**.
- Or double-click `backup-now.bat`, or run `php bin/console.php backup`.
- Backups are saved in `storage/backups/`. Use **Download** to save a copy elsewhere.

## Keep copies outside the server computer

A backup on the same disk does not survive a broken disk, theft or fire. At least once a week:

1. Download the latest backup, or copy the newest file from `storage/backups/`.
2. Save it to a **USB drive** kept by a church officer, and, if possible, a second computer.
3. Backups contain confidential financial and member data. Keep the USB drive secure.

**Windows Task Scheduler** can run `backup-now.bat` every night:

1. Open Task Scheduler and choose Create Basic Task.
2. Set the trigger to Daily.
3. Set the action to Start a program and choose `backup-now.bat`.

## Restoring

Restoring **replaces all current data and uploaded files** with the backup's contents.

1. Go to **Settings → Backup & restore → Restore**.
2. Choose a saved backup, or upload a `.zip` backup file.
3. Type `RESTORE` to confirm and click **Restore backup**.

What the system does:

- **Checks the file first**:
  - it must be a backup made by this system
  - the checksum must match
  - no unexpected files are allowed
  - all required tables must be present
  - the database must pass an integrity check
  - it must contain an active Super Admin account

  An invalid file is rejected and **nothing is changed**.
- **Makes a safety backup** of the current data, named `...-before-restore.zip`, so a restore can be undone.
- Replaces the database and uploads, then signs everyone out.
- Records the restore in the **Backup history** and the audit log.

Command-line alternative: `php bin/console.php restore storage/backups/<file>.zip`

## Moving to a new computer

1. On the old computer, make a backup and copy the `.zip` to a USB drive.
2. Install the system on the new computer ([INSTALLATION.md](INSTALLATION.md)) and create a temporary Super Admin on the setup page.
3. Restore the backup. Sign in with the **old** accounts; the temporary one is replaced.

Alternative: stop the server and copy the whole `storage/` folder to the new installation.

## Forgotten Super Admin password

On the server computer, open Command Prompt in the `rbcms` folder and run:

```
php bin/console.php users
php bin/console.php reset-admin <username>
```

Enter the new password twice. The account is unlocked and reactivated. Only someone with access to the server computer can do this.
