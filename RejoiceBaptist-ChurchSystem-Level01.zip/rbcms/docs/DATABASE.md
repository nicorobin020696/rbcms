# Database schema

- **Engine:** SQLite 3, stored in a single file: `storage/database.sqlite`.
- **Journal mode and integrity:** WAL journal mode, with foreign keys enforced.
- **Structure:** defined in `database/migrations/001_initial.sql`. New `.sql` files in that folder are applied automatically, in order; applied versions are tracked in `schema_migrations`.
- **Default data:** roles, categories, templates and settings are inserted on a new database by `database/seed_defaults.php`.

## Conventions

- Dates are text, `YYYY-MM-DD`; timestamps are `YYYY-MM-DD HH:MM:SS` in local time (Asia/Manila by default).
- **Money is stored as whole centavos** (`amount_cents INTEGER`), so ₱1,234.50 is stored as `123450`. This avoids rounding errors.
- **Soft delete:** important records have `archived_at` / `archived_by` instead of being deleted. Finance entries use `voided_at` / `void_reason`; events use `cancelled_at`.
- **Sample data:** rows created by *Load sample data* have `is_sample = 1`, so they can be removed safely without touching real records.

## Tables

### System

| Table | Purpose |
|---|---|
| `settings` | Key/value settings: church details, ID formats, security limits, backup retention |
| `id_sequences` | Counters for auto-generated IDs (member, document, lineup, transaction) per year |
| `categories` | Configurable lists, by `type`: event, attendance, finance_income, finance_expense, instrument, ministry… |
| `roles` / `role_permissions` | Roles and the permission keys each has |
| `users` | Accounts. `password_hash` is Argon2id; plus failed attempts, lock time, `session_version`, theme and `must_change_password` |
| `user_permissions` | Per-user overrides: `allowed = 1` grants, `0` revokes |
| `login_attempts` | Recent sign-in attempts per username and IP, for lockout (kept 30 days) |
| `audit_logs` | Every important action: who, what, module, record, details, IP, time. Insert-only. |
| `notifications` | Per-user notifications, with a dedupe key so reminders are not repeated |

### Church and members

| Table | Purpose |
|---|---|
| `members` | Member records: `member_code` (auto ID), names, contact, `membership_status` (active/inactive), `baptism_status` and details, date joined, photo, `archived_at` |
| `member_history` | Field-by-field change history for each member |
| `ministries` | Ministries, with leader, weekly schedule (`schedule_day` 0 = Sunday, start/end time), location, status |
| `ministry_members` | Which members belong to which ministry (with role, for example leader) |
| `events` | Activities and weekly schedules: dates, times, `recurrence` (none/weekly), category, ministry, poster, cancellation |
| `announcements` | Title, body, image, draft/published, pinned |

### Attendance

| Table | Purpose |
|---|---|
| `attendance_sessions` | One service or meeting on a date (category, for example Sunday Worship or Morning Prayer; optional ministry or event). Unique per category, date and title. |
| `attendance_records` | One row per member per session: present / absent / late / excused, and remarks |

### Music team

| Table | Purpose |
|---|---|
| `artists` | Song artists or bands |
| `songs` | Song library: title, artist, default key |
| `worship_lineups` | One lineup per service date and type: code, song leader, title, photo, notes |
| `lineup_songs` | Songs in a lineup, in order, with part (praise, worship…), YouTube link and notes |
| `lineup_members` | Team members: instrumentalist (with instrument), backup singer and others |

### Documents

| Table | Purpose |
|---|---|
| `document_templates` | Editable templates per document type (HTML with `{{placeholders}}`) |
| `signatories` | People who sign documents: name, title, signature image |
| `documents` | Generated letters and certificates: code, type, recipient or member, body, draft/final, confidential flag |
| `document_signatories` | Which signatories appear on each document, in order |

### Finance (confidential)

| Table | Purpose |
|---|---|
| `fin_transactions` | Income and expense entries: code, type, `amount_cents`, date, category, ministry, event, donor member, method, reference, receipt, void info |
| `budgets` | Budget per ministry, event or category for a period, with `amount_cents`. Actual spending is computed from `fin_transactions`. |

## Relationships (main ones)

```
roles 1─* users *─* (user_permissions)
members 1─* attendance_records *─1 attendance_sessions *─1 categories
members *─* ministries            (ministry_members)
ministries 1─* events             events *─1 categories
worship_lineups 1─* lineup_songs *─1 songs *─1 artists
worship_lineups 1─* lineup_members *─1 members
documents *─* signatories         (document_signatories)    documents *─1 members
fin_transactions *─1 categories / ministries / events / members(donor)
budgets *─1 ministries / events / categories
users 1─* audit_logs, notifications
```
