<?php
declare(strict_types=1);

/*
 * Default configuration for a brand-new database: roles, categories, settings and document templates.
 * Runs once, automatically, right after the initial migration. Contains no personal data.
 */

use App\Core\Database as DB;
use App\Core\Permissions;

$settings = [
    'church.name'               => 'Rejoice Baptist Church',
    'church.short_name'         => 'RBC',
    'church.founded'            => '1982',
    'church.address'            => '',
    'church.phone'              => '',
    'church.email'              => '',
    'church.facebook'           => '',
    'church.service_times'      => '',
    'church.history'            => '',
    'church.beliefs'            => '',
    'church.mission'            => '',
    'church.vision'             => '',
    'church.background'         => '',
    'church.leadership'         => '',
    'ids.member_prefix'         => 'RBC',
    'ids.member_year'           => '1',
    'ids.member_digits'         => '4',
    'ids.separator'             => '-',
    'security.session_timeout'  => '30',
    'security.max_attempts'     => '5',
    'security.lockout_minutes'  => '15',
    'backup.auto_daily'         => '1',
    'backup.keep'               => '30',
    'app.default_theme'         => 'system',
];
foreach ($settings as $k => $v) {
    DB::query('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', [$k, $v]);
}

foreach (Permissions::defaultRoles() as $code => [$name, $desc, $perms]) {
    $rid = DB::insert('roles', ['code' => $code, 'name' => $name, 'description' => $desc, 'is_system' => 1]);
    if ($perms !== ['*']) {
        foreach ($perms as $p) {
            DB::insert('role_permissions', ['role_id' => $rid, 'permission' => $p]);
        }
    }
}

$categories = [
    'event' => [
        ['worship', 'Worship Service', 'blue'], ['youth', 'Youth Activity', 'violet'], ['sunday_school', 'Sunday School', 'teal'],
        ['vbs', 'Vacation Bible School', 'amber'], ['fellowship', 'Fellowship', 'green'], ['anniversary', 'Church Anniversary', 'rose'],
        ['special', 'Special Service', 'indigo'], ['prayer', 'Prayer Meeting', 'cyan'], ['meeting', 'Meeting', 'slate'],
        ['outreach', 'Outreach', 'orange'], ['other', 'Other Activity', 'slate'],
    ],
    'attendance' => [
        ['sunday_service', 'Sunday Worship Service', 'blue'], ['morning_prayer', 'Morning Prayer', 'cyan'],
        ['sunday_school', 'Sunday School', 'teal'], ['youth', 'Youth Activities', 'violet'], ['special', 'Special Services', 'indigo'],
        ['ministry_meeting', 'Ministry Meetings', 'green'], ['other', 'Other Church Activities', 'slate'],
    ],
    'ministry' => [
        ['worship', 'Worship & Music', 'blue'], ['education', 'Christian Education', 'teal'], ['youth', 'Youth & Children', 'violet'],
        ['outreach', 'Outreach & Missions', 'orange'], ['fellowship', 'Fellowship', 'green'], ['service', 'Church Service', 'slate'],
    ],
    'income' => [
        ['tithe', 'Tithes', 'green', 'giving'], ['offering', 'Offerings', 'green', 'giving'], ['donation', 'Donations', 'teal', 'giving'],
        ['love_gift', 'Love Gifts / Pledges', 'teal', 'giving'], ['ministry_fund', 'Ministry Funds', 'blue', null],
        ['event_income', 'Event Income', 'indigo', null], ['other_income', 'Other Income', 'slate', null],
    ],
    'expense' => [
        ['utilities', 'Utilities', 'amber'], ['ministry_exp', 'Ministry Expenses', 'blue'], ['event_exp', 'Event Expenses', 'indigo'],
        ['maintenance', 'Building & Maintenance', 'orange'], ['supplies', 'Supplies', 'slate'], ['benevolence', 'Benevolence', 'rose'],
        ['honorarium', 'Honorarium / Allowances', 'violet'], ['missions', 'Missions Support', 'teal'], ['other_exp', 'Other Expenses', 'slate'],
    ],
    'instrument' => [
        ['lead_guitar', 'Lead Guitar', 'slate'], ['rhythm_guitar', 'Rhythm Guitar', 'slate'], ['acoustic_guitar', 'Acoustic Guitar', 'slate'],
        ['bass', 'Bass Guitar', 'slate'], ['keyboard', 'Keyboard', 'slate'], ['drums', 'Drums', 'slate'],
        ['percussion', 'Percussion', 'slate'], ['other_instr', 'Other Instrument', 'slate'],
    ],
];
foreach ($categories as $type => $rows) {
    foreach ($rows as $i => $row) {
        DB::insert('categories', [
            'type' => $type, 'code' => $row[0], 'name' => $row[1], 'color' => $row[2],
            'grp' => $row[3] ?? null, 'sort_order' => $i + 1,
            'is_system' => in_array($row[0], ['sunday_service', 'morning_prayer'], true) ? 1 : 0,
        ]);
    }
}

$p = static fn(string ...$paras) => implode('', array_map(static fn($t) => "<p>$t</p>", $paras));
$templates = [
    ['Recommendation Letter', 'recommendation', 'Letter of Recommendation', $p(
        'To Whom It May Concern:',
        'This is to recommend <b>{{recipient_name}}</b>, a member of {{church_name}} since {{member_since}}. During this time, {{first_name}} has shown faithfulness in attending church services and in serving the Lord through the ministries of the church.',
        'We recommend {{first_name}} for {{purpose}}. We believe {{first_name}} will carry out every responsibility with diligence and integrity.',
        'This recommendation is issued upon request for whatever legal purpose it may serve.'
    ), 'In His service,', 0, 0],
    ['Request Letter', 'request', 'Letter of Request', $p(
        'Dear {{recipient_name}},',
        'Greetings in the name of our Lord Jesus Christ!',
        'On behalf of {{church_name}}, we respectfully request {{purpose}}.',
        'Your favorable response to this request will be greatly appreciated. Should you need further information, please do not hesitate to contact the church office.',
        'Thank you and God bless.'
    ), 'Respectfully yours,', 0, 0],
    ['Solicitation Letter', 'solicitation', 'Letter of Solicitation', $p(
        'Dear {{recipient_name}},',
        'Grace and peace to you in the name of our Lord Jesus Christ!',
        '{{church_name}} will be holding {{purpose}}. In line with this, we humbly ask for your support in any amount or in kind to help make this activity possible.',
        'Every gift will be used for the purpose stated above and will be properly recorded and acknowledged by the church.',
        '"Each of you should give what you have decided in your heart to give, not reluctantly or under compulsion, for God loves a cheerful giver." — 2 Corinthians 9:7 (NIV)',
        'Thank you for your generosity. May the Lord bless you abundantly.'
    ), 'Gratefully yours,', 0, 0],
    ['Certificate of Membership', 'certificate_membership', 'Certificate of Membership', $p(
        'This is to certify that',
        '<b>{{recipient_name}}</b>',
        'is a member of {{church_name}} since {{member_since}} and is presently a member in {{membership_status}} standing.',
        'This certification is issued upon the request of the above-named person for {{purpose}}.',
        'Given this {{date_long}}.'
    ), '', 1, 0],
    ['Certificate of Baptism', 'certificate_baptism', 'Certificate of Baptism', $p(
        'This is to certify that',
        '<b>{{recipient_name}}</b>',
        'having professed faith in the Lord Jesus Christ, was baptized by immersion in the name of the Father, the Son and the Holy Spirit on {{baptism_date}}{{baptism_place}}{{baptized_by}}.',
        '"Therefore we were buried with him through baptism into death in order that, just as Christ was raised from the dead through the glory of the Father, we too may live a new life." — Romans 6:4 (NIV)',
        'Given this {{date_long}}.'
    ), '', 1, 0],
    ['Certificate of Attendance', 'certificate_attendance', 'Certificate of Attendance', $p(
        'This is to certify that',
        '<b>{{recipient_name}}</b>',
        'attended {{purpose}} held at {{church_name}}.',
        'Given this {{date_long}}.'
    ), '', 1, 0],
    ['Church Invitation Letter', 'invitation', 'Invitation', $p(
        'Dear {{recipient_name}},',
        'Grace and peace to you in the name of our Lord Jesus Christ!',
        'We are pleased to invite you to {{purpose}}.',
        'Your presence will be a great blessing to us. We look forward to worshipping and fellowshipping with you.',
        'God bless you!'
    ), 'In Christ,', 0, 0],
    ['Authorization Letter', 'authorization', 'Letter of Authorization', $p(
        'To Whom It May Concern:',
        'This is to authorize <b>{{recipient_name}}</b> to {{purpose}} on behalf of {{church_name}}.',
        'Please extend to {{recipient_name}} the assistance needed for this purpose. This authorization is valid only for the purpose stated above.',
        'Thank you.'
    ), 'Sincerely,', 0, 0],
    ['Blank Church Letter', 'other', 'Official Letter', $p(
        'Dear {{recipient_name}},',
        'Write the content of the letter here.'
    ), 'Sincerely,', 0, 0],
];
foreach ($templates as [$name, $type, $title, $body, $closing, $cert, $conf]) {
    DB::insert('document_templates', [
        'name' => $name, 'doc_type' => $type, 'title' => $title, 'body_html' => $body,
        'closing' => $closing, 'is_certificate' => $cert, 'confidential' => $conf,
    ]);
}
