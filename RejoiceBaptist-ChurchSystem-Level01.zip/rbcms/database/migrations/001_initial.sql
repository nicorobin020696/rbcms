-- Rejoice Baptist Church Management System
-- Migration 001: initial schema (SQLite)
--
-- Conventions
--   * Every business record has a human-readable code (e.g. RBC-2026-0001) in a UNIQUE column.
--   * Records are archived (archived_at) instead of deleted so history is never lost.
--   * Money is stored as INTEGER centavos to avoid floating-point rounding errors.
--   * is_sample = 1 marks demonstration data; it can be removed from Settings in one step.

-- ---------------------------------------------------------------- system
CREATE TABLE settings (
    key        TEXT PRIMARY KEY,
    value      TEXT,
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE id_sequences (
    name       TEXT NOT NULL,
    period     TEXT NOT NULL DEFAULT '',
    last_value INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (name, period)
);

CREATE TABLE categories (
    id         INTEGER PRIMARY KEY,
    type       TEXT NOT NULL CHECK (type IN ('event','attendance','ministry','income','expense','instrument')),
    code       TEXT,                       -- stable identifier for system categories
    name       TEXT NOT NULL,
    color      TEXT NOT NULL DEFAULT 'slate',
    grp        TEXT,                       -- e.g. 'giving' for offerings/donations/tithes
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_system  INTEGER NOT NULL DEFAULT 0,
    is_active  INTEGER NOT NULL DEFAULT 1,
    UNIQUE (type, name COLLATE NOCASE)
);
CREATE UNIQUE INDEX ux_categories_code ON categories(type, code) WHERE code IS NOT NULL;

-- ---------------------------------------------------------------- people
CREATE TABLE members (
    id                 INTEGER PRIMARY KEY,
    member_code        TEXT NOT NULL UNIQUE,
    first_name         TEXT NOT NULL,
    middle_name        TEXT,
    last_name          TEXT NOT NULL,
    suffix             TEXT,
    gender             TEXT CHECK (gender IN ('male','female') OR gender IS NULL),
    birth_date         TEXT,
    civil_status       TEXT,
    contact_number     TEXT,
    email              TEXT,
    address            TEXT,
    date_joined        TEXT,
    membership_status  TEXT NOT NULL DEFAULT 'active' CHECK (membership_status IN ('active','inactive')),
    baptism_status     TEXT NOT NULL DEFAULT 'unbaptized' CHECK (baptism_status IN ('baptized','unbaptized')),
    baptism_date       TEXT,
    baptism_place      TEXT,
    baptized_by        TEXT,
    emergency_name     TEXT,
    emergency_contact  TEXT,
    emergency_relation TEXT,
    photo_path         TEXT,
    notes              TEXT,
    is_sample          INTEGER NOT NULL DEFAULT 0,
    archived_at        TEXT,
    created_by         INTEGER REFERENCES users(id) ON DELETE SET NULL,
    updated_by         INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at         TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_members_name   ON members(last_name COLLATE NOCASE, first_name COLLATE NOCASE);
CREATE INDEX ix_members_status ON members(membership_status, baptism_status);

CREATE TABLE member_history (
    id         INTEGER PRIMARY KEY,
    member_id  INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    event      TEXT NOT NULL,           -- created, updated, status, baptism, ministry, archived, restored
    summary    TEXT NOT NULL,
    user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_member_history ON member_history(member_id, created_at);

-- ---------------------------------------------------------------- access control
CREATE TABLE roles (
    id          INTEGER PRIMARY KEY,
    code        TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    description TEXT,
    is_system   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE role_permissions (
    role_id    INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission TEXT NOT NULL,
    PRIMARY KEY (role_id, permission)
);

CREATE TABLE users (
    id                   INTEGER PRIMARY KEY,
    username             TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email                TEXT COLLATE NOCASE,
    full_name            TEXT NOT NULL,
    position             TEXT,
    password_hash        TEXT NOT NULL,
    role_id              INTEGER NOT NULL REFERENCES roles(id),
    member_id            INTEGER REFERENCES members(id) ON DELETE SET NULL,
    is_active            INTEGER NOT NULL DEFAULT 1,
    theme                TEXT NOT NULL DEFAULT 'system' CHECK (theme IN ('system','light','dark')),
    must_change_password INTEGER NOT NULL DEFAULT 0,
    failed_attempts      INTEGER NOT NULL DEFAULT 0,
    locked_until         TEXT,
    session_version      INTEGER NOT NULL DEFAULT 1,
    last_login_at        TEXT,
    password_changed_at  TEXT,
    created_at           TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at           TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_users_email ON users(email) WHERE email IS NOT NULL AND email <> '';

-- Per-user overrides on top of the role: allowed = 1 grants, allowed = 0 revokes.
CREATE TABLE user_permissions (
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    permission TEXT NOT NULL,
    allowed    INTEGER NOT NULL CHECK (allowed IN (0,1)),
    PRIMARY KEY (user_id, permission)
);

CREATE TABLE login_attempts (
    id         INTEGER PRIMARY KEY,
    username   TEXT,
    ip         TEXT,
    success    INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_login_attempts_ip ON login_attempts(ip, created_at);

CREATE TABLE audit_logs (
    id           INTEGER PRIMARY KEY,
    user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    user_name    TEXT,
    action       TEXT NOT NULL,            -- login, logout, create, update, archive, restore, delete, export, generate, ...
    module       TEXT NOT NULL,
    record_type  TEXT,
    record_id    INTEGER,
    record_label TEXT,
    details      TEXT,
    ip           TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_audit_created ON audit_logs(created_at);
CREATE INDEX ix_audit_module  ON audit_logs(module, created_at);
CREATE INDEX ix_audit_record  ON audit_logs(record_type, record_id);

CREATE TABLE notifications (
    id         INTEGER PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type       TEXT NOT NULL,
    title      TEXT NOT NULL,
    body       TEXT,
    link       TEXT,
    dedupe_key TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    read_at    TEXT
);
CREATE INDEX ix_notifications_user ON notifications(user_id, read_at, created_at);
CREATE UNIQUE INDEX ux_notifications_dedupe ON notifications(user_id, dedupe_key) WHERE dedupe_key IS NOT NULL;

-- ---------------------------------------------------------------- ministries
CREATE TABLE ministries (
    id                  INTEGER PRIMARY KEY,
    ministry_code       TEXT NOT NULL UNIQUE,
    name                TEXT NOT NULL UNIQUE COLLATE NOCASE,
    category_id         INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    description         TEXT,
    leader_member_id    INTEGER REFERENCES members(id) ON DELETE SET NULL,
    assistant_member_id INTEGER REFERENCES members(id) ON DELETE SET NULL,
    schedule_day        INTEGER CHECK (schedule_day BETWEEN 0 AND 6 OR schedule_day IS NULL), -- 0 = Sunday
    schedule_start      TEXT,
    schedule_end        TEXT,
    schedule_location   TEXT,
    schedule_note       TEXT,
    contact_info        TEXT,
    status              TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
    is_sample           INTEGER NOT NULL DEFAULT 0,
    archived_at         TEXT,
    created_by          INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at          TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at          TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE ministry_members (
    ministry_id INTEGER NOT NULL REFERENCES ministries(id) ON DELETE CASCADE,
    member_id   INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    joined_on   TEXT NOT NULL DEFAULT (date('now','localtime')),
    PRIMARY KEY (ministry_id, member_id)
);
CREATE INDEX ix_ministry_members_member ON ministry_members(member_id);

-- ---------------------------------------------------------------- events & calendar
CREATE TABLE events (
    id            INTEGER PRIMARY KEY,
    event_code    TEXT NOT NULL UNIQUE,
    title         TEXT NOT NULL,
    description   TEXT,
    category_id   INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    ministry_id   INTEGER REFERENCES ministries(id) ON DELETE SET NULL,
    start_date    TEXT NOT NULL,
    end_date      TEXT,
    start_time    TEXT,
    end_time      TEXT,
    location      TEXT,
    poster_path   TEXT,
    is_activity   INTEGER NOT NULL DEFAULT 1,   -- 1 = listed under Events; 0 = calendar-only schedule
    recurrence    TEXT NOT NULL DEFAULT 'none' CHECK (recurrence IN ('none','weekly')),
    recur_until   TEXT,
    cancelled_at  TEXT,
    cancel_reason TEXT,
    is_sample     INTEGER NOT NULL DEFAULT 0,
    archived_at   TEXT,
    created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    updated_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_events_dates ON events(start_date, end_date);

CREATE TABLE announcements (
    id             INTEGER PRIMARY KEY,
    title          TEXT NOT NULL,
    body           TEXT NOT NULL,
    image_path     TEXT,
    status         TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
    is_pinned      INTEGER NOT NULL DEFAULT 0,
    published_at   TEXT,
    author_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    is_sample      INTEGER NOT NULL DEFAULT 0,
    created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at     TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_announcements_status ON announcements(status, published_at);

-- ---------------------------------------------------------------- attendance (incl. morning prayer)
CREATE TABLE attendance_sessions (
    id           INTEGER PRIMARY KEY,
    session_code TEXT NOT NULL UNIQUE,
    category_id  INTEGER NOT NULL REFERENCES categories(id),
    title        TEXT NOT NULL,
    session_date TEXT NOT NULL,
    session_time TEXT,
    ministry_id  INTEGER REFERENCES ministries(id) ON DELETE SET NULL,
    event_id     INTEGER REFERENCES events(id) ON DELETE SET NULL,
    notes        TEXT,
    is_sample    INTEGER NOT NULL DEFAULT 0,
    created_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (category_id, session_date, title COLLATE NOCASE, ministry_id)
);
CREATE INDEX ix_attendance_sessions_date ON attendance_sessions(session_date);

CREATE TABLE attendance_records (
    id          INTEGER PRIMARY KEY,
    session_id  INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    member_id   INTEGER NOT NULL REFERENCES members(id),
    status      TEXT NOT NULL CHECK (status IN ('present','absent','excused')),
    remarks     TEXT,
    recorded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (session_id, member_id)
);
CREATE INDEX ix_attendance_records_member ON attendance_records(member_id, status);

-- ---------------------------------------------------------------- music team
CREATE TABLE artists (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE COLLATE NOCASE
);

CREATE TABLE songs (
    id        INTEGER PRIMARY KEY,
    title     TEXT NOT NULL COLLATE NOCASE,
    artist_id INTEGER REFERENCES artists(id) ON DELETE SET NULL,
    UNIQUE (title, artist_id)
);

CREATE TABLE worship_lineups (
    id                    INTEGER PRIMARY KEY,
    lineup_code           TEXT NOT NULL UNIQUE,
    service_date          TEXT NOT NULL,
    service_type          TEXT NOT NULL CHECK (service_type IN ('morning','afternoon','special')),
    service_title         TEXT,
    song_leader_member_id INTEGER REFERENCES members(id) ON DELETE SET NULL,
    photo_path            TEXT,
    remarks               TEXT,
    is_sample             INTEGER NOT NULL DEFAULT 0,
    archived_at           TEXT,
    created_by            INTEGER REFERENCES users(id) ON DELETE SET NULL,
    updated_by            INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at            TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at            TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_lineups_service ON worship_lineups(service_date, service_type) WHERE archived_at IS NULL AND service_type <> 'special';
CREATE INDEX ix_lineups_date ON worship_lineups(service_date);

CREATE TABLE lineup_members (
    id            INTEGER PRIMARY KEY,
    lineup_id     INTEGER NOT NULL REFERENCES worship_lineups(id) ON DELETE CASCADE,
    member_id     INTEGER NOT NULL REFERENCES members(id),
    role          TEXT NOT NULL CHECK (role IN ('instrumentalist','backup','other')),
    instrument_id INTEGER REFERENCES categories(id),
    note          TEXT
);
CREATE INDEX ix_lineup_members ON lineup_members(lineup_id);
CREATE INDEX ix_lineup_members_member ON lineup_members(member_id, role);

CREATE TABLE lineup_songs (
    id          INTEGER PRIMARY KEY,
    lineup_id   INTEGER NOT NULL REFERENCES worship_lineups(id) ON DELETE CASCADE,
    song_id     INTEGER NOT NULL REFERENCES songs(id),
    category    TEXT NOT NULL CHECK (category IN ('praise','worship','special')),
    sort_order  INTEGER NOT NULL,
    youtube_url TEXT,
    remarks     TEXT
);
CREATE INDEX ix_lineup_songs ON lineup_songs(lineup_id, sort_order);
CREATE INDEX ix_lineup_songs_song ON lineup_songs(song_id);

-- ---------------------------------------------------------------- documents
CREATE TABLE document_templates (
    id                INTEGER PRIMARY KEY,
    name              TEXT NOT NULL UNIQUE COLLATE NOCASE,
    doc_type          TEXT NOT NULL,
    title             TEXT NOT NULL,          -- heading printed on the document
    body_html         TEXT NOT NULL,
    closing           TEXT,
    is_certificate    INTEGER NOT NULL DEFAULT 0,
    confidential      INTEGER NOT NULL DEFAULT 0,
    is_active         INTEGER NOT NULL DEFAULT 1,
    updated_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
    updated_at        TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE signatories (
    id             INTEGER PRIMARY KEY,
    name           TEXT NOT NULL,
    position       TEXT NOT NULL,
    signature_path TEXT,
    sort_order     INTEGER NOT NULL DEFAULT 0,
    is_active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE documents (
    id                 INTEGER PRIMARY KEY,
    doc_code           TEXT NOT NULL UNIQUE,
    template_id        INTEGER REFERENCES document_templates(id) ON DELETE SET NULL,
    doc_type           TEXT NOT NULL,
    title              TEXT NOT NULL,
    recipient_name     TEXT,
    recipient_details  TEXT,
    member_id          INTEGER REFERENCES members(id) ON DELETE SET NULL,
    purpose            TEXT,
    doc_date           TEXT NOT NULL,
    body_html          TEXT NOT NULL,
    closing            TEXT,
    show_logo          INTEGER NOT NULL DEFAULT 1,
    show_letterhead    INTEGER NOT NULL DEFAULT 1,
    show_signatures    INTEGER NOT NULL DEFAULT 1,
    is_certificate     INTEGER NOT NULL DEFAULT 0,
    confidential       INTEGER NOT NULL DEFAULT 0,
    status             TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','final','archived')),
    is_sample          INTEGER NOT NULL DEFAULT 0,
    created_by         INTEGER REFERENCES users(id) ON DELETE SET NULL,
    updated_by         INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at         TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE document_signatories (
    document_id  INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    signatory_id INTEGER NOT NULL REFERENCES signatories(id),
    sort_order   INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (document_id, signatory_id)
);

-- ---------------------------------------------------------------- finance
CREATE TABLE budgets (
    id           INTEGER PRIMARY KEY,
    budget_code  TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    ministry_id  INTEGER REFERENCES ministries(id) ON DELETE SET NULL,
    event_id     INTEGER REFERENCES events(id) ON DELETE SET NULL,
    period_start TEXT NOT NULL,
    period_end   TEXT NOT NULL,
    amount_cents INTEGER NOT NULL CHECK (amount_cents >= 0),
    notes        TEXT,
    status       TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','closed')),
    is_sample    INTEGER NOT NULL DEFAULT 0,
    created_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    CHECK (period_end >= period_start)
);

CREATE TABLE fin_transactions (
    id              INTEGER PRIMARY KEY,
    txn_code        TEXT NOT NULL UNIQUE,
    txn_date        TEXT NOT NULL,
    txn_type        TEXT NOT NULL CHECK (txn_type IN ('income','expense')),
    category_id     INTEGER NOT NULL REFERENCES categories(id),
    description     TEXT NOT NULL,
    amount_cents    INTEGER NOT NULL CHECK (amount_cents > 0),
    ministry_id     INTEGER REFERENCES ministries(id) ON DELETE SET NULL,
    event_id        INTEGER REFERENCES events(id) ON DELETE SET NULL,
    budget_id       INTEGER REFERENCES budgets(id) ON DELETE SET NULL,
    payer_payee     TEXT,
    reference_no    TEXT,
    remarks         TEXT,
    attachment_path TEXT,
    attachment_name TEXT,
    voided_at       TEXT,
    voided_by       INTEGER REFERENCES users(id) ON DELETE SET NULL,
    void_reason     TEXT,
    is_sample       INTEGER NOT NULL DEFAULT 0,
    recorded_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_fin_date     ON fin_transactions(txn_date, txn_type);
CREATE INDEX ix_fin_category ON fin_transactions(category_id);
CREATE INDEX ix_fin_budget   ON fin_transactions(budget_id);
