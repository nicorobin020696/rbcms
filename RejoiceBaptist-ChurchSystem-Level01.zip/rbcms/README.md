# Rejoice Baptist Church Management System

A private, local-network system for Rejoice Baptist Church. It covers:

- members (with auto IDs) and ministries
- attendance and morning prayer
- the music team's Sunday lineups
- events and the calendar
- announcements and church information
- official letters and certificates
- confidential finance and budgets
- user roles, the audit log, and backup and restore

It runs on one computer in the church office. Other computers and phones on the same Wi-Fi or LAN open it in a browser. It is **not** a public website, and it needs no internet connection.

## Quick start (Windows)

1. Install PHP 8.1 or newer. See [docs/INSTALLATION.md](docs/INSTALLATION.md); it takes about 5 minutes.
2. Double-click **`start-server.bat`**.
3. Open **http://localhost:8080** on that computer. The first visit asks you to create the **Super Admin** account.
4. Other computers open `http://<office-PC-IP>:8080`.

On Linux or macOS, run `./start-server.sh` instead.

## Documentation

| Guide | For |
|---|---|
| [INSTALLATION.md](docs/INSTALLATION.md) | Installing PHP, starting the system, LAN access, Apache/XAMPP option, Super Admin setup |
| [USER_MANUAL.md](docs/USER_MANUAL.md) | How to use every module, by role |
| [BACKUP_RESTORE.md](docs/BACKUP_RESTORE.md) | Backups, restoring, moving to a new computer, password recovery |
| [TESTING_CHECKLIST.md](docs/TESTING_CHECKLIST.md) | What to check before go-live and after updates |
| [DATABASE.md](docs/DATABASE.md) | Database tables and how they relate |
| [TECH_STACK.md](docs/TECH_STACK.md) | Technology used, folder layout, security design |

## Folder layout

```
app/         program code (never served to browsers)
database/    database structure (migrations) and default settings
public/      the only folder browsers can reach (CSS, JS, images, index.php)
storage/     YOUR DATA: database.sqlite, uploads, backups, logs  <- back this up
bin/         command-line tools (backup, restore, password reset, system check)
docs/        guides
tests/       automated test script
```
