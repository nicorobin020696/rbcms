<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Generates unique, human-readable record codes such as RBC-2026-0001.
 * Must be called inside Database::transaction(); the write lock plus the UNIQUE column
 * constraint guarantee that two users saving at the same moment never get the same code.
 */
final class Ids
{
    /** Formats for each record type: prefix, whether the year is included, digits. */
    private const FORMATS = [
        'member'     => ['MEM', true, 4],
        'ministry'   => ['MIN', false, 3],
        'event'      => ['EVT', true, 4],
        'attendance' => ['ATT', true, 5],
        'lineup'     => ['PW', true, 4],
        'document'   => ['DOC', true, 4],
        'txn'        => ['TXN', true, 5],
        'budget'     => ['BUD', true, 3],
    ];

    private const TARGETS = [
        'member' => ['members', 'member_code'], 'ministry' => ['ministries', 'ministry_code'],
        'event' => ['events', 'event_code'], 'attendance' => ['attendance_sessions', 'session_code'],
        'lineup' => ['worship_lineups', 'lineup_code'], 'document' => ['documents', 'doc_code'],
        'txn' => ['fin_transactions', 'txn_code'], 'budget' => ['budgets', 'budget_code'],
    ];

    public static function next(string $type, ?string $date = null): string
    {
        [$table, $col] = self::TARGETS[$type];
        do {
            $code = self::generate($type, $date);
        } while (Database::value("SELECT 1 FROM $table WHERE $col = ?", [$code]));
        return $code;
    }

    private static function generate(string $type, ?string $date): string
    {
        [$prefix, $withYear, $digits] = self::format($type);
        $year = substr($date ?: today(), 0, 4);
        $period = $withYear ? $year : '';
        Database::query(
            'INSERT INTO id_sequences (name, period, last_value) VALUES (?, ?, 1)
             ON CONFLICT(name, period) DO UPDATE SET last_value = last_value + 1',
            [$type, $period]
        );
        $n = (int) Database::value('SELECT last_value FROM id_sequences WHERE name = ? AND period = ?', [$type, $period]);
        $sep = Settings::get('ids.separator', '-');
        return $prefix . $sep . ($withYear ? $year . $sep : '') . str_pad((string) $n, $digits, '0', STR_PAD_LEFT);
    }

    public static function format(string $type): array
    {
        [$prefix, $withYear, $digits] = self::FORMATS[$type];
        if ($type === 'member') {
            $prefix = Settings::get('ids.member_prefix', 'RBC');
            $withYear = Settings::get('ids.member_year', '1') === '1';
            $digits = max(3, min(8, Settings::int('ids.member_digits', 4)));
        }
        return [$prefix, $withYear, $digits];
    }

    public static function preview(string $type): string
    {
        [$prefix, $withYear, $digits] = self::format($type);
        $sep = Settings::get('ids.separator', '-');
        return $prefix . $sep . ($withYear ? date('Y') . $sep : '') . str_pad('1', $digits, '0', STR_PAD_LEFT);
    }
}
