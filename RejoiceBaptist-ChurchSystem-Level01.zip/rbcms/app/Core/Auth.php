<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Authentication, session lifetime, login throttling and permission checks.
 */
final class Auth
{
    private static ?array $user = null;
    private static ?array $permissions = null;
    private static ?array $ledMinistries = null;

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function user(): ?array
    {
        if (self::$user !== null) {
            return self::$user;
        }
        $id = $_SESSION['uid'] ?? null;
        if (!$id) {
            return null;
        }
        $u = Database::one(
            'SELECT u.*, r.code AS role_code, r.name AS role_name
               FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?',
            [(int) $id]
        );
        // Deactivated accounts and password changes end every other session immediately.
        if (!$u || !$u['is_active'] || (int) $u['session_version'] !== (int) ($_SESSION['sv'] ?? 0)) {
            self::destroySession();
            return null;
        }
        self::$user = $u;
        return $u;
    }

    public static function id(): ?int
    {
        return self::user() ? (int) self::user()['id'] : null;
    }

    public static function isSuperAdmin(): bool
    {
        return (self::user()['role_code'] ?? '') === 'super_admin';
    }

    /** Apply idle timeout. Returns false when the session just expired. */
    public static function touch(): bool
    {
        if (empty($_SESSION['uid'])) {
            return true;
        }
        $timeout = max(5, Settings::int('security.session_timeout', 30)) * 60;
        $last = (int) ($_SESSION['last_activity'] ?? time());
        if (time() - $last > $timeout) {
            Audit::log('timeout', 'auth', 'user', (int) $_SESSION['uid'], $_SESSION['uname'] ?? null, 'Session expired after inactivity', (int) $_SESSION['uid'], $_SESSION['uname'] ?? null);
            self::destroySession();
            return false;
        }
        $_SESSION['last_activity'] = time();
        return true;
    }

    /**
     * Attempt a login. Returns [bool success, ?string error].
     * Accounts lock after repeated failures; the error message never reveals whether the username exists.
     */
    public static function attempt(string $login, string $password): array
    {
        $ip = client_ip();
        $window = date('Y-m-d H:i:s', time() - 900);
        $ipFailures = (int) Database::value('SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND success = 0 AND created_at > ?', [$ip, $window]);
        if ($ipFailures >= 25) {
            return [false, 'Too many failed sign-in attempts from this computer. Please wait 15 minutes.'];
        }

        $u = Database::one('SELECT * FROM users WHERE username = ? OR (email <> \'\' AND email = ?)', [$login, $login]);
        $generic = 'Incorrect username or password.';

        if ($u && $u['locked_until'] && strtotime($u['locked_until']) > time()) {
            self::recordAttempt($login, false);
            $mins = (int) ceil((strtotime($u['locked_until']) - time()) / 60);
            return [false, "This account is temporarily locked after too many failed attempts. Try again in $mins minute" . ($mins === 1 ? '' : 's') . ' or ask the administrator.'];
        }

        // Verify against a dummy hash when the user does not exist to keep timing consistent.
        if ($u === null) {
            password_verify($password, password_hash('timing-equaliser', PASSWORD_BCRYPT));
            $ok = false;
        } else {
            $ok = password_verify($password, $u['password_hash']);
        }

        if (!$ok) {
            self::recordAttempt($login, false);
            if ($u) {
                $max = max(3, Settings::int('security.max_attempts', 5));
                $fails = (int) $u['failed_attempts'] + 1;
                $lock = $fails >= $max ? date('Y-m-d H:i:s', time() + 60 * Settings::int('security.lockout_minutes', 15)) : null;
                Database::update('users', ['failed_attempts' => $lock ? 0 : $fails, 'locked_until' => $lock], 'id = :id', ['id' => $u['id']]);
                if ($lock) {
                    Audit::log('lockout', 'auth', 'user', (int) $u['id'], $u['username'], "Locked after $max failed attempts", null, $u['username']);
                }
            }
            return [false, $generic];
        }
        if (!$u['is_active']) {
            self::recordAttempt($login, false);
            return [false, 'This account has been deactivated. Please contact the system administrator.'];
        }

        if (password_needs_rehash($u['password_hash'], self::algo())) {
            Database::update('users', ['password_hash' => self::hash($password)], 'id = :id', ['id' => $u['id']]);
        }
        Database::update('users', ['failed_attempts' => 0, 'locked_until' => null, 'last_login_at' => now()], 'id = :id', ['id' => $u['id']]);
        self::recordAttempt($login, true);

        session_regenerate_id(true);
        $_SESSION['uid'] = (int) $u['id'];
        $_SESSION['uname'] = $u['full_name'];
        $_SESSION['sv'] = (int) $u['session_version'];
        $_SESSION['last_activity'] = time();
        unset($_SESSION['_csrf']);
        self::$user = null;
        Audit::log('login', 'auth', 'user', (int) $u['id'], $u['username'], 'Signed in');
        return [true, null];
    }

    public static function logout(): void
    {
        if (self::check()) {
            Audit::log('logout', 'auth', 'user', self::id(), self::user()['username'], 'Signed out');
        }
        self::destroySession();
    }

    public static function destroySession(): void
    {
        self::$user = null;
        self::$permissions = null;
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
    }

    public static function algo(): string|int
    {
        return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
    }

    public static function hash(string $password): string
    {
        return password_hash($password, self::algo());
    }

    /** Returns an error message, or null when the password is acceptable. */
    public static function passwordProblem(string $password, ?string $username = null): ?string
    {
        if (mb_strlen($password) < 10) {
            return 'Use at least 10 characters.';
        }
        if (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
            return 'Use both letters and numbers.';
        }
        if ($username && stripos($password, $username) !== false) {
            return 'The password must not contain the username.';
        }
        return null;
    }

    private static function recordAttempt(string $login, bool $success): void
    {
        Database::insert('login_attempts', ['username' => mb_substr($login, 0, 100), 'ip' => client_ip(), 'success' => $success ? 1 : 0]);
        if (random_int(1, 50) === 1) {
            Database::query("DELETE FROM login_attempts WHERE created_at < datetime('now','localtime','-30 days')");
        }
    }

    // ------------------------------------------------------------------ permissions

    /** Effective permissions = role permissions + per-user grants − per-user revocations. */
    public static function permissions(): array
    {
        if (self::$permissions !== null) {
            return self::$permissions;
        }
        $u = self::user();
        if (!$u) {
            return self::$permissions = [];
        }
        if ($u['role_code'] === 'super_admin') {
            return self::$permissions = array_keys(Permissions::all());
        }
        $perms = array_flip(Database::column('SELECT permission FROM role_permissions WHERE role_id = ?', [$u['role_id']]));
        foreach (Database::all('SELECT permission, allowed FROM user_permissions WHERE user_id = ?', [$u['id']]) as $o) {
            if ($o['allowed']) {
                $perms[$o['permission']] = true;
            } else {
                unset($perms[$o['permission']]);
            }
        }
        return self::$permissions = array_keys($perms);
    }

    public static function can(string $permission): bool
    {
        if (!self::check()) {
            return false;
        }
        if (self::isSuperAdmin()) {
            return true;
        }
        return in_array($permission, self::permissions(), true);
    }

    public static function canAny(string ...$permissions): bool
    {
        foreach ($permissions as $p) {
            if (self::can($p)) {
                return true;
            }
        }
        return false;
    }

    public static function require(string ...$permissions): void
    {
        if (!self::check()) {
            redirect('/login');
        }
        if (!self::canAny(...$permissions)) {
            Audit::log('denied', 'security', null, null, $_SERVER['REQUEST_URI'] ?? '', 'Access denied: requires ' . implode(' or ', $permissions));
            throw new HttpException(403);
        }
    }

    /**
     * IDs of ministries the current user leads (via their linked member record).
     * Used to scope what ministry leaders can see and edit.
     */
    public static function ledMinistryIds(): array
    {
        if (self::$ledMinistries !== null) {
            return self::$ledMinistries;
        }
        $mid = self::user()['member_id'] ?? null;
        if (!$mid || !self::can('ministry.lead')) {
            return self::$ledMinistries = [];
        }
        return self::$ledMinistries = array_map('intval', Database::column(
            'SELECT id FROM ministries WHERE archived_at IS NULL AND (leader_member_id = ? OR assistant_member_id = ?)',
            [$mid, $mid]
        ));
    }

    public static function leads(int $ministryId): bool
    {
        return in_array($ministryId, self::ledMinistryIds(), true);
    }

    public static function forgetCache(): void
    {
        self::$user = null;
        self::$permissions = null;
        self::$ledMinistries = null;
    }
}
