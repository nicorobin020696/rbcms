<?php
declare(strict_types=1);

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Settings;

function config(string $key, mixed $default = null): mixed
{
    return $GLOBALS['__config'][$key] ?? $default;
}

/** HTML-escape a value for output. */
function e(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function base_url(): string
{
    static $base = null;
    if ($base === null) {
        $base = rtrim((string) config('base_url'), '/');
        // Only trust SCRIPT_NAME when it is the front controller (PHP's built-in server sets it to the URL for paths like /x/export.csv).
        if ($base === '' && isset($_SERVER['SCRIPT_NAME']) && str_ends_with($_SERVER['SCRIPT_NAME'], '/index.php')) {
            $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
            $base = ($dir === '/' || $dir === '.') ? '' : rtrim($dir, '/');
        }
    }
    return $base;
}

function url(string $path = '/', array $query = []): string
{
    $q = array_filter($query, static fn($v) => $v !== null && $v !== '');
    return base_url() . '/' . ltrim($path, '/') . ($q ? '?' . http_build_query($q) : '');
}

function asset(string $path): string
{
    $file = PUBLIC_PATH . '/assets/' . ltrim($path, '/');
    $v = is_file($file) ? filemtime($file) : APP_VERSION;
    return base_url() . '/assets/' . ltrim($path, '/') . '?v=' . $v;
}

/** URL for an uploaded file; access is checked by FilesController. */
function file_url(?string $path): ?string
{
    return $path ? url('/files/' . $path) : null;
}

function redirect(string $path, array $query = []): never
{
    header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path, $query)));
    exit;
}

function back(string $fallback = '/'): never
{
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    if ($ref !== '' && parse_url($ref, PHP_URL_HOST) === parse_url('http://' . $host, PHP_URL_HOST)) {
        header('Location: ' . $ref);
        exit;
    }
    redirect($fallback);
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(Csrf::token()) . '">';
}

function flash(string $type, string $message): void
{
    $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
}

function take_flashes(): array
{
    $f = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $f;
}

/** Keep submitted form values for one request after a validation failure. */
function with_input(array $errors = []): void
{
    $input = $_POST;
    unset($input['_token'], $input['password'], $input['password_confirm'], $input['current_password']);
    $_SESSION['_old'] = $input;
    $_SESSION['_errors'] = $errors;
}

function old(string $key, mixed $default = ''): mixed
{
    return $GLOBALS['__old'][$key] ?? $default;
}

function field_error(string $key): string
{
    $msg = $GLOBALS['__errors'][$key] ?? null;
    return $msg ? '<p class="field-error">' . e($msg) . '</p>' : '';
}

function has_error(string $key): string
{
    return isset($GLOBALS['__errors'][$key]) ? ' is-invalid' : '';
}

function can(string $permission): bool
{
    return Auth::can($permission);
}

function user(): ?array
{
    return Auth::user();
}

function setting(string $key, ?string $default = null): ?string
{
    return Settings::get($key, $default);
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

function today(): string
{
    return date('Y-m-d');
}

/** 25 Nov 2026 */
function fmt_date(?string $date, string $format = 'j M Y'): string
{
    if (!$date) {
        return '—';
    }
    $ts = strtotime($date);
    return $ts ? date($format, $ts) : '—';
}

function fmt_datetime(?string $dt): string
{
    return fmt_date($dt, 'j M Y, g:i A');
}

function fmt_time(?string $time): string
{
    if (!$time) {
        return '';
    }
    $ts = strtotime('2000-01-01 ' . $time);
    return $ts ? date('g:i A', $ts) : '';
}

function time_range(?string $start, ?string $end): string
{
    if (!$start) {
        return 'Whole day';
    }
    return fmt_time($start) . ($end ? ' – ' . fmt_time($end) : '');
}

function time_ago(?string $dt): string
{
    if (!$dt) {
        return '';
    }
    $diff = time() - strtotime($dt);
    return match (true) {
        $diff < 60      => 'just now',
        $diff < 3600    => floor($diff / 60) . ' minute' . (floor($diff / 60) == 1 ? '' : 's') . ' ago',
        $diff < 86400   => floor($diff / 3600) . ' hour' . (floor($diff / 3600) == 1 ? '' : 's') . ' ago',
        $diff < 604800  => floor($diff / 86400) . ' day' . (floor($diff / 86400) == 1 ? '' : 's') . ' ago',
        default         => fmt_date($dt),
    };
}

function age(?string $birthDate): ?int
{
    if (!$birthDate || !strtotime($birthDate)) {
        return null;
    }
    return (new DateTime($birthDate))->diff(new DateTime('today'))->y;
}

/** Format centavos as pesos: 125050 -> ₱1,250.50 */
function money(int|float|null $cents, bool $symbol = true): string
{
    $v = number_format(((int) $cents) / 100, 2);
    return ($symbol ? '₱' : '') . $v;
}

/** Parse a user-entered amount ("1,250.50") into centavos; null if invalid. */
function parse_money(?string $input): ?int
{
    $s = str_replace([',', '₱', ' '], '', trim((string) $input));
    if ($s === '' || !preg_match('/^\d+(\.\d{1,2})?$/', $s)) {
        return null;
    }
    [$whole, $frac] = array_pad(explode('.', $s), 2, '0');
    return (int) $whole * 100 + (int) str_pad(substr($frac, 0, 2), 2, '0');
}

function initials(?string $name): string
{
    $parts = preg_split('/\s+/', trim((string) $name)) ?: [];
    $first = $parts[0] ?? '';
    $last = count($parts) > 1 ? end($parts) : '';
    return mb_strtoupper(mb_substr($first, 0, 1) . mb_substr($last, 0, 1)) ?: '?';
}

function member_name(array $m, bool $lastFirst = false): string
{
    $mid = !empty($m['middle_name']) ? ' ' . mb_substr($m['middle_name'], 0, 1) . '.' : '';
    $suf = !empty($m['suffix']) ? ' ' . $m['suffix'] : '';
    return $lastFirst
        ? $m['last_name'] . $suf . ', ' . $m['first_name'] . $mid
        : $m['first_name'] . $mid . ' ' . $m['last_name'] . $suf;
}

/** Display badge for a status value. */
function badge(string $label, string $tone = 'neutral'): string
{
    return '<span class="badge badge-' . e($tone) . '">' . e($label) . '</span>';
}

function status_badge(?string $status): string
{
    $map = [
        'active' => ['Active', 'green'], 'inactive' => ['Inactive', 'neutral'],
        'baptized' => ['Baptized', 'blue'], 'unbaptized' => ['Unbaptized', 'amber'],
        'published' => ['Published', 'green'], 'draft' => ['Draft', 'neutral'], 'archived' => ['Archived', 'neutral'],
        'upcoming' => ['Upcoming', 'blue'], 'ongoing' => ['Ongoing', 'green'], 'completed' => ['Completed', 'neutral'],
        'cancelled' => ['Cancelled', 'red'], 'present' => ['Present', 'green'], 'absent' => ['Absent', 'red'],
        'excused' => ['Excused', 'amber'], 'final' => ['Final', 'green'], 'closed' => ['Closed', 'neutral'],
        'income' => ['Income', 'green'], 'expense' => ['Expense', 'red'], 'voided' => ['Voided', 'neutral'],
    ];
    [$label, $tone] = $map[$status] ?? [ucfirst((string) $status), 'neutral'];
    return badge($label, $tone);
}

function sample_tag(array $row): string
{
    return !empty($row['is_sample']) ? ' <span class="tag-sample" title="Demonstration record">Sample</span>' : '';
}

function weekday_name(?int $d): string
{
    return $d === null ? '' : ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][$d];
}

function input_str(string $key, int $max = 255): string
{
    $v = $_POST[$key] ?? $_GET[$key] ?? '';
    if (is_array($v)) {
        return '';
    }
    $v = trim(str_replace("\0", '', (string) $v));
    return mb_substr($v, 0, $max);
}

function input_text(string $key, int $max = 20000): string
{
    $v = $_POST[$key] ?? '';
    if (is_array($v)) {
        return '';
    }
    $v = str_replace(["\r\n", "\0"], ["\n", ''], (string) $v);
    return mb_substr(trim($v), 0, $max);
}

function input_int(string $key): ?int
{
    $v = $_POST[$key] ?? $_GET[$key] ?? null;
    if ($v === null || $v === '' || is_array($v) || !preg_match('/^-?\d+$/', (string) $v)) {
        return null;
    }
    return (int) $v;
}

function input_date(string $key): ?string
{
    $v = input_str($key, 10);
    if ($v === '') {
        return null;
    }
    $d = DateTime::createFromFormat('!Y-m-d', $v);
    return ($d && $d->format('Y-m-d') === $v) ? $v : null;
}

function input_time(string $key): ?string
{
    $v = input_str($key, 8);
    if ($v === '') {
        return null;
    }
    return preg_match('/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/', $v) ? substr($v, 0, 5) : null;
}

function input_in(string $key, array $allowed, ?string $default = null): ?string
{
    $v = input_str($key, 50);
    return in_array($v, $allowed, true) ? $v : $default;
}

function query_str(string $key, int $max = 100): string
{
    $v = $_GET[$key] ?? '';
    return is_array($v) ? '' : mb_substr(trim((string) $v), 0, $max);
}

/** Current query string with some values replaced; used by filters and pagination. */
function query_with(array $changes): string
{
    $q = array_merge($_GET, $changes);
    $q = array_filter($q, static fn($v) => $v !== null && $v !== '');
    return $q ? '?' . http_build_query($q) : '?';
}

/** Escape a value for use in a SQL LIKE pattern with ESCAPE '\'. */
function like(string $term): string
{
    return '%' . strtr($term, ['\\' => '\\\\', '%' => '\\%', '_' => '\\_']) . '%';
}

function nl2p(?string $text): string
{
    $text = trim((string) $text);
    if ($text === '') {
        return '';
    }
    $paras = preg_split("/\n{2,}/", $text) ?: [];
    return implode('', array_map(static fn($p) => '<p>' . nl2br(e($p)) . '</p>', $paras));
}

function youtube_id(?string $url): ?string
{
    if (!$url) {
        return null;
    }
    if (preg_match('~(?:youtu\.be/|youtube\.com/(?:watch\?(?:.*&)?v=|embed/|shorts/|live/))([A-Za-z0-9_-]{11})~', $url, $m)) {
        return $m[1];
    }
    return null;
}

function json_attr(mixed $data): string
{
    return e(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP));
}

function client_ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? 'cli';
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function abort(int $code, string $message = ''): never
{
    throw new App\Core\HttpException($code, $message);
}

/** Inline SVG icon (24×24 stroke icons). */
function icon(string $name, string $class = ''): string
{
    static $paths = [
        'grid' => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        'calendar' => '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        'megaphone' => '<path d="M3 11v2a1 1 0 0 0 1 1h3l5 4V6L7 10H4a1 1 0 0 0-1 1z"/><path d="M16 8a5 5 0 0 1 0 8M19 5a9 9 0 0 1 0 14"/>',
        'users' => '<circle cx="9" cy="8" r="4"/><path d="M2 21v-1a6 6 0 0 1 6-6h2a6 6 0 0 1 6 6v1M16 3.13a4 4 0 0 1 0 7.75M22 21v-1a6 6 0 0 0-4-5.65"/>',
        'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a7 7 0 0 1 16 0v1"/>',
        'layers' => '<path d="M12 2 2 7l10 5 10-5-10-5z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
        'clipboard' => '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
        'sunrise' => '<path d="M12 2v6M4.93 10.93l1.41 1.41M2 18h2M20 18h2M19.07 10.93l-1.41 1.41M22 22H2M16 18a4 4 0 0 0-8 0"/><path d="m8 6 4-4 4 4"/>',
        'music' => '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
        'flag' => '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7"/>',
        'file' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>',
        'file-plus' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M12 18v-6M9 15h6"/>',
        'folder' => '<path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2z"/>',
        'wallet' => '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
        'swap' => '<path d="m21 16-4 4-4-4M17 20V4M3 8l4-4 4 4M7 4v16"/>',
        'gift' => '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7M7.5 8a2.5 2.5 0 0 1 0-5C10 3 12 8 12 8s2-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
        'pie' => '<path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/>',
        'chart' => '<path d="M3 3v18h18"/><path d="M18 17V9M13 17V5M8 17v-3"/>',
        'bell' => '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
        'shield' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        'history' => '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5M12 7v5l4 2"/>',
        'sliders' => '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
        'church' => '<path d="M12 2v4M10 4h4M5 22V11l7-5 7 5v11"/><path d="M10 22v-5h4v5M2 22h20"/>',
        'book' => '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
        'sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',
        'moon' => '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z"/>',
        'monitor' => '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
        'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
        'search' => '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'pencil' => '<path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>',
        'archive' => '<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8M10 12h4"/>',
        'trash' => '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
        'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
        'upload' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
        'printer' => '<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
        'eye' => '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
        'x' => '<path d="M18 6 6 18M6 6l12 12"/>',
        'chevron-left' => '<path d="m15 18-6-6 6-6"/>',
        'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
        'chevron-down' => '<path d="m6 9 6 6 6-6"/>',
        'chevrons' => '<path d="m7 15 5 5 5-5M7 9l5-5 5 5"/>',
        'check' => '<path d="M20 6 9 17l-5-5"/>',
        'check-circle' => '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
        'clock' => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
        'pin' => '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
        'image' => '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21"/>',
        'key' => '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
        'refresh' => '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
        'database' => '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5M3 12a9 3 0 0 0 18 0"/>',
        'arrow-up' => '<path d="M12 19V5M5 12l7-7 7 7"/>',
        'arrow-down' => '<path d="M12 5v14M19 12l-7 7-7-7"/>',
        'arrow-right' => '<path d="M5 12h14M12 5l7 7-7 7"/>',
        'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'panel' => '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18"/>',
        'play' => '<polygon points="6 3 20 12 6 21 6 3"/>',
        'clip' => '<path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
        'alert' => '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4M12 17h.01"/>',
        'lock' => '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'external' => '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
        'info' => '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
        'copy' => '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
        'droplet' => '<path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>',
    ];
    $inner = $paths[$name] ?? $paths['info'];
    return '<svg class="icon ' . e($class) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $inner . '</svg>';
}
