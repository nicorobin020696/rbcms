<?php
declare(strict_types=1);

namespace App\Core;

use Throwable;

/** Shows friendly error pages and logs details privately; never leaks stack traces in production. */
final class ErrorHandler
{
    public static function handle(Throwable $e): void
    {
        $status = $e instanceof HttpException ? $e->status : 500;
        if ($status >= 500) {
            $ref = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
            error_log(sprintf("[%s] ref %s: %s in %s:%d\n%s", date('c'), $ref, $e->getMessage(), $e->getFile(), $e->getLine(), $e->getTraceAsString()));
        }
        if (!headers_sent()) {
            http_response_code($status);
        }
        $wantsJson = str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');
        $titles = [400 => 'Bad request', 403 => 'Access denied', 404 => 'Page not found', 405 => 'Method not allowed', 419 => 'Session expired', 413 => 'File too large', 500 => 'Something went wrong'];
        $title = $titles[$status] ?? 'Error';
        $message = $e instanceof HttpException && $e->getMessage() !== '' ? $e->getMessage() : match ($status) {
            403 => 'You do not have permission to open this page. Ask the system administrator if you need access.',
            404 => 'The page or record you are looking for does not exist or was archived.',
            419 => 'Your form expired. Please go back, reload the page and try again.',
            500 => 'An unexpected error occurred. The details were saved to the system log' . (isset($ref) ? " (reference $ref)" : '') . '.',
            default => 'The request could not be completed.',
        };
        if (config('debug') && $status >= 500) {
            $message .= "\n\n" . $e->getMessage() . ' — ' . $e->getFile() . ':' . $e->getLine();
        }
        if ($wantsJson) {
            header('Content-Type: application/json');
            echo json_encode(['error' => $message]);
            return;
        }
        try {
            echo View::render('errors/error', ['status' => $status, 'title' => $title, 'message' => $message], Auth::check() ? 'app' : 'blank');
        } catch (Throwable) {
            echo '<h1>' . e($title) . '</h1><p>' . e($message) . '</p>';
        }
    }
}
