<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Internal notifications. Recipients are resolved by permission so nobody is told about
 * something they are not allowed to open. Notification text must never contain amounts
 * or confidential details; it only points to the record.
 */
final class Notify
{
    public static function user(int $userId, string $type, string $title, ?string $body = null, ?string $link = null, ?string $dedupe = null): void
    {
        Database::query(
            'INSERT OR IGNORE INTO notifications (user_id, type, title, body, link, dedupe_key) VALUES (?, ?, ?, ?, ?, ?)',
            [$userId, $type, mb_substr($title, 0, 150), $body !== null ? mb_substr($body, 0, 500) : null, $link, $dedupe]
        );
    }

    /** Notify every active user who holds the permission (super admins always included). */
    public static function permission(string $permission, string $type, string $title, ?string $body = null, ?string $link = null, ?string $dedupe = null, bool $excludeSelf = true): void
    {
        foreach (self::usersWith($permission) as $uid) {
            if ($excludeSelf && $uid === Auth::id()) {
                continue;
            }
            self::user($uid, $type, $title, $body, $link, $dedupe);
        }
    }

    public static function usersWith(string $permission): array
    {
        $rows = Database::all(
            "SELECT u.id, r.code,
                    EXISTS(SELECT 1 FROM role_permissions rp WHERE rp.role_id = u.role_id AND rp.permission = :p) AS by_role,
                    (SELECT allowed FROM user_permissions up WHERE up.user_id = u.id AND up.permission = :p) AS override
               FROM users u JOIN roles r ON r.id = u.role_id
              WHERE u.is_active = 1",
            ['p' => $permission]
        );
        $ids = [];
        foreach ($rows as $r) {
            $allowed = $r['code'] === 'super_admin'
                || ($r['override'] !== null ? (bool) $r['override'] : (bool) $r['by_role']);
            if ($allowed) {
                $ids[] = (int) $r['id'];
            }
        }
        return $ids;
    }

    public static function unreadCount(int $userId): int
    {
        return (int) Database::value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL', [$userId]);
    }

    /**
     * Time-based reminders (upcoming events, ministry schedules, attendance). Runs at most once
     * per user per day when they open the system, so no background service is required.
     */
    public static function dailyReminders(array $user): void
    {
        $key = 'notify.daily.' . $user['id'];
        if (Settings::get($key) === today()) {
            return;
        }
        Settings::set($key, today());
        $uid = (int) $user['id'];
        $perms = Auth::permissions();
        $has = static fn(string $p) => Auth::isSuperAdmin() || in_array($p, $perms, true);

        if ($has('events.view') || $has('calendar.view')) {
            $soon = Database::all(
                "SELECT id, title, start_date, start_time FROM events
                  WHERE archived_at IS NULL AND cancelled_at IS NULL AND is_activity = 1 AND recurrence = 'none'
                    AND start_date BETWEEN date('now','localtime') AND date('now','localtime','+3 days')"
            );
            foreach ($soon as $ev) {
                $when = $ev['start_date'] === today() ? 'today' : 'on ' . fmt_date($ev['start_date'], 'l, j M');
                self::user($uid, 'event', 'Upcoming: ' . $ev['title'], 'Scheduled ' . $when . ($ev['start_time'] ? ' at ' . fmt_time($ev['start_time']) : '') . '.', '/events/' . $ev['id'], 'event-soon-' . $ev['id']);
            }
        }
        $led = Auth::ledMinistryIds();
        if ($led) {
            $dow = (int) date('w');
            foreach (Database::all('SELECT id, name, schedule_day, schedule_start FROM ministries WHERE schedule_day IS NOT NULL AND id IN (' . implode(',', $led) . ')') as $m) {
                if ((int) $m['schedule_day'] === $dow || (int) $m['schedule_day'] === ($dow + 1) % 7) {
                    $day = (int) $m['schedule_day'] === $dow ? 'today' : 'tomorrow';
                    self::user($uid, 'ministry', $m['name'] . ' meets ' . $day, $m['schedule_start'] ? 'At ' . fmt_time($m['schedule_start']) . '.' : null, '/ministries/' . $m['id'], 'ministry-' . $m['id'] . '-' . today());
                }
            }
        }
        if ($has('attendance.record') && date('w') === '1') {
            $last = date('Y-m-d', strtotime('last sunday'));
            $recorded = (int) Database::value(
                "SELECT COUNT(*) FROM attendance_sessions s JOIN categories c ON c.id = s.category_id WHERE c.code = 'sunday_service' AND s.session_date = ?",
                [$last]
            );
            if ($recorded === 0) {
                self::user($uid, 'attendance', 'Attendance reminder', 'No Sunday Worship attendance has been recorded for ' . fmt_date($last) . '.', '/attendance/new', 'att-reminder-' . $last);
            }
        }
        if ($has('backup.manage')) {
            $latest = \App\Services\Backup::all()[0]['time'] ?? 0;
            $days = $latest ? (int) floor((time() - $latest) / 86400) : null;
            if ($days === null || $days >= 3) {
                self::user($uid, 'backup', 'Backup overdue', $days === null ? 'No backup has been made yet.' : "The newest backup is $days days old.", '/settings/backup', 'backup-overdue-' . today());
            }
        }
        if (random_int(1, 20) === 1) {
            Database::query("DELETE FROM notifications WHERE read_at IS NOT NULL AND read_at < datetime('now','localtime','-180 days')");
        }
    }
}
