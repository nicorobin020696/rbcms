<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Validates and stores uploaded files outside the public web folder.
 * Images are re-encoded (when GD is available) which strips metadata and any embedded content.
 * Files are served only through FilesController, which checks permissions.
 */
final class Upload
{
    private const IMAGE_TYPES = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    private const DOC_TYPES = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
        'application/msword' => 'doc', 'application/vnd.ms-excel' => 'xls',
    ];

    /** Returns [relativePath|null, error|null]. A missing optional file returns [null, null]. */
    public static function image(string $field, string $dir, int $maxDim = 1600): array
    {
        return self::store($field, $dir, self::IMAGE_TYPES, true, $maxDim);
    }

    public static function document(string $field, string $dir): array
    {
        return self::store($field, $dir, self::DOC_TYPES, false, 0);
    }

    public static function originalName(string $field): ?string
    {
        $n = $_FILES[$field]['name'] ?? null;
        return $n ? mb_substr(preg_replace('/[^\p{L}\p{N} ._()-]/u', '_', basename((string) $n)), 0, 150) : null;
    }

    public static function delete(?string $relative): void
    {
        if (!$relative) {
            return;
        }
        $full = self::path($relative);
        if ($full && is_file($full)) {
            @unlink($full);
        }
    }

    /** Absolute path of a stored file, or null when the path tries to leave the uploads folder. */
    public static function path(string $relative): ?string
    {
        $root = realpath(STORAGE_PATH . '/uploads');
        $full = realpath(STORAGE_PATH . '/uploads/' . $relative);
        return ($root && $full && str_starts_with($full, $root . DIRECTORY_SEPARATOR)) ? $full : null;
    }

    private static function store(string $field, string $dir, array $types, bool $isImage, int $maxDim): array
    {
        $f = $_FILES[$field] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE || ($f['name'] ?? '') === '') {
            return [null, null];
        }
        if (is_array($f['error'])) {
            return [null, 'Upload one file at a time.'];
        }
        if ($f['error'] !== UPLOAD_ERR_OK) {
            return [null, in_array($f['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)
                ? 'The file is larger than the server allows.' : 'The file could not be uploaded. Please try again.'];
        }
        $max = (int) config('upload_max_mb', 10) * 1024 * 1024;
        if ($f['size'] > $max) {
            return [null, 'The file must be smaller than ' . config('upload_max_mb', 10) . ' MB.'];
        }
        if (!is_uploaded_file($f['tmp_name'])) {
            return [null, 'Invalid upload.'];
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']) ?: '';
        if (!isset($types[$mime])) {
            return [null, $isImage ? 'Please upload a JPG, PNG, WEBP or GIF image.' : 'Allowed files: PDF, images, Word or Excel documents.'];
        }
        $ext = $types[$mime];
        if (str_starts_with($mime, 'image/')) {
            $info = @getimagesize($f['tmp_name']);
            if (!$info || $info[0] < 1 || $info[1] < 1 || $info[0] * $info[1] > 40_000_000) {
                return [null, 'The image appears to be damaged or too large.'];
            }
        }

        $sub = trim($dir, '/') . '/' . date('Y/m');
        $target = STORAGE_PATH . '/uploads/' . $sub;
        if (!is_dir($target) && !mkdir($target, 0770, true) && !is_dir($target)) {
            return [null, 'Storage folder is not writable.'];
        }
        $name = bin2hex(random_bytes(12));

        if (str_starts_with($mime, 'image/') && extension_loaded('gd') && $mime !== 'image/gif') {
            $saved = self::reencode($f['tmp_name'], $mime, $target . '/' . $name, $maxDim ?: 2400);
            if ($saved) {
                return [$sub . '/' . basename($saved), null];
            }
        }
        $dest = $target . '/' . $name . '.' . $ext;
        if (!move_uploaded_file($f['tmp_name'], $dest)) {
            return [null, 'The file could not be saved.'];
        }
        return [$sub . '/' . $name . '.' . $ext, null];
    }

    private static function reencode(string $src, string $mime, string $destNoExt, int $maxDim): ?string
    {
        $img = match ($mime) {
            'image/jpeg' => @imagecreatefromjpeg($src),
            'image/png'  => @imagecreatefrompng($src),
            'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($src) : false,
            default      => false,
        };
        if (!$img) {
            return null;
        }
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $exif = @exif_read_data($src);
            $rot = [3 => 180, 6 => -90, 8 => 90][$exif['Orientation'] ?? 1] ?? 0;
            if ($rot) {
                $img = imagerotate($img, $rot, 0);
            }
        }
        $w = imagesx($img);
        $h = imagesy($img);
        $scale = min(1, $maxDim / max($w, $h));
        if ($scale < 1) {
            $nw = (int) round($w * $scale);
            $nh = (int) round($h * $scale);
            $res = imagecreatetruecolor($nw, $nh);
            imagealphablending($res, false);
            imagesavealpha($res, true);
            imagecopyresampled($res, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);
            $img = $res;
        }
        $keepAlpha = $mime === 'image/png' || $mime === 'image/webp';
        if ($keepAlpha) {
            imagesavealpha($img, true);
            $out = $destNoExt . '.png';
            $ok = imagepng($img, $out, 7);
        } else {
            $out = $destNoExt . '.jpg';
            $ok = imagejpeg($img, $out, 86);
        }
        return $ok ? $out : null;
    }
}
