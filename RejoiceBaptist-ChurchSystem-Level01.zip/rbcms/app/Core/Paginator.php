<?php
declare(strict_types=1);

namespace App\Core;

final class Paginator
{
    public int $page;
    public int $pages;
    public int $offset;

    public function __construct(public int $total, public int $perPage = 25)
    {
        $this->pages = max(1, (int) ceil($total / $perPage));
        $requested = (int) ($_GET['page'] ?? 1);
        $this->page = min(max(1, $requested), $this->pages);
        $this->offset = ($this->page - 1) * $perPage;
    }

    public function sql(): string
    {
        return ' LIMIT ' . $this->perPage . ' OFFSET ' . $this->offset;
    }

    public function from(): int
    {
        return $this->total === 0 ? 0 : $this->offset + 1;
    }

    public function to(): int
    {
        return min($this->total, $this->offset + $this->perPage);
    }
}
