<?php
declare(strict_types=1);

namespace App\Core;

/** Key/value configuration stored in the database so it survives restarts and is included in backups. */
final class Settings
{
    private static ?array $cache = null;

    public static function get(string $key, ?string $default = null): ?string
    {
        self::load();
        return array_key_exists($key, self::$cache) && self::$cache[$key] !== null ? self::$cache[$key] : $default;
    }

    public static function int(string $key, int $default): int
    {
        $v = self::get($key);
        return $v === null || $v === '' ? $default : (int) $v;
    }

    public static function set(string $key, ?string $value): void
    {
        Database::query(
            "INSERT INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now','localtime'))
             ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
            [$key, $value]
        );
        self::load();
        self::$cache[$key] = $value;
    }

    public static function many(string $prefix): array
    {
        self::load();
        $out = [];
        foreach (self::$cache as $k => $v) {
            if (str_starts_with($k, $prefix)) {
                $out[$k] = $v;
            }
        }
        return $out;
    }

    public static function flush(): void
    {
        self::$cache = null;
    }

    private static function load(): void
    {
        if (self::$cache === null) {
            self::$cache = Database::pairs('SELECT key, value FROM settings');
        }
    }
}
