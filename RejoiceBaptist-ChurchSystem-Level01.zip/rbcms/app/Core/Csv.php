<?php
declare(strict_types=1);

namespace App\Core;

final class Csv
{
    /** Stream a CSV download. Cells that start with = + - @ are prefixed so spreadsheet apps never run them as formulas. */
    public static function download(string $filename, array $headers, iterable $rows): never
    {
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_.-]/', '_', $filename) . '"');
        header('Cache-Control: no-store');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, $headers, ',', '"', '');
        foreach ($rows as $row) {
            fputcsv($out, array_map([self::class, 'safe'], array_values($row)), ',', '"', '');
        }
        fclose($out);
        exit;
    }

    public static function safe(mixed $v): string
    {
        $s = (string) ($v ?? '');
        return ($s !== '' && in_array($s[0], ['=', '+', '-', '@', "\t", "\r"], true) && !is_numeric($s)) ? "'" . $s : $s;
    }
}
