<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Standard church report layout: letterhead, title block, tables, summary rows and page footer.
 */
final class PdfReport extends Pdf
{
    private array $columns = [];
    private bool $inTable = false;

    public function __construct(string $title, string $subtitle = '', string $orientation = 'P', bool $confidential = false)
    {
        parent::__construct($orientation, $title);
        $this->margin = 40;
        $first = true;
        $this->onPageStart = function (Pdf $pdf) use ($title, $subtitle, &$first, $confidential): void {
            if ($first) {
                $this->letterhead();
                $pdf->setFont('B', 14);
                $pdf->color(20);
                $pdf->text($pdf->margin, $pdf->y, $title);
                $pdf->y += 18;
                if ($subtitle !== '') {
                    $pdf->setFont('', 9);
                    $pdf->color(90);
                    $pdf->paragraph($subtitle, $pdf->margin, $pdf->contentWidth(), 12);
                }
                $pdf->y += 6;
                $first = false;
            } else {
                $pdf->setFont('B', 9);
                $pdf->color(90);
                $pdf->text($pdf->margin, $pdf->y, Settings::get('church.name', 'Rejoice Baptist Church') . ' — ' . $title);
                $pdf->y += 18;
                if ($this->inTable) {
                    $this->tableHeader();
                }
            }
            $pdf->color(20);
        };
        $this->onPageEnd = function (Pdf $pdf) use ($confidential): void {
            $y = $pdf->h - 30;
            $pdf->strokeColor(210, 210, 210);
            $pdf->line($pdf->margin, $y - 6, $pdf->w - $pdf->margin, $y - 6, 0.5);
            $pdf->setFont('', 7.5);
            $pdf->color(120);
            $by = Auth::user()['full_name'] ?? 'System';
            $left = 'Generated ' . date('j M Y, g:i A') . ' by ' . $by . ($confidential ? '  ·  CONFIDENTIAL — for authorized personnel only' : '');
            $pdf->text($pdf->margin, $y, $left);
            $pdf->text($pdf->margin, $y, 'Page ' . $pdf->pageNo() . ' of {nb}', 'R', $pdf->contentWidth());
            $pdf->color(20);
        };
        $this->addPage();
    }

    public function letterhead(): void
    {
        $logo = self::logoFile();
        $x = $this->margin;
        if ($logo) {
            $this->image($logo, $x, $this->y, 46, 46);
            $x += 56;
        }
        $this->color(20);
        $this->setFont('B', 15);
        $this->text($x, $this->y + 4, Settings::get('church.name', 'Rejoice Baptist Church'));
        $this->setFont('', 8.5);
        $this->color(80);
        $addr = trim((string) Settings::get('church.address', ''));
        $contact = trim(implode('  ·  ', array_filter([Settings::get('church.phone'), Settings::get('church.email')])));
        $lines = array_values(array_filter([$addr, $contact], static fn($l) => $l !== ''));
        foreach ($lines as $i => $l) {
            $this->text($x, $this->y + 22 + $i * 11, $l);
        }
        $this->y += 54;
        $this->strokeColor(30, 30, 30);
        $this->line($this->margin, $this->y, $this->w - $this->margin, $this->y, 1.2);
        $this->y += 14;
        $this->color(20);
    }

    public static function logoFile(): ?string
    {
        $custom = Settings::get('church.logo');
        if ($custom && ($p = Upload::path($custom))) {
            return $p;
        }
        $default = PUBLIC_PATH . '/assets/img/logo-print.jpg';
        return is_file($default) ? $default : null;
    }

    /** Key figures shown as a row of boxes: [[label, value], ...]. */
    public function summary(array $items): void
    {
        $n = count($items);
        if ($n === 0) {
            return;
        }
        $gap = 8;
        $bw = ($this->contentWidth() - $gap * ($n - 1)) / $n;
        $this->ensureSpace(46);
        foreach ($items as $i => [$label, $value]) {
            $x = $this->margin + $i * ($bw + $gap);
            $this->strokeColor(215, 215, 215);
            $this->fillColor(247, 247, 245);
            $this->rect($x, $this->y, $bw, 40, 'FD');
            $this->setFont('', 7.5);
            $this->color(100);
            $this->text($x + 8, $this->y + 7, mb_strtoupper($label));
            $this->setFont('B', 12);
            $this->color(20);
            $this->text($x + 8, $this->y + 20, (string) $value);
        }
        $this->y += 52;
    }

    public function heading(string $text): void
    {
        $this->ensureSpace(40);
        $this->y += 4;
        $this->setFont('B', 10.5);
        $this->color(20);
        $this->text($this->margin, $this->y, $text);
        $this->y += 16;
    }

    public function note(string $text): void
    {
        $this->setFont('', 9);
        $this->color(70);
        $this->paragraph($text, $this->margin, $this->contentWidth(), 12);
        $this->color(20);
        $this->y += 4;
    }

    /**
     * Columns: [[label, widthFraction, align], ...]. Rows are arrays of strings.
     * Optional $totals row is printed bold under the table.
     */
    public function table(array $columns, array $rows, ?array $totals = null, string $empty = 'No records found.'): void
    {
        $cw = $this->contentWidth();
        $sum = array_sum(array_column($columns, 1)) ?: 1;
        $this->columns = array_map(static fn($c) => [$c[0], $c[1] / $sum * $cw, $c[2] ?? 'L'], $columns);
        $this->ensureSpace(40);
        $this->inTable = true;
        $this->tableHeader();
        if (!$rows) {
            $this->setFont('I', 9);
            $this->color(110);
            $this->text($this->margin + 6, $this->y + 5, $empty);
            $this->y += 20;
        }
        foreach ($rows as $i => $row) {
            $this->tableRow(array_values($row), false, $i % 2 === 1);
        }
        if ($totals) {
            $this->tableRow(array_values($totals), true, false);
        }
        $this->inTable = false;
        $this->y += 10;
    }

    private function tableHeader(): void
    {
        $x = $this->margin;
        $this->fillColor(35, 38, 45);
        $this->rect($this->margin, $this->y, $this->contentWidth(), 18, 'F');
        $this->setFont('B', 7.5);
        $this->color(255);
        foreach ($this->columns as [$label, $w, $align]) {
            $this->text($x + 5, $this->y + 5.5, mb_strtoupper($label), $align, $w - 10);
            $x += $w;
        }
        $this->color(20);
        $this->y += 18;
    }

    private function tableRow(array $cells, bool $bold, bool $zebra): void
    {
        $this->setFont($bold ? 'B' : '', 8.5);
        $wrapped = [];
        $lines = 1;
        foreach ($this->columns as $i => [, $w]) {
            $wrapped[$i] = $this->wrap((string) ($cells[$i] ?? ''), $w - 10);
            $lines = max($lines, count($wrapped[$i]));
        }
        $h = 8 + $lines * 10.5;
        $this->ensureSpace($h);
        $this->setFont($bold ? 'B' : '', 8.5);
        if ($zebra || $bold) {
            $bold ? $this->fillColor(236, 236, 232) : $this->fillColor(248, 248, 246);
            $this->rect($this->margin, $this->y, $this->contentWidth(), $h, 'F');
        }
        $this->color(25);
        $x = $this->margin;
        foreach ($this->columns as $i => [, $w, $align]) {
            foreach ($wrapped[$i] as $li => $line) {
                $this->text($x + 5, $this->y + 4.5 + $li * 10.5, $line, $align, $w - 10);
            }
            $x += $w;
        }
        $this->strokeColor(225, 225, 222);
        $this->line($this->margin, $this->y + $h, $this->w - $this->margin, $this->y + $h, 0.4);
        $this->y += $h;
    }
}
