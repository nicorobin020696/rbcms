<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Small dependency-free PDF writer (PDF 1.4) used for reports, member profiles and church documents.
 * Supports the standard Helvetica family, lines, rectangles, JPEG/PNG images (with transparency),
 * word-wrapped rich text and automatic page numbers. Coordinates are in points from the top-left.
 */
class Pdf
{
    public float $w;
    public float $h;
    public float $margin = 42;
    public float $y = 42;
    /** @var callable|null */
    public $onPageStart = null;
    /** @var callable|null */
    public $onPageEnd = null;

    private array $pages = [];
    private int $page = -1;
    private string $font = 'Helvetica';
    private float $size = 10;
    private array $usedFonts = [];
    private array $images = [];
    private static ?array $metrics = null;
    private string $title = '';

    private const FONTS = ['' => 'Helvetica', 'B' => 'Helvetica-Bold', 'I' => 'Helvetica-Oblique', 'BI' => 'Helvetica-BoldOblique'];

    public function __construct(string $orientation = 'P', string $title = '')
    {
        [$this->w, $this->h] = $orientation === 'L' ? [841.89, 595.28] : [595.28, 841.89];
        $this->title = $title;
        self::$metrics ??= require __DIR__ . '/font_metrics.php';
    }

    // ------------------------------------------------------------ pages

    public function addPage(): void
    {
        if ($this->page >= 0 && $this->onPageEnd) {
            ($this->onPageEnd)($this);
        }
        $this->pages[] = '';
        $this->page = count($this->pages) - 1;
        $this->y = $this->margin;
        if ($this->onPageStart) {
            ($this->onPageStart)($this);
        }
    }

    public function pageNo(): int
    {
        return $this->page + 1;
    }

    /** Start a new page when fewer than $needed points remain. */
    public function ensureSpace(float $needed, float $bottomReserve = 40): bool
    {
        if ($this->y + $needed > $this->h - $this->margin - $bottomReserve) {
            $this->addPage();
            return true;
        }
        return false;
    }

    public function contentWidth(): float
    {
        return $this->w - 2 * $this->margin;
    }

    // ------------------------------------------------------------ drawing

    public function setFont(string $style = '', float $size = 10): void
    {
        $style = strtoupper(str_replace('U', '', $style));
        $style = $style === 'IB' ? 'BI' : $style;
        $this->font = self::FONTS[$style] ?? 'Helvetica';
        $this->size = $size;
        $this->usedFonts[$this->font] = true;
    }

    public function color(int $r, int $g = -1, int $b = -1): void
    {
        if ($g < 0) {
            $g = $b = $r;
        }
        $this->out(sprintf('%.3F %.3F %.3F rg %.3F %.3F %.3F RG', $r / 255, $g / 255, $b / 255, $r / 255, $g / 255, $b / 255));
    }

    public function text(float $x, float $y, string $s, string $align = 'L', float $width = 0): void
    {
        $enc = self::encode($s);
        if ($align !== 'L' && $width > 0) {
            $tw = $this->widthOf($s);
            $x += $align === 'R' ? $width - $tw : ($width - $tw) / 2;
        }
        $this->usedFonts[$this->font] = true;
        $this->out(sprintf('BT /F%d %.2F Tf %.2F %.2F Td (%s) Tj ET', $this->fontIndex($this->font), $this->size, $x, $this->h - $y - $this->size * 0.8, self::escape($enc)));
    }

    public function line(float $x1, float $y1, float $x2, float $y2, float $width = 0.5): void
    {
        $this->out(sprintf('%.2F w %.2F %.2F m %.2F %.2F l S', $width, $x1, $this->h - $y1, $x2, $this->h - $y2));
    }

    public function rect(float $x, float $y, float $w, float $h, string $mode = 'S', float $lineWidth = 0.5): void
    {
        $op = ['S' => 'S', 'F' => 'f', 'FD' => 'B'][$mode] ?? 'S';
        $this->out(sprintf('%.2F w %.2F %.2F %.2F %.2F re %s', $lineWidth, $x, $this->h - $y - $h, $w, $h, $op));
    }

    public function fillColor(int $r, int $g, int $b): void
    {
        $this->out(sprintf('%.3F %.3F %.3F rg', $r / 255, $g / 255, $b / 255));
    }

    public function strokeColor(int $r, int $g, int $b): void
    {
        $this->out(sprintf('%.3F %.3F %.3F RG', $r / 255, $g / 255, $b / 255));
    }

    /** Draw a JPEG or PNG file. Height is derived from the aspect ratio when 0. Returns drawn height. */
    public function image(string $file, float $x, float $y, float $w, float $h = 0): float
    {
        if (!is_file($file)) {
            return 0;
        }
        $key = realpath($file) ?: $file;
        if (!isset($this->images[$key])) {
            $info = $this->parseImage($file);
            if (!$info) {
                return 0;
            }
            $info['i'] = count($this->images) + 1;
            $this->images[$key] = $info;
        }
        $img = $this->images[$key];
        if ($h <= 0) {
            $h = $w * $img['h'] / $img['w'];
        }
        if ($w <= 0) {
            $w = $h * $img['w'] / $img['h'];
        }
        $this->out(sprintf('q %.2F 0 0 %.2F %.2F %.2F cm /I%d Do Q', $w, $h, $x, $this->h - $y - $h, $img['i']));
        return $h;
    }

    public function widthOf(string $s, ?string $font = null, ?float $size = null): float
    {
        $font ??= $this->font;
        $size ??= $this->size;
        $cw = self::$metrics[$font];
        $enc = self::encode($s);
        $w = 0;
        $len = strlen($enc);
        for ($i = 0; $i < $len; $i++) {
            $w += $cw[ord($enc[$i])] ?? 500;
        }
        return $w * $size / 1000;
    }

    /** Wrap plain text to a width; returns lines. */
    public function wrap(string $text, float $width): array
    {
        $lines = [];
        foreach (preg_split("/\n/", $text) as $para) {
            $words = preg_split('/\s+/', trim($para)) ?: [''];
            $line = '';
            foreach ($words as $word) {
                $try = $line === '' ? $word : $line . ' ' . $word;
                if ($this->widthOf($try) <= $width || $line === '') {
                    // Hard-break words that are longer than the line.
                    while ($this->widthOf($try) > $width && mb_strlen($try) > 1) {
                        $cut = mb_strlen($try);
                        while ($cut > 1 && $this->widthOf(mb_substr($try, 0, $cut)) > $width) {
                            $cut--;
                        }
                        $lines[] = mb_substr($try, 0, $cut);
                        $try = mb_substr($try, $cut);
                    }
                    $line = $try;
                } else {
                    $lines[] = $line;
                    $line = $word;
                }
            }
            $lines[] = $line;
        }
        return $lines;
    }

    /** Write wrapped plain text at the cursor and advance it. */
    public function paragraph(string $text, float $x, float $width, float $lineHeight, string $align = 'L'): void
    {
        foreach ($this->wrap($text, $width) as $line) {
            $this->ensureSpace($lineHeight);
            $this->text($x, $this->y, $line, $align, $width);
            $this->y += $lineHeight;
        }
    }

    /**
     * Rich paragraph: $runs is a list of [text, style] where style may contain B, I, U.
     * Supports L, C, R and J (justified) alignment.
     */
    public function richParagraph(array $runs, float $x, float $width, float $size, float $lineHeight, string $align = 'L', float $indent = 0): void
    {
        $words = [];
        foreach ($runs as [$text, $style]) {
            $parts = preg_split('/(\s+)/u', $text, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY) ?: [];
            foreach ($parts as $p) {
                if (trim($p) === '') {
                    if ($words) {
                        $words[count($words) - 1]['space'] = true;
                    }
                    continue;
                }
                $st = strtoupper($style);
                $fontStyle = (str_contains($st, 'B') ? 'B' : '') . (str_contains($st, 'I') ? 'I' : '');
                $font = self::FONTS[$fontStyle];
                $words[] = ['t' => $p, 'font' => $font, 'u' => str_contains($st, 'U'), 'w' => $this->widthOf($p, $font, $size), 'space' => false];
            }
        }
        if (!$words) {
            $this->y += $lineHeight * 0.6;
            return;
        }
        $spaceW = $this->widthOf(' ', 'Helvetica', $size);
        $lines = [];
        $cur = [];
        $curW = 0;
        foreach ($words as $wd) {
            $avail = $width - (count($lines) === 0 ? $indent : 0);
            $prevSpace = $cur ? $cur[count($cur) - 1]['space'] : false;
            $add = ($cur && $prevSpace ? $spaceW : 0) + $wd['w'];
            if ($cur && $curW + $add > $avail) {
                $lines[] = [$cur, $curW];
                $cur = [];
                $curW = 0;
                $add = $wd['w'];
            }
            $cur[] = $wd;
            $curW += $add;
        }
        $lines[] = [$cur, $curW];

        foreach ($lines as $li => [$lw, $lineW]) {
            $this->ensureSpace($lineHeight);
            $lx = $x + ($li === 0 ? $indent : 0);
            $avail = $width - ($li === 0 ? $indent : 0);
            $gap = $spaceW;
            if ($align === 'C') {
                $lx += ($avail - $lineW) / 2;
            } elseif ($align === 'R') {
                $lx += $avail - $lineW;
            } elseif ($align === 'J' && $li < count($lines) - 1 && count($lw) > 1) {
                $gaps = count(array_filter(array_slice($lw, 0, -1), static fn($x) => $x['space']));
                $gap = $gaps ? $spaceW + ($avail - $lineW) / $gaps : $spaceW;
            }
            foreach ($lw as $i => $wd) {
                $this->font = $wd['font'];
                $this->size = $size;
                $this->usedFonts[$wd['font']] = true;
                $this->text($lx, $this->y, $wd['t']);
                if ($wd['u']) {
                    $this->strokeColor(20, 20, 20);
                    $this->line($lx, $this->y + $size * 0.95, $lx + $wd['w'] + ($i < count($lw) - 1 && $wd['space'] ? $gap : 0), $this->y + $size * 0.95, 0.5);
                }
                $lx += $wd['w'] + ($wd['space'] ? $gap : 0);
            }
            $this->y += $lineHeight;
        }
        $this->setFont('', $size);
    }

    // ------------------------------------------------------------ output

    public function output(): string
    {
        if ($this->page < 0) {
            $this->addPage();
        }
        if ($this->onPageEnd) {
            ($this->onPageEnd)($this);
            $this->onPageEnd = null;
        }
        $total = (string) count($this->pages);
        $objects = [];
        $fontNames = array_values(self::FONTS);

        // 1 catalog, 2 pages, 3..6 fonts, then images, then page + content objects.
        $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        foreach ($fontNames as $i => $name) {
            $objects[3 + $i] = "<< /Type /Font /Subtype /Type1 /BaseFont /$name /Encoding /WinAnsiEncoding >>";
        }
        $next = 7;
        $imgRefs = [];
        $streams = [];
        foreach ($this->images as $img) {
            $smaskRef = '';
            if (isset($img['smask'])) {
                $sid = $next++;
                $streams[$sid] = $img['smask'];
                $objects[$sid] = sprintf('<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceGray /BitsPerComponent 8 /Filter /FlateDecode /DecodeParms << /Predictor 15 /Colors 1 /BitsPerComponent 8 /Columns %d >> /Length %d >>', $img['w'], $img['h'], $img['w'], strlen($img['smask']));
                $smaskRef = " /SMask $sid 0 R";
            }
            $id = $next++;
            $imgRefs[$img['i']] = $id;
            $streams[$id] = $img['data'];
            $parms = isset($img['parms']) ? ' /DecodeParms ' . $img['parms'] : '';
            $objects[$id] = sprintf('<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s /BitsPerComponent %d /Filter /%s%s%s /Length %d >>', $img['w'], $img['h'], $img['cs'], $img['bpc'], $img['filter'], $parms, $smaskRef, strlen($img['data']));
        }
        $fontRes = '';
        foreach ($fontNames as $i => $name) {
            $fontRes .= sprintf('/F%d %d 0 R ', $i + 1, 3 + $i);
        }
        $xRes = '';
        foreach ($imgRefs as $i => $ref) {
            $xRes .= "/I$i $ref 0 R ";
        }
        $resources = "<< /Font << $fontRes>>" . ($xRes ? " /XObject << $xRes>>" : '') . ' /ProcSet [/PDF /Text /ImageB /ImageC] >>';
        $kids = [];
        foreach ($this->pages as $content) {
            $content = str_replace('{nb}', $total, $content);
            $compressed = gzcompress($content, 6);
            $cid = $next++;
            $streams[$cid] = $compressed;
            $objects[$cid] = '<< /Filter /FlateDecode /Length ' . strlen($compressed) . ' >>';
            $pid = $next++;
            $objects[$pid] = sprintf('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources %s /Contents %d 0 R >>', $this->w, $this->h, $resources, $cid);
            $kids[] = "$pid 0 R";
        }
        $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($kids) . ' >>';
        $infoId = $next++;
        $objects[$infoId] = '<< /Producer (Rejoice Baptist Church Management System) /Title (' . self::escape(self::encode($this->title)) . ') /CreationDate (D:' . date('YmdHis') . ') >>';

        ksort($objects);
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [];
        foreach ($objects as $id => $dict) {
            $offsets[$id] = strlen($pdf);
            $pdf .= "$id 0 obj\n$dict\n";
            if (isset($streams[$id])) {
                $pdf .= "stream\n" . $streams[$id] . "\nendstream\n";
            }
            $pdf .= "endobj\n";
        }
        $xref = strlen($pdf);
        $max = max(array_keys($objects));
        $pdf .= "xref\n0 " . ($max + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= $max; $i++) {
            $pdf .= isset($offsets[$i]) ? sprintf("%010d 00000 n \n", $offsets[$i]) : "0000000000 65535 f \n";
        }
        $pdf .= "trailer\n<< /Size " . ($max + 1) . " /Root 1 0 R /Info $infoId 0 R >>\nstartxref\n$xref\n%%EOF";
        return $pdf;
    }

    public function download(string $filename, bool $inline = false): never
    {
        $data = $this->output();
        header('Content-Type: application/pdf');
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . preg_replace('/[^A-Za-z0-9_.-]/', '_', $filename) . '"');
        header('Content-Length: ' . strlen($data));
        header('Cache-Control: private, no-store');
        echo $data;
        exit;
    }

    // ------------------------------------------------------------ internals

    private function out(string $s): void
    {
        if ($this->page < 0) {
            $this->addPage();
        }
        $this->pages[$this->page] .= $s . "\n";
    }

    private function fontIndex(string $font): int
    {
        return array_search($font, array_values(self::FONTS), true) + 1;
    }

    public static function encode(string $s): string
    {
        $s = strtr($s, ['₱' => 'PHP ', '–' => '-', '—' => '-', '“' => '"', '”' => '"', '‘' => "'", '’' => "'", '…' => '...', '•' => '-', '→' => '->']);
        $out = @mb_convert_encoding($s, 'Windows-1252', 'UTF-8');
        return $out === false ? preg_replace('/[^\x20-\x7E]/', '?', $s) : $out;
    }

    private static function escape(string $s): string
    {
        return strtr($s, ['\\' => '\\\\', '(' => '\\(', ')' => '\\)', "\r" => '\\r']);
    }

    private function parseImage(string $file): ?array
    {
        $info = @getimagesize($file);
        if (!$info) {
            return null;
        }
        if ($info[2] === IMAGETYPE_JPEG) {
            $cs = ($info['channels'] ?? 3) === 4 ? '/DeviceCMYK' : (($info['channels'] ?? 3) === 1 ? '/DeviceGray' : '/DeviceRGB');
            return ['w' => $info[0], 'h' => $info[1], 'cs' => $cs, 'bpc' => 8, 'filter' => 'DCTDecode', 'data' => (string) file_get_contents($file)];
        }
        if ($info[2] === IMAGETYPE_PNG) {
            return $this->parsePng($file);
        }
        // Other formats (WEBP/GIF): convert through GD when available.
        if (extension_loaded('gd')) {
            $img = @imagecreatefromstring((string) file_get_contents($file));
            if ($img) {
                $tmp = tempnam(sys_get_temp_dir(), 'pdfimg');
                imagepng($img, $tmp);
                $res = $this->parsePng($tmp);
                @unlink($tmp);
                return $res;
            }
        }
        return null;
    }

    /** PNG reader: non-interlaced, 8-bit, gray/RGB/palette with optional alpha channel. */
    private function parsePng(string $file): ?array
    {
        $f = fopen($file, 'rb');
        if (!$f || fread($f, 8) !== "\x89PNG\r\n\x1a\n") {
            return null;
        }
        fread($f, 4);
        if (fread($f, 4) !== 'IHDR') {
            return null;
        }
        $w = unpack('N', fread($f, 4))[1];
        $h = unpack('N', fread($f, 4))[1];
        $bpc = ord(fread($f, 1));
        $ct = ord(fread($f, 1));
        $comp = ord(fread($f, 1));
        $filt = ord(fread($f, 1));
        $interlace = ord(fread($f, 1));
        fread($f, 4);
        if ($bpc > 8 || $interlace || $comp || $filt) {
            fclose($f);
            return $this->viaGd($file);
        }
        $cs = match ($ct) { 0, 4 => '/DeviceGray', 2, 6 => '/DeviceRGB', 3 => 'Indexed', default => null };
        if ($cs === null) {
            fclose($f);
            return null;
        }
        $pal = '';
        $data = '';
        $trns = null;
        do {
            $n = unpack('N', fread($f, 4))[1];
            $type = fread($f, 4);
            if ($type === 'PLTE') {
                $pal = fread($f, $n);
                fread($f, 4);
            } elseif ($type === 'tRNS' || $type === 'IDAT') {
                $chunk = $n > 0 ? fread($f, $n) : '';
                if ($type === 'IDAT') {
                    $data .= $chunk;
                } else {
                    $trns = $chunk;
                }
                fread($f, 4);
            } elseif ($type === 'IEND') {
                break;
            } else {
                fread($f, $n + 4);
            }
        } while ($n !== null && !feof($f));
        fclose($f);

        if ($ct === 3 && $trns !== null) {
            return $this->viaGd($file); // palette transparency: let GD expand to RGBA
        }
        $colors = match ($ct) { 0, 4, 3 => 1, default => 3 };
        $img = ['w' => $w, 'h' => $h, 'bpc' => $bpc, 'filter' => 'FlateDecode'];
        if ($ct === 3) {
            $img['cs'] = '[/Indexed /DeviceRGB ' . (strlen($pal) / 3 - 1) . ' <' . bin2hex($pal) . '>]';
        } else {
            $img['cs'] = $cs;
        }
        if ($ct >= 4) {
            // Separate the alpha channel into a soft mask, keeping each row's filter byte.
            $raw = gzuncompress($data);
            if ($raw === false) {
                return null;
            }
            $px = $ct === 4 ? 2 : 4;
            $len = $px * $w;
            $color = '';
            $alpha = '';
            for ($i = 0; $i < $h; $i++) {
                $pos = (1 + $len) * $i;
                $color .= $raw[$pos];
                $alpha .= $raw[$pos];
                $line = substr($raw, $pos + 1, $len);
                if ($ct === 4) {
                    $color .= preg_replace('/(.)./s', '$1', $line);
                    $alpha .= preg_replace('/.(.)/s', '$1', $line);
                } else {
                    $color .= preg_replace('/(.{3})./s', '$1', $line);
                    $alpha .= preg_replace('/.{3}(.)/s', '$1', $line);
                }
            }
            $data = gzcompress($color);
            $img['smask'] = gzcompress($alpha);
        }
        $img['parms'] = sprintf('<< /Predictor 15 /Colors %d /BitsPerComponent %d /Columns %d >>', $colors, $bpc, $w);
        $img['data'] = $data;
        return $img;
    }

    private function viaGd(string $file): ?array
    {
        if (!extension_loaded('gd')) {
            return null;
        }
        $src = @imagecreatefrompng($file);
        if (!$src) {
            return null;
        }
        $w = imagesx($src);
        $h = imagesy($src);
        $dst = imagecreatetruecolor($w, $h);
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        imagecopy($dst, $src, 0, 0, 0, 0, $w, $h);
        $tmp = tempnam(sys_get_temp_dir(), 'pdfpng');
        imagepng($dst, $tmp);
        $res = $this->parsePng($tmp);
        @unlink($tmp);
        return $res;
    }
}
