<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Minimal router. Each route declares its access rule:
 *   'guest'   – only when signed out (login page)
 *   'auth'    – any signed-in user
 *   'perm.a|perm.b' – signed in and holding at least one of the permissions
 * Permissions are enforced here on the server, so typing a URL by hand cannot bypass them.
 */
final class Router
{
    private array $routes = [];

    public function get(string $path, string $handler, string $access = 'auth'): void
    {
        $this->routes[] = ['GET', $path, $handler, $access];
    }

    public function post(string $path, string $handler, string $access = 'auth'): void
    {
        $this->routes[] = ['POST', $path, $handler, $access];
    }

    public function dispatch(string $method, string $uri): void
    {
        $path = '/' . trim((string) parse_url($uri, PHP_URL_PATH), '/');
        $base = base_url();
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = '/' . trim(substr($path, strlen($base)), '/');
        }
        if ($path === '/index.php') {
            $path = '/';
        }

        $allowed = false;
        foreach ($this->routes as [$m, $pattern, $handler, $access]) {
            // {id} matches digits; {name*} matches a file path.
            $regex = '#^' . preg_replace_callback('#\{(\w+)(\*?)\}#', static fn($p) => $p[2] === '*'
                ? '(?P<' . $p[1] . '>[A-Za-z0-9/_.-]+)'
                : '(?P<' . $p[1] . '>\d+)', $pattern) . '$#';
            if (!preg_match($regex, $path, $match)) {
                continue;
            }
            $allowed = true;
            if ($m !== $method) {
                continue;
            }
            $params = array_filter($match, 'is_string', ARRAY_FILTER_USE_KEY);
            $this->run($method, $handler, $access, $params);
            return;
        }
        throw new HttpException($allowed ? 405 : 404);
    }

    private function run(string $method, string $handler, string $access, array $params): void
    {
        if ($method === 'POST') {
            Csrf::verify();
        }
        if ($access === 'public') {
            // No sign-in required (first-run setup only; the controller guards itself).
        } elseif ($access === 'guest') {
            if (Auth::check()) {
                redirect('/');
            }
        } else {
            if (!Auth::touch()) {
                flash('info', 'You were signed out after a period of inactivity. Please sign in again.');
                $this->toLogin();
            }
            if (!Auth::check()) {
                $this->toLogin();
            }
            $u = Auth::user();
            if ($u['must_change_password'] && !in_array($handler, ['ProfileController@password', 'ProfileController@updatePassword', 'AuthController@logout'], true)) {
                flash('info', 'Please set a new password before continuing.');
                redirect('/password');
            }
            if ($access !== 'auth') {
                Auth::require(...explode('|', $access));
            }
        }
        [$class, $action] = explode('@', $handler);
        $fqcn = 'App\\Controllers\\' . $class;
        $controller = new $fqcn();
        $args = array_map(static fn($v) => ctype_digit($v) ? (int) $v : $v, array_values($params));

        $controller->$action(...$args);
    }

    private function toLogin(): never
    {
        if (str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')) {
            throw new HttpException(401, 'Your session has ended. Please sign in again.');
        }
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            $_SESSION['intended'] = $_SERVER['REQUEST_URI'] ?? null;
        }
        redirect('/login');
    }
}
