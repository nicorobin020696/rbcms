<?php
declare(strict_types=1);

namespace App\Core;

/** Append-only record of important actions: who did what, to which record, and when. */
final class Audit
{
    public static function log(
        string $action,
        string $module,
        ?string $recordType = null,
        ?int $recordId = null,
        ?string $label = null,
        ?string $details = null,
        ?int $userId = null,
        ?string $userName = null
    ): void {
        $u = Auth::user();
        try {
            Database::insert('audit_logs', [
                'user_id'      => $userId ?? ($u['id'] ?? null),
                'user_name'    => $userName ?? ($u['full_name'] ?? null),
                'action'       => $action,
                'module'       => $module,
                'record_type'  => $recordType,
                'record_id'    => $recordId,
                'record_label' => $label !== null ? mb_substr($label, 0, 200) : null,
                'details'      => $details !== null ? mb_substr($details, 0, 2000) : null,
                'ip'           => client_ip(),
            ]);
        } catch (\Throwable $e) {
            error_log('Audit log failure: ' . $e->getMessage());
        }
    }

    /** Human-readable list of changed fields between two versions of a record. */
    public static function diff(array $before, array $after, array $labels): string
    {
        $changes = [];
        foreach ($labels as $field => $label) {
            $old = (string) ($before[$field] ?? '');
            $new = (string) ($after[$field] ?? '');
            if ($old !== $new) {
                $changes[] = $label . ': "' . mb_substr($old, 0, 60) . '" → "' . mb_substr($new, 0, 60) . '"';
            }
        }
        return $changes ? implode('; ', $changes) : 'No field changes';
    }
}
