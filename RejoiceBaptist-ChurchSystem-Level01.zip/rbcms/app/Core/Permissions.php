<?php
declare(strict_types=1);

namespace App\Core;

/**
 * The single source of truth for what a user may do.
 * Every route declares the permission it needs; checks happen on the server for every request.
 */
final class Permissions
{
    public const GROUPS = [
        'General' => [
            'dashboard.view'      => 'View the dashboard',
            'church.view'         => 'View church information',
            'church.manage'       => 'Edit church information',
            'announcements.view'  => 'View announcements and messages',
            'announcements.manage'=> 'Write, publish and archive announcements',
            'events.view'         => 'View events and activities',
            'events.manage'       => 'Add, edit, cancel and archive events',
            'calendar.view'       => 'View the calendar',
            'calendar.manage'     => 'Add and edit calendar schedules',
        ],
        'Members & Ministries' => [
            'members.view'        => 'View member records',
            'members.manage'      => 'Add, edit and archive members',
            'members.export'      => 'Export and print member lists',
            'ministries.view'     => 'View all ministries',
            'ministries.manage'   => 'Add and edit ministries, assign members',
            'ministry.lead'       => 'Manage own ministry (for ministry leaders)',
        ],
        'Attendance' => [
            'attendance.view'     => 'View attendance records and statistics',
            'attendance.record'   => 'Record attendance (incl. morning prayer)',
            'attendance.correct'  => 'Correct or delete saved attendance',
            'attendance.export'   => 'Export attendance reports',
        ],
        'Music Team' => [
            'music.view'          => 'View worship lineups, history and statistics',
            'music.manage'        => 'Record and edit worship lineups',
        ],
        'Documents' => [
            'documents.view'      => 'View saved documents',
            'documents.create'    => 'Create and edit documents',
            'documents.confidential' => 'Access confidential documents',
            'documents.templates' => 'Manage templates and signatories',
        ],
        'Finance (confidential)' => [
            'finance.view'        => 'View financial records, budgets and reports',
            'finance.manage'      => 'Record and void transactions, manage budgets',
            'finance.export'      => 'Export and print financial reports',
        ],
        'System' => [
            'users.manage'        => 'Manage user accounts and permissions',
            'audit.view'          => 'View audit logs',
            'settings.manage'     => 'Change system settings and categories',
            'backup.manage'       => 'Create and restore backups',
        ],
    ];

    private const BASIC = ['dashboard.view', 'church.view', 'announcements.view', 'events.view', 'calendar.view'];

    /** Default roles. The Super Admin role bypasses all checks and cannot be edited. */
    public static function defaultRoles(): array
    {
        return [
            'super_admin' => ['Super Admin', 'IT administrator with full access to every module.', ['*']],
            'secretary' => ['Secretary', 'Members, ministries, attendance, announcements, events and official documents. No finance.', array_merge(self::BASIC, [
                'church.manage', 'announcements.manage', 'events.manage', 'calendar.manage',
                'members.view', 'members.manage', 'members.export', 'ministries.view', 'ministries.manage',
                'attendance.view', 'attendance.record', 'attendance.correct', 'attendance.export',
                'music.view', 'documents.view', 'documents.create', 'documents.confidential', 'documents.templates',
            ])],
            'treasurer' => ['Treasurer', 'Financial records, budgets and financial reports.', array_merge(self::BASIC, [
                'finance.view', 'finance.manage', 'finance.export',
            ])],
            'ministry_leader' => ['Ministry Leader', 'Own ministry: members, schedule and attendance.', array_merge(self::BASIC, [
                'ministry.lead',
            ])],
            'music_encoder' => ['Music Team Encoder', 'Records worship lineups, songs and team pictures.', array_merge(self::BASIC, [
                'music.view', 'music.manage',
            ])],
            'attendance_encoder' => ['Attendance Encoder', 'Records service and morning prayer attendance.', array_merge(self::BASIC, [
                'attendance.view', 'attendance.record', 'attendance.export',
            ])],
            'viewer' => ['Viewer', 'Read-only access to general church information.', self::BASIC],
        ];
    }

    public static function all(): array
    {
        $all = [];
        foreach (self::GROUPS as $perms) {
            $all += $perms;
        }
        return $all;
    }

    public static function exists(string $permission): bool
    {
        return array_key_exists($permission, self::all());
    }

    /** Permissions that must never be granted to non-finance users by accident; shown with a warning. */
    public static function isConfidential(string $permission): bool
    {
        return str_starts_with($permission, 'finance.') || $permission === 'documents.confidential'
            || in_array($permission, ['users.manage', 'backup.manage', 'settings.manage', 'audit.view'], true);
    }
}
