<?php
declare(strict_types=1);

/**
 * Route table. Third argument is the access rule enforced on the server:
 * 'public', 'guest', 'auth', or one or more permissions separated by "|".
 *
 * @var App\Core\Router $router
 */

// ---------------------------------------------------------------- authentication
$router->get('/setup', 'SetupController@show', 'public');
$router->post('/setup', 'SetupController@store', 'public');
$router->get('/login', 'AuthController@showLogin', 'guest');
$router->post('/login', 'AuthController@login', 'guest');
$router->post('/logout', 'AuthController@logout', 'auth');

$router->get('/', 'DashboardController@index', 'auth');
$router->get('/files/{path*}', 'FilesController@show', 'auth');

$router->get('/profile', 'ProfileController@show', 'auth');
$router->post('/profile', 'ProfileController@update', 'auth');
$router->post('/profile/theme', 'ProfileController@theme', 'auth');
$router->get('/password', 'ProfileController@password', 'auth');
$router->post('/password', 'ProfileController@updatePassword', 'auth');

$router->get('/notifications', 'NotificationsController@index', 'auth');
$router->get('/notifications/feed', 'NotificationsController@feed', 'auth');
$router->get('/notifications/{id}/open', 'NotificationsController@open', 'auth');
$router->post('/notifications/read-all', 'NotificationsController@readAll', 'auth');

// ---------------------------------------------------------------- church information & publications
$router->get('/church', 'ChurchController@show', 'church.view');
$router->get('/church/edit', 'ChurchController@edit', 'church.manage');
$router->post('/church', 'ChurchController@update', 'church.manage');

$router->get('/announcements', 'AnnouncementsController@index', 'announcements.view');
$router->get('/announcements/new', 'AnnouncementsController@create', 'announcements.manage');
$router->post('/announcements', 'AnnouncementsController@store', 'announcements.manage');
$router->get('/announcements/{id}', 'AnnouncementsController@show', 'announcements.view');
$router->get('/announcements/{id}/edit', 'AnnouncementsController@edit', 'announcements.manage');
$router->post('/announcements/{id}', 'AnnouncementsController@update', 'announcements.manage');
$router->post('/announcements/{id}/status', 'AnnouncementsController@status', 'announcements.manage');

$router->get('/events', 'EventsController@index', 'events.view');
$router->get('/events/new', 'EventsController@create', 'events.manage|calendar.manage');
$router->post('/events', 'EventsController@store', 'events.manage|calendar.manage');
$router->post('/events/check', 'EventsController@check', 'events.manage|calendar.manage');
$router->get('/events/{id}', 'EventsController@show', 'events.view|calendar.view');
$router->get('/events/{id}/edit', 'EventsController@edit', 'events.manage|calendar.manage');
$router->post('/events/{id}', 'EventsController@update', 'events.manage|calendar.manage');
$router->post('/events/{id}/cancel', 'EventsController@cancel', 'events.manage|calendar.manage');
$router->post('/events/{id}/archive', 'EventsController@archive', 'events.manage|calendar.manage');
$router->post('/events/{id}/restore', 'EventsController@restore', 'events.manage|calendar.manage');

$router->get('/calendar', 'CalendarController@index', 'calendar.view');
$router->get('/calendar/day', 'CalendarController@day', 'calendar.view');

// ---------------------------------------------------------------- members
$router->get('/members', 'MembersController@index', 'members.view');
$router->get('/members/export.csv', 'MembersController@exportCsv', 'members.export');
$router->get('/members/export.pdf', 'MembersController@exportPdf', 'members.export');
$router->get('/members/new', 'MembersController@create', 'members.manage');
$router->post('/members', 'MembersController@store', 'members.manage');
$router->get('/members/duplicates', 'MembersController@duplicates', 'members.manage');
$router->get('/members/{id}', 'MembersController@show', 'members.view|ministry.lead');
$router->get('/members/{id}/pdf', 'MembersController@pdf', 'members.export');
$router->get('/members/{id}/edit', 'MembersController@edit', 'members.manage');
$router->post('/members/{id}', 'MembersController@update', 'members.manage');
$router->post('/members/{id}/archive', 'MembersController@archive', 'members.manage');
$router->post('/members/{id}/restore', 'MembersController@restore', 'members.manage');

// ---------------------------------------------------------------- ministries
$router->get('/ministries', 'MinistriesController@index', 'ministries.view|ministry.lead');
$router->get('/ministries/export.csv', 'MinistriesController@exportCsv', 'ministries.view');
$router->get('/ministries/new', 'MinistriesController@create', 'ministries.manage');
$router->post('/ministries', 'MinistriesController@store', 'ministries.manage');
$router->get('/ministries/{id}', 'MinistriesController@show', 'ministries.view|ministry.lead');
$router->get('/ministries/{id}/report.pdf', 'MinistriesController@report', 'ministries.view|ministry.lead');
$router->get('/ministries/{id}/edit', 'MinistriesController@edit', 'ministries.manage|ministry.lead');
$router->post('/ministries/{id}', 'MinistriesController@update', 'ministries.manage|ministry.lead');
$router->post('/ministries/{id}/members', 'MinistriesController@addMembers', 'ministries.manage|ministry.lead');
$router->post('/ministries/{id}/members/remove', 'MinistriesController@removeMember', 'ministries.manage|ministry.lead');
$router->post('/ministries/{id}/archive', 'MinistriesController@archive', 'ministries.manage');

// ---------------------------------------------------------------- attendance & morning prayer
$router->get('/attendance', 'AttendanceController@index', 'attendance.view|attendance.record');
$router->get('/attendance/sessions', 'AttendanceController@sessions', 'attendance.view|attendance.record|ministry.lead');
$router->get('/attendance/records', 'AttendanceController@records', 'attendance.view');
$router->get('/attendance/export.csv', 'AttendanceController@exportCsv', 'attendance.export');
$router->get('/attendance/export.pdf', 'AttendanceController@exportPdf', 'attendance.export');
$router->get('/attendance/new', 'AttendanceController@create', 'attendance.record|ministry.lead');
$router->post('/attendance', 'AttendanceController@store', 'attendance.record|ministry.lead');
$router->get('/attendance/{id}', 'AttendanceController@show', 'attendance.view|attendance.record|ministry.lead');
$router->get('/attendance/{id}/pdf', 'AttendanceController@sessionPdf', 'attendance.export|ministry.lead');
$router->get('/attendance/{id}/mark', 'AttendanceController@mark', 'attendance.record|ministry.lead');
$router->post('/attendance/{id}/mark', 'AttendanceController@saveMarks', 'attendance.record|ministry.lead');
$router->post('/attendance/{id}/delete', 'AttendanceController@destroy', 'attendance.correct');

$router->get('/morning-prayer', 'MorningPrayerController@index', 'attendance.view|attendance.record');
$router->post('/morning-prayer', 'MorningPrayerController@save', 'attendance.record');

// ---------------------------------------------------------------- music team
$router->get('/music', 'MusicController@index', 'music.view');
$router->get('/music/stats', 'MusicController@stats', 'music.view');
$router->get('/music/songs', 'MusicController@songs', 'music.view');
$router->get('/music/export.csv', 'MusicController@exportCsv', 'music.view');
$router->get('/music/stats.pdf', 'MusicController@statsPdf', 'music.view');
$router->get('/music/new', 'MusicController@create', 'music.manage');
$router->post('/music', 'MusicController@store', 'music.manage');
$router->get('/music/{id}', 'MusicController@show', 'music.view');
$router->get('/music/{id}/pdf', 'MusicController@pdf', 'music.view');
$router->get('/music/{id}/edit', 'MusicController@edit', 'music.manage');
$router->post('/music/{id}', 'MusicController@update', 'music.manage');
$router->post('/music/{id}/archive', 'MusicController@archive', 'music.manage');

// ---------------------------------------------------------------- documents
$router->get('/documents', 'DocumentsController@index', 'documents.view');
$router->get('/documents/new', 'DocumentsController@choose', 'documents.create');
$router->get('/documents/compose', 'DocumentsController@create', 'documents.create');
$router->post('/documents', 'DocumentsController@store', 'documents.create');
$router->get('/documents/{id}', 'DocumentsController@show', 'documents.view');
$router->get('/documents/{id}/edit', 'DocumentsController@edit', 'documents.create');
$router->post('/documents/{id}', 'DocumentsController@update', 'documents.create');
$router->get('/documents/{id}/pdf', 'DocumentsController@pdf', 'documents.view');
$router->get('/documents/{id}/print', 'DocumentsController@print', 'documents.view');
$router->post('/documents/{id}/archive', 'DocumentsController@archive', 'documents.create');
$router->post('/documents/{id}/duplicate', 'DocumentsController@duplicate', 'documents.create');

// ---------------------------------------------------------------- finance (confidential)
$router->get('/finance', 'FinanceController@dashboard', 'finance.view');
$router->get('/finance/transactions', 'FinanceController@index', 'finance.view');
$router->get('/finance/transactions/export.csv', 'FinanceController@exportCsv', 'finance.export');
$router->get('/finance/transactions/new', 'FinanceController@create', 'finance.manage');
$router->post('/finance/transactions', 'FinanceController@store', 'finance.manage');
$router->get('/finance/transactions/{id}', 'FinanceController@show', 'finance.view');
$router->get('/finance/transactions/{id}/edit', 'FinanceController@edit', 'finance.manage');
$router->post('/finance/transactions/{id}', 'FinanceController@update', 'finance.manage');
$router->post('/finance/transactions/{id}/void', 'FinanceController@void', 'finance.manage');
$router->get('/finance/giving', 'FinanceController@giving', 'finance.view');
$router->get('/finance/budgets', 'BudgetsController@index', 'finance.view');
$router->get('/finance/budgets/new', 'BudgetsController@create', 'finance.manage');
$router->post('/finance/budgets', 'BudgetsController@store', 'finance.manage');
$router->get('/finance/budgets/{id}', 'BudgetsController@show', 'finance.view');
$router->get('/finance/budgets/{id}/edit', 'BudgetsController@edit', 'finance.manage');
$router->post('/finance/budgets/{id}', 'BudgetsController@update', 'finance.manage');
$router->get('/finance/reports', 'FinanceReportsController@index', 'finance.view');
$router->get('/finance/reports/pdf', 'FinanceReportsController@pdf', 'finance.export');
$router->get('/finance/reports/csv', 'FinanceReportsController@csv', 'finance.export');

// ---------------------------------------------------------------- system
$router->get('/users', 'UsersController@index', 'users.manage');
$router->get('/users/new', 'UsersController@create', 'users.manage');
$router->post('/users', 'UsersController@store', 'users.manage');
$router->get('/users/roles', 'RolesController@index', 'users.manage');
$router->get('/users/roles/new', 'RolesController@create', 'users.manage');
$router->post('/users/roles', 'RolesController@store', 'users.manage');
$router->get('/users/roles/{id}', 'RolesController@edit', 'users.manage');
$router->post('/users/roles/{id}', 'RolesController@update', 'users.manage');
$router->get('/users/{id}/edit', 'UsersController@edit', 'users.manage');
$router->post('/users/{id}', 'UsersController@update', 'users.manage');
$router->post('/users/{id}/password', 'UsersController@resetPassword', 'users.manage');
$router->post('/users/{id}/status', 'UsersController@toggle', 'users.manage');

$router->get('/audit', 'AuditController@index', 'audit.view');
$router->get('/audit/export.csv', 'AuditController@export', 'audit.view');

$router->get('/settings', 'SettingsController@index', 'settings.manage|backup.manage|documents.templates');
$router->get('/settings/general', 'SettingsController@general', 'settings.manage');
$router->post('/settings/general', 'SettingsController@saveGeneral', 'settings.manage');
$router->get('/settings/categories', 'SettingsController@categoryList', 'settings.manage');
$router->post('/settings/categories', 'SettingsController@saveCategory', 'settings.manage');
$router->post('/settings/sample', 'SettingsController@sampleData', 'settings.manage');
$router->get('/settings/templates', 'TemplatesController@index', 'documents.templates');
$router->get('/settings/templates/new', 'TemplatesController@create', 'documents.templates');
$router->post('/settings/templates', 'TemplatesController@store', 'documents.templates');
$router->get('/settings/templates/{id}', 'TemplatesController@edit', 'documents.templates');
$router->post('/settings/templates/{id}', 'TemplatesController@update', 'documents.templates');
$router->get('/settings/signatories', 'TemplatesController@signatories', 'documents.templates');
$router->post('/settings/signatories', 'TemplatesController@saveSignatory', 'documents.templates');
$router->get('/settings/backup', 'BackupController@index', 'backup.manage');
$router->post('/settings/backup', 'BackupController@create', 'backup.manage');
$router->get('/settings/backup/download', 'BackupController@download', 'backup.manage');
$router->post('/settings/backup/restore', 'BackupController@restore', 'backup.manage');
$router->post('/settings/backup/delete', 'BackupController@delete', 'backup.manage');
