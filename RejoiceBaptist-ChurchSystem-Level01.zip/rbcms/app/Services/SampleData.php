<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\Ids;

/**
 * Demonstration records for training and testing. Every row is tagged is_sample = 1 (and shown with a
 * "Sample" tag in the UI) so it can be removed in one step without touching real church records.
 * Names are fictional. No real church details (history, officers, finances) are invented here.
 */
final class SampleData
{
    public const TABLES = ['members', 'ministries', 'events', 'announcements', 'attendance_sessions', 'worship_lineups', 'documents', 'budgets', 'fin_transactions'];

    private const FIRST_M = ['Juan', 'Mark', 'Paolo', 'Joshua', 'Daniel', 'Samuel', 'Gabriel', 'Nathan', 'Caleb', 'Elijah', 'Joel', 'Ramon', 'Carlo', 'Miguel', 'Andrei', 'Rafael', 'Noel', 'Jericho', 'Timothy', 'Aaron'];
    private const FIRST_F = ['Maria', 'Grace', 'Joy', 'Faith', 'Hannah', 'Ruth', 'Esther', 'Leah', 'Abigail', 'Sarah', 'Rachel', 'Lydia', 'Kristine', 'Angela', 'Rose', 'Hope', 'Princess', 'Camille', 'Andrea', 'Bea'];
    private const LAST = ['Santos', 'Reyes', 'Cruz', 'Bautista', 'Ocampo', 'Garcia', 'Mendoza', 'Torres', 'Villanueva', 'Ramos', 'Aquino', 'Castillo', 'Navarro', 'Flores', 'Dela Cruz', 'Gonzales', 'Lopez', 'Fernandez', 'Mercado', 'Pascual'];
    private const SONGS = [
        ['Way Maker', 'Sinach'], ['Goodness of God', 'Bethel Music'], ['Build My Life', 'Housefires'], ['What A Beautiful Name', 'Hillsong Worship'],
        ['10,000 Reasons (Bless the Lord)', 'Matt Redman'], ['Living Hope', 'Phil Wickham'], ['Great Are You Lord', 'All Sons & Daughters'],
        ['Cornerstone', 'Hillsong Worship'], ['This Is Amazing Grace', 'Phil Wickham'], ['Raise A Hallelujah', 'Bethel Music'],
        ['King of Kings', 'Hillsong Worship'], ['Graves Into Gardens', 'Elevation Worship'], ['Blessed Be Your Name', 'Matt Redman'],
        ['How Great Is Our God', 'Chris Tomlin'], ['Good Good Father', 'Chris Tomlin'], ['Holy Spirit', 'Francesca Battistelli'],
        ['Who You Say I Am', 'Hillsong Worship'], ['Battle Belongs', 'Phil Wickham'], ['In Christ Alone', 'Keith & Kristyn Getty'], ['It Is Well With My Soul', 'Horatio Spafford'],
    ];

    private static function cat(string $type, string $code): ?int
    {
        $v = DB::value('SELECT id FROM categories WHERE type = ? AND code = ?', [$type, $code]);
        return $v ? (int) $v : null;
    }

    public static function load(): int
    {
        mt_srand(2026);
        $n = 0;
        $uid = Auth::id();
        DB::transaction(function () use (&$n, $uid) {
            // ---------------- members
            $members = [];
            for ($i = 0; $i < 48; $i++) {
                $female = $i % 2 === 1;
                $first = ($female ? self::FIRST_F : self::FIRST_M)[intdiv($i, 2) % 20];
                $last = self::LAST[($i * 7) % 20];
                $joined = date('Y-m-d', strtotime('-' . mt_rand(60, 4000) . ' days'));
                $baptized = mt_rand(1, 100) <= 70;
                $active = mt_rand(1, 100) <= 85;
                $id = DB::insert('members', [
                    'member_code' => Ids::next('member', $joined), 'first_name' => $first, 'last_name' => $last, 'middle_name' => self::LAST[($i * 3 + 5) % 20],
                    'gender' => $female ? 'female' : 'male', 'birth_date' => date('Y-m-d', strtotime('-' . mt_rand(13, 70) . ' years -' . mt_rand(0, 360) . ' days')),
                    'civil_status' => mt_rand(0, 1) ? 'Single' : 'Married', 'contact_number' => '09' . mt_rand(10, 99) . ' ' . mt_rand(100, 999) . ' ' . mt_rand(1000, 9999),
                    'address' => 'Sample address ' . ($i + 1), 'date_joined' => $joined, 'membership_status' => $active ? 'active' : 'inactive',
                    'baptism_status' => $baptized ? 'baptized' : 'unbaptized', 'baptism_date' => $baptized ? date('Y-m-d', strtotime($joined . ' +' . mt_rand(30, 300) . ' days')) : null,
                    'is_sample' => 1, 'created_by' => $uid, 'updated_by' => $uid,
                ]);
                $members[] = ['id' => $id, 'active' => $active, 'female' => $female];
                $n++;
            }
            $activeIds = array_column(array_filter($members, fn($m) => $m['active']), 'id');

            // ---------------- ministries
            $minDefs = [
                ['Music Ministry (Sample)', 'worship', 6, '18:00', '20:00', 'Practice for Sunday worship.'],
                ['Youth Ministry (Sample)', 'youth', 6, '15:00', '17:00', 'Youth fellowship and Bible study.'],
                ['Sunday School (Sample)', 'education', 0, '08:00', '09:00', 'Classes for children and adults before the worship service.'],
                ['Ushering Ministry (Sample)', 'service', null, null, null, 'Welcomes and assists during services.'],
            ];
            $ministries = [];
            foreach ($minDefs as $k => [$name, $cat, $day, $s, $e, $desc]) {
                if (DB::value('SELECT 1 FROM ministries WHERE name = ?', [$name])) { continue; }
                $pool = array_slice($activeIds, $k * 9, 11);
                $id = DB::insert('ministries', ['ministry_code' => Ids::next('ministry'), 'name' => $name, 'category_id' => self::cat('ministry', $cat), 'description' => $desc,
                    'leader_member_id' => $pool[0] ?? null, 'assistant_member_id' => $pool[1] ?? null, 'schedule_day' => $day, 'schedule_start' => $s, 'schedule_end' => $e,
                    'schedule_location' => $day === null ? null : 'Church', 'is_sample' => 1, 'created_by' => $uid]);
                foreach ($pool as $mid) { DB::query('INSERT OR IGNORE INTO ministry_members (ministry_id, member_id) VALUES (?, ?)', [$id, $mid]); }
                $ministries[$cat] = ['id' => $id, 'members' => $pool];
                $n++;
            }

            // ---------------- events (past activities, upcoming, weekly schedules)
            $y = (int) date('Y');
            $ev = [
                ['Youth Jam ' . $y, 'youth', "$y-04-18", null, '14:00', '20:00', 1, 'Praise, games and the Word for the youth.'],
                ['Vacation Bible School ' . $y, 'vbs', "$y-05-12", "$y-05-16", '08:00', '11:30', 1, 'Five-day VBS for children in the community.'],
                ['Family Day', 'fellowship', "$y-06-14", null, '08:00', '15:00', 1, 'Games and fellowship for church families.'],
                ['Fun Run for a Cause', 'outreach', "$y-03-08", null, '05:30', '09:00', 1, 'Community fun run.'],
                ['Night of Worship', 'special', "$y-08-29", null, '18:00', '21:00', 1, 'An evening of praise and worship.'],
                ['Church Anniversary Celebration', 'anniversary', "$y-10-12", null, '09:00', '13:00', 1, 'Thanksgiving service for the church anniversary.'],
                ['Christmas Cantata', 'special', "$y-12-20", null, '18:00', '20:30', 1, 'Christmas program by the music ministry.'],
                ['Year-end Thanksgiving Service', 'worship', "$y-12-31", null, '20:00', '23:59', 1, 'Thanksgiving and prayer for the new year.'],
            ];
            foreach ($ev as [$title, $cat, $start, $end, $st, $et, $act, $desc]) {
                DB::insert('events', ['event_code' => Ids::next('event', $start), 'title' => $title, 'description' => $desc, 'category_id' => self::cat('event', $cat),
                    'start_date' => $start, 'end_date' => $end, 'start_time' => $st, 'end_time' => $et, 'location' => 'Church grounds', 'is_activity' => $act,
                    'recurrence' => 'none', 'is_sample' => 1, 'created_by' => $uid, 'updated_by' => $uid,
                    'ministry_id' => $cat === 'youth' ? ($ministries['youth']['id'] ?? null) : null]);
                $n++;
            }
            $firstSunday = date('Y-m-d', strtotime('last sunday', strtotime("$y-01-08")));
            foreach ([['Sunday Worship Service', 'worship', $firstSunday, '09:30', '11:30'], ['Wednesday Prayer Meeting', 'prayer', date('Y-m-d', strtotime('wednesday', strtotime("$y-01-01"))), '19:00', '20:30']] as [$t, $c, $d, $s, $e]) {
                DB::insert('events', ['event_code' => Ids::next('event', $d), 'title' => $t, 'category_id' => self::cat('event', $c), 'start_date' => $d, 'start_time' => $s, 'end_time' => $e,
                    'location' => 'Church sanctuary', 'is_activity' => 0, 'recurrence' => 'weekly', 'is_sample' => 1, 'created_by' => $uid, 'updated_by' => $uid]);
                $n++;
            }

            // ---------------- announcements
            DB::insert('announcements', ['title' => 'Welcome to the new church system (sample)', 'body' => "This is a sample announcement.\n\nAnnouncements appear on the dashboard for every user.", 'status' => 'published', 'is_pinned' => 1, 'published_at' => now(), 'author_user_id' => $uid, 'is_sample' => 1]);
            DB::insert('announcements', ['title' => 'Prayer and fasting week (sample)', 'body' => 'Join the church in a week of prayer. Morning prayer starts at 5:00 AM daily.', 'status' => 'published', 'published_at' => date('Y-m-d H:i:s', strtotime('-3 days')), 'author_user_id' => $uid, 'is_sample' => 1]);
            $n += 2;

            // ---------------- attendance: Sundays for 9 months, morning prayer for 6 weeks
            $sunCat = self::cat('attendance', 'sunday_service');
            $mpCat = self::cat('attendance', 'morning_prayer');
            $sunday = strtotime('last sunday', strtotime('+1 day'));
            for ($w = 0; $w < 40; $w++) {
                $d = date('Y-m-d', strtotime("-$w weeks", $sunday));
                if (DB::value('SELECT 1 FROM attendance_sessions WHERE category_id = ? AND session_date = ? AND ministry_id IS NULL', [$sunCat, $d])) { continue; }
                $sid = DB::insert('attendance_sessions', ['session_code' => Ids::next('attendance', $d), 'category_id' => $sunCat, 'title' => 'Sunday Worship Service', 'session_date' => $d, 'session_time' => '09:30', 'is_sample' => 1, 'created_by' => $uid]);
                $rate = mt_rand(62, 88);
                foreach ($activeIds as $mid) {
                    DB::insert('attendance_records', ['session_id' => $sid, 'member_id' => $mid, 'status' => mt_rand(1, 100) <= $rate ? 'present' : (mt_rand(1, 4) === 1 ? 'excused' : 'absent'), 'recorded_by' => $uid]);
                }
                $n++;
            }
            $faithful = array_slice($activeIds, 0, 16);
            for ($dd = 1; $dd <= 42; $dd++) {
                $d = date('Y-m-d', strtotime("-$dd days"));
                if (DB::value('SELECT 1 FROM attendance_sessions WHERE category_id = ? AND session_date = ?', [$mpCat, $d])) { continue; }
                $sid = DB::insert('attendance_sessions', ['session_code' => Ids::next('attendance', $d), 'category_id' => $mpCat, 'title' => 'Morning Prayer', 'session_date' => $d, 'session_time' => '05:00', 'is_sample' => 1, 'created_by' => $uid]);
                foreach ($faithful as $k => $mid) {
                    DB::insert('attendance_records', ['session_id' => $sid, 'member_id' => $mid, 'status' => mt_rand(1, 100) <= (90 - $k * 4) ? 'present' : 'absent', 'recorded_by' => $uid]);
                }
                $n++;
            }
            if (isset($ministries['youth'])) {
                for ($w = 0; $w < 10; $w++) {
                    $d = date('Y-m-d', strtotime("-$w weeks", strtotime('last saturday', strtotime('+1 day'))));
                    $sid = DB::insert('attendance_sessions', ['session_code' => Ids::next('attendance', $d), 'category_id' => self::cat('attendance', 'ministry_meeting'), 'title' => 'Youth Fellowship', 'session_date' => $d, 'session_time' => '15:00', 'ministry_id' => $ministries['youth']['id'], 'is_sample' => 1, 'created_by' => $uid]);
                    foreach ($ministries['youth']['members'] as $mid) { DB::insert('attendance_records', ['session_id' => $sid, 'member_id' => $mid, 'status' => mt_rand(1, 100) <= 75 ? 'present' : 'absent', 'recorded_by' => $uid]); }
                    $n++;
                }
            }

            // ---------------- worship lineups
            $music = $ministries['worship']['members'] ?? array_slice($activeIds, 0, 11);
            $instr = DB::pairs("SELECT code, id FROM categories WHERE type = 'instrument'");
            $songIds = [];
            foreach (self::SONGS as [$t, $a]) {
                $aid = DB::value('SELECT id FROM artists WHERE name = ?', [$a]) ?: DB::insert('artists', ['name' => $a]);
                $songIds[] = DB::value('SELECT id FROM songs WHERE title = ? AND artist_id = ?', [$t, $aid]) ?: DB::insert('songs', ['title' => $t, 'artist_id' => $aid]);
            }
            for ($w = 0; $w < 24; $w++) {
                $d = date('Y-m-d', strtotime("-$w weeks", $sunday));
                if (DB::value("SELECT 1 FROM worship_lineups WHERE service_date = ? AND service_type = 'morning' AND archived_at IS NULL", [$d])) { continue; }
                $lid = DB::insert('worship_lineups', ['lineup_code' => Ids::next('lineup', $d), 'service_date' => $d, 'service_type' => 'morning', 'song_leader_member_id' => $music[$w % 3],
                    'is_sample' => 1, 'created_by' => $uid, 'updated_by' => $uid]);
                $pick = [];
                while (count($pick) < 5) { $pick[$songIds[(int) floor(pow(mt_rand(0, 1000) / 1000, 1.6) * count($songIds)) % count($songIds)]] = true; }
                $o = 1;
                foreach (array_keys($pick) as $k => $sid) { DB::insert('lineup_songs', ['lineup_id' => $lid, 'song_id' => $sid, 'category' => $k < 2 ? 'praise' : 'worship', 'sort_order' => $o++]); }
                $team = [[$music[3], 'instrumentalist', 'keyboard'], [$music[4 + $w % 2], 'instrumentalist', 'acoustic_guitar'], [$music[6], 'instrumentalist', 'bass'], [$music[7 + $w % 2], 'instrumentalist', 'drums'], [$music[9], 'backup', null], [$music[10 % count($music)], 'backup', null]];
                foreach ($team as [$mid, $role, $ins]) { DB::insert('lineup_members', ['lineup_id' => $lid, 'member_id' => $mid, 'role' => $role, 'instrument_id' => $ins ? ($instr[$ins] ?? null) : null]); }
                $n++;
            }

            // ---------------- finance (sample amounts only)
            $budgetId = DB::insert('budgets', ['budget_code' => Ids::next('budget'), 'name' => 'VBS ' . $y . ' (sample)', 'ministry_id' => $ministries['education']['id'] ?? null,
                'period_start' => "$y-04-01", 'period_end' => "$y-05-31", 'amount_cents' => 2500000, 'is_sample' => 1, 'created_by' => $uid]);
            $budget2 = DB::insert('budgets', ['budget_code' => Ids::next('budget'), 'name' => 'Youth Ministry ' . $y . ' (sample)', 'ministry_id' => $ministries['youth']['id'] ?? null,
                'period_start' => "$y-01-01", 'period_end' => "$y-12-31", 'amount_cents' => 4000000, 'is_sample' => 1, 'created_by' => $uid]);
            $n += 2;
            $txn = function (string $date, string $type, string $cat, string $desc, int $cents, ?int $budget = null) use ($uid, &$n) {
                DB::insert('fin_transactions', ['txn_code' => Ids::next('txn', $date), 'txn_date' => $date, 'txn_type' => $type, 'category_id' => self::cat($type, $cat),
                    'description' => $desc, 'amount_cents' => $cents, 'budget_id' => $budget, 'is_sample' => 1, 'recorded_by' => $uid]);
                $n++;
            };
            for ($w = 0; $w < 40; $w++) {
                $d = date('Y-m-d', strtotime("-$w weeks", $sunday));
                $txn($d, 'income', 'tithe', 'Sunday tithes', mt_rand(800, 1600) * 1000);
                $txn($d, 'income', 'offering', 'Sunday offering', mt_rand(250, 600) * 1000);
                if ($w % 6 === 0) { $txn($d, 'income', 'love_gift', 'Love gift for missions', mt_rand(100, 300) * 1000); }
            }
            for ($m = 0; $m < 10; $m++) {
                $d = date('Y-m-05', strtotime("-$m months"));
                if ($d > today()) { continue; }
                $txn($d, 'expense', 'utilities', 'Electric bill', mt_rand(450, 700) * 1000);
                $txn($d, 'expense', 'utilities', 'Water bill', mt_rand(60, 120) * 1000);
                $txn(date('Y-m-15', strtotime($d)), 'expense', 'honorarium', 'Monthly allowance', 1500000);
                $txn(date('Y-m-20', strtotime($d)), 'expense', 'ministry_exp', 'Youth fellowship snacks', mt_rand(15, 40) * 1000, $budget2);
            }
            $txn("$y-05-02", 'expense', 'event_exp', 'VBS materials and crafts', 1185000, $budgetId);
            $txn("$y-05-12", 'expense', 'event_exp', 'VBS snacks', 960000, $budgetId);
            $txn("$y-05-16", 'income', 'donation', 'VBS donation', 500000);

            // ---------------- a sample document
            $tpl = DB::one("SELECT * FROM document_templates WHERE doc_type = 'recommendation' LIMIT 1");
            if ($tpl) {
                $m = DB::one('SELECT * FROM members WHERE id = ?', [$activeIds[0]]);
                $doc = ['doc_date' => today(), 'recipient_name' => member_name($m), 'purpose' => 'a scholarship application', 'doc_type' => 'recommendation'];
                DB::insert('documents', ['doc_code' => Ids::next('document'), 'template_id' => $tpl['id'], 'doc_type' => 'recommendation', 'title' => $tpl['title'],
                    'recipient_name' => $doc['recipient_name'], 'member_id' => $m['id'], 'purpose' => $doc['purpose'], 'doc_date' => today(),
                    'body_html' => DocumentRenderer::fill($tpl['body_html'], $doc, $m), 'closing' => $tpl['closing'], 'status' => 'draft', 'is_sample' => 1, 'created_by' => $uid, 'updated_by' => $uid]);
                $n++;
            }
        });
        return $n;
    }

    public static function remove(): int
    {
        $n = 0;
        DB::transaction(function () use (&$n) {
            $mem = 'SELECT id FROM members WHERE is_sample = 1';
            DB::query("DELETE FROM attendance_records WHERE member_id IN ($mem) OR session_id IN (SELECT id FROM attendance_sessions WHERE is_sample = 1)");
            DB::query("DELETE FROM lineup_members WHERE member_id IN ($mem)");
            DB::query("UPDATE users SET member_id = NULL WHERE member_id IN ($mem)");
            foreach (['attendance_sessions', 'worship_lineups', 'documents', 'fin_transactions', 'budgets', 'announcements', 'events', 'ministries', 'members'] as $t) {
                $n += DB::query("DELETE FROM $t WHERE is_sample = 1")->rowCount();
            }
            DB::query('DELETE FROM songs WHERE id NOT IN (SELECT song_id FROM lineup_songs)');
            DB::query('DELETE FROM artists WHERE id NOT IN (SELECT artist_id FROM songs WHERE artist_id IS NOT NULL)');
        });
        return $n;
    }
}
