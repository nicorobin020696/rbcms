<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;
use DateTime;

/**
 * Builds calendar entries for a date range from:
 *   - events (one-time, multi-day, or weekly recurring schedules)
 *   - active ministries with a weekly meeting day
 * Recurring items are expanded on the fly, so nothing is duplicated in the database.
 */
final class Calendar
{
    /** @return array<string, list<array>> entries keyed by Y-m-d, sorted by time */
    public static function range(string $from, string $to, ?string $categoryFilter = null): array
    {
        $out = [];
        $params = ['from' => $from, 'to' => $to];
        $catSql = '';
        if ($categoryFilter !== null && $categoryFilter !== '' && $categoryFilter !== 'ministry') {
            $catSql = ' AND e.category_id = :cat';
            $params['cat'] = (int) $categoryFilter;
        }
        if ($categoryFilter !== 'ministry') {
            $events = DB::all(
                "SELECT e.*, c.name AS category, c.color, m.name AS ministry_name
                   FROM events e
                   LEFT JOIN categories c ON c.id = e.category_id
                   LEFT JOIN ministries m ON m.id = e.ministry_id
                  WHERE e.archived_at IS NULL
                    AND e.start_date <= :to
                    AND (
                         (e.recurrence = 'none' AND COALESCE(e.end_date, e.start_date) >= :from)
                      OR (e.recurrence = 'weekly' AND (e.recur_until IS NULL OR e.recur_until >= :from))
                    )$catSql",
                $params
            );
            foreach ($events as $e) {
                foreach (self::occurrences($e, $from, $to) as $date) {
                    $out[$date][] = [
                        'kind' => 'event', 'id' => (int) $e['id'], 'date' => $date, 'title' => $e['title'],
                        'category' => $e['category'] ?? 'Uncategorized', 'color' => $e['color'] ?? 'slate',
                        'start_time' => $e['start_time'], 'end_time' => $e['end_time'], 'location' => $e['location'],
                        'description' => $e['description'], 'cancelled' => $e['cancelled_at'] !== null,
                        'recurring' => $e['recurrence'] === 'weekly', 'is_activity' => (int) $e['is_activity'],
                        'multi_day' => $e['end_date'] && $e['end_date'] !== $e['start_date'],
                        'start_date' => $e['start_date'], 'end_date' => $e['end_date'], 'ministry' => $e['ministry_name'],
                    ];
                }
            }
        }
        if ($categoryFilter === null || $categoryFilter === '' || $categoryFilter === 'ministry') {
            $ministries = DB::all(
                "SELECT m.id, m.name, m.schedule_day, m.schedule_start, m.schedule_end, m.schedule_location, m.schedule_note, m.description
                   FROM ministries m WHERE m.archived_at IS NULL AND m.status = 'active' AND m.schedule_day IS NOT NULL"
            );
            $d = new DateTime($from);
            $end = new DateTime($to);
            while ($d <= $end) {
                $dow = (int) $d->format('w');
                foreach ($ministries as $m) {
                    if ((int) $m['schedule_day'] === $dow) {
                        $date = $d->format('Y-m-d');
                        $out[$date][] = [
                            'kind' => 'ministry', 'id' => (int) $m['id'], 'date' => $date, 'title' => $m['name'],
                            'category' => 'Weekly Ministry', 'color' => 'green', 'start_time' => $m['schedule_start'],
                            'end_time' => $m['schedule_end'], 'location' => $m['schedule_location'],
                            'description' => $m['schedule_note'] ?: $m['description'], 'cancelled' => false, 'recurring' => true,
                            'is_activity' => 0, 'multi_day' => false, 'ministry' => $m['name'],
                        ];
                    }
                }
                $d->modify('+1 day');
            }
        }
        foreach ($out as &$items) {
            usort($items, static fn($a, $b) => [$a['start_time'] ?? '00:00', $a['title']] <=> [$b['start_time'] ?? '00:00', $b['title']]);
        }
        ksort($out);
        return $out;
    }

    /** Dates on which an event occurs inside [from, to]. */
    public static function occurrences(array $e, string $from, string $to): array
    {
        $dates = [];
        if ($e['recurrence'] === 'weekly') {
            $start = new DateTime($e['start_date']);
            $limit = min($to, $e['recur_until'] ?: $to);
            $d = clone $start;
            if ($from > $e['start_date']) {
                $diff = (int) $start->diff(new DateTime($from))->days;
                $d->modify('+' . (intdiv($diff + 6, 7) * 7) . ' days');
            }
            while ($d->format('Y-m-d') <= $limit) {
                if ($d->format('Y-m-d') >= $from) {
                    $dates[] = $d->format('Y-m-d');
                }
                $d->modify('+7 days');
            }
            return $dates;
        }
        $d = new DateTime(max($from, $e['start_date']));
        $last = min($to, $e['end_date'] ?: $e['start_date']);
        while ($d->format('Y-m-d') <= $last) {
            $dates[] = $d->format('Y-m-d');
            $d->modify('+1 day');
        }
        return $dates;
    }

    /** The next calendar entry from now (today's later items included). */
    public static function nextUpcoming(): ?array
    {
        static $cache = false;
        if ($cache !== false) {
            return $cache;
        }
        $nowTime = date('H:i');
        foreach (self::range(today(), date('Y-m-d', strtotime('+21 days'))) as $date => $items) {
            foreach ($items as $it) {
                if ($it['cancelled'] || $it['kind'] !== 'event') {
                    continue;
                }
                if ($date === today() && $it['start_time'] && $it['start_time'] < $nowTime) {
                    continue;
                }
                return $cache = $it;
            }
        }
        return $cache = null;
    }

    public static function relative(string $date): string
    {
        $days = (int) round((strtotime($date) - strtotime(today())) / 86400);
        return match (true) {
            $days === 0 => 'today',
            $days === 1 => 'tomorrow',
            $days > 1 => "in $days days",
            $days === -1 => 'yesterday',
            default => abs($days) . ' days ago',
        };
    }

    /** Events on the same date whose time overlaps; used to warn before saving. */
    public static function conflicts(string $date, ?string $start, ?string $end, ?int $ignoreId = null): array
    {
        $found = [];
        foreach (self::range($date, $date)[$date] ?? [] as $it) {
            if ($it['cancelled'] || ($it['kind'] === 'event' && $it['id'] === $ignoreId)) {
                continue;
            }
            if (!$start || !$it['start_time']) {
                if (!$start && !$it['start_time']) {
                    $found[] = $it;
                }
                continue;
            }
            $aEnd = $end ?: date('H:i', strtotime($start) + 3600);
            $bEnd = $it['end_time'] ?: date('H:i', strtotime($it['start_time']) + 3600);
            if ($start < $bEnd && $it['start_time'] < $aEnd) {
                $found[] = $it;
            }
        }
        return $found;
    }
}
