<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;

/**
 * Statistics shared by dashboards. Every figure is computed from the database at request time;
 * nothing is hard-coded or cached.
 */
final class Stats
{
    public static function memberCounts(): array
    {
        $r = DB::one(
            "SELECT COUNT(*) total,
                    SUM(membership_status = 'active') active,
                    SUM(membership_status = 'inactive') inactive,
                    SUM(membership_status = 'active' AND baptism_status = 'unbaptized') active_unbaptized,
                    SUM(baptism_status = 'baptized') baptized
               FROM members WHERE archived_at IS NULL"
        );
        return array_map('intval', $r);
    }

    /** Present count per month (1..12) for a year, optionally for one attendance category. */
    public static function monthlyAttendance(int $year, ?int $categoryId = null, ?array $ministryIds = null): array
    {
        $params = ['y' => (string) $year];
        $extra = '';
        if ($categoryId) {
            $extra .= ' AND s.category_id = :c';
            $params['c'] = $categoryId;
        }
        if ($ministryIds !== null) {
            $extra .= ' AND s.ministry_id IN (' . (implode(',', array_map('intval', $ministryIds)) ?: '0') . ')';
        }
        $rows = DB::pairs(
            "SELECT CAST(strftime('%m', s.session_date) AS INTEGER) m, COUNT(*) FROM attendance_records r
               JOIN attendance_sessions s ON s.id = r.session_id
              WHERE r.status = 'present' AND strftime('%Y', s.session_date) = :y $extra GROUP BY m",
            $params
        );
        $out = [];
        for ($m = 1; $m <= 12; $m++) {
            $out[] = (int) ($rows[$m] ?? 0);
        }
        return $out;
    }

    /** Present count per year for the last N years. */
    public static function yearlyAttendance(int $years = 5): array
    {
        $from = (int) date('Y') - $years + 1;
        $rows = DB::pairs(
            "SELECT CAST(strftime('%Y', s.session_date) AS INTEGER) y, COUNT(*) FROM attendance_records r
               JOIN attendance_sessions s ON s.id = r.session_id
              WHERE r.status = 'present' AND CAST(strftime('%Y', s.session_date) AS INTEGER) >= ? GROUP BY y",
            [$from]
        );
        $out = [];
        for ($y = $from; $y <= (int) date('Y'); $y++) {
            $out[(string) $y] = (int) ($rows[$y] ?? 0);
        }
        return $out;
    }

    /** Present count per week (Monday start) for the last N weeks. */
    public static function weeklyAttendance(int $weeks = 12): array
    {
        $monday = strtotime('monday this week');
        $start = date('Y-m-d', strtotime('-' . ($weeks - 1) . ' weeks', $monday));
        $rows = DB::pairs(
            "SELECT date(s.session_date, '-' || ((CAST(strftime('%w', s.session_date) AS INTEGER) + 6) % 7) || ' days') wk, COUNT(*)
               FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id
              WHERE r.status = 'present' AND s.session_date >= ? GROUP BY wk",
            [$start]
        );
        $out = [];
        for ($i = 0; $i < $weeks; $i++) {
            $wk = date('Y-m-d', strtotime("+$i weeks", strtotime($start)));
            $out[$wk] = (int) ($rows[$wk] ?? 0);
        }
        return $out;
    }

    /** Present count per day for the last N days. */
    public static function dailyAttendance(int $days = 14, ?int $categoryId = null): array
    {
        $start = date('Y-m-d', strtotime('-' . ($days - 1) . ' days'));
        $params = [$start];
        $extra = '';
        if ($categoryId) {
            $extra = ' AND s.category_id = ?';
            $params[] = $categoryId;
        }
        $rows = DB::pairs(
            "SELECT s.session_date, COUNT(*) FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id
              WHERE r.status = 'present' AND s.session_date >= ? $extra GROUP BY s.session_date",
            $params
        );
        $out = [];
        for ($i = 0; $i < $days; $i++) {
            $d = date('Y-m-d', strtotime("+$i days", strtotime($start)));
            $out[$d] = (int) ($rows[$d] ?? 0);
        }
        return $out;
    }

    public static function presentBetween(string $from, string $to): int
    {
        return (int) DB::value(
            "SELECT COUNT(*) FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id
              WHERE r.status = 'present' AND s.session_date BETWEEN ? AND ?",
            [$from, $to]
        );
    }

    public static function byCategory(string $from, string $to): array
    {
        return DB::all(
            "SELECT c.name, COUNT(r.id) total FROM categories c
               JOIN attendance_sessions s ON s.category_id = c.id AND s.session_date BETWEEN :f AND :t
               JOIN attendance_records r ON r.session_id = s.id AND r.status = 'present'
              WHERE c.type = 'attendance' GROUP BY c.id ORDER BY total DESC",
            ['f' => $from, 't' => $to]
        );
    }

    public static function byMinistry(string $from, string $to): array
    {
        return DB::all(
            "SELECT mi.name, COUNT(r.id) total FROM ministries mi
               JOIN attendance_sessions s ON s.ministry_id = mi.id AND s.session_date BETWEEN :f AND :t
               JOIN attendance_records r ON r.session_id = s.id AND r.status = 'present'
              GROUP BY mi.id ORDER BY total DESC",
            ['f' => $from, 't' => $to]
        );
    }

    /** Song usage ranking within an optional date range. */
    public static function topSongs(int $limit = 10, ?string $from = null, ?string $to = null): array
    {
        [$w, $p] = self::lineupRange($from, $to);
        return DB::all(
            "SELECT so.id, so.title, a.name AS artist, COUNT(*) uses, MAX(l.service_date) last_used
               FROM lineup_songs ls JOIN songs so ON so.id = ls.song_id LEFT JOIN artists a ON a.id = so.artist_id
               JOIN worship_lineups l ON l.id = ls.lineup_id AND l.archived_at IS NULL $w
              GROUP BY so.id ORDER BY uses DESC, last_used DESC, so.title LIMIT $limit",
            $p
        );
    }

    public static function topArtists(int $limit = 10, ?string $from = null, ?string $to = null): array
    {
        [$w, $p] = self::lineupRange($from, $to);
        return DB::all(
            "SELECT a.name, COUNT(*) uses, COUNT(DISTINCT so.id) songs
               FROM lineup_songs ls JOIN songs so ON so.id = ls.song_id JOIN artists a ON a.id = so.artist_id
               JOIN worship_lineups l ON l.id = ls.lineup_id AND l.archived_at IS NULL $w
              GROUP BY a.id ORDER BY uses DESC, a.name LIMIT $limit",
            $p
        );
    }

    public static function topSongLeaders(int $limit = 10, ?string $from = null, ?string $to = null): array
    {
        [$w, $p] = self::lineupRange($from, $to);
        return DB::all(
            "SELECT m.id, m.first_name, m.last_name, m.middle_name, m.suffix, COUNT(*) uses
               FROM worship_lineups l JOIN members m ON m.id = l.song_leader_member_id
              WHERE l.archived_at IS NULL $w
              GROUP BY m.id ORDER BY uses DESC, m.last_name LIMIT $limit",
            $p
        );
    }

    public static function topInstrumentalists(int $limit = 10, ?string $from = null, ?string $to = null): array
    {
        [$w, $p] = self::lineupRange($from, $to);
        return DB::all(
            "SELECT m.id, m.first_name, m.last_name, m.middle_name, m.suffix, COUNT(*) uses,
                    GROUP_CONCAT(DISTINCT c.name) instruments
               FROM lineup_members lm JOIN members m ON m.id = lm.member_id
               JOIN worship_lineups l ON l.id = lm.lineup_id AND l.archived_at IS NULL $w
               LEFT JOIN categories c ON c.id = lm.instrument_id
              WHERE lm.role = 'instrumentalist'
              GROUP BY m.id ORDER BY uses DESC, m.last_name LIMIT $limit",
            $p
        );
    }

    public static function lineupsPerMonth(int $year): array
    {
        $rows = DB::pairs(
            "SELECT CAST(strftime('%m', service_date) AS INTEGER), COUNT(*) FROM worship_lineups
              WHERE archived_at IS NULL AND strftime('%Y', service_date) = ? GROUP BY 1",
            [(string) $year]
        );
        $out = [];
        for ($m = 1; $m <= 12; $m++) {
            $out[] = (int) ($rows[$m] ?? 0);
        }
        return $out;
    }

    public static function lineupsPerYear(): array
    {
        return array_map('intval', DB::pairs("SELECT strftime('%Y', service_date) y, COUNT(*) FROM worship_lineups WHERE archived_at IS NULL GROUP BY y ORDER BY y"));
    }

    private static function lineupRange(?string $from, ?string $to): array
    {
        $w = '';
        $p = [];
        if ($from) {
            $w .= ' AND l.service_date >= :from';
            $p['from'] = $from;
        }
        if ($to) {
            $w .= ' AND l.service_date <= :to';
            $p['to'] = $to;
        }
        return [$w, $p];
    }

    public static function monthLabels(): array
    {
        return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    }
}
