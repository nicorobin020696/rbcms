<?php
declare(strict_types=1);

namespace App\Services;

use DOMDocument;
use DOMElement;
use DOMNode;

/**
 * Allow-list sanitizer for the document editor and converter to PDF "blocks".
 * Only simple formatting survives: paragraphs, line breaks, bold, italic, underline, lists, alignment.
 */
final class RichText
{
    private const BLOCK = ['p', 'div', 'h1', 'h2', 'h3', 'h4', 'blockquote'];
    private const INLINE = ['b' => 'b', 'strong' => 'b', 'i' => 'i', 'em' => 'i', 'u' => 'u'];

    public static function sanitize(string $html): string
    {
        $html = trim($html);
        if ($html === '') {
            return '';
        }
        $doc = self::load($html);
        $out = '';
        foreach (self::blocks($doc->documentElement) as $b) {
            $out .= $b;
        }
        return $out;
    }

    private static function load(string $html): DOMDocument
    {
        $doc = new DOMDocument();
        libxml_use_internal_errors(true);
        $doc->loadHTML('<?xml encoding="UTF-8"><div id="root">' . $html . '</div>', LIBXML_NONET | LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        $root = $doc->getElementById('root') ?? $doc->documentElement;
        $d2 = new DOMDocument();
        $d2->appendChild($d2->importNode($root, true));
        return $d2;
    }

    /** Converts the children of $node into a list of clean block HTML strings. */
    private static function blocks(DOMNode $node): array
    {
        $out = [];
        $inline = '';
        $flush = function (string $align = '') use (&$inline, &$out) {
            if (trim(strip_tags($inline, '<br>')) !== '' || str_contains($inline, '<br>')) {
                $out[] = '<p' . $align . '>' . trim($inline) . '</p>';
            }
            $inline = '';
        };
        foreach ($node->childNodes as $child) {
            $name = strtolower($child->nodeName);
            if ($child instanceof DOMElement && in_array($name, self::BLOCK, true)) {
                $flush();
                $align = self::align($child);
                $inner = self::inline($child);
                $nested = self::hasBlockChildren($child);
                if ($nested) {
                    foreach (self::blocks($child) as $b) { $out[] = $b; }
                } elseif (trim(strip_tags($inner)) !== '') {
                    $tag = in_array($name, ['h1', 'h2', 'h3', 'h4'], true) ? 'h3' : 'p';
                    $out[] = "<$tag$align>" . trim($inner) . "</$tag>";
                } else {
                    $out[] = '<p><br></p>';
                }
            } elseif ($child instanceof DOMElement && ($name === 'ul' || $name === 'ol')) {
                $flush();
                $items = '';
                foreach ($child->childNodes as $li) {
                    if ($li instanceof DOMElement && strtolower($li->nodeName) === 'li') {
                        $t = trim(self::inline($li));
                        if (trim(strip_tags($t)) !== '') { $items .= '<li>' . $t . '</li>'; }
                    }
                }
                if ($items !== '') { $out[] = "<$name>$items</$name>"; }
            } else {
                $inline .= self::inlineNode($child);
            }
        }
        $flush();
        return $out;
    }

    private static function hasBlockChildren(DOMNode $n): bool
    {
        foreach ($n->childNodes as $c) {
            if ($c instanceof DOMElement && (in_array(strtolower($c->nodeName), self::BLOCK, true) || in_array(strtolower($c->nodeName), ['ul', 'ol'], true))) {
                return true;
            }
        }
        return false;
    }

    private static function align(DOMElement $el): string
    {
        $style = strtolower($el->getAttribute('style') . ' ' . $el->getAttribute('align'));
        if (preg_match('/(?:text-align\s*:\s*)?\b(center|right|justify)\b/', $style, $m)) {
            return ' style="text-align:' . $m[1] . '"';
        }
        return '';
    }

    private static function inline(DOMNode $n): string
    {
        $s = '';
        foreach ($n->childNodes as $c) {
            $s .= self::inlineNode($c);
        }
        return $s;
    }

    private static function inlineNode(DOMNode $c): string
    {
        if ($c->nodeType === XML_TEXT_NODE) {
            return htmlspecialchars(preg_replace('/\s+/u', ' ', $c->nodeValue), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        if (!$c instanceof DOMElement) {
            return '';
        }
        $name = strtolower($c->nodeName);
        if ($name === 'br') {
            return '<br>';
        }
        if (in_array($name, ['script', 'style', 'iframe', 'object', 'img', 'svg', 'math', 'template'], true)) {
            return '';
        }
        $inner = self::inline($c);
        if (isset(self::INLINE[$name])) {
            $t = self::INLINE[$name];
            return trim($inner) === '' ? $inner : "<$t>$inner</$t>";
        }
        if ($name === 'span' || $name === 'font') {
            $st = strtolower($c->getAttribute('style'));
            if (str_contains($st, 'font-weight: bold') || str_contains($st, 'font-weight:bold') || str_contains($st, 'font-weight: 700')) { $inner = "<b>$inner</b>"; }
            if (str_contains($st, 'italic')) { $inner = "<i>$inner</i>"; }
            if (str_contains($st, 'underline')) { $inner = "<u>$inner</u>"; }
        }
        return $inner;
    }

    /**
     * Blocks for the PDF writer: [['type' => p|h|li, 'align' => L|C|R|J, 'runs' => [[text, style], ...], 'n' => number]].
     */
    public static function toBlocks(string $clean): array
    {
        if (trim($clean) === '') {
            return [];
        }
        $doc = self::load($clean);
        $blocks = [];
        foreach ($doc->documentElement->childNodes as $el) {
            if (!$el instanceof DOMElement) { continue; }
            $name = strtolower($el->nodeName);
            $al = ['center' => 'C', 'right' => 'R', 'justify' => 'J'];
            preg_match('/text-align:(\w+)/', $el->getAttribute('style'), $m);
            $align = $al[$m[1] ?? ''] ?? 'L';
            if ($name === 'ul' || $name === 'ol') {
                $n = 0;
                foreach ($el->childNodes as $li) {
                    if ($li instanceof DOMElement) {
                        $n++;
                        foreach (self::lines(self::runs($li, '')) as $k => $runs) {
                            $blocks[] = ['type' => 'li', 'align' => 'L', 'runs' => $runs, 'n' => $k === 0 ? ($name === 'ol' ? $n . '.' : '-') : '', 'cont' => $k > 0];
                        }
                    }
                }
                continue;
            }
            foreach (self::lines(self::runs($el, $name === 'h3' ? 'B' : '')) as $k => $runs) {
                $blocks[] = ['type' => $name === 'h3' ? 'h' : 'p', 'align' => $align, 'runs' => $runs, 'n' => '', 'cont' => $k > 0];
            }
        }
        return $blocks;
    }

    /** Split runs at <br> markers into separate lines. */
    private static function lines(array $runs): array
    {
        $lines = [[]];
        foreach ($runs as $r) {
            if ($r === 'BR') { $lines[] = []; continue; }
            $lines[count($lines) - 1][] = $r;
        }
        return $lines;
    }

    private static function runs(DOMNode $n, string $style): array
    {
        $out = [];
        foreach ($n->childNodes as $c) {
            if ($c->nodeType === XML_TEXT_NODE) {
                $out[] = [html_entity_decode($c->nodeValue, ENT_QUOTES | ENT_HTML5, 'UTF-8'), $style];
            } elseif ($c instanceof DOMElement) {
                $nm = strtolower($c->nodeName);
                if ($nm === 'br') { $out[] = 'BR'; continue; }
                $add = ['b' => 'B', 'i' => 'I', 'u' => 'U'][$nm] ?? '';
                foreach (self::runs($c, $style . $add) as $r) { $out[] = $r; }
            }
        }
        return $out;
    }

    /** Plain-text version (search, previews). */
    public static function toText(string $clean): string
    {
        return trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags(str_replace(['</p>', '<br>', '</li>'], [' ', ' ', ' '], $clean)), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
    }
}
