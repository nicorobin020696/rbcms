<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Database as DB;
use App\Core\Settings;
use PDO;
use RuntimeException;
use ZipArchive;

/**
 * Full backups: a consistent copy of the SQLite database (VACUUM INTO) plus every uploaded file,
 * packed in one .zip with a manifest. Restores are validated first and always preceded by a safety backup.
 */
final class Backup
{
    public const REQUIRED_TABLES = ['settings', 'users', 'roles', 'members', 'attendance_sessions', 'worship_lineups', 'documents', 'fin_transactions', 'audit_logs'];

    public static function dir(): string
    {
        $d = STORAGE_PATH . '/backups';
        if (!is_dir($d)) { mkdir($d, 0770, true); }
        return $d;
    }

    /** @return array{file:string,size:int} */
    public static function create(string $kind = 'manual', ?string $by = null): array
    {
        if (!class_exists(ZipArchive::class)) {
            throw new RuntimeException('The PHP zip extension is required for backups.');
        }
        $stamp = date('Ymd-His');
        $name = "rbcms-backup-$stamp-$kind.zip";
        $path = self::dir() . '/' . $name;
        $tmpDb = sys_get_temp_dir() . '/rbcms-' . bin2hex(random_bytes(6)) . '.sqlite';
        DB::query('VACUUM INTO ' . DB::pdo()->quote($tmpDb));
        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            @unlink($tmpDb);
            throw new RuntimeException('Could not create the backup file. Check that storage/backups is writable.');
        }
        $zip->addFile($tmpDb, 'database.sqlite');
        $files = 0;
        $uploads = STORAGE_PATH . '/uploads';
        if (is_dir($uploads)) {
            $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($uploads, \FilesystemIterator::SKIP_DOTS));
            foreach ($it as $f) {
                if ($f->isFile()) {
                    $rel = 'uploads/' . str_replace('\\', '/', substr($f->getPathname(), strlen($uploads) + 1));
                    $zip->addFile($f->getPathname(), $rel);
                    $files++;
                }
            }
        }
        $manifest = [
            'app' => 'Rejoice Baptist Church Management System', 'format' => 1, 'kind' => $kind, 'created_at' => date('c'), 'created_by' => $by,
            'php' => PHP_VERSION, 'db_sha256' => hash_file('sha256', $tmpDb), 'uploads' => $files,
            'migrations' => DB::column('SELECT version FROM schema_migrations ORDER BY version'),
            'counts' => ['members' => (int) DB::value('SELECT COUNT(*) FROM members'), 'users' => (int) DB::value('SELECT COUNT(*) FROM users'),
                'attendance_records' => (int) DB::value('SELECT COUNT(*) FROM attendance_records'), 'lineups' => (int) DB::value('SELECT COUNT(*) FROM worship_lineups'),
                'documents' => (int) DB::value('SELECT COUNT(*) FROM documents'), 'transactions' => (int) DB::value('SELECT COUNT(*) FROM fin_transactions')],
        ];
        $zip->addFromString('manifest.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        $zip->close();
        @unlink($tmpDb);
        self::prune();
        return ['file' => $name, 'size' => (int) filesize($path)];
    }

    public static function all(): array
    {
        $out = [];
        foreach (glob(self::dir() . '/rbcms-backup-*.zip') ?: [] as $f) {
            $m = self::manifest($f);
            $out[] = ['file' => basename($f), 'size' => filesize($f), 'time' => filemtime($f), 'manifest' => $m];
        }
        usort($out, static fn($a, $b) => $b['time'] <=> $a['time']);
        return $out;
    }

    public static function manifest(string $zipPath): ?array
    {
        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::RDONLY) !== true) { return null; }
        $raw = $zip->getFromName('manifest.json');
        $zip->close();
        $m = $raw ? json_decode($raw, true) : null;
        return is_array($m) ? $m : null;
    }

    /** Safe path to a backup in the backups folder by file name (rejects anything else). */
    public static function path(string $name): ?string
    {
        if (!preg_match('/^rbcms-backup-[0-9]{8}-[0-9]{6}-[a-z-]+\.zip$/', $name)) { return null; }
        $p = self::dir() . '/' . $name;
        return is_file($p) ? $p : null;
    }

    /**
     * Validate a backup archive. Returns [true, manifest, tmpDbPath] or [false, errorMessage].
     * Checks: manifest present, entries safe (no path traversal), DB hash, SQLite integrity, required tables, at least one active Super Admin.
     */
    public static function validate(string $zipPath): array
    {
        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::RDONLY) !== true) { return [false, 'The file is not a valid ZIP archive.']; }
        $m = json_decode((string) $zip->getFromName('manifest.json'), true);
        if (!is_array($m) || ($m['format'] ?? null) !== 1) { $zip->close(); return [false, 'This is not a backup made by this system (manifest missing).']; }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $n = (string) $zip->getNameIndex($i);
            if (str_contains($n, '..') || str_starts_with($n, '/') || str_contains($n, '\\') || !($n === 'manifest.json' || $n === 'database.sqlite' || str_starts_with($n, 'uploads/'))) {
                $zip->close();
                return [false, 'The backup contains an unexpected file (' . $n . ') and was rejected.'];
            }
        }
        $tmp = sys_get_temp_dir() . '/rbcms-restore-' . bin2hex(random_bytes(6)) . '.sqlite';
        $data = $zip->getFromName('database.sqlite');
        $zip->close();
        if ($data === false) { return [false, 'The backup has no database.']; }
        file_put_contents($tmp, $data);
        unset($data);
        if (!empty($m['db_sha256']) && !hash_equals($m['db_sha256'], hash_file('sha256', $tmp))) { @unlink($tmp); return [false, 'The database inside the backup is damaged (checksum mismatch).']; }
        try {
            $pdo = new PDO('sqlite:' . $tmp, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            if ($pdo->query('PRAGMA integrity_check')->fetchColumn() !== 'ok') { throw new RuntimeException('integrity'); }
            $tables = $pdo->query("SELECT name FROM sqlite_master WHERE type = 'table'")->fetchAll(PDO::FETCH_COLUMN);
            if ($missing = array_diff(self::REQUIRED_TABLES, $tables)) { $pdo = null; @unlink($tmp); return [false, 'The backup database is missing tables: ' . implode(', ', $missing)]; }
            $sa = (int) $pdo->query("SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = 'super_admin' AND u.is_active = 1")->fetchColumn();
            $pdo = null;
            if ($sa < 1) { @unlink($tmp); return [false, 'The backup has no active Super Admin account, so nobody could sign in after restoring.']; }
        } catch (\Throwable) {
            @unlink($tmp);
            return [false, 'The database inside the backup failed the integrity check.'];
        }
        return [true, $m, $tmp];
    }

    /** Restore from a validated archive. A safety backup of the current data is made first. */
    public static function restore(string $zipPath, string $by): array
    {
        $v = self::validate($zipPath);
        if (!$v[0]) { throw new RuntimeException($v[1]); }
        [, $manifest, $tmpDb] = $v;
        $safety = self::create('before-restore', $by);

        $dbFile = (string) config('database');
        $uploads = STORAGE_PATH . '/uploads';
        $oldUploads = STORAGE_PATH . '/uploads-old-' . date('YmdHis');
        DB::disconnect();
        foreach (['-wal', '-shm'] as $sfx) { if (is_file($dbFile . $sfx)) { @unlink($dbFile . $sfx); } }
        if (!@copy($tmpDb, $dbFile)) { @unlink($tmpDb); throw new RuntimeException('Could not write the database file. Your data was not changed; a safety backup exists: ' . $safety['file']); }
        @unlink($tmpDb);
        if (is_dir($uploads)) { @rename($uploads, $oldUploads); }
        @mkdir($uploads, 0770, true);
        $zip = new ZipArchive();
        $zip->open($zipPath, ZipArchive::RDONLY);
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $n = (string) $zip->getNameIndex($i);
            if (!str_starts_with($n, 'uploads/') || str_ends_with($n, '/')) { continue; }
            $target = STORAGE_PATH . '/' . $n;
            @mkdir(dirname($target), 0770, true);
            file_put_contents($target, $zip->getFromIndex($i));
        }
        $zip->close();
        self::rrmdir($oldUploads);
        DB::migrate();
        Settings::flush();
        return ['safety' => $safety['file'], 'manifest' => $manifest];
    }

    public static function prune(): void
    {
        $keep = max(3, Settings::int('backup.keep', 30));
        $files = glob(self::dir() . '/rbcms-backup-*.zip') ?: [];
        usort($files, static fn($a, $b) => filemtime($b) <=> filemtime($a));
        foreach (array_slice($files, $keep) as $f) { @unlink($f); }
    }

    /** Called lazily on page loads: makes one automatic backup per day when enabled. */
    public static function autoDaily(): void
    {
        if (Settings::get('backup.auto_daily', '1') !== '1') { return; }
        if (glob(self::dir() . '/rbcms-backup-' . date('Ymd') . '-*.zip')) { return; }
        $lock = self::dir() . '/.auto.lock';
        $fh = @fopen($lock, 'c');
        if (!$fh || !flock($fh, LOCK_EX | LOCK_NB)) { return; }
        try {
            if (!glob(self::dir() . '/rbcms-backup-' . date('Ymd') . '-*.zip')) {
                $r = self::create('auto', 'system');
                Audit::log('backup', 'backup', null, null, $r['file'], 'Automatic daily backup', null, 'System');
            }
        } catch (\Throwable $e) {
            error_log('Automatic backup failed: ' . $e->getMessage());
        } finally {
            flock($fh, LOCK_UN);
            fclose($fh);
        }
    }

    private static function rrmdir(string $dir): void
    {
        if (!is_dir($dir)) { return; }
        $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($it as $f) { $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname()); }
        @rmdir($dir);
    }
}
