<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;
use App\Core\Pdf;
use App\Core\PdfReport;
use App\Core\Settings;
use App\Core\Upload;

/** Placeholder filling and PDF layout for letters and certificates. */
final class DocumentRenderer
{
    public const PLACEHOLDERS = [
        '{{recipient_name}}' => 'Recipient / member full name',
        '{{first_name}}' => 'Member first name',
        '{{purpose}}' => 'Purpose (from the Purpose field)',
        '{{church_name}}' => 'Church name',
        '{{member_since}}' => 'Date the member joined',
        '{{membership_status}}' => 'active / inactive',
        '{{baptism_date}}' => 'Baptism date',
        '{{baptism_place}}' => '“ at <place>” if recorded',
        '{{baptized_by}}' => '“ by <minister>” if recorded',
        '{{date_long}}' => 'e.g. 25th day of November 2026',
        '{{date}}' => 'Document date',
    ];

    public static function ordinal(int $n): string
    {
        $s = ['th', 'st', 'nd', 'rd'];
        $v = $n % 100;
        return $n . ($s[($v - 20) % 10] ?? $s[$v] ?? $s[0]);
    }

    /** Replace placeholders. Values are HTML-escaped because the body is HTML. */
    public static function fill(string $html, array $doc, ?array $member): string
    {
        $date = $doc['doc_date'] ?: today();
        $first = $member['first_name'] ?? trim(explode(' ', (string) ($doc['recipient_name'] ?? ''))[0]);
        $map = [
            '{{recipient_name}}' => $doc['recipient_name'] ?: ($member ? member_name($member) : ''),
            '{{first_name}}' => $first,
            '{{purpose}}' => $doc['purpose'] ?? '',
            '{{church_name}}' => Settings::get('church.name', 'Rejoice Baptist Church'),
            '{{member_since}}' => $member && $member['date_joined'] ? fmt_date($member['date_joined'], 'F j, Y') : '',
            '{{membership_status}}' => $member ? ($member['membership_status'] === 'active' ? 'active' : 'inactive') : '',
            '{{baptism_date}}' => $member && $member['baptism_date'] ? fmt_date($member['baptism_date'], 'F j, Y') : '',
            '{{baptism_place}}' => $member && $member['baptism_place'] ? ' at ' . $member['baptism_place'] : '',
            '{{baptized_by}}' => $member && $member['baptized_by'] ? ' by ' . $member['baptized_by'] : '',
            '{{date_long}}' => self::ordinal((int) date('j', strtotime($date))) . ' day of ' . date('F Y', strtotime($date)),
            '{{date}}' => fmt_date($date, 'F j, Y'),
        ];
        $out = $html;
        foreach ($map as $k => $v) {
            if ($v !== '') {
                $out = str_replace($k, htmlspecialchars($v, ENT_QUOTES | ENT_HTML5, 'UTF-8'), $out);
            }
        }
        return $out;
    }

    /** Placeholders still present (no data available yet). */
    public static function unresolved(string $html): array
    {
        preg_match_all('/\{\{[a-z_]+\}\}/', $html, $m);
        return array_values(array_unique($m[0]));
    }

    public static function signatories(int $docId): array
    {
        return DB::all('SELECT s.* FROM document_signatories ds JOIN signatories s ON s.id = ds.signatory_id WHERE ds.document_id = ? ORDER BY ds.sort_order, s.sort_order', [$docId]);
    }

    public static function pdf(array $d): Pdf
    {
        $pdf = new Pdf('P', $d['title']);
        $confidential = (bool) $d['confidential'];
        $pdf->onPageEnd = static function (Pdf $p) use ($confidential, $d): void {
            $p->setFont('', 7.5);
            $p->color(140);
            $p->text($p->margin, $p->h - 26, $d['doc_code'] . ($confidential ? '  ·  CONFIDENTIAL' : ''));
            $p->text($p->margin, $p->h - 26, 'Page ' . $p->pageNo() . ' of {nb}', 'R', $p->contentWidth());
        };
        $pdf->addPage();
        $m = $pdf->margin = 56;
        $pdf->y = 46;
        $cw = $pdf->w - 2 * $m;
        $cert = (bool) $d['is_certificate'];

        if ($d['show_letterhead'] || $d['show_logo']) {
            $logo = $d['show_logo'] ? PdfReport::logoFile() : null;
            if ($cert) {
                if ($logo) { $pdf->image($logo, $pdf->w / 2 - 32, $pdf->y, 64, 64); $pdf->y += 72; }
                if ($d['show_letterhead']) { self::centerHead($pdf, $cw); }
            } else {
                $top = $pdf->y;
                if ($logo) { $pdf->image($logo, $m, $top, 58, 58); }
                if ($d['show_letterhead']) {
                    $pdf->y = $top + 6;
                    self::centerHead($pdf, $cw);
                }
                $pdf->y = max($pdf->y, $top + 64);
                $pdf->strokeColor(40, 40, 40);
                $pdf->line($m, $pdf->y, $pdf->w - $m, $pdf->y, 1.1);
                $pdf->y += 22;
            }
        }

        $size = 11;
        $lh = 15.5;
        if ($cert) {
            $pdf->y += 28;
            $pdf->setFont('B', 22);
            $pdf->color(25);
            $pdf->text($m, $pdf->y, mb_strtoupper($d['title']), 'C', $cw);
            $pdf->y += 50;
        } else {
            $pdf->setFont('', $size);
            $pdf->color(30);
            $pdf->text($m, $pdf->y, fmt_date($d['doc_date'], 'F j, Y'));
            $pdf->y += 28;
            if ($d['recipient_name'] || $d['recipient_details']) {
                $pdf->setFont('B', $size);
                if ($d['recipient_name']) { $pdf->text($m, $pdf->y, $d['recipient_name']); $pdf->y += $lh; }
                $pdf->setFont('', $size);
                foreach (preg_split('/\R/', (string) $d['recipient_details']) as $line) {
                    if (trim($line) !== '') { $pdf->text($m, $pdf->y, trim($line)); $pdf->y += $lh; }
                }
                $pdf->y += 12;
            }
            if ($d['title']) {
                $pdf->setFont('B', 12.5);
                $pdf->text($m, $pdf->y, mb_strtoupper($d['title']), 'C', $cw);
                $pdf->y += 28;
            }
        }

        $pdf->color(25);
        foreach (RichText::toBlocks($d['body_html']) as $b) {
            $align = $cert && $b['align'] === 'L' ? 'C' : $b['align'];
            $runs = $b['runs'];
            $bodySize = $size;
            if ($cert && count($runs) === 1 && str_contains($runs[0][1], 'B')) {
                $bodySize = 18;
                $pdf->y += 6;
            }
            if ($b['type'] === 'h') { $bodySize = 12.5; }
            if (!$b['cont'] && $pdf->y > 60) { $pdf->y += $cert ? 6 : 4; }
            if ($b['type'] === 'li') {
                $pdf->ensureSpace($lh);
                $pdf->setFont('', $bodySize);
                $pdf->text($m + 14, $pdf->y, $b['n']);
                $pdf->richParagraph($runs, $m + 30, $cw - 30, $bodySize, $lh, 'L');
            } else {
                $pdf->richParagraph($runs, $m, $cw, $bodySize, $bodySize > 13 ? $bodySize * 1.4 : $lh, $align);
            }
            if ($bodySize === 18) { $pdf->y += 6; }
        }

        if ($d['closing'] && !$cert) {
            $pdf->y += 18;
            $pdf->ensureSpace(30);
            $pdf->setFont('', $size);
            $pdf->text($m, $pdf->y, $d['closing']);
            $pdf->y += 8;
        }

        if ($d['show_signatures'] && !empty($d['id'])) {
            $sigs = self::signatories((int) $d['id']);
            if ($sigs) {
                $pdf->y += $cert ? 40 : 14;
                $cols = min(count($sigs), $cert ? 2 : 2);
                $colW = $cw / $cols;
                foreach (array_chunk($sigs, $cols) as $row) {
                    $pdf->ensureSpace(90);
                    $y0 = $pdf->y;
                    foreach ($row as $i => $s) {
                        $x = ($cert || count($row) > 1) ? $m + $i * $colW + ($cert && count($row) === 1 ? $colW / 2 - 90 : 0) : $m;
                        if ($cert && count($row) === 1) { $x = $m + $cw / 2 - 90; }
                        $sigFile = $s['signature_path'] ? Upload::path($s['signature_path']) : null;
                        if ($sigFile) { $pdf->image($sigFile, $x + 10, $y0, 0, 42); }
                        $pdf->strokeColor(40, 40, 40);
                        $pdf->line($x, $y0 + 46, $x + 180, $y0 + 46, 0.6);
                        $pdf->setFont('B', 10.5);
                        $pdf->color(20);
                        $pdf->text($x, $y0 + 51, mb_strtoupper($s['name']), 'C', 180);
                        $pdf->setFont('', 9.5);
                        $pdf->color(70);
                        $pdf->text($x, $y0 + 64, $s['position'], 'C', 180);
                    }
                    $pdf->y = $y0 + 92;
                }
            }
        }
        return $pdf;
    }

    private static function centerHead(Pdf $pdf, float $cw): void
    {
        $m = $pdf->margin;
        $pdf->setFont('B', 16);
        $pdf->color(20);
        $pdf->text($m, $pdf->y, Settings::get('church.name', 'Rejoice Baptist Church'), 'C', $cw);
        $pdf->y += 20;
        $pdf->setFont('', 9);
        $pdf->color(85);
        foreach (array_filter([trim((string) Settings::get('church.address')), trim(implode('  ·  ', array_filter([Settings::get('church.phone'), Settings::get('church.email')])))]) as $line) {
            $pdf->text($m, $pdf->y, $line, 'C', $cw);
            $pdf->y += 12;
        }
    }
}
