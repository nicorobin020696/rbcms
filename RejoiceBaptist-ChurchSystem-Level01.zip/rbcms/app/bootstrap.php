<?php
declare(strict_types=1);

/*
 * Application bootstrap: paths, configuration, autoloading, error handling and sessions.
 * Loaded by public/index.php and by the command-line scripts in bin/.
 */

define('APP_VERSION', '1.0.0');
define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('STORAGE_PATH', BASE_PATH . '/storage');
define('PUBLIC_PATH', BASE_PATH . '/public');

spl_autoload_register(static function (string $class): void {
    if (str_starts_with($class, 'App\\')) {
        $file = APP_PATH . '/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (is_file($file)) {
            require $file;
        }
    }
});

require APP_PATH . '/Core/helpers.php';

$defaults = [
    'debug'          => false,
    'timezone'       => 'Asia/Manila',
    'database'       => STORAGE_PATH . '/database.sqlite',
    'upload_max_mb'  => 10,
    'base_url'       => '',          // leave empty: detected automatically
    'session_name'   => 'RBCMS_SESSION',
];
$local = is_file(STORAGE_PATH . '/config.php') ? (require STORAGE_PATH . '/config.php') : [];
$GLOBALS['__config'] = array_merge($defaults, is_array($local) ? $local : []);

date_default_timezone_set(config('timezone'));
mb_internal_encoding('UTF-8');

foreach (['uploads', 'backups', 'logs', 'sessions', 'cache'] as $dir) {
    if (!is_dir(STORAGE_PATH . '/' . $dir)) {
        @mkdir(STORAGE_PATH . '/' . $dir, 0770, true);
    }
}

error_reporting(E_ALL);
ini_set('display_errors', config('debug') ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', STORAGE_PATH . '/logs/php-error.log');

set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

if (PHP_SAPI !== 'cli') {
    set_exception_handler([App\Core\ErrorHandler::class, 'handle']);

    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name(config('session_name'));
    session_save_path(STORAGE_PATH . '/sessions');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', '28800');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'secure'   => $secure,
        'samesite' => 'Lax',
    ]);
    session_start();

    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-src 'self' https://www.youtube.com; object-src 'none'; base-uri 'self'; form-action 'self'");
}

App\Core\Database::migrate();
