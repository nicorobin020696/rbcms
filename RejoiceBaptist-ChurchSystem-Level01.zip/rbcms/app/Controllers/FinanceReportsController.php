<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\PdfReport;

/**
 * Financial reports. One builder produces a neutral structure (summary + tables) that is rendered
 * as HTML, PDF (marked CONFIDENTIAL) or CSV, so the three always show the same numbers.
 */
final class FinanceReportsController extends Controller
{
    public const TYPES = [
        'statement' => 'Income & expense statement', 'income' => 'Income report', 'expense' => 'Expense report',
        'giving' => 'Tithes, offerings & donations', 'budget' => 'Budget vs actual', 'ministry' => 'Ministry fund report',
        'event' => 'Event fund report', 'balance' => 'Fund balance (monthly)',
    ];

    private function period(): array
    {
        $mode = input_in('period', ['month', 'year', 'custom'], 'month');
        if ($mode === 'year') {
            $y = input_int('year') ?: (int) date('Y');
            return ["$y-01-01", "$y-12-31", "Year $y", $mode];
        }
        if ($mode === 'custom') {
            $f = input_date('from') ?: date('Y-01-01');
            $t = input_date('to') ?: today();
            if ($t < $f) { [$f, $t] = [$t, $f]; }
            return [$f, $t, fmt_date($f) . ' – ' . fmt_date($t), $mode];
        }
        $m = preg_match('/^\d{4}-\d{2}$/', query_str('month')) ? query_str('month') : date('Y-m');
        return ["$m-01", date('Y-m-t', strtotime("$m-01")), date('F Y', strtotime("$m-01")), $mode];
    }

    public function build(string $type, string $from, string $to): array
    {
        $tot = FinanceController::totals($from, $to);
        $r = ['summary' => [['Income', money($tot['income'])], ['Expenses', money($tot['expense'])], ['Net', money($tot['net'])]], 'tables' => []];
        $p = ['f' => $from, 't' => $to];
        $act = "t.voided_at IS NULL AND t.txn_date BETWEEN :f AND :t";
        $byCat = fn(string $kind) => DB::all("SELECT c.name, COUNT(*) n, SUM(t.amount_cents) total FROM fin_transactions t JOIN categories c ON c.id = t.category_id WHERE $act AND t.txn_type = '$kind' GROUP BY c.id ORDER BY total DESC", $p);
        $list = fn(string $kind) => DB::all("SELECT t.txn_code, t.txn_date, c.name category, t.description, t.payer_payee, t.reference_no, t.amount_cents FROM fin_transactions t JOIN categories c ON c.id = t.category_id WHERE $act AND t.txn_type = '$kind' ORDER BY t.txn_date, t.id", $p);
        $catTable = fn(string $heading, array $rows, int $total) => [$heading, [['Category', 3], ['Entries', 1, 'R'], ['Amount', 1.5, 'R'], ['Share', 1, 'R']],
            array_map(fn($x) => [$x['name'], $x['n'], money($x['total']), $total ? round($x['total'] / $total * 100, 1) . '%' : '—'], $rows), ['Total', array_sum(array_column($rows, 'n')), money($total), $rows ? '100%' : '']];
        $txTable = fn(string $heading, array $rows) => [$heading, [['Date', 1.1], ['ID', 1.3], ['Category', 1.4], ['Description', 3], ['Payer / payee', 1.6], ['Amount', 1.3, 'R']],
            array_map(fn($x) => [fmt_date($x['txn_date']), $x['txn_code'], $x['category'], $x['description'], $x['payer_payee'] ?? '', money($x['amount_cents'])], $rows), ['Total', '', '', count($rows) . ' entries', '', money(array_sum(array_column($rows, 'amount_cents')))]];

        switch ($type) {
            case 'statement':
                $open = FinanceController::balanceBefore($from);
                $r['summary'] = [['Opening balance', money($open)], ['Income', money($tot['income'])], ['Expenses', money($tot['expense'])], ['Closing balance', money($open + $tot['net'])]];
                $r['tables'][] = $catTable('Income by category', $byCat('income'), $tot['income']);
                $r['tables'][] = $catTable('Expenses by category', $byCat('expense'), $tot['expense']);
                break;
            case 'income':
                $r['summary'] = [['Total income', money($tot['income'])]];
                $r['tables'][] = $catTable('Income by category', $byCat('income'), $tot['income']);
                $r['tables'][] = $txTable('Income entries', $list('income'));
                break;
            case 'expense':
                $r['summary'] = [['Total expenses', money($tot['expense'])]];
                $r['tables'][] = $catTable('Expenses by category', $byCat('expense'), $tot['expense']);
                $r['tables'][] = $txTable('Expense entries', $list('expense'));
                break;
            case 'giving':
                $rows = DB::all("SELECT c.name, COUNT(*) n, SUM(t.amount_cents) total FROM fin_transactions t JOIN categories c ON c.id = t.category_id WHERE $act AND t.txn_type = 'income' AND c.grp = 'giving' GROUP BY c.id ORDER BY c.sort_order", $p);
                $sum = array_sum(array_column($rows, 'total'));
                $r['summary'] = [['Total giving', money($sum)], ['Share of all income', $tot['income'] ? round($sum / $tot['income'] * 100, 1) . '%' : '—']];
                $r['tables'][] = $catTable('Giving by type', $rows, $sum);
                $byMonth = DB::all("SELECT strftime('%Y-%m', t.txn_date) ym, SUM(t.amount_cents) total FROM fin_transactions t JOIN categories c ON c.id = t.category_id WHERE $act AND t.txn_type = 'income' AND c.grp = 'giving' GROUP BY ym ORDER BY ym", $p);
                $r['tables'][] = ['Giving per month', [['Month', 3], ['Amount', 1.5, 'R']], array_map(fn($x) => [date('F Y', strtotime($x['ym'] . '-01')), money($x['total'])], $byMonth), ['Total', money($sum)]];
                break;
            case 'budget':
                $list2 = BudgetsController::withActuals('b.period_start <= :t AND b.period_end >= :f', $p);
                $planned = array_sum(array_column($list2, 'amount_cents'));
                $spent = array_sum(array_column($list2, 'spent'));
                $r['summary'] = [['Planned', money($planned)], ['Actual spending', money($spent)], ['Remaining', money($planned - $spent)], ['Utilization', $planned ? round($spent / $planned * 100) . '%' : '—']];
                $r['tables'][] = ['Budgets overlapping this period', [['Budget', 2.6], ['Period', 2], ['Planned', 1.3, 'R'], ['Actual', 1.3, 'R'], ['Remaining', 1.3, 'R'], ['Used', .8, 'R']],
                    array_map(fn($b) => [$b['name'] . ($b['ministry'] ? ' (' . $b['ministry'] . ')' : ''), fmt_date($b['period_start'], 'j M Y') . ' – ' . fmt_date($b['period_end'], 'j M Y'), money($b['amount_cents']), money($b['spent']), money($b['amount_cents'] - $b['spent']), $b['amount_cents'] ? round($b['spent'] / $b['amount_cents'] * 100) . '%' : '—'], $list2),
                    ['Total', '', money($planned), money($spent), money($planned - $spent), '']];
                $r['note'] = 'Actual spending counts all non-voided expenses linked to each budget, regardless of date.';
                break;
            case 'ministry':
            case 'event':
                $col = $type === 'ministry' ? 't.ministry_id' : 't.event_id';
                $join = $type === 'ministry' ? 'JOIN ministries x ON x.id = t.ministry_id' : 'JOIN events x ON x.id = t.event_id';
                $name = $type === 'ministry' ? 'x.name' : "x.title || ' (' || x.start_date || ')'";
                $rows = DB::all("SELECT $name label, SUM(CASE WHEN t.txn_type='income' THEN t.amount_cents ELSE 0 END) inc, SUM(CASE WHEN t.txn_type='expense' THEN t.amount_cents ELSE 0 END) exp, COUNT(*) n
                                   FROM fin_transactions t $join WHERE $act AND $col IS NOT NULL GROUP BY $col ORDER BY label", $p);
                $inc = array_sum(array_column($rows, 'inc'));
                $exp = array_sum(array_column($rows, 'exp'));
                $r['summary'] = [['Income linked', money($inc)], ['Expenses linked', money($exp)], ['Net', money($inc - $exp)]];
                $r['tables'][] = [$type === 'ministry' ? 'Funds per ministry' : 'Funds per event', [[$type === 'ministry' ? 'Ministry' : 'Event', 3], ['Entries', .8, 'R'], ['Income', 1.4, 'R'], ['Expenses', 1.4, 'R'], ['Net', 1.4, 'R']],
                    array_map(fn($x) => [$x['label'], $x['n'], money($x['inc']), money($x['exp']), money($x['inc'] - $x['exp'])], $rows), ['Total', array_sum(array_column($rows, 'n')), money($inc), money($exp), money($inc - $exp)]];
                $r['note'] = 'Only transactions tagged with a ' . $type . ' are included.';
                break;
            case 'balance':
                $open = FinanceController::balanceBefore($from);
                $rows = DB::all("SELECT strftime('%Y-%m', t.txn_date) ym, SUM(CASE WHEN t.txn_type='income' THEN t.amount_cents ELSE 0 END) inc, SUM(CASE WHEN t.txn_type='expense' THEN t.amount_cents ELSE 0 END) exp
                                   FROM fin_transactions t WHERE $act GROUP BY ym ORDER BY ym", $p);
                $run = $open;
                $out = [];
                foreach ($rows as $x) {
                    $o = $run;
                    $run += $x['inc'] - $x['exp'];
                    $out[] = [date('F Y', strtotime($x['ym'] . '-01')), money($o), money($x['inc']), money($x['exp']), money($run)];
                }
                $r['summary'] = [['Opening balance', money($open)], ['Net change', money($tot['net'])], ['Closing balance', money($open + $tot['net'])]];
                $r['tables'][] = ['Monthly fund balance', [['Month', 2], ['Opening', 1.4, 'R'], ['Income', 1.4, 'R'], ['Expenses', 1.4, 'R'], ['Closing', 1.4, 'R']], $out, ['Total', money($open), money($tot['income']), money($tot['expense']), money($open + $tot['net'])]];
                break;
        }
        return $r;
    }

    public function index(): void
    {
        $type = input_in('type', array_keys(self::TYPES), 'statement');
        [$from, $to, $label, $mode] = $this->period();
        $this->view('finance/reports', ['title' => 'Financial reports', 'type' => $type, 'from' => $from, 'to' => $to, 'label' => $label, 'mode' => $mode,
            'report' => $this->build($type, $from, $to)]);
    }

    public function pdf(): void
    {
        $type = input_in('type', array_keys(self::TYPES), 'statement');
        [$from, $to, $label] = $this->period();
        $rep = $this->build($type, $from, $to);
        $wide = in_array($type, ['income', 'expense', 'budget'], true);
        $pdf = new PdfReport(self::TYPES[$type], $label . ' · Generated ' . date('M j, Y g:i A') . ' by ' . (user()['full_name'] ?? ''), $wide ? 'L' : 'P', true);
        $pdf->summary($rep['summary']);
        if (!empty($rep['note'])) { $pdf->note($rep['note']); }
        foreach ($rep['tables'] as [$h, $cols, $rows, $totals]) {
            $pdf->heading($h);
            $pdf->table($cols, $rows, $rows ? $totals : null, 'No transactions in this period.');
        }
        Audit::log('export', 'finance', null, null, self::TYPES[$type], 'PDF · ' . $label);
        $pdf->download('finance-' . $type . '-' . $from . '.pdf', true);
    }

    public function csv(): void
    {
        $type = input_in('type', array_keys(self::TYPES), 'statement');
        [$from, $to, $label] = $this->period();
        $rep = $this->build($type, $from, $to);
        $rows = [[self::TYPES[$type]], ['Period', $label], []];
        foreach ($rep['summary'] as [$k, $v]) { $rows[] = [$k, $v]; }
        foreach ($rep['tables'] as [$h, $cols, $data, $totals]) {
            $rows[] = [];
            $rows[] = [$h];
            $rows[] = array_column($cols, 0);
            foreach ($data as $d) { $rows[] = $d; }
            if ($data) { $rows[] = $totals; }
        }
        Audit::log('export', 'finance', null, null, self::TYPES[$type], 'CSV · ' . $label);
        Csv::download('finance-' . $type . '-' . $from . '.csv', ['Rejoice Baptist Church — CONFIDENTIAL'], $rows);
    }
}
