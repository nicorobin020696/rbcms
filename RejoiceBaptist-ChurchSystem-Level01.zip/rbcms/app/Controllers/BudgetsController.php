<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\Ids;

/** Budgets: planned amount for a period (optionally per ministry/event) vs actual expenses linked to it. */
final class BudgetsController extends Controller
{
    public static function withActuals(string $where, array $params = [], int $limit = 0): array
    {
        return DB::all("SELECT b.*, mi.name ministry, ev.title event,
                               COALESCE((SELECT SUM(t.amount_cents) FROM fin_transactions t WHERE t.budget_id = b.id AND t.voided_at IS NULL AND t.txn_type = 'expense'), 0) spent,
                               (SELECT COUNT(*) FROM fin_transactions t WHERE t.budget_id = b.id AND t.voided_at IS NULL) txns
                          FROM budgets b LEFT JOIN ministries mi ON mi.id = b.ministry_id LEFT JOIN events ev ON ev.id = b.event_id
                         WHERE $where ORDER BY b.status, b.period_end DESC, b.name" . ($limit ? " LIMIT $limit" : ''), $params);
    }

    public function index(): void
    {
        $status = input_in('status', ['active', 'closed', 'all'], 'active');
        $where = $status === 'all' ? '1=1' : 'b.status = :s';
        $params = $status === 'all' ? [] : ['s' => $status];
        if ($y = input_int('year')) { $where .= " AND (strftime('%Y', b.period_start) = :y OR strftime('%Y', b.period_end) = :y)"; $params['y'] = (string) $y; }
        $list = self::withActuals($where, $params);
        $this->view('finance/budgets', ['title' => 'Budgets', 'list' => $list, 'status' => $status,
            'planned' => array_sum(array_column($list, 'amount_cents')), 'spent' => array_sum(array_column($list, 'spent'))]);
    }

    public function show(int $id): void
    {
        $b = self::withActuals('b.id = :id', ['id' => $id])[0] ?? null;
        if (!$b) { throw new \App\Core\HttpException(404); }
        $this->view('finance/budget_show', ['title' => $b['name'], 'b' => $b,
            'txns' => DB::all("SELECT t.*, c.name category FROM fin_transactions t JOIN categories c ON c.id = t.category_id WHERE t.budget_id = ? ORDER BY t.txn_date DESC", [$id]),
            'byCat' => DB::all("SELECT c.name, SUM(t.amount_cents) total FROM fin_transactions t JOIN categories c ON c.id = t.category_id WHERE t.budget_id = ? AND t.voided_at IS NULL AND t.txn_type = 'expense' GROUP BY c.id ORDER BY total DESC", [$id])]);
    }

    public function create(): void
    {
        $this->form(['period_start' => date('Y-01-01'), 'period_end' => date('Y-12-31'), 'status' => 'active'], 'New budget');
    }

    public function edit(int $id): void
    {
        $this->form($this->find('SELECT * FROM budgets WHERE id = ?', [$id]), 'Edit budget');
    }

    private function form(array $b, string $title): void
    {
        $this->view('finance/budget_form', ['title' => $title, 'b' => $b,
            'ministries' => DB::all('SELECT id, name FROM ministries WHERE archived_at IS NULL ORDER BY name'),
            'events' => DB::all("SELECT id, title, start_date FROM events WHERE archived_at IS NULL AND is_activity = 1 ORDER BY start_date DESC LIMIT 100")]);
    }

    public function store(): void
    {
        [$d, $e] = $this->validate();
        if ($e) { $this->failed($e, '/finance/budgets/new'); }
        $id = DB::transaction(function () use ($d) {
            $d['budget_code'] = Ids::next('budget', $d['period_start']);
            $d['created_by'] = Auth::id();
            return DB::insert('budgets', $d);
        });
        Audit::log('create', 'finance', 'budget', $id, $d['name'], money($d['amount_cents']) . ' · ' . $d['period_start'] . ' to ' . $d['period_end']);
        flash('success', 'Budget created.');
        redirect("/finance/budgets/$id");
    }

    public function update(int $id): void
    {
        $before = $this->find('SELECT * FROM budgets WHERE id = ?', [$id]);
        [$d, $e] = $this->validate();
        if ($e) { $this->failed($e, "/finance/budgets/$id/edit"); }
        DB::update('budgets', $d + ['updated_at' => now()], 'id = :id', ['id' => $id]);
        Audit::log('update', 'finance', 'budget', $id, $d['name'], Audit::diff($before, $d, ['name' => 'Name', 'amount_cents' => 'Amount (centavos)', 'period_start' => 'Start', 'period_end' => 'End', 'status' => 'Status']) ?: null);
        flash('success', 'Budget saved.');
        redirect("/finance/budgets/$id");
    }

    private function validate(): array
    {
        $d = ['name' => input_str('name', 150), 'amount_cents' => parse_money(input_str('amount', 20)),
            'period_start' => input_date('period_start'), 'period_end' => input_date('period_end'),
            'ministry_id' => input_int('ministry_id'), 'event_id' => input_int('event_id'),
            'notes' => input_text('notes', 1000) ?: null, 'status' => input_in('status', ['active', 'closed'], 'active')];
        $e = [];
        if ($d['name'] === '') { $e['name'] = 'Name the budget, e.g. VBS 2026 or Youth Ministry 2026.'; }
        if ($d['amount_cents'] === null) { $e['amount'] = 'Enter the planned amount.'; }
        if (!$d['period_start']) { $e['period_start'] = 'Required.'; }
        if (!$d['period_end']) { $e['period_end'] = 'Required.'; }
        if ($d['period_start'] && $d['period_end'] && $d['period_end'] < $d['period_start']) { $e['period_end'] = 'End must be after start.'; }
        if ($d['ministry_id'] && !DB::value('SELECT 1 FROM ministries WHERE id = ?', [$d['ministry_id']])) { $d['ministry_id'] = null; }
        if ($d['event_id'] && !DB::value('SELECT 1 FROM events WHERE id = ?', [$d['event_id']])) { $d['event_id'] = null; }
        return [$d, $e];
    }
}
