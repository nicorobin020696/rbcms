<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Database as DB;
use App\Core\Ids;
use App\Core\Settings;
use App\Core\Upload;

final class SettingsController extends Controller
{
    public const COLORS = ['blue', 'violet', 'teal', 'amber', 'green', 'rose', 'indigo', 'cyan', 'slate', 'orange'];
    public const CAT_TYPES = ['event' => 'Event categories', 'attendance' => 'Attendance activities', 'income' => 'Income categories', 'expense' => 'Expense categories', 'instrument' => 'Instruments'];

    public function index(): void
    {
        redirect(can('settings.manage') ? '/settings/general' : (can('documents.templates') ? '/settings/templates' : '/settings/backup'));
    }

    public function general(): void
    {
        $this->view('settings/general', ['title' => 'Settings', 's' => Settings::many(''),
            'samples' => [
                'members' => (int) DB::value('SELECT COUNT(*) FROM members WHERE is_sample = 1'),
                'all' => array_sum(array_map(static fn($t) => (int) DB::value("SELECT COUNT(*) FROM $t WHERE is_sample = 1"), \App\Services\SampleData::TABLES)),
            ]]);
    }

    public function saveGeneral(): void
    {
        $section = input_in('section', ['branding', 'ids', 'security', 'system'], '');
        $e = [];
        $changes = [];
        $set = function (string $k, string $v) use (&$changes) {
            if ((string) Settings::get($k) !== $v) { Settings::set($k, $v); $changes[] = $k; }
        };
        if ($section === 'branding') {
            [$logo, $err] = Upload::image('logo', 'branding', 600);
            if ($err) { $e['logo'] = $err; }
            elseif ($logo) {
                $old = Settings::get('church.logo');
                $set('church.logo', $logo);
                Upload::delete($old);
                // Public copy so the sign-in page can show the logo without a session.
                if (($p = Upload::path($logo)) && function_exists('imagecreatefromstring') && ($img = @imagecreatefromstring((string) file_get_contents($p)))) {
                    imagesavealpha($img, true);
                    imagepng($img, PUBLIC_PATH . '/assets/img/custom-logo.png');
                    imagedestroy($img);
                }
            }
            if (!empty($_POST['remove_logo'])) {
                Upload::delete(Settings::get('church.logo'));
                $set('church.logo', '');
                @unlink(PUBLIC_PATH . '/assets/img/custom-logo.png');
            }
        } elseif ($section === 'ids') {
            $prefix = strtoupper(input_str('member_prefix', 10));
            if (!preg_match('/^[A-Z0-9]{1,10}$/', $prefix)) { $e['member_prefix'] = 'Use 1–10 letters or numbers.'; }
            $digits = input_int('member_digits') ?? 4;
            if ($digits < 3 || $digits > 8) { $e['member_digits'] = 'Choose 3 to 8 digits.'; }
            $sep = input_in('separator', ['-', '', '/', '.'], '-');
            if (!$e) {
                $set('ids.member_prefix', $prefix);
                $set('ids.member_digits', (string) $digits);
                $set('ids.member_year', input_str('member_year') === '1' ? '1' : '0');
                $set('ids.separator', $sep);
            }
        } elseif ($section === 'security') {
            $t = input_int('session_timeout') ?? 30;
            $a = input_int('max_attempts') ?? 5;
            $l = input_int('lockout_minutes') ?? 15;
            if ($t < 5 || $t > 480) { $e['session_timeout'] = 'Between 5 and 480 minutes.'; }
            if ($a < 3 || $a > 20) { $e['max_attempts'] = 'Between 3 and 20.'; }
            if ($l < 1 || $l > 1440) { $e['lockout_minutes'] = 'Between 1 and 1440 minutes.'; }
            if (!$e) {
                $set('security.session_timeout', (string) $t);
                $set('security.max_attempts', (string) $a);
                $set('security.lockout_minutes', (string) $l);
            }
        } elseif ($section === 'system') {
            $set('app.default_theme', input_in('default_theme', ['system', 'light', 'dark'], 'system'));
            $set('backup.auto_daily', input_str('auto_daily') === '1' ? '1' : '0');
            $keep = input_int('keep') ?? 30;
            if ($keep < 3 || $keep > 365) { $e['keep'] = 'Keep between 3 and 365 backups.'; } else { $set('backup.keep', (string) $keep); }
        }
        if ($e) { $this->failed($e, '/settings/general#' . $section); }
        if ($changes) { Audit::log('update', 'settings', 'settings', null, ucfirst($section), 'Changed: ' . implode(', ', $changes)); }
        flash('success', $changes ? 'Settings saved.' : 'No changes.');
        redirect('/settings/general#' . $section);
    }

    public function categoryList(): void
    {
        $type = input_in('type', array_keys(self::CAT_TYPES), 'event');
        $usage = match ($type) {
            'event' => 'SELECT COUNT(*) FROM events WHERE category_id = c.id',
            'attendance' => 'SELECT COUNT(*) FROM attendance_sessions WHERE category_id = c.id',
            'income', 'expense' => 'SELECT COUNT(*) FROM fin_transactions WHERE category_id = c.id',
            'instrument' => 'SELECT COUNT(*) FROM lineup_members WHERE instrument_id = c.id',
        };
        $this->view('settings/categories', ['title' => 'Categories', 'type' => $type,
            'list' => DB::all("SELECT c.*, ($usage) used FROM categories c WHERE c.type = ? ORDER BY c.is_active DESC, c.sort_order, c.name", [$type]),
            'edit' => ($id = input_int('edit')) ? DB::one('SELECT * FROM categories WHERE id = ? AND type = ?', [$id, $type]) : null]);
    }

    public function saveCategory(): void
    {
        $type = input_in('type', array_keys(self::CAT_TYPES), '');
        if (in_array($type, ['income', 'expense'], true) && !can('finance.manage')) {
            throw new \App\Core\HttpException(403, 'Finance categories can only be changed by finance managers.');
        }
        $id = input_int('id');
        $before = $id ? $this->find('SELECT * FROM categories WHERE id = ? AND type = ?', [$id, $type]) : null;
        $d = ['name' => input_str('name', 60), 'color' => input_in('color', self::COLORS, 'slate'), 'sort_order' => input_int('sort_order') ?? 0,
            'is_active' => input_str('is_active') === '1' ? 1 : 0];
        if ($type === 'income') { $d['grp'] = input_str('grp') === 'giving' ? 'giving' : null; }
        $back = '/settings/categories?type=' . $type . ($id ? '&edit=' . $id : '');
        if ($d['name'] === '') { $this->failed(['name' => 'Name is required.'], $back); }
        if (DB::value('SELECT 1 FROM categories WHERE type = ? AND name = ? COLLATE NOCASE AND id <> ?', [$type, $d['name'], $id ?? 0])) { $this->failed(['name' => 'This name already exists.'], $back); }
        if ($before && $before['is_system']) { $d['is_active'] = 1; }
        if ($before) {
            DB::update('categories', $d, 'id = :id', ['id' => $id]);
            Audit::log('update', 'settings', 'category', $id, $type . ': ' . $d['name'], Audit::diff($before, $d, ['name' => 'Name', 'color' => 'Color', 'is_active' => 'Active']) ?: null);
        } else {
            $id = DB::insert('categories', $d + ['type' => $type]);
            Audit::log('create', 'settings', 'category', $id, $type . ': ' . $d['name']);
        }
        flash('success', 'Category saved.');
        redirect('/settings/categories?type=' . $type);
    }

    public function sampleData(): void
    {
        $action = input_in('action', ['load', 'remove'], '');
        if ($action === 'load') {
            $n = \App\Services\SampleData::load();
            Audit::log('create', 'settings', null, null, 'Sample data', "Loaded $n sample records");
            flash('success', "Loaded $n sample records. They are tagged “Sample” and can be removed at any time.");
        } elseif ($action === 'remove') {
            if (input_str('confirm') !== 'REMOVE') {
                flash('error', 'Type REMOVE to confirm.');
                redirect('/settings/general#sample');
            }
            $n = \App\Services\SampleData::remove();
            Audit::log('delete', 'settings', null, null, 'Sample data', "Removed $n sample records");
            flash('success', "Removed $n sample records. Real records were not touched.");
        }
        redirect('/settings/general#sample');
    }

    public static function idPreview(): string
    {
        return Ids::preview('member');
    }
}
