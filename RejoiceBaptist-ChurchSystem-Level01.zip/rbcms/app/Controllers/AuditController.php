<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Paginator;

/** Read-only audit trail. Nothing in the system can edit or delete these rows. */
final class AuditController extends Controller
{
    private function filters(): array
    {
        $w = ['1=1'];
        $p = [];
        if ($u = input_int('user')) { $w[] = 'a.user_id = :u'; $p['u'] = $u; }
        if (($m = query_str('module')) !== '') { $w[] = 'a.module = :m'; $p['m'] = $m; }
        if (($ac = query_str('action')) !== '') { $w[] = 'a.action = :ac'; $p['ac'] = $ac; }
        if ($f = input_date('from')) { $w[] = 'a.created_at >= :f'; $p['f'] = $f . ' 00:00:00'; }
        if ($t = input_date('to')) { $w[] = 'a.created_at <= :t'; $p['t'] = $t . ' 23:59:59'; }
        if (($q = query_str('q')) !== '') { $w[] = "(a.record_label LIKE :q ESCAPE '\\' OR a.details LIKE :q ESCAPE '\\' OR a.user_name LIKE :q ESCAPE '\\' OR a.ip LIKE :q ESCAPE '\\')"; $p['q'] = like($q); }
        return [implode(' AND ', $w), $p];
    }

    public function index(): void
    {
        [$w, $p] = $this->filters();
        $pg = new Paginator((int) DB::value("SELECT COUNT(*) FROM audit_logs a WHERE $w", $p), 50);
        $this->view('audit/index', [
            'title' => 'Audit logs', 'logs' => DB::all("SELECT a.* FROM audit_logs a WHERE $w ORDER BY a.id DESC" . $pg->sql(), $p), 'p' => $pg,
            'users' => DB::all('SELECT id, full_name FROM users ORDER BY full_name'),
            'modules' => DB::column('SELECT DISTINCT module FROM audit_logs ORDER BY module'),
            'actions' => DB::column('SELECT DISTINCT action FROM audit_logs ORDER BY action'),
            'failed' => (int) DB::value("SELECT COUNT(*) FROM login_attempts WHERE success = 0 AND created_at >= datetime('now','localtime','-1 day')"),
            'denied' => (int) DB::value("SELECT COUNT(*) FROM audit_logs WHERE action = 'denied' AND created_at >= datetime('now','localtime','-7 days')"),
        ]);
    }

    public function export(): void
    {
        [$w, $p] = $this->filters();
        $rows = DB::all("SELECT a.* FROM audit_logs a WHERE $w ORDER BY a.id DESC LIMIT 50000", $p);
        Audit::log('export', 'audit', null, null, 'Audit logs', 'CSV · ' . count($rows) . ' rows');
        Csv::download('audit-log-' . date('Ymd-His') . '.csv', ['Date & time', 'User', 'Action', 'Module', 'Record', 'Record ID', 'Details', 'IP address'],
            array_map(static fn($a) => [$a['created_at'], $a['user_name'], $a['action'], $a['module'], $a['record_label'], $a['record_id'], $a['details'], $a['ip']], $rows));
    }
}
