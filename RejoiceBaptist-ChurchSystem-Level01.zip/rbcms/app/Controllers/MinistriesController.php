<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Ids;
use App\Core\PdfReport;

final class MinistriesController extends Controller
{
    private const FIELDS = ['name' => 'Name', 'category_id' => 'Category', 'description' => 'Description', 'leader_member_id' => 'Leader',
        'assistant_member_id' => 'Assistant leader', 'schedule_day' => 'Meeting day', 'schedule_start' => 'Start time', 'schedule_end' => 'End time',
        'schedule_location' => 'Location', 'schedule_note' => 'Schedule notes', 'contact_info' => 'Contact', 'status' => 'Status'];

    private const SELECT = "SELECT mi.*, c.name AS category, c.color,
            l.first_name AS l_first, l.last_name AS l_last, l.middle_name AS l_middle, l.suffix AS l_suffix,
            a.first_name AS a_first, a.last_name AS a_last, a.middle_name AS a_middle, a.suffix AS a_suffix,
            (SELECT COUNT(*) FROM ministry_members mm JOIN members m ON m.id = mm.member_id AND m.archived_at IS NULL WHERE mm.ministry_id = mi.id) AS member_count
          FROM ministries mi
          LEFT JOIN categories c ON c.id = mi.category_id
          LEFT JOIN members l ON l.id = mi.leader_member_id
          LEFT JOIN members a ON a.id = mi.assistant_member_id";

    private function canSee(int $id): bool
    {
        return can('ministries.view') || Auth::leads($id);
    }

    private function canManage(int $id): bool
    {
        return can('ministries.manage') || Auth::leads($id);
    }

    public function index(): void
    {
        $where = ['mi.archived_at IS NULL'];
        $params = [];
        if (!can('ministries.view')) {
            $led = Auth::ledMinistryIds() ?: [0];
            $where[] = 'mi.id IN (' . implode(',', $led) . ')';
        }
        $status = query_str('status');
        if (in_array($status, ['active', 'inactive'], true)) {
            $where[] = 'mi.status = :status';
            $params['status'] = $status;
        }
        if (($q = query_str('q')) !== '') {
            $where[] = "(mi.name LIKE :q ESCAPE '\\' OR mi.ministry_code LIKE :q ESCAPE '\\')";
            $params['q'] = like($q);
        }
        $ministries = DB::all(self::SELECT . ' WHERE ' . implode(' AND ', $where) . ' ORDER BY mi.name COLLATE NOCASE', $params);
        $stats = can('ministries.view') ? [
            'total' => (int) DB::value('SELECT COUNT(*) FROM ministries WHERE archived_at IS NULL'),
            'active' => (int) DB::value("SELECT COUNT(*) FROM ministries WHERE archived_at IS NULL AND status = 'active'"),
            'assigned' => (int) DB::value('SELECT COUNT(DISTINCT mm.member_id) FROM ministry_members mm JOIN members m ON m.id = mm.member_id AND m.archived_at IS NULL JOIN ministries mi ON mi.id = mm.ministry_id AND mi.archived_at IS NULL'),
            'unassigned' => (int) DB::value('SELECT COUNT(*) FROM members m WHERE m.archived_at IS NULL AND NOT EXISTS (SELECT 1 FROM ministry_members mm JOIN ministries mi ON mi.id = mm.ministry_id AND mi.archived_at IS NULL WHERE mm.member_id = m.id)'),
        ] : null;
        $this->view('ministries/index', ['title' => 'Ministries', 'ministries' => $ministries, 'stats' => $stats]);
    }

    public function create(): void
    {
        $this->view('ministries/form', ['title' => 'Add ministry', 'mi' => [], 'members' => $this->memberOptions(), 'categories' => $this->categories('ministry'), 'full' => true]);
    }

    public function store(): void
    {
        [$d, $errors] = $this->validate(null, true);
        if ($errors) {
            $this->failed($errors, '/ministries/new');
        }
        $id = DB::transaction(function () use ($d) {
            $d['ministry_code'] = Ids::next('ministry');
            $d['created_by'] = Auth::id();
            $id = DB::insert('ministries', $d);
            foreach (array_filter([$d['leader_member_id'], $d['assistant_member_id']]) as $mid) {
                DB::query('INSERT OR IGNORE INTO ministry_members (ministry_id, member_id) VALUES (?, ?)', [$id, $mid]);
            }
            return $id;
        });
        Audit::log('create', 'ministries', 'ministry', $id, $d['name']);
        flash('success', "Ministry \"{$d['name']}\" was created.");
        redirect("/ministries/$id");
    }

    public function show(int $id): void
    {
        if (!$this->canSee($id)) {
            throw new HttpException(403);
        }
        $mi = $this->find(self::SELECT . ' WHERE mi.id = ?', [$id]);
        $members = DB::all(
            'SELECT m.*, mm.joined_on FROM ministry_members mm JOIN members m ON m.id = mm.member_id
              WHERE mm.ministry_id = ? AND m.archived_at IS NULL ORDER BY m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE',
            [$id]
        );
        $sessions = DB::all(
            "SELECT s.*, c.name AS category,
                    (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status = 'present') AS present,
                    (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id) AS total
               FROM attendance_sessions s JOIN categories c ON c.id = s.category_id
              WHERE s.ministry_id = ? ORDER BY s.session_date DESC, s.id DESC LIMIT 10",
            [$id]
        );
        $memberIds = array_map(static fn($m) => (int) $m['id'], $members);
        $available = $this->canManage($id) ? array_values(array_filter($this->memberOptions(), static fn($m) => !in_array((int) $m['id'], $memberIds, true))) : [];
        $upcoming = DB::all(
            "SELECT id, title, start_date, start_time FROM events WHERE ministry_id = ? AND archived_at IS NULL AND cancelled_at IS NULL AND start_date >= date('now','localtime') ORDER BY start_date LIMIT 5",
            [$id]
        );
        $this->view('ministries/show', ['title' => $mi['name'], 'mi' => $mi, 'members' => $members, 'sessions' => $sessions,
            'available' => $available, 'manage' => $this->canManage($id), 'upcoming' => $upcoming]);
    }

    public function edit(int $id): void
    {
        if (!$this->canManage($id)) {
            throw new HttpException(403);
        }
        $mi = $this->find('SELECT * FROM ministries WHERE id = ? AND archived_at IS NULL', [$id]);
        $this->view('ministries/form', ['title' => 'Edit ministry', 'mi' => $mi, 'members' => $this->memberOptions(),
            'categories' => $this->categories('ministry'), 'full' => can('ministries.manage')]);
    }

    public function update(int $id): void
    {
        if (!$this->canManage($id)) {
            throw new HttpException(403);
        }
        $before = $this->find('SELECT * FROM ministries WHERE id = ? AND archived_at IS NULL', [$id]);
        $full = can('ministries.manage');
        [$d, $errors] = $this->validate($id, $full);
        if ($errors) {
            $this->failed($errors, "/ministries/$id/edit");
        }
        $d['updated_at'] = now();
        DB::transaction(function () use ($id, $d) {
            DB::update('ministries', $d, 'id = :id', ['id' => $id]);
            foreach (array_filter([$d['leader_member_id'] ?? null, $d['assistant_member_id'] ?? null]) as $mid) {
                DB::query('INSERT OR IGNORE INTO ministry_members (ministry_id, member_id) VALUES (?, ?)', [$id, $mid]);
            }
        });
        $after = DB::one('SELECT * FROM ministries WHERE id = ?', [$id]);
        Audit::log('update', 'ministries', 'ministry', $id, $after['name'], Audit::diff($before, $after, self::FIELDS));
        if ($full && $before['leader_member_id'] !== $after['leader_member_id']) {
            Audit::log('update', 'ministries', 'ministry', $id, $after['name'], 'Ministry leader changed');
        }
        flash('success', 'Ministry details saved.');
        redirect("/ministries/$id");
    }

    public function addMembers(int $id): void
    {
        if (!$this->canManage($id)) {
            throw new HttpException(403);
        }
        $mi = $this->find('SELECT * FROM ministries WHERE id = ? AND archived_at IS NULL', [$id]);
        $ids = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['member_ids'] ?? [])))));
        if (!$ids) {
            flash('error', 'Select at least one member to add.');
            redirect("/ministries/$id");
        }
        $added = 0;
        DB::transaction(function () use ($id, $ids, $mi, &$added) {
            foreach ($ids as $mid) {
                if (!DB::value('SELECT 1 FROM members WHERE id = ? AND archived_at IS NULL', [$mid])) {
                    continue;
                }
                $n = DB::query('INSERT OR IGNORE INTO ministry_members (ministry_id, member_id) VALUES (?, ?)', [$id, $mid])->rowCount();
                if ($n) {
                    $added++;
                    DB::insert('member_history', ['member_id' => $mid, 'event' => 'ministry', 'summary' => 'Added to ' . $mi['name'], 'user_id' => Auth::id()]);
                }
            }
        });
        Audit::log('update', 'ministries', 'ministry', $id, $mi['name'], "Assigned $added member(s)");
        flash('success', $added === 1 ? '1 member was added to the ministry.' : "$added members were added to the ministry.");
        redirect("/ministries/$id");
    }

    public function removeMember(int $id): void
    {
        if (!$this->canManage($id)) {
            throw new HttpException(403);
        }
        $mi = $this->find('SELECT * FROM ministries WHERE id = ?', [$id]);
        $mid = (int) input_int('member_id');
        if (in_array($mid, [(int) $mi['leader_member_id'], (int) $mi['assistant_member_id']], true)) {
            flash('error', 'Change the leader or assistant leader before removing this member.');
            redirect("/ministries/$id");
        }
        $n = DB::query('DELETE FROM ministry_members WHERE ministry_id = ? AND member_id = ?', [$id, $mid])->rowCount();
        if ($n) {
            DB::insert('member_history', ['member_id' => $mid, 'event' => 'ministry', 'summary' => 'Removed from ' . $mi['name'], 'user_id' => Auth::id()]);
            $name = DB::one('SELECT * FROM members WHERE id = ?', [$mid]);
            Audit::log('update', 'ministries', 'ministry', $id, $mi['name'], 'Removed member ' . ($name ? member_name($name) : "#$mid"));
            flash('success', 'Member removed from the ministry.');
        }
        redirect("/ministries/$id");
    }

    public function archive(int $id): void
    {
        $mi = $this->find('SELECT * FROM ministries WHERE id = ? AND archived_at IS NULL', [$id]);
        DB::update('ministries', ['archived_at' => now(), 'status' => 'inactive'], 'id = :id', ['id' => $id]);
        Audit::log('archive', 'ministries', 'ministry', $id, $mi['name']);
        flash('success', "\"{$mi['name']}\" was archived. Its attendance history is kept.");
        redirect('/ministries');
    }

    public function exportCsv(): void
    {
        $rows = DB::all(self::SELECT . ' WHERE mi.archived_at IS NULL ORDER BY mi.name');
        Audit::log('export', 'ministries', null, null, 'Ministry list', 'CSV');
        Csv::download('ministries-' . today() . '.csv', ['Ministry ID', 'Name', 'Category', 'Leader', 'Assistant', 'Members', 'Meeting day', 'Time', 'Location', 'Contact', 'Status'],
            array_map(static fn($m) => [$m['ministry_code'], $m['name'], $m['category'], trim($m['l_first'] . ' ' . $m['l_last']), trim($m['a_first'] . ' ' . $m['a_last']),
                $m['member_count'], weekday_name($m['schedule_day'] === null ? null : (int) $m['schedule_day']), time_range($m['schedule_start'], $m['schedule_end']),
                $m['schedule_location'], $m['contact_info'], ucfirst($m['status'])], $rows));
    }

    public function report(int $id): void
    {
        if (!$this->canSee($id)) {
            throw new HttpException(403);
        }
        $mi = $this->find(self::SELECT . ' WHERE mi.id = ?', [$id]);
        $members = DB::all(
            "SELECT m.*, (SELECT COUNT(*) FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id WHERE r.member_id = m.id AND s.ministry_id = :id AND r.status = 'present') AS present,
                    (SELECT COUNT(*) FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id WHERE r.member_id = m.id AND s.ministry_id = :id) AS recorded
               FROM ministry_members mm JOIN members m ON m.id = mm.member_id WHERE mm.ministry_id = :id AND m.archived_at IS NULL
              ORDER BY m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE",
            ['id' => $id]
        );
        $sessions = DB::all(
            "SELECT s.*, (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status = 'present') present,
                    (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id) total
               FROM attendance_sessions s WHERE s.ministry_id = ? ORDER BY s.session_date DESC LIMIT 30",
            [$id]
        );
        $leader = $mi['l_first'] ? trim($mi['l_first'] . ' ' . $mi['l_last']) : 'Not assigned';
        $pdf = new PdfReport('Ministry Report — ' . $mi['name'], $mi['ministry_code'] . ' · Leader: ' . $leader . ' · Status: ' . ucfirst($mi['status']));
        $schedule = $mi['schedule_day'] !== null ? weekday_name((int) $mi['schedule_day']) . 's, ' . time_range($mi['schedule_start'], $mi['schedule_end']) : 'No regular schedule';
        $pdf->summary([['Members', count($members)], ['Meetings recorded', count($sessions)], ['Schedule', $schedule]]);
        if ($mi['description']) {
            $pdf->note($mi['description']);
        }
        $pdf->heading('Members');
        $pdf->table([['Member ID', 1.2], ['Name', 2.4], ['Contact', 1.4], ['Status', 1], ['Attendance', 1.2, 'R']],
            array_map(static fn($m) => [$m['member_code'], member_name($m, true), $m['contact_number'], ucfirst($m['membership_status']), $m['recorded'] ? $m['present'] . ' / ' . $m['recorded'] : '—'], $members));
        $pdf->heading('Recent ministry attendance');
        $pdf->table([['Date', 1.2], ['Activity', 3], ['Present', 1, 'R'], ['Recorded', 1, 'R']],
            array_map(static fn($s) => [fmt_date($s['session_date']), $s['title'], $s['present'], $s['total']], $sessions), null, 'No ministry attendance has been recorded yet.');
        Audit::log('export', 'ministries', 'ministry', $id, $mi['name'], 'Ministry report (PDF)');
        $pdf->download('ministry-' . $mi['ministry_code'] . '.pdf', true);
    }

    private function validate(?int $id, bool $full): array
    {
        $d = [
            'description' => input_text('description', 3000) ?: null,
            'schedule_day' => ($day = input_int('schedule_day')) !== null && $day >= 0 && $day <= 6 ? $day : null,
            'schedule_start' => input_time('schedule_start'), 'schedule_end' => input_time('schedule_end'),
            'schedule_location' => input_str('schedule_location', 150) ?: null, 'schedule_note' => input_str('schedule_note', 250) ?: null,
            'contact_info' => input_str('contact_info', 200) ?: null,
        ];
        $e = [];
        if ($full) {
            $d += [
                'name' => input_str('name', 120), 'category_id' => input_int('category_id'),
                'leader_member_id' => input_int('leader_member_id'), 'assistant_member_id' => input_int('assistant_member_id'),
                'status' => input_in('status', ['active', 'inactive'], 'active'),
            ];
            if ($d['name'] === '') {
                $e['name'] = 'Ministry name is required.';
            } elseif (DB::value('SELECT 1 FROM ministries WHERE name = ? COLLATE NOCASE AND id <> ?', [$d['name'], $id ?? 0])) {
                $e['name'] = 'Another ministry already uses this name.';
            }
            foreach (['leader_member_id', 'assistant_member_id'] as $f) {
                if ($d[$f] && !DB::value('SELECT 1 FROM members WHERE id = ? AND archived_at IS NULL', [$d[$f]])) {
                    $e[$f] = 'Select a member from the list.';
                }
            }
            if ($d['leader_member_id'] && $d['leader_member_id'] === $d['assistant_member_id']) {
                $e['assistant_member_id'] = 'The assistant must be a different person from the leader.';
            }
            if ($d['category_id'] && !DB::value("SELECT 1 FROM categories WHERE id = ? AND type = 'ministry'", [$d['category_id']])) {
                $d['category_id'] = null;
            }
        }
        if ($d['schedule_start'] && $d['schedule_end'] && $d['schedule_end'] <= $d['schedule_start']) {
            $e['schedule_end'] = 'End time must be after the start time.';
        }
        if ($d['schedule_day'] === null) {
            $d['schedule_start'] = $d['schedule_end'] = null;
        }
        return [$d, $e];
    }
}
