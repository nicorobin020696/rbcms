<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Ids;
use App\Core\Notify;
use App\Core\Paginator;
use App\Core\Upload;
use App\Services\Calendar;

/**
 * Church events & activities (Youth Jam, VBS, Family Day...) and calendar-only schedules
 * (weekly services, meetings). Status is derived from the dates unless the event is cancelled,
 * so it never goes stale.
 */
final class EventsController extends Controller
{
    private const FIELDS = ['title' => 'Title', 'description' => 'Description', 'category_id' => 'Category', 'ministry_id' => 'Ministry',
        'start_date' => 'Start date', 'end_date' => 'End date', 'start_time' => 'Start time', 'end_time' => 'End time',
        'location' => 'Location', 'recurrence' => 'Repeats', 'recur_until' => 'Repeat until', 'is_activity' => 'Listed as event'];

    public static function statusSql(): string
    {
        return "CASE WHEN e.cancelled_at IS NOT NULL THEN 'cancelled'
                     WHEN e.recurrence = 'weekly' AND (e.recur_until IS NULL OR e.recur_until >= date('now','localtime')) THEN 'upcoming'
                     WHEN COALESCE(e.recur_until, e.end_date, e.start_date) < date('now','localtime') THEN 'completed'
                     WHEN e.start_date <= date('now','localtime') THEN 'ongoing'
                     ELSE 'upcoming' END";
    }

    /** Activities need events.manage; calendar-only schedules can also be managed with calendar.manage. */
    private function authorize(bool $isActivity): void
    {
        if ($isActivity ? !can('events.manage') : !Auth::canAny('events.manage', 'calendar.manage')) {
            throw new HttpException(403);
        }
    }

    public function index(): void
    {
        $tab = in_array(query_str('tab'), ['upcoming', 'past', 'cancelled', 'archived', 'all'], true) ? query_str('tab') : 'upcoming';
        $status = self::statusSql();
        $where = ['e.is_activity = 1'];
        $params = [];
        $where[] = $tab === 'archived' ? 'e.archived_at IS NOT NULL' : 'e.archived_at IS NULL';
        if ($tab === 'upcoming') { $where[] = "($status) IN ('upcoming','ongoing')"; }
        if ($tab === 'past') { $where[] = "($status) = 'completed'"; }
        if ($tab === 'cancelled') { $where[] = "($status) = 'cancelled'"; }
        if ($c = input_int('category')) { $where[] = 'e.category_id = :c'; $params['c'] = $c; }
        if (($q = query_str('q')) !== '') { $where[] = "(e.title LIKE :q ESCAPE '\\' OR e.location LIKE :q ESCAPE '\\' OR e.event_code LIKE :q ESCAPE '\\')"; $params['q'] = like($q); }
        if ($y = input_int('year')) { $where[] = "strftime('%Y', e.start_date) = :y"; $params['y'] = (string) $y; }
        $w = implode(' AND ', $where);
        $p = new Paginator((int) DB::value("SELECT COUNT(*) FROM events e WHERE $w", $params), 20);
        $order = $tab === 'upcoming' ? 'e.start_date ASC, e.start_time' : 'e.start_date DESC, e.start_time DESC';
        $events = DB::all(
            "SELECT e.*, ($status) AS status, c.name AS category, c.color, mi.name AS ministry FROM events e
               LEFT JOIN categories c ON c.id = e.category_id LEFT JOIN ministries mi ON mi.id = e.ministry_id
              WHERE $w ORDER BY $order" . $p->sql(),
            $params
        );
        $counts = DB::one("SELECT SUM(archived_at IS NULL AND ($status) IN ('upcoming','ongoing')) upcoming, SUM(archived_at IS NULL AND ($status) = 'completed') past,
                                  SUM(archived_at IS NULL AND ($status) = 'cancelled') cancelled, SUM(archived_at IS NOT NULL) archived, SUM(archived_at IS NULL) total
                             FROM events e WHERE is_activity = 1");
        $this->view('events/index', ['title' => 'Events & activities', 'events' => $events, 'tab' => $tab, 'p' => $p,
            'counts' => array_map('intval', $counts), 'categories' => $this->categories('event'),
            'years' => DB::column("SELECT DISTINCT strftime('%Y', start_date) FROM events WHERE is_activity = 1 ORDER BY 1 DESC")]);
    }

    public function create(): void
    {
        $isActivity = query_str('type') !== 'schedule';
        if ($isActivity && !can('events.manage')) {
            $isActivity = false;
        }
        $this->authorize($isActivity);
        $this->form(['is_activity' => $isActivity ? 1 : 0, 'start_date' => input_date('date') ?: '', 'recurrence' => 'none'], 'New ' . ($isActivity ? 'event' : 'schedule'));
    }

    private function form(array $e, string $title): void
    {
        $this->view('events/form', ['title' => $title, 'e' => $e, 'categories' => $this->categories('event'),
            'ministries' => DB::all('SELECT id, name FROM ministries WHERE archived_at IS NULL ORDER BY name'),
            'conflicts' => $_SESSION['_conflicts'] ?? []]);
        unset($_SESSION['_conflicts']);
    }

    public function store(): void
    {
        [$d, $errors] = $this->validate();
        $this->authorize((bool) $d['is_activity']);
        [$poster, $err] = Upload::image('poster', 'events', 1600);
        if ($err) { $errors['poster'] = $err; }
        $back = '/events/new' . ($d['is_activity'] ? '' : '?type=schedule');
        if ($errors) {
            Upload::delete($poster);
            $this->failed($errors, $back);
        }
        if (!$this->conflictsAccepted($d, null)) {
            Upload::delete($poster);
            $this->failed(['confirm_overlap' => 'This schedule overlaps with other activities. Review them and tick the box to save anyway.'], $back);
        }
        if ($this->isDuplicate($d, null)) {
            Upload::delete($poster);
            $this->failed(['title' => 'An event with the same title, date and time already exists.'], $back);
        }
        $id = DB::transaction(function () use ($d, $poster) {
            $d['event_code'] = Ids::next('event', $d['start_date']);
            $d['poster_path'] = $poster;
            $d['created_by'] = $d['updated_by'] = Auth::id();
            return DB::insert('events', $d);
        });
        Audit::log('create', 'events', 'event', $id, $d['title'] . ' · ' . $d['start_date']);
        Notify::permission('calendar.view', 'event', ($d['is_activity'] ? 'New event: ' : 'New schedule: ') . $d['title'],
            fmt_date($d['start_date'], 'l, j F Y') . ($d['start_time'] ? ' at ' . fmt_time($d['start_time']) : '') . ($d['recurrence'] === 'weekly' ? ' (weekly)' : ''), '/events/' . $id);
        flash('success', ($d['is_activity'] ? 'Event' : 'Schedule') . ' "' . $d['title'] . '" was saved.');
        redirect("/events/$id");
    }

    public function show(int $id): void
    {
        $status = self::statusSql();
        $e = $this->find(
            "SELECT e.*, ($status) AS status, c.name AS category, c.color, mi.name AS ministry, u.full_name AS created_by_name, u2.full_name AS updated_by_name
               FROM events e LEFT JOIN categories c ON c.id = e.category_id LEFT JOIN ministries mi ON mi.id = e.ministry_id
               LEFT JOIN users u ON u.id = e.created_by LEFT JOIN users u2 ON u2.id = e.updated_by WHERE e.id = ?",
            [$id]
        );
        $sessions = Auth::canAny('attendance.view', 'attendance.record') ? DB::all(
            "SELECT s.id, s.title, s.session_date, (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status = 'present') present
               FROM attendance_sessions s WHERE s.event_id = ? ORDER BY s.session_date",
            [$id]
        ) : [];
        $next = $e['recurrence'] === 'weekly' ? Calendar::occurrences($e, today(), date('Y-m-d', strtotime('+8 weeks'))) : [];
        $canManage = $e['is_activity'] ? can('events.manage') : Auth::canAny('events.manage', 'calendar.manage');
        $this->view('events/show', ['title' => $e['title'], 'e' => $e, 'sessions' => $sessions, 'next' => array_slice($next, 0, 6), 'canManage' => $canManage]);
    }

    public function edit(int $id): void
    {
        $e = $this->find('SELECT * FROM events WHERE id = ?', [$id]);
        $this->authorize((bool) $e['is_activity']);
        $this->form($e, 'Edit ' . ($e['is_activity'] ? 'event' : 'schedule'));
    }

    public function update(int $id): void
    {
        $before = $this->find('SELECT * FROM events WHERE id = ?', [$id]);
        $this->authorize((bool) $before['is_activity']);
        [$d, $errors] = $this->validate();
        $this->authorize((bool) $d['is_activity']);
        [$poster, $err] = Upload::image('poster', 'events', 1600);
        if ($err) { $errors['poster'] = $err; }
        if ($errors) {
            Upload::delete($poster);
            $this->failed($errors, "/events/$id/edit");
        }
        if (!$this->conflictsAccepted($d, $id)) {
            Upload::delete($poster);
            $this->failed(['confirm_overlap' => 'This schedule overlaps with other activities. Review them and tick the box to save anyway.'], "/events/$id/edit");
        }
        $removePoster = !empty($_POST['remove_poster']);
        if ($poster || $removePoster) {
            $d['poster_path'] = $poster;
        }
        $d['updated_by'] = Auth::id();
        $d['updated_at'] = now();
        DB::update('events', $d, 'id = :id', ['id' => $id]);
        if ($poster || $removePoster) {
            Upload::delete($before['poster_path']);
        }
        $after = DB::one('SELECT * FROM events WHERE id = ?', [$id]);
        $diff = Audit::diff($before, $after, self::FIELDS);
        Audit::log('update', 'events', 'event', $id, $after['title'], $diff);
        $scheduleChanged = $before['start_date'] !== $after['start_date'] || $before['start_time'] !== $after['start_time'] || $before['location'] !== $after['location'] || $before['end_date'] !== $after['end_date'];
        if ($scheduleChanged) {
            Notify::permission('calendar.view', 'event', 'Schedule changed: ' . $after['title'],
                'Now on ' . fmt_date($after['start_date'], 'l, j F Y') . ($after['start_time'] ? ' at ' . fmt_time($after['start_time']) : '') . ($after['location'] ? ' · ' . $after['location'] : '') . '.', '/events/' . $id);
        }
        flash('success', 'Changes saved.');
        redirect("/events/$id");
    }

    public function cancel(int $id): void
    {
        $e = $this->find('SELECT * FROM events WHERE id = ?', [$id]);
        $this->authorize((bool) $e['is_activity']);
        if ($e['cancelled_at']) {
            DB::update('events', ['cancelled_at' => null, 'cancel_reason' => null, 'updated_by' => Auth::id()], 'id = :id', ['id' => $id]);
            Audit::log('update', 'events', 'event', $id, $e['title'], 'Cancellation undone');
            Notify::permission('calendar.view', 'event', 'Back on schedule: ' . $e['title'], 'This activity is no longer cancelled.', '/events/' . $id);
            flash('success', 'The event is active again.');
        } else {
            $reason = input_str('reason', 250);
            DB::update('events', ['cancelled_at' => now(), 'cancel_reason' => $reason ?: null, 'updated_by' => Auth::id()], 'id = :id', ['id' => $id]);
            Audit::log('cancel', 'events', 'event', $id, $e['title'], $reason ?: null);
            Notify::permission('calendar.view', 'event', 'Cancelled: ' . $e['title'], fmt_date($e['start_date'], 'l, j F Y') . ($reason ? ' — ' . $reason : ''), '/events/' . $id);
            flash('success', 'The event was marked as cancelled.');
        }
        redirect("/events/$id");
    }

    public function archive(int $id): void
    {
        $e = $this->find('SELECT * FROM events WHERE id = ? AND archived_at IS NULL', [$id]);
        $this->authorize((bool) $e['is_activity']);
        DB::update('events', ['archived_at' => now(), 'updated_by' => Auth::id()], 'id = :id', ['id' => $id]);
        Audit::log('archive', 'events', 'event', $id, $e['title']);
        flash('success', '"' . $e['title'] . '" was archived and removed from the calendar.');
        redirect($e['is_activity'] ? '/events' : '/calendar');
    }

    public function restore(int $id): void
    {
        $e = $this->find('SELECT * FROM events WHERE id = ? AND archived_at IS NOT NULL', [$id]);
        $this->authorize((bool) $e['is_activity']);
        DB::update('events', ['archived_at' => null, 'updated_by' => Auth::id()], 'id = :id', ['id' => $id]);
        Audit::log('restore', 'events', 'event', $id, $e['title']);
        flash('success', 'Restored.');
        redirect("/events/$id");
    }

    /** JSON endpoint used by the form to warn about overlapping activities before saving. */
    public function check(): void
    {
        $date = input_date('start_date');
        if (!$date) {
            $this->json(['conflicts' => []]);
        }
        $items = Calendar::conflicts($date, input_time('start_time'), input_time('end_time'), input_int('id'));
        $this->json(['conflicts' => array_map(static fn($c) => ['title' => $c['title'], 'time' => time_range($c['start_time'], $c['end_time']), 'category' => $c['category']], $items)]);
    }

    // ------------------------------------------------------------ helpers

    private function validate(): array
    {
        $d = [
            'title' => input_str('title', 150), 'description' => input_text('description', 5000) ?: null,
            'category_id' => input_int('category_id'), 'ministry_id' => input_int('ministry_id'),
            'start_date' => input_date('start_date'), 'end_date' => input_date('end_date'),
            'start_time' => input_time('start_time'), 'end_time' => input_time('end_time'),
            'location' => input_str('location', 150) ?: null,
            'is_activity' => input_str('is_activity') === '1' ? 1 : 0,
            'recurrence' => input_in('recurrence', ['none', 'weekly'], 'none'), 'recur_until' => input_date('recur_until'),
        ];
        $e = [];
        if ($d['title'] === '') { $e['title'] = 'Title is required.'; }
        if (!$d['start_date']) { $e['start_date'] = 'Enter a valid date.'; }
        if ($d['category_id'] && !DB::value("SELECT 1 FROM categories WHERE id = ? AND type = 'event'", [$d['category_id']])) { $d['category_id'] = null; }
        if ($d['ministry_id'] && !DB::value('SELECT 1 FROM ministries WHERE id = ?', [$d['ministry_id']])) { $d['ministry_id'] = null; }
        if ($d['recurrence'] === 'weekly') {
            $d['end_date'] = null;
            if ($d['recur_until'] && $d['start_date'] && $d['recur_until'] < $d['start_date']) { $e['recur_until'] = 'The repeat end date must be after the start date.'; }
        } else {
            $d['recur_until'] = null;
            if ($d['end_date'] && $d['start_date'] && $d['end_date'] < $d['start_date']) { $e['end_date'] = 'End date cannot be before the start date.'; }
            if ($d['end_date'] === $d['start_date']) { $d['end_date'] = null; }
        }
        if ($d['start_time'] && $d['end_time'] && $d['end_time'] <= $d['start_time'] && !$d['end_date']) { $e['end_time'] = 'End time must be after the start time.'; }
        if (!$d['start_time']) { $d['end_time'] = null; }
        return [$d, $e];
    }

    private function conflictsAccepted(array $d, ?int $id): bool
    {
        if (!empty($_POST['confirm_overlap']) || !$d['start_time']) {
            return true;
        }
        $found = Calendar::conflicts($d['start_date'], $d['start_time'], $d['end_time'], $id);
        if ($found) {
            $_SESSION['_conflicts'] = $found;
            return false;
        }
        return true;
    }

    private function isDuplicate(array $d, ?int $id): bool
    {
        return (bool) DB::value(
            'SELECT 1 FROM events WHERE archived_at IS NULL AND title = ? COLLATE NOCASE AND start_date = ? AND start_time IS ? AND id <> ?',
            [$d['title'], $d['start_date'], $d['start_time'], $id ?? 0]
        );
    }
}
