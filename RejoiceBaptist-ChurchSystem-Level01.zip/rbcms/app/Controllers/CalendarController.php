<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database as DB;
use App\Services\Calendar;

final class CalendarController extends Controller
{
    public function index(): void
    {
        $view = input_in('view', ['month', 'week', 'list'], 'month');
        $date = input_date('date') ?: today();
        $cat = query_str('category');
        $ts = strtotime($date);
        if ($view === 'month') {
            $first = date('Y-m-01', $ts);
            $from = date('Y-m-d', strtotime($first) - (int) date('w', strtotime($first)) * 86400);
            $last = date('Y-m-t', $ts);
            $to = date('Y-m-d', strtotime($last) + (6 - (int) date('w', strtotime($last))) * 86400);
            $label = date('F Y', $ts);
            $prev = date('Y-m-d', strtotime($first . ' -1 month'));
            $next = date('Y-m-d', strtotime($first . ' +1 month'));
        } elseif ($view === 'week') {
            $from = date('Y-m-d', $ts - (int) date('w', $ts) * 86400);
            $to = date('Y-m-d', strtotime($from . ' +6 days'));
            $label = fmt_date($from, 'j M') . ' – ' . fmt_date($to, 'j M Y');
            $prev = date('Y-m-d', strtotime($from . ' -7 days'));
            $next = date('Y-m-d', strtotime($from . ' +7 days'));
        } else {
            $from = $date;
            $to = date('Y-m-d', strtotime($date . ' +30 days'));
            $label = fmt_date($from, 'j M') . ' – ' . fmt_date($to, 'j M Y');
            $prev = date('Y-m-d', strtotime($date . ' -31 days'));
            $next = date('Y-m-d', strtotime($date . ' +31 days'));
        }
        $entries = Calendar::range($from, $to, $cat);
        $this->view('calendar/index', [
            'title' => 'Calendar', 'view' => $view, 'date' => $date, 'from' => $from, 'to' => $to, 'label' => $label,
            'prev' => $prev, 'next' => $next, 'entries' => $entries, 'cat' => $cat, 'categories' => $this->categories('event'),
            'canAdd' => Auth::canAny('events.manage', 'calendar.manage'),
            'legend' => DB::all("SELECT name, color FROM categories WHERE type = 'event' AND is_active = 1 AND id IN (SELECT DISTINCT category_id FROM events WHERE archived_at IS NULL) ORDER BY sort_order, name"),
        ]);
    }

    /** JSON for the day popup. */
    public function day(): void
    {
        $date = input_date('date');
        if (!$date) {
            $this->json(['error' => 'Invalid date'], 422);
        }
        $items = Calendar::range($date, $date, query_str('category'))[$date] ?? [];
        $this->json([
            'date' => $date,
            'label' => fmt_date($date, 'l, j F Y'),
            'canAdd' => Auth::canAny('events.manage', 'calendar.manage'),
            'items' => array_map(static fn($i) => [
                'title' => $i['title'], 'category' => $i['category'], 'color' => $i['color'],
                'time' => time_range($i['start_time'], $i['end_time']), 'location' => $i['location'] ?? '',
                'description' => mb_strimwidth((string) ($i['description'] ?? ''), 0, 300, '…'),
                'cancelled' => $i['cancelled'], 'recurring' => $i['recurring'],
                'url' => url($i['kind'] === 'ministry' ? '/ministries/' . $i['id'] : '/events/' . $i['id']),
            ], $items),
        ]);
    }
}
