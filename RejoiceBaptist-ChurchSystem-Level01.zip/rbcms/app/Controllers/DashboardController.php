<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\Notify;
use App\Services\Backup;
use App\Services\Calendar;
use App\Services\Stats;

/**
 * Home dashboard. Each widget is included only when the user holds the permission behind it,
 * so finance figures, for example, are never computed for or sent to non-finance users.
 */
final class DashboardController extends Controller
{
    public function index(): void
    {
        $u = user();
        Backup::autoDaily();          // once a day, whoever opens the dashboard first
        Notify::dailyReminders($u);
        $year = input_int('year') ?: (int) date('Y');
        $data = ['title' => 'Dashboard', 'year' => $year, 'w' => []];
        $years = DB::column("SELECT DISTINCT strftime('%Y', session_date) FROM attendance_sessions ORDER BY 1 DESC");
        $data['years'] = array_values(array_unique(array_merge([date('Y')], $years)));

        if (can('members.view')) {
            $data['w']['members'] = Stats::memberCounts();
            $data['w']['newMembers'] = (int) DB::value("SELECT COUNT(*) FROM members WHERE archived_at IS NULL AND date_joined >= date('now','localtime','start of month')");
        }
        if (Auth::canAny('ministries.view', 'members.view')) {
            $data['w']['ministries'] = DB::all("SELECT m.id, m.name, (SELECT COUNT(*) FROM ministry_members mm JOIN members x ON x.id = mm.member_id AND x.archived_at IS NULL WHERE mm.ministry_id = m.id) n
                                                  FROM ministries m WHERE m.archived_at IS NULL AND m.status = 'active' ORDER BY n DESC LIMIT 6");
            $data['w']['ministryCount'] = (int) DB::value("SELECT COUNT(*) FROM ministries WHERE archived_at IS NULL AND status = 'active'");
        }
        if (can('attendance.view')) {
            $sunCat = (int) DB::value("SELECT id FROM categories WHERE type = 'attendance' AND code = 'sunday_service'");
            $data['w']['attendance'] = [
                'monthly' => Stats::monthlyAttendance($year), 'prev' => Stats::monthlyAttendance($year - 1), 'yearly' => Stats::yearlyAttendance(5),
                'lastSunday' => DB::one("SELECT s.id, s.session_date, (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status = 'present') present
                                           FROM attendance_sessions s WHERE s.category_id = ? AND s.ministry_id IS NULL AND s.session_date <= date('now','localtime') ORDER BY s.session_date DESC LIMIT 1", [$sunCat]),
                'avgSunday' => (int) round((float) DB::value("SELECT AVG(c) FROM (SELECT COUNT(r.id) c FROM attendance_sessions s LEFT JOIN attendance_records r ON r.session_id = s.id AND r.status = 'present'
                                           WHERE s.category_id = ? AND s.ministry_id IS NULL AND s.session_date >= date('now','localtime','-3 months') GROUP BY s.id)", [$sunCat])),
                'month' => Stats::presentBetween(date('Y-m-01'), date('Y-m-t')),
                'recent' => DB::all("SELECT s.id, s.title, s.session_date, c.name category, (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status = 'present') present
                                       FROM attendance_sessions s JOIN categories c ON c.id = s.category_id ORDER BY s.session_date DESC, s.id DESC LIMIT 5"),
            ];
        } elseif ($led = Auth::ledMinistryIds()) {
            $data['w']['leader'] = [
                'monthly' => Stats::monthlyAttendance($year, null, $led),
                'ministries' => DB::all('SELECT id, name FROM ministries WHERE id IN (' . implode(',', array_map('intval', $led)) . ')'),
            ];
        }
        if (can('calendar.view')) {
            $up = Calendar::range(today(), date('Y-m-d', strtotime('+14 days')));
            $flat = [];
            foreach ($up as $items) { foreach ($items as $i) { if (!$i['cancelled']) { $flat[] = $i; } } }
            $data['w']['upcoming'] = array_slice($flat, 0, 7);
        }
        if (can('announcements.view')) {
            $data['w']['announcements'] = DB::all("SELECT id, title, body, published_at, is_pinned, is_sample FROM announcements WHERE status = 'published' ORDER BY is_pinned DESC, published_at DESC LIMIT 3");
        }
        if (can('music.view')) {
            $data['w']['music'] = [
                'recent' => DB::all("SELECT l.id, l.service_date, l.service_type, l.service_title, m.first_name, m.last_name,
                                            (SELECT COUNT(*) FROM lineup_songs s WHERE s.lineup_id = l.id) songs
                                       FROM worship_lineups l LEFT JOIN members m ON m.id = l.song_leader_member_id WHERE l.archived_at IS NULL ORDER BY l.service_date DESC LIMIT 4"),
                'top' => Stats::topSongs(5, "$year-01-01", "$year-12-31"),
            ];
        }
        if (can('finance.view')) {
            $data['w']['finance'] = [
                'month' => FinanceController::totals(date('Y-m-01'), date('Y-m-t')),
                'balance' => FinanceController::balanceBefore('9999-12-31'),
                'monthly' => FinanceController::monthly($year),
            ];
        }
        if (can('audit.view')) {
            $data['w']['activity'] = DB::all("SELECT * FROM audit_logs WHERE action NOT IN ('login','logout') " . (can('finance.view') ? '' : "AND module <> 'finance' ") . 'ORDER BY id DESC LIMIT 6');
        }
        if (can('documents.view')) {
            $data['w']['documents'] = (int) DB::value("SELECT COUNT(*) FROM documents WHERE status = 'draft'" . (can('documents.confidential') ? '' : ' AND confidential = 0'));
        }
        $this->view('dashboard/index', $data);
    }
}
