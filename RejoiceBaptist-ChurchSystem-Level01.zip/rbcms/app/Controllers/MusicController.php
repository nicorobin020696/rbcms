<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Ids;
use App\Core\Paginator;
use App\Core\PdfReport;
use App\Core\Upload;
use App\Services\Stats;

/**
 * Worship / music team lineups: song leader, instrumentalists (with instrument), backup singers,
 * other team members, ordered songs with artists, YouTube references and the Sunday P&W photo.
 */
final class MusicController extends Controller
{
    public const SERVICE_TYPES = ['morning' => 'Morning Worship', 'afternoon' => 'Afternoon Service', 'special' => 'Special Service'];
    public const SONG_CATS = ['praise' => 'Praise', 'worship' => 'Worship', 'special' => 'Special number'];
    public const ROLES = ['instrumentalist' => 'Instrumentalist', 'backup' => 'Backup singer', 'other' => 'Other'];

    private const LIST_SQL = "SELECT l.*, sl.first_name sl_first, sl.last_name sl_last,
            (SELECT COUNT(*) FROM lineup_songs s WHERE s.lineup_id = l.id) song_count,
            (SELECT COUNT(*) FROM lineup_members m WHERE m.lineup_id = l.id) member_count,
            (SELECT GROUP_CONCAT(t, ' · ') FROM (SELECT so.title t FROM lineup_songs s JOIN songs so ON so.id = s.song_id WHERE s.lineup_id = l.id ORDER BY s.sort_order)) songs
        FROM worship_lineups l LEFT JOIN members sl ON sl.id = l.song_leader_member_id";

    public function index(): void
    {
        [$where, $params] = $this->filters();
        $p = new Paginator((int) DB::value("SELECT COUNT(*) FROM worship_lineups l WHERE $where", $params), 15);
        $lineups = DB::all(self::LIST_SQL . " WHERE $where ORDER BY l.service_date DESC, l.id DESC" . $p->sql(), $params);
        $year = (int) date('Y');
        $this->view('music/index', [
            'title' => 'Music Team', 'lineups' => $lineups, 'p' => $p,
            'leaders' => DB::all('SELECT DISTINCT m.id, m.first_name, m.last_name, m.middle_name, m.suffix, m.member_code FROM worship_lineups l JOIN members m ON m.id = l.song_leader_member_id ORDER BY m.last_name'),
            'cards' => [
                'total' => (int) DB::value('SELECT COUNT(*) FROM worship_lineups WHERE archived_at IS NULL'),
                'year' => (int) DB::value("SELECT COUNT(*) FROM worship_lineups WHERE archived_at IS NULL AND strftime('%Y', service_date) = ?", [(string) $year]),
                'songs' => (int) DB::value('SELECT COUNT(DISTINCT song_id) FROM lineup_songs ls JOIN worship_lineups l ON l.id = ls.lineup_id AND l.archived_at IS NULL'),
                'artists' => (int) DB::value('SELECT COUNT(DISTINCT so.artist_id) FROM lineup_songs ls JOIN songs so ON so.id = ls.song_id JOIN worship_lineups l ON l.id = ls.lineup_id AND l.archived_at IS NULL'),
            ],
            'topSongs' => Stats::topSongs(5),
        ]);
    }

    private function filters(): array
    {
        $where = [query_str('archived') ? 'l.archived_at IS NOT NULL' : 'l.archived_at IS NULL'];
        $params = [];
        if (($q = query_str('q')) !== '') {
            $where[] = "(l.lineup_code LIKE :q ESCAPE '\\' OR l.service_title LIKE :q ESCAPE '\\' OR EXISTS (SELECT 1 FROM lineup_songs s JOIN songs so ON so.id = s.song_id LEFT JOIN artists a ON a.id = so.artist_id WHERE s.lineup_id = l.id AND (so.title LIKE :q ESCAPE '\\' OR a.name LIKE :q ESCAPE '\\')))";
            $params['q'] = like($q);
        }
        if ($leader = input_int('leader')) { $where[] = 'l.song_leader_member_id = :leader'; $params['leader'] = $leader; }
        if ($member = input_int('member')) { $where[] = '(l.song_leader_member_id = :mem OR EXISTS (SELECT 1 FROM lineup_members x WHERE x.lineup_id = l.id AND x.member_id = :mem))'; $params['mem'] = $member; }
        if ($song = input_int('song')) { $where[] = 'EXISTS (SELECT 1 FROM lineup_songs s WHERE s.lineup_id = l.id AND s.song_id = :song)'; $params['song'] = $song; }
        if ($t = input_in('type', array_keys(self::SERVICE_TYPES), '')) { $where[] = 'l.service_type = :t'; $params['t'] = $t; }
        if ($f = input_date('from')) { $where[] = 'l.service_date >= :from'; $params['from'] = $f; }
        if ($to = input_date('to')) { $where[] = 'l.service_date <= :to'; $params['to'] = $to; }
        return [implode(' AND ', $where), $params];
    }

    public function show(int $id): void
    {
        $l = $this->find("SELECT l.*, sl.first_name sl_first, sl.last_name sl_last, sl.middle_name sl_middle, sl.member_code sl_code,
                                 u.full_name created_by_name, u2.full_name updated_by_name
                            FROM worship_lineups l LEFT JOIN members sl ON sl.id = l.song_leader_member_id
                            LEFT JOIN users u ON u.id = l.created_by LEFT JOIN users u2 ON u2.id = l.updated_by WHERE l.id = ?", [$id]);
        $this->view('music/show', ['title' => 'Lineup ' . $l['lineup_code'], 'l' => $l, 'songs' => $this->songsOf($id), 'team' => $this->teamOf($id)]);
    }

    private function songsOf(int $id): array
    {
        return DB::all('SELECT ls.*, so.title, a.name artist, (SELECT COUNT(*) FROM lineup_songs x JOIN worship_lineups y ON y.id = x.lineup_id AND y.archived_at IS NULL WHERE x.song_id = ls.song_id) times
                          FROM lineup_songs ls JOIN songs so ON so.id = ls.song_id LEFT JOIN artists a ON a.id = so.artist_id WHERE ls.lineup_id = ? ORDER BY ls.sort_order', [$id]);
    }

    private function teamOf(int $id): array
    {
        return DB::all("SELECT lm.*, m.first_name, m.last_name, m.middle_name, m.suffix, m.member_code, c.name instrument
                          FROM lineup_members lm JOIN members m ON m.id = lm.member_id LEFT JOIN categories c ON c.id = lm.instrument_id
                         WHERE lm.lineup_id = ? ORDER BY CASE lm.role WHEN 'instrumentalist' THEN 1 WHEN 'backup' THEN 2 ELSE 3 END, c.sort_order, m.last_name", [$id]);
    }

    public function create(): void
    {
        $copy = input_int('copy');
        $l = ['service_date' => $this->nextSunday(), 'service_type' => 'morning'];
        $songs = $team = [];
        if ($copy && ($src = DB::one('SELECT * FROM worship_lineups WHERE id = ?', [$copy]))) {
            $l['song_leader_member_id'] = $src['song_leader_member_id'];
            $team = $this->teamOf($copy);
        }
        $this->form($l, $songs, $team, 'New lineup');
    }

    public function edit(int $id): void
    {
        $l = $this->find('SELECT * FROM worship_lineups WHERE id = ?', [$id]);
        $this->form($l, $this->songsOf($id), $this->teamOf($id), 'Edit lineup ' . $l['lineup_code']);
    }

    private function form(array $l, array $songs, array $team, string $title): void
    {
        $oldSongs = old('songs');
        $oldTeam = old('team');
        $this->view('music/form', [
            'title' => $title, 'l' => $l,
            'songs' => is_array($oldSongs) ? array_values($oldSongs) : $songs,
            'team' => is_array($oldTeam) ? array_values($oldTeam) : $team,
            'members' => $this->memberOptions(true),
            'instruments' => $this->categories('instrument'),
            'songTitles' => DB::all('SELECT so.title, a.name artist FROM songs so LEFT JOIN artists a ON a.id = so.artist_id ORDER BY so.title'),
            'artists' => DB::column('SELECT name FROM artists ORDER BY name'),
        ]);
    }

    private function nextSunday(): string
    {
        return date('w') === '0' ? today() : date('Y-m-d', strtotime('next sunday'));
    }

    public function store(): void
    {
        [$d, $songs, $team, $errors] = $this->validate(null);
        [$photo, $err] = Upload::image('photo', 'lineups', 2000);
        if ($err) { $errors['photo'] = $err; }
        if ($errors) { Upload::delete($photo); $this->failed($errors, '/music/new'); }
        $id = DB::transaction(function () use ($d, $songs, $team, $photo) {
            $d['lineup_code'] = Ids::next('lineup', $d['service_date']);
            $d['photo_path'] = $photo;
            $d['created_by'] = $d['updated_by'] = Auth::id();
            $id = DB::insert('worship_lineups', $d);
            $this->saveChildren($id, $songs, $team);
            return $id;
        });
        Audit::log('create', 'music', 'lineup', $id, self::SERVICE_TYPES[$d['service_type']] . ' · ' . $d['service_date'], count($songs) . ' songs, ' . count($team) . ' team members');
        flash('success', 'Lineup saved.');
        redirect("/music/$id");
    }

    public function update(int $id): void
    {
        $before = $this->find('SELECT * FROM worship_lineups WHERE id = ?', [$id]);
        [$d, $songs, $team, $errors] = $this->validate($id);
        [$photo, $err] = Upload::image('photo', 'lineups', 2000);
        if ($err) { $errors['photo'] = $err; }
        if ($errors) { Upload::delete($photo); $this->failed($errors, "/music/$id/edit"); }
        $remove = !empty($_POST['remove_photo']);
        if ($photo || $remove) { $d['photo_path'] = $photo; }
        $d['updated_by'] = Auth::id();
        $d['updated_at'] = now();
        DB::transaction(function () use ($id, $d, $songs, $team) {
            DB::update('worship_lineups', $d, 'id = :id', ['id' => $id]);
            DB::query('DELETE FROM lineup_songs WHERE lineup_id = ?', [$id]);
            DB::query('DELETE FROM lineup_members WHERE lineup_id = ?', [$id]);
            $this->saveChildren($id, $songs, $team);
        });
        if ($photo || $remove) { Upload::delete($before['photo_path']); }
        Audit::log('update', 'music', 'lineup', $id, $before['lineup_code'], count($songs) . ' songs, ' . count($team) . ' team members' . ($photo ? ', new photo' : ''));
        flash('success', 'Lineup updated.');
        redirect("/music/$id");
    }

    public function archive(int $id): void
    {
        $l = $this->find('SELECT * FROM worship_lineups WHERE id = ?', [$id]);
        if ($l['archived_at']) {
            $clash = $l['service_type'] !== 'special' && DB::value('SELECT 1 FROM worship_lineups WHERE archived_at IS NULL AND service_date = ? AND service_type = ? AND id <> ?', [$l['service_date'], $l['service_type'], $id]);
            if ($clash) { flash('error', 'Another lineup already exists for that service, so this one cannot be restored.'); redirect("/music/$id"); }
            DB::update('worship_lineups', ['archived_at' => null], 'id = :id', ['id' => $id]);
            Audit::log('restore', 'music', 'lineup', $id, $l['lineup_code']);
            flash('success', 'Lineup restored.');
        } else {
            DB::update('worship_lineups', ['archived_at' => now()], 'id = :id', ['id' => $id]);
            Audit::log('archive', 'music', 'lineup', $id, $l['lineup_code']);
            flash('success', 'Lineup archived. It no longer counts in statistics.');
        }
        redirect("/music/$id");
    }

    private function saveChildren(int $id, array $songs, array $team): void
    {
        foreach ($songs as $i => $s) {
            $artistId = null;
            if ($s['artist'] !== '') {
                $artistId = DB::value('SELECT id FROM artists WHERE name = ? COLLATE NOCASE', [$s['artist']]) ?: DB::insert('artists', ['name' => $s['artist']]);
            }
            $songId = DB::value('SELECT id FROM songs WHERE title = ? COLLATE NOCASE AND artist_id IS ?', [$s['title'], $artistId])
                ?: DB::insert('songs', ['title' => $s['title'], 'artist_id' => $artistId]);
            DB::insert('lineup_songs', ['lineup_id' => $id, 'song_id' => $songId, 'category' => $s['category'], 'sort_order' => $i + 1,
                'youtube_url' => $s['youtube_url'] ?: null, 'remarks' => $s['remarks'] ?: null]);
        }
        foreach ($team as $t) {
            DB::insert('lineup_members', ['lineup_id' => $id, 'member_id' => $t['member_id'], 'role' => $t['role'],
                'instrument_id' => $t['role'] === 'instrumentalist' ? $t['instrument_id'] : null, 'note' => $t['note'] ?: null]);
        }
    }

    private function validate(?int $id): array
    {
        $d = [
            'service_date' => input_date('service_date'),
            'service_type' => input_in('service_type', array_keys(self::SERVICE_TYPES), 'morning'),
            'service_title' => input_str('service_title', 150) ?: null,
            'song_leader_member_id' => input_int('song_leader_member_id'),
            'remarks' => input_text('remarks', 2000) ?: null,
        ];
        $e = [];
        if (!$d['service_date']) { $e['service_date'] = 'Enter the service date.'; }
        if ($d['service_type'] === 'special' && !$d['service_title']) { $e['service_title'] = 'Give the special service a name, e.g. Night of Worship.'; }
        if ($d['service_date'] && $d['service_type'] !== 'special'
            && DB::value('SELECT 1 FROM worship_lineups WHERE archived_at IS NULL AND service_date = ? AND service_type = ? AND id <> ?', [$d['service_date'], $d['service_type'], $id ?? 0])) {
            $e['service_date'] = 'A ' . strtolower(self::SERVICE_TYPES[$d['service_type']]) . ' lineup already exists for this date.';
        }
        $validMembers = array_flip(array_map('intval', DB::column('SELECT id FROM members')));
        if ($d['song_leader_member_id'] && !isset($validMembers[$d['song_leader_member_id']])) { $d['song_leader_member_id'] = null; }
        if (!$d['song_leader_member_id']) { $e['song_leader_member_id'] = 'Select the song leader.'; }
        $instruments = array_flip(array_map('intval', DB::column("SELECT id FROM categories WHERE type = 'instrument'")));

        $songs = [];
        foreach ((array) ($_POST['songs'] ?? []) as $row) {
            $title = trim(mb_substr(preg_replace('/\s+/', ' ', (string) ($row['title'] ?? '')), 0, 150));
            if ($title === '') { continue; }
            $yt = trim((string) ($row['youtube_url'] ?? ''));
            if ($yt !== '' && !youtube_id($yt)) { $e['songs'] = 'One of the YouTube links is not valid (“' . mb_strimwidth($title, 0, 40, '…') . '”).'; }
            $songs[] = ['title' => $title, 'artist' => trim(mb_substr(preg_replace('/\s+/', ' ', (string) ($row['artist'] ?? '')), 0, 120)),
                'category' => in_array($row['category'] ?? '', array_keys(self::SONG_CATS), true) ? $row['category'] : 'praise',
                'youtube_url' => $yt === '' ? '' : mb_substr($yt, 0, 300), 'remarks' => trim(mb_substr((string) ($row['remarks'] ?? ''), 0, 200))];
        }
        if (!$songs) { $e['songs'] = 'Add at least one song.'; }
        if (count($songs) > 30) { $e['songs'] = 'A lineup can have at most 30 songs.'; }

        $team = [];
        $seen = [];
        foreach ((array) ($_POST['team'] ?? []) as $row) {
            $mid = (int) ($row['member_id'] ?? 0);
            if (!$mid || !isset($validMembers[$mid])) { continue; }
            $role = in_array($row['role'] ?? '', array_keys(self::ROLES), true) ? $row['role'] : 'other';
            $inst = (int) ($row['instrument_id'] ?? 0);
            $inst = isset($instruments[$inst]) ? $inst : null;
            if ($role === 'instrumentalist' && !$inst) { $e['team'] = 'Choose the instrument for each instrumentalist.'; }
            $key = $mid . '|' . $role . '|' . $inst;
            if (isset($seen[$key])) { continue; }
            $seen[$key] = true;
            $team[] = ['member_id' => $mid, 'role' => $role, 'instrument_id' => $inst, 'note' => trim(mb_substr((string) ($row['note'] ?? ''), 0, 120))];
        }
        return [$d, $songs, $team, $e];
    }

    // ------------------------------------------------------------ library & statistics

    public function songs(): void
    {
        $params = [];
        $where = '1=1';
        if (($q = query_str('q')) !== '') { $where = "(so.title LIKE :q ESCAPE '\\' OR a.name LIKE :q ESCAPE '\\')"; $params['q'] = like($q); }
        $sort = input_in('sort', ['uses', 'title', 'artist', 'last'], 'uses');
        $order = ['uses' => 'uses DESC, so.title', 'title' => 'so.title', 'artist' => 'a.name, so.title', 'last' => 'last_used DESC'][$sort];
        $base = "FROM songs so LEFT JOIN artists a ON a.id = so.artist_id
                 LEFT JOIN lineup_songs ls ON ls.song_id = so.id LEFT JOIN worship_lineups l ON l.id = ls.lineup_id AND l.archived_at IS NULL WHERE $where";
        $p = new Paginator((int) DB::value("SELECT COUNT(DISTINCT so.id) $base", $params), 30);
        $rows = DB::all("SELECT so.id, so.title, a.name artist, COUNT(l.id) uses, MAX(l.service_date) last_used,
                                (SELECT ls2.youtube_url FROM lineup_songs ls2 WHERE ls2.song_id = so.id AND ls2.youtube_url IS NOT NULL ORDER BY ls2.id DESC LIMIT 1) youtube
                         $base GROUP BY so.id ORDER BY $order" . $p->sql(), $params);
        $this->view('music/songs', ['title' => 'Song library', 'songs' => $rows, 'p' => $p, 'sort' => $sort]);
    }

    public function stats(): void
    {
        [$from, $to, $year] = $this->statRange();
        $this->view('music/stats', [
            'title' => 'Music statistics', 'from' => $from, 'to' => $to, 'year' => $year,
            'topSongs' => Stats::topSongs(15, $from, $to), 'topArtists' => Stats::topArtists(10, $from, $to),
            'leaders' => Stats::topSongLeaders(10, $from, $to), 'instrumentalists' => Stats::topInstrumentalists(10, $from, $to),
            'backups' => $this->topBackups($from, $to), 'perMonth' => Stats::lineupsPerMonth($year), 'perYear' => Stats::lineupsPerYear(),
            'years' => DB::column("SELECT DISTINCT strftime('%Y', service_date) FROM worship_lineups WHERE archived_at IS NULL ORDER BY 1 DESC") ?: [date('Y')],
        ]);
    }

    private function statRange(): array
    {
        $year = input_int('year') ?: (int) date('Y');
        $from = input_date('from');
        $to = input_date('to');
        if (!$from && !$to && query_str('range') !== 'all') { $from = "$year-01-01"; $to = "$year-12-31"; }
        return [$from, $to, $year];
    }

    private function topBackups(?string $from, ?string $to): array
    {
        $w = '';
        $p = [];
        if ($from) { $w .= ' AND l.service_date >= :f'; $p['f'] = $from; }
        if ($to) { $w .= ' AND l.service_date <= :t'; $p['t'] = $to; }
        return DB::all("SELECT m.id, m.first_name, m.last_name, m.middle_name, m.suffix, COUNT(*) uses FROM lineup_members lm JOIN members m ON m.id = lm.member_id
                          JOIN worship_lineups l ON l.id = lm.lineup_id AND l.archived_at IS NULL $w WHERE lm.role = 'backup' GROUP BY m.id ORDER BY uses DESC, m.last_name LIMIT 10", $p);
    }

    public function statsPdf(): void
    {
        [$from, $to] = $this->statRange();
        $period = $from || $to ? fmt_date($from ?: '2000-01-01') . ' – ' . fmt_date($to ?: today()) : 'All time';
        $pdf = new PdfReport('Music Team Statistics', $period);
        $count = (int) DB::value('SELECT COUNT(*) FROM worship_lineups WHERE archived_at IS NULL' . ($from ? ' AND service_date >= :f' : '') . ($to ? ' AND service_date <= :t' : ''), array_filter(['f' => $from, 't' => $to]));
        $pdf->summary([['Lineups', $count], ['Period', $period]]);
        $pdf->heading('Most lined-up songs');
        $pdf->table([['#', .4, 'R'], ['Song', 3], ['Artist', 2], ['Times', .8, 'R'], ['Last used', 1.2]],
            array_map(static fn($s, $i) => [$i + 1, $s['title'], $s['artist'] ?: '—', $s['uses'], fmt_date($s['last_used'])], $songs = Stats::topSongs(25, $from, $to), array_keys($songs)));
        $pdf->heading('Most featured artists');
        $pdf->table([['Artist', 3], ['Songs used', 1, 'R']], array_map(static fn($a) => [$a['artist'] ?? $a['name'] ?? '—', $a['uses']], Stats::topArtists(15, $from, $to)));
        $pdf->heading('Song leaders');
        $pdf->table([['Name', 3], ['Services', 1, 'R']], array_map(static fn($m) => [member_name($m), $m['uses']], Stats::topSongLeaders(15, $from, $to)));
        $pdf->heading('Instrumentalists');
        $pdf->table([['Name', 2.4], ['Instruments', 2], ['Services', 1, 'R']], array_map(static fn($m) => [member_name($m), $m['instruments'] ?? '', $m['uses']], Stats::topInstrumentalists(15, $from, $to)));
        Audit::log('export', 'music', null, null, 'Music statistics', 'PDF · ' . $period);
        $pdf->download('music-statistics.pdf', true);
    }

    public function pdf(int $id): void
    {
        $l = $this->find('SELECT l.*, sl.first_name, sl.last_name, sl.middle_name, sl.suffix FROM worship_lineups l LEFT JOIN members sl ON sl.id = l.song_leader_member_id WHERE l.id = ?', [$id]);
        $songs = $this->songsOf($id);
        $team = $this->teamOf($id);
        $title = $l['service_title'] ?: self::SERVICE_TYPES[$l['service_type']];
        $pdf = new PdfReport('Worship Lineup — ' . $title, fmt_date($l['service_date'], 'l, j F Y') . ' · ' . $l['lineup_code']);
        $pdf->summary([['Song leader', $l['first_name'] ? member_name($l) : '—'], ['Songs', count($songs)], ['Team members', count($team)]]);
        $pdf->heading('Songs');
        $pdf->table([['#', .4, 'R'], ['Song', 3], ['Artist', 2], ['Part', 1], ['Notes', 2]],
            array_map(static fn($s) => [$s['sort_order'], $s['title'], $s['artist'] ?: '—', self::SONG_CATS[$s['category']], $s['remarks'] ?? ''], $songs));
        $pdf->heading('Music team');
        $pdf->table([['Name', 2.5], ['Role', 1.5], ['Instrument', 1.5], ['Note', 2]],
            array_map(static fn($t) => [member_name($t), self::ROLES[$t['role']], $t['instrument'] ?? '', $t['note'] ?? ''], $team), null, 'No team members recorded.');
        if ($l['remarks']) { $pdf->heading('Remarks'); $pdf->note($l['remarks']); }
        $pdf->download('lineup-' . $l['lineup_code'] . '.pdf', true);
    }

    public function exportCsv(): void
    {
        [$where, $params] = $this->filters();
        $rows = DB::all("SELECT l.lineup_code, l.service_date, l.service_type, l.service_title, sl.first_name, sl.last_name, sl.middle_name, sl.suffix,
                                ls.sort_order, ls.category, so.title, a.name artist, ls.youtube_url
                           FROM worship_lineups l LEFT JOIN members sl ON sl.id = l.song_leader_member_id
                           JOIN lineup_songs ls ON ls.lineup_id = l.id JOIN songs so ON so.id = ls.song_id LEFT JOIN artists a ON a.id = so.artist_id
                          WHERE $where ORDER BY l.service_date DESC, ls.sort_order", $params);
        Audit::log('export', 'music', null, null, 'Lineups', 'CSV · ' . count($rows) . ' rows');
        Csv::download('worship-lineups-' . date('Ymd') . '.csv',
            ['Lineup ID', 'Date', 'Service', 'Song leader', 'Order', 'Part', 'Song', 'Artist', 'YouTube'],
            array_map(static fn($r) => [$r['lineup_code'], $r['service_date'], $r['service_title'] ?: self::SERVICE_TYPES[$r['service_type']], $r['first_name'] ? member_name($r) : '',
                $r['sort_order'], self::SONG_CATS[$r['category']], $r['title'], $r['artist'], $r['youtube_url']], $rows));
    }
}
