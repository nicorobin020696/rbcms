<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\HttpException;

/** First-run setup: creates the Super Admin account. Disabled permanently once any user exists. */
final class SetupController extends Controller
{
    private function guard(): void
    {
        if ((int) DB::value('SELECT COUNT(*) FROM users') > 0) {
            throw new HttpException(404);
        }
    }

    public function show(): void
    {
        $this->guard();
        $this->view('auth/setup', ['title' => 'First-time setup'], 'blank');
    }

    public function store(): void
    {
        $this->guard();
        $name = input_str('full_name', 120);
        $username = strtolower(input_str('username', 50));
        $email = input_str('email', 150);
        $password = (string) ($_POST['password'] ?? '');
        $errors = [];
        if ($name === '') { $errors['full_name'] = 'Enter your full name.'; }
        if (!preg_match('/^[a-z0-9._-]{3,50}$/', $username)) { $errors['username'] = 'Use 3–50 letters, numbers, dots, dashes or underscores.'; }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors['email'] = 'Enter a valid e-mail address or leave it blank.'; }
        if ($p = Auth::passwordProblem($password, $username)) { $errors['password'] = $p; }
        if ($password !== ($_POST['password_confirm'] ?? '')) { $errors['password_confirm'] = 'The passwords do not match.'; }
        if ($errors) {
            $this->failed($errors, '/setup');
        }
        $roleId = (int) DB::value("SELECT id FROM roles WHERE code = 'super_admin'");
        $id = DB::insert('users', [
            'username' => $username, 'email' => $email ?: null, 'full_name' => $name, 'position' => 'IT Administrator',
            'password_hash' => Auth::hash($password), 'role_id' => $roleId, 'password_changed_at' => now(),
        ]);
        Audit::log('create', 'users', 'user', $id, $username, 'Super Admin account created during first-time setup', $id, $name);
        flash('success', 'Setup complete. Sign in with your new Super Admin account.');
        redirect('/login');
    }
}
