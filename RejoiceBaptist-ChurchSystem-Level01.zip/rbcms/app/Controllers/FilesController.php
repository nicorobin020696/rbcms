<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Upload;

/**
 * Serves uploaded files from storage/ after checking the permission that protects each folder.
 * Finance receipts and confidential documents can never be opened by guessing a URL.
 */
final class FilesController extends Controller
{
    private const RULES = [
        'members'       => ['members.view', 'ministry.lead', 'attendance.record', 'music.view'],
        'events'        => ['events.view', 'calendar.view'],
        'announcements' => ['announcements.view'],
        'lineups'       => ['music.view'],
        'signatures'    => ['documents.view', 'documents.templates'],
        'receipts'      => ['finance.view'],
        'branding'      => [],
    ];

    public function show(string $path): void
    {
        $folder = explode('/', $path)[0];
        if (!array_key_exists($folder, self::RULES)) {
            throw new HttpException(404);
        }
        $perms = self::RULES[$folder];
        if ($perms && !Auth::canAny(...$perms)) {
            throw new HttpException(403);
        }
        if ($folder === 'receipts' && !DB::value('SELECT 1 FROM fin_transactions WHERE attachment_path = ?', [$path])) {
            throw new HttpException(404);
        }
        $full = Upload::path($path);
        if (!$full || !is_file($full)) {
            throw new HttpException(404);
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($full) ?: 'application/octet-stream';
        $inline = str_starts_with($mime, 'image/') || $mime === 'application/pdf';
        $name = basename($full);
        if ($folder === 'receipts') {
            $orig = DB::value('SELECT attachment_name FROM fin_transactions WHERE attachment_path = ?', [$path]);
            $name = $orig ?: $name;
        }
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($full));
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . preg_replace('/[^\w .()-]/u', '_', $name) . '"');
        header('Cache-Control: private, max-age=3600');
        header("Content-Security-Policy: default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox");
        readfile($full);
        exit;
    }
}
