<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\View;

abstract class Controller
{
    protected function view(string $template, array $data = [], string $layout = 'app'): void
    {
        $GLOBALS['__old'] = $_SESSION['_old'] ?? [];
        $GLOBALS['__errors'] = $_SESSION['_errors'] ?? [];
        unset($_SESSION['_old'], $_SESSION['_errors']);
        $data['errors'] = $GLOBALS['__errors'];
        echo View::render($template, $data, $layout);
    }

    protected function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    /** Fetch one row or throw 404. */
    protected function find(string $sql, array $params): array
    {
        $row = DB::one($sql, $params);
        if (!$row) {
            throw new HttpException(404);
        }
        return $row;
    }

    /** Redirect back to the form with errors and the submitted values. */
    protected function failed(array $errors, string $to): never
    {
        with_input($errors);
        flash('error', count($errors) === 1 ? reset($errors) : 'Please correct the highlighted fields.');
        redirect($to);
    }

    /** Options for a <select> of active members: [id => "Last, First (CODE)"]. */
    protected function memberOptions(bool $includeInactive = false): array
    {
        return DB::all(
            "SELECT id, member_code, first_name, middle_name, last_name, suffix, membership_status
               FROM members WHERE archived_at IS NULL" . ($includeInactive ? '' : " AND membership_status = 'active'") .
            ' ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE'
        );
    }

    protected function categories(string $type, bool $activeOnly = true): array
    {
        return DB::all(
            'SELECT * FROM categories WHERE type = ?' . ($activeOnly ? ' AND is_active = 1' : '') . ' ORDER BY sort_order, name',
            [$type]
        );
    }
}
