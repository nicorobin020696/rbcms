<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\Upload;
use App\Services\RichText;

/** Document templates and signatories (with optional e-signature image). */
final class TemplatesController extends Controller
{
    public function index(): void
    {
        $this->view('settings/templates', ['title' => 'Document templates',
            'templates' => DB::all('SELECT t.*, (SELECT COUNT(*) FROM documents d WHERE d.template_id = t.id) used FROM document_templates t ORDER BY t.is_active DESC, t.is_certificate, t.name')]);
    }

    public function create(): void
    {
        $this->view('settings/template_form', ['title' => 'New template', 't' => ['is_active' => 1, 'doc_type' => 'other', 'body_html' => '<p>Dear {{recipient_name}},</p><p></p>', 'closing' => 'Sincerely,']]);
    }

    public function edit(int $id): void
    {
        $this->view('settings/template_form', ['title' => 'Edit template', 't' => $this->find('SELECT * FROM document_templates WHERE id = ?', [$id])]);
    }

    public function store(): void
    {
        [$d, $e] = $this->validate(null);
        if ($e) { $this->failed($e, '/settings/templates/new'); }
        $id = DB::insert('document_templates', $d + ['updated_by' => Auth::id()]);
        Audit::log('create', 'documents', 'template', $id, $d['name']);
        flash('success', 'Template created.');
        redirect('/settings/templates');
    }

    public function update(int $id): void
    {
        $before = $this->find('SELECT * FROM document_templates WHERE id = ?', [$id]);
        [$d, $e] = $this->validate($id);
        if ($e) { $this->failed($e, "/settings/templates/$id"); }
        DB::update('document_templates', $d + ['updated_by' => Auth::id(), 'updated_at' => now()], 'id = :id', ['id' => $id]);
        Audit::log('update', 'documents', 'template', $id, $d['name'], Audit::diff($before, $d, ['name' => 'Name', 'title' => 'Title', 'is_active' => 'Active', 'confidential' => 'Confidential']) ?: 'Content edited');
        flash('success', 'Template saved. Existing documents are not changed.');
        redirect('/settings/templates');
    }

    private function validate(?int $id): array
    {
        $d = ['name' => input_str('name', 100), 'doc_type' => input_in('doc_type', array_keys(DocumentsController::TYPES), 'other'),
            'title' => input_str('title', 150), 'body_html' => RichText::sanitize((string) ($_POST['body_html'] ?? '')),
            'closing' => input_str('closing', 100) ?: null, 'is_certificate' => input_str('is_certificate') === '1' ? 1 : 0,
            'confidential' => input_str('confidential') === '1' ? 1 : 0, 'is_active' => input_str('is_active') === '1' ? 1 : 0];
        $e = [];
        if ($d['name'] === '') { $e['name'] = 'Name is required.'; }
        elseif (DB::value('SELECT 1 FROM document_templates WHERE name = ? COLLATE NOCASE AND id <> ?', [$d['name'], $id ?? 0])) { $e['name'] = 'A template with this name already exists.'; }
        if ($d['title'] === '') { $e['title'] = 'Title is required.'; }
        if (RichText::toText($d['body_html']) === '') { $e['body_html'] = 'Write the template text.'; }
        return [$d, $e];
    }

    public function signatories(): void
    {
        $edit = ($id = input_int('edit')) ? DB::one('SELECT * FROM signatories WHERE id = ?', [$id]) : null;
        $this->view('settings/signatories', ['title' => 'Signatories', 'list' => DB::all('SELECT * FROM signatories ORDER BY is_active DESC, sort_order, name'), 'edit' => $edit]);
    }

    public function saveSignatory(): void
    {
        $id = input_int('id');
        $before = $id ? $this->find('SELECT * FROM signatories WHERE id = ?', [$id]) : null;
        $d = ['name' => input_str('name', 120), 'position' => input_str('position', 120), 'sort_order' => input_int('sort_order') ?? 0, 'is_active' => input_str('is_active') === '1' ? 1 : 0];
        $e = [];
        if ($d['name'] === '') { $e['name'] = 'Name is required.'; }
        if ($d['position'] === '') { $e['position'] = 'Position is required, e.g. Senior Pastor.'; }
        [$sig, $err] = Upload::image('signature', 'signatures', 800);
        if ($err) { $e['signature'] = $err; }
        $back = '/settings/signatories' . ($id ? '?edit=' . $id : '');
        if ($e) { Upload::delete($sig); $this->failed($e, $back); }
        $remove = !empty($_POST['remove_signature']);
        if ($sig || $remove) { $d['signature_path'] = $sig; }
        if ($before) {
            DB::update('signatories', $d, 'id = :id', ['id' => $id]);
            if ($sig || $remove) { Upload::delete($before['signature_path']); }
            Audit::log('update', 'documents', 'signatory', $id, $d['name'], $sig ? 'Signature image replaced' : ($remove ? 'Signature image removed' : null));
        } else {
            $id = DB::insert('signatories', $d);
            Audit::log('create', 'documents', 'signatory', $id, $d['name'] . ' · ' . $d['position']);
        }
        flash('success', 'Signatory saved.');
        redirect('/settings/signatories');
    }
}
