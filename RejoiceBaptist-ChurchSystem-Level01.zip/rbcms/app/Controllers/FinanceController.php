<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Ids;
use App\Core\Notify;
use App\Core\Paginator;
use App\Core\Upload;
use App\Services\Stats;

/**
 * Church funds: income (tithes, offerings, donations...) and expenses.
 * Every route is protected by finance.* permissions; amounts are stored as integer centavos.
 * Transactions are never deleted — mistakes are voided with a reason so the books stay auditable.
 */
final class FinanceController extends Controller
{
    public const ACTIVE = 'voided_at IS NULL';

    public static function totals(string $from, string $to, string $extra = '', array $params = []): array
    {
        $r = DB::one("SELECT COALESCE(SUM(CASE WHEN txn_type = 'income' THEN amount_cents END), 0) income,
                             COALESCE(SUM(CASE WHEN txn_type = 'expense' THEN amount_cents END), 0) expense
                        FROM fin_transactions t WHERE voided_at IS NULL AND txn_date BETWEEN :f AND :t $extra", ['f' => $from, 't' => $to] + $params);
        return ['income' => (int) $r['income'], 'expense' => (int) $r['expense'], 'net' => (int) $r['income'] - (int) $r['expense']];
    }

    public static function balanceBefore(string $date): int
    {
        return (int) DB::value("SELECT COALESCE(SUM(CASE WHEN txn_type = 'income' THEN amount_cents ELSE -amount_cents END), 0) FROM fin_transactions WHERE voided_at IS NULL AND txn_date < ?", [$date]);
    }

    public static function monthly(int $year): array
    {
        $rows = DB::all("SELECT CAST(strftime('%m', txn_date) AS INTEGER) m, txn_type, SUM(amount_cents) s FROM fin_transactions
                          WHERE voided_at IS NULL AND strftime('%Y', txn_date) = ? GROUP BY m, txn_type", [(string) $year]);
        $out = ['income' => array_fill(0, 12, 0), 'expense' => array_fill(0, 12, 0)];
        foreach ($rows as $r) {
            $out[$r['txn_type']][$r['m'] - 1] = (int) $r['s'];
        }
        return $out;
    }

    public function dashboard(): void
    {
        $year = input_int('year') ?: (int) date('Y');
        $mStart = date('Y-m-01');
        $mEnd = date('Y-m-t');
        $prevStart = date('Y-m-01', strtotime('first day of last month'));
        $prevEnd = date('Y-m-t', strtotime('last day of last month'));
        $monthly = self::monthly($year);
        $this->view('finance/dashboard', [
            'title' => 'Finance', 'year' => $year,
            'month' => self::totals($mStart, $mEnd), 'prev' => self::totals($prevStart, $prevEnd),
            'yearTotals' => self::totals("$year-01-01", "$year-12-31"),
            'balance' => self::balanceBefore('9999-12-31'),
            'monthly' => $monthly,
            'byIncome' => DB::all("SELECT c.name, c.color, SUM(t.amount_cents) total FROM fin_transactions t JOIN categories c ON c.id = t.category_id
                                    WHERE t.voided_at IS NULL AND t.txn_type = 'income' AND strftime('%Y', t.txn_date) = ? GROUP BY c.id ORDER BY total DESC", [(string) $year]),
            'byExpense' => DB::all("SELECT c.name, c.color, SUM(t.amount_cents) total FROM fin_transactions t JOIN categories c ON c.id = t.category_id
                                     WHERE t.voided_at IS NULL AND t.txn_type = 'expense' AND strftime('%Y', t.txn_date) = ? GROUP BY c.id ORDER BY total DESC", [(string) $year]),
            'budgets' => BudgetsController::withActuals("b.status = 'active' AND b.period_end >= date('now','localtime','-31 days')", [], 6),
            'recent' => DB::all("SELECT t.*, c.name category FROM fin_transactions t JOIN categories c ON c.id = t.category_id ORDER BY t.txn_date DESC, t.id DESC LIMIT 8"),
            'years' => array_unique(array_merge([date('Y')], DB::column("SELECT DISTINCT strftime('%Y', txn_date) FROM fin_transactions ORDER BY 1 DESC"))),
        ]);
    }

    private function filters(): array
    {
        $where = ['1=1'];
        $p = [];
        if (($q = query_str('q')) !== '') {
            $where[] = "(t.txn_code LIKE :q ESCAPE '\\' OR t.description LIKE :q ESCAPE '\\' OR t.payer_payee LIKE :q ESCAPE '\\' OR t.reference_no LIKE :q ESCAPE '\\')";
            $p['q'] = like($q);
        }
        if ($type = input_in('type', ['income', 'expense'], '')) { $where[] = 't.txn_type = :type'; $p['type'] = $type; }
        if ($c = input_int('category')) { $where[] = 't.category_id = :c'; $p['c'] = $c; }
        if ($m = input_int('ministry')) { $where[] = 't.ministry_id = :mi'; $p['mi'] = $m; }
        if ($b = input_int('budget')) { $where[] = 't.budget_id = :b'; $p['b'] = $b; }
        if ($f = input_date('from')) { $where[] = 't.txn_date >= :f'; $p['f'] = $f; }
        if ($to = input_date('to')) { $where[] = 't.txn_date <= :to'; $p['to'] = $to; }
        $st = input_in('status', ['active', 'voided', 'all'], 'active');
        if ($st === 'active') { $where[] = 't.voided_at IS NULL'; }
        if ($st === 'voided') { $where[] = 't.voided_at IS NOT NULL'; }
        return [implode(' AND ', $where), $p];
    }

    private const LIST_SQL = "SELECT t.*, c.name category, c.color, mi.name ministry, ev.title event, b.name budget, u.full_name recorder
        FROM fin_transactions t JOIN categories c ON c.id = t.category_id LEFT JOIN ministries mi ON mi.id = t.ministry_id
        LEFT JOIN events ev ON ev.id = t.event_id LEFT JOIN budgets b ON b.id = t.budget_id LEFT JOIN users u ON u.id = t.recorded_by";

    public function index(): void
    {
        [$w, $p] = $this->filters();
        $pg = new Paginator((int) DB::value("SELECT COUNT(*) FROM fin_transactions t WHERE $w", $p), 25);
        $sum = DB::one("SELECT COALESCE(SUM(CASE WHEN txn_type='income' AND voided_at IS NULL THEN amount_cents END),0) income,
                               COALESCE(SUM(CASE WHEN txn_type='expense' AND voided_at IS NULL THEN amount_cents END),0) expense FROM fin_transactions t WHERE $w", $p);
        $this->view('finance/transactions', [
            'title' => 'Transactions', 'rows' => DB::all(self::LIST_SQL . " WHERE $w ORDER BY t.txn_date DESC, t.id DESC" . $pg->sql(), $p), 'p' => $pg, 'sum' => $sum,
            'categories' => DB::all("SELECT id, name, type FROM categories WHERE type IN ('income','expense') ORDER BY type, sort_order, name"),
            'ministries' => DB::all('SELECT id, name FROM ministries ORDER BY name'),
        ]);
    }

    public function show(int $id): void
    {
        $t = $this->find(self::LIST_SQL . ' WHERE t.id = ?', [$id]);
        $t['voided_by_name'] = $t['voided_by'] ? DB::value('SELECT full_name FROM users WHERE id = ?', [$t['voided_by']]) : null;
        $this->view('finance/show', ['title' => $t['txn_code'], 't' => $t]);
    }

    public function create(): void
    {
        $this->form(['txn_type' => input_in('type', ['income', 'expense'], 'income'), 'txn_date' => today(), 'budget_id' => input_int('budget')], 'Record transaction');
    }

    public function edit(int $id): void
    {
        $t = $this->find('SELECT * FROM fin_transactions WHERE id = ?', [$id]);
        if ($t['voided_at']) {
            flash('warning', 'Voided transactions cannot be edited.');
            redirect("/finance/transactions/$id");
        }
        $this->form($t, 'Edit ' . $t['txn_code']);
    }

    private function form(array $t, string $title): void
    {
        $this->view('finance/form', [
            'title' => $title, 't' => $t,
            'income' => $this->categories('income'), 'expense' => $this->categories('expense'),
            'ministries' => DB::all('SELECT id, name FROM ministries WHERE archived_at IS NULL ORDER BY name'),
            'events' => DB::all("SELECT id, title, start_date FROM events WHERE archived_at IS NULL AND is_activity = 1 AND start_date >= date('now','localtime','-1 year') ORDER BY start_date DESC"),
            'budgets' => DB::all("SELECT id, name, budget_code FROM budgets WHERE status = 'active' OR id = ? ORDER BY period_start DESC", [(int) ($t['budget_id'] ?? 0)]),
        ]);
    }

    public function store(): void
    {
        [$d, $e] = $this->validate();
        [$file, $err] = Upload::document('attachment', 'receipts');
        if ($err) { $e['attachment'] = $err; }
        if ($e) { Upload::delete($file); $this->failed($e, '/finance/transactions/new?type=' . $d['txn_type']); }
        if ($file) { $d['attachment_path'] = $file; $d['attachment_name'] = Upload::originalName('attachment'); }
        $id = DB::transaction(function () use ($d) {
            $d['txn_code'] = Ids::next('txn', $d['txn_date']);
            $d['recorded_by'] = Auth::id();
            return DB::insert('fin_transactions', $d);
        });
        Audit::log('create', 'finance', 'transaction', $id, ucfirst($d['txn_type']) . ' · ' . $d['description'], money($d['amount_cents']) . ' on ' . $d['txn_date']);
        $this->checkBudget($d['budget_id']);
        flash('success', ucfirst($d['txn_type']) . ' of ' . money($d['amount_cents']) . ' recorded.');
        redirect(input_str('again') === '1' ? '/finance/transactions/new?type=' . $d['txn_type'] : "/finance/transactions/$id");
    }

    public function update(int $id): void
    {
        $before = $this->find('SELECT * FROM fin_transactions WHERE id = ?', [$id]);
        if ($before['voided_at']) { throw new HttpException(403, 'Voided transactions cannot be edited.'); }
        [$d, $e] = $this->validate();
        [$file, $err] = Upload::document('attachment', 'receipts');
        if ($err) { $e['attachment'] = $err; }
        if ($e) { Upload::delete($file); $this->failed($e, "/finance/transactions/$id/edit"); }
        $remove = !empty($_POST['remove_attachment']);
        if ($file || $remove) { $d['attachment_path'] = $file; $d['attachment_name'] = $file ? Upload::originalName('attachment') : null; }
        $d['updated_at'] = now();
        DB::update('fin_transactions', $d, 'id = :id', ['id' => $id]);
        if ($file || $remove) { Upload::delete($before['attachment_path']); }
        $labels = ['txn_date' => 'Date', 'txn_type' => 'Type', 'category_id' => 'Category', 'description' => 'Description', 'amount_cents' => 'Amount (centavos)',
            'ministry_id' => 'Ministry', 'event_id' => 'Event', 'budget_id' => 'Budget', 'payer_payee' => 'Payer/payee', 'reference_no' => 'Reference'];
        Audit::log('update', 'finance', 'transaction', $id, $before['txn_code'], Audit::diff($before, $d, $labels) ?: null);
        $this->checkBudget($d['budget_id']);
        flash('success', 'Transaction updated.');
        redirect("/finance/transactions/$id");
    }

    public function void(int $id): void
    {
        $t = $this->find('SELECT * FROM fin_transactions WHERE id = ? AND voided_at IS NULL', [$id]);
        $reason = input_str('reason', 250);
        if ($reason === '') {
            flash('error', 'Give a reason for voiding this transaction.');
            redirect("/finance/transactions/$id");
        }
        DB::update('fin_transactions', ['voided_at' => now(), 'voided_by' => Auth::id(), 'void_reason' => $reason], 'id = :id', ['id' => $id]);
        Audit::log('void', 'finance', 'transaction', $id, $t['txn_code'], money($t['amount_cents']) . ' — ' . $reason);
        flash('success', 'Transaction voided. It no longer counts in totals.');
        redirect("/finance/transactions/$id");
    }

    private function validate(): array
    {
        $type = input_in('txn_type', ['income', 'expense'], 'income');
        $d = [
            'txn_type' => $type, 'txn_date' => input_date('txn_date'), 'category_id' => input_int('category_id'),
            'description' => input_str('description', 200), 'amount_cents' => parse_money(input_str('amount', 20)),
            'ministry_id' => input_int('ministry_id'), 'event_id' => input_int('event_id'), 'budget_id' => $type === 'expense' ? input_int('budget_id') : null,
            'payer_payee' => input_str('payer_payee', 150) ?: null, 'reference_no' => input_str('reference_no', 60) ?: null, 'remarks' => input_text('remarks', 1000) ?: null,
        ];
        $e = [];
        if (!$d['txn_date']) { $e['txn_date'] = 'Enter the transaction date.'; }
        elseif ($d['txn_date'] > date('Y-m-d', strtotime('+1 day'))) { $e['txn_date'] = 'The date cannot be in the future.'; }
        if (!$d['category_id'] || !DB::value('SELECT 1 FROM categories WHERE id = ? AND type = ?', [$d['category_id'], $type])) { $e['category_id'] = 'Choose a category.'; }
        if ($d['description'] === '') { $e['description'] = 'Describe the transaction.'; }
        if ($d['amount_cents'] === null || $d['amount_cents'] <= 0) { $e['amount'] = 'Enter an amount greater than zero, e.g. 1,500.00'; }
        elseif ($d['amount_cents'] > 99_999_999_999) { $e['amount'] = 'Amount is too large.'; }
        foreach (['ministry_id' => 'ministries', 'event_id' => 'events', 'budget_id' => 'budgets'] as $k => $tbl) {
            if ($d[$k] && !DB::value("SELECT 1 FROM $tbl WHERE id = ?", [$d[$k]])) { $d[$k] = null; }
        }
        return [$d, $e];
    }

    /** Warn finance users once when a budget goes over. */
    private function checkBudget(?int $budgetId): void
    {
        if (!$budgetId) { return; }
        $b = BudgetsController::withActuals('b.id = :id', ['id' => $budgetId], 1)[0] ?? null;
        if ($b && $b['amount_cents'] > 0 && $b['spent'] > $b['amount_cents']) {
            Notify::permission('finance.view', 'finance', 'Budget exceeded: ' . $b['name'],
                'Spending is now ' . round($b['spent'] / $b['amount_cents'] * 100) . '% of the planned budget.', '/finance/budgets/' . $budgetId, 'budget-over-' . $budgetId, false);
            flash('warning', 'Note: the budget "' . $b['name'] . '" is now over its planned amount.');
        }
    }

    public function giving(): void
    {
        $year = input_int('year') ?: (int) date('Y');
        $cats = DB::all("SELECT id, name, color FROM categories WHERE type = 'income' AND grp = 'giving' ORDER BY sort_order");
        $rows = DB::all("SELECT category_id, CAST(strftime('%m', txn_date) AS INTEGER) m, SUM(amount_cents) s FROM fin_transactions
                          WHERE voided_at IS NULL AND txn_type = 'income' AND strftime('%Y', txn_date) = ? AND category_id IN (SELECT id FROM categories WHERE grp = 'giving')
                          GROUP BY category_id, m", [(string) $year]);
        $grid = [];
        foreach ($cats as $c) { $grid[$c['id']] = array_fill(0, 12, 0); }
        foreach ($rows as $r) { $grid[$r['category_id']][$r['m'] - 1] = (int) $r['s']; }
        $prevTotal = (int) DB::value("SELECT COALESCE(SUM(amount_cents),0) FROM fin_transactions WHERE voided_at IS NULL AND txn_type = 'income' AND strftime('%Y', txn_date) = ? AND category_id IN (SELECT id FROM categories WHERE grp = 'giving')", [(string) ($year - 1)]);
        $sundays = DB::all("SELECT txn_date, SUM(amount_cents) s FROM fin_transactions WHERE voided_at IS NULL AND txn_type = 'income' AND category_id IN (SELECT id FROM categories WHERE grp = 'giving')
                             AND strftime('%w', txn_date) = '0' AND txn_date <= date('now','localtime') GROUP BY txn_date ORDER BY txn_date DESC LIMIT 12");
        $this->view('finance/giving', ['title' => 'Donations & offerings', 'year' => $year, 'cats' => $cats, 'grid' => $grid, 'prevTotal' => $prevTotal, 'sundays' => array_reverse($sundays),
            'years' => array_unique(array_merge([date('Y')], DB::column("SELECT DISTINCT strftime('%Y', txn_date) FROM fin_transactions ORDER BY 1 DESC")))]);
    }

    public function exportCsv(): void
    {
        [$w, $p] = $this->filters();
        $rows = DB::all(self::LIST_SQL . " WHERE $w ORDER BY t.txn_date, t.id", $p);
        Audit::log('export', 'finance', null, null, 'Transactions', 'CSV · ' . count($rows) . ' rows');
        Csv::download('transactions-' . date('Ymd') . '.csv',
            ['Transaction ID', 'Date', 'Type', 'Category', 'Description', 'Amount', 'Payer/Payee', 'Reference', 'Ministry', 'Event', 'Budget', 'Status', 'Void reason', 'Recorded by'],
            array_map(static fn($t) => [$t['txn_code'], $t['txn_date'], ucfirst($t['txn_type']), $t['category'], $t['description'], number_format($t['amount_cents'] / 100, 2, '.', ''),
                $t['payer_payee'], $t['reference_no'], $t['ministry'], $t['event'], $t['budget'], $t['voided_at'] ? 'Voided' : 'Active', $t['void_reason'], $t['recorder']], $rows));
    }
}
