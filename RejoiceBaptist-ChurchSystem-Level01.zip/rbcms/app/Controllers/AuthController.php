<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database as DB;

final class AuthController extends Controller
{
    public function showLogin(): void
    {
        if ((int) DB::value('SELECT COUNT(*) FROM users') === 0) {
            redirect('/setup');
        }
        $this->view('auth/login', ['title' => 'Sign in', 'error' => $_SESSION['login_error'] ?? null, 'username' => $_SESSION['login_user'] ?? '', 'flashes' => take_flashes()], 'blank');
        unset($_SESSION['login_error'], $_SESSION['login_user']);
    }

    public function login(): void
    {
        $login = input_str('username', 100);
        $password = (string) ($_POST['password'] ?? '');
        if ($login === '' || $password === '') {
            $_SESSION['login_error'] = 'Enter your username and password.';
            $_SESSION['login_user'] = $login;
            redirect('/login');
        }
        [$ok, $error] = Auth::attempt($login, mb_substr($password, 0, 200));
        if (!$ok) {
            $_SESSION['login_error'] = $error;
            $_SESSION['login_user'] = $login;
            redirect('/login');
        }
        $intended = $_SESSION['intended'] ?? null;
        unset($_SESSION['intended']);
        if ($intended && str_starts_with($intended, '/') && !str_starts_with($intended, '//') && !str_contains($intended, '/notifications/feed')) {
            header('Location: ' . $intended);
            exit;
        }
        redirect('/');
    }

    public function logout(): void
    {
        Auth::logout();
        flash('success', 'You have been signed out.');
        redirect('/login');
    }
}
