<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;

final class ProfileController extends Controller
{
    public function show(): void
    {
        $this->view('profile/show', ['title' => 'Profile & appearance', 'u' => Auth::user(), 'narrow' => true]);
    }

    public function update(): void
    {
        $name = input_str('full_name', 120);
        $theme = input_in('theme', ['system', 'light', 'dark'], 'system');
        if ($name === '') {
            $this->failed(['full_name' => 'Enter your full name.'], '/profile');
        }
        DB::update('users', ['full_name' => $name, 'theme' => $theme, 'updated_at' => now()], 'id = :id', ['id' => Auth::id()]);
        $_SESSION['uname'] = $name;
        flash('success', 'Your profile was saved.');
        redirect('/profile');
    }

    public function theme(): void
    {
        $theme = input_in('theme', ['system', 'light', 'dark'], 'system');
        DB::update('users', ['theme' => $theme], 'id = :id', ['id' => Auth::id()]);
        $this->json(['ok' => true]);
    }

    public function password(): void
    {
        $this->view('profile/password', ['title' => 'Change password', 'forced' => (bool) Auth::user()['must_change_password'], 'narrow' => true]);
    }

    public function updatePassword(): void
    {
        $u = Auth::user();
        $current = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['password'] ?? '');
        $errors = [];
        if (!password_verify($current, $u['password_hash'])) {
            $errors['current_password'] = 'Your current password is incorrect.';
        }
        if ($p = Auth::passwordProblem($new, $u['username'])) {
            $errors['password'] = $p;
        } elseif (password_verify($new, $u['password_hash'])) {
            $errors['password'] = 'Choose a password different from your current one.';
        }
        if ($new !== ($_POST['password_confirm'] ?? '')) {
            $errors['password_confirm'] = 'The passwords do not match.';
        }
        if ($errors) {
            $this->failed($errors, '/password');
        }
        $version = (int) $u['session_version'] + 1;
        DB::update('users', [
            'password_hash' => Auth::hash($new), 'must_change_password' => 0, 'password_changed_at' => now(),
            'session_version' => $version, 'updated_at' => now(),
        ], 'id = :id', ['id' => $u['id']]);
        // Keep this session; every other computer signed in as this user is signed out.
        $_SESSION['sv'] = $version;
        session_regenerate_id(true);
        Auth::forgetCache();
        Audit::log('password', 'users', 'user', (int) $u['id'], $u['username'], 'Changed own password');
        flash('success', 'Your password was changed. Other computers signed in as you were signed out.');
        redirect('/');
    }
}
