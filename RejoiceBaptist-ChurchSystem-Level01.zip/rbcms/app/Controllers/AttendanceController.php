<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Ids;
use App\Core\Paginator;
use App\Core\PdfReport;
use App\Services\Stats;

final class AttendanceController extends Controller
{
    /** Saved records may be corrected freely for this many hours; afterwards attendance.correct is required. */
    public const CORRECTION_WINDOW_HOURS = 48;

    // ------------------------------------------------------------ access helpers

    private function canRecordSession(array $s): bool
    {
        return can('attendance.record') || ($s['ministry_id'] && Auth::leads((int) $s['ministry_id']));
    }

    private function canViewSession(array $s): bool
    {
        return can('attendance.view') || can('attendance.record') || ($s['ministry_id'] && Auth::leads((int) $s['ministry_id']));
    }

    public static function canCorrect(array $s): bool
    {
        return can('attendance.correct') || (time() - strtotime($s['created_at'])) < self::CORRECTION_WINDOW_HOURS * 3600;
    }

    // ------------------------------------------------------------ dashboard

    public function index(): void
    {
        if (!can('attendance.view')) {
            redirect('/attendance/sessions');
        }
        $year = max(2000, min(2100, input_int('year') ?? (int) date('Y')));
        $today = today();
        $weekStart = date('Y-m-d', strtotime('monday this week'));
        $monthStart = date('Y-m-01');
        $yearStart = date('Y-01-01');
        $cards = [
            'today' => Stats::presentBetween($today, $today),
            'week' => Stats::presentBetween($weekStart, $today),
            'month' => Stats::presentBetween($monthStart, $today),
            'year' => Stats::presentBetween($yearStart, $today),
        ];
        $prevMonth = Stats::presentBetween(date('Y-m-01', strtotime('first day of last month')), date('Y-m-t', strtotime('last day of last month')));
        $categories = $this->categories('attendance');
        $sundayId = (int) DB::value("SELECT id FROM categories WHERE type = 'attendance' AND code = 'sunday_service'");
        $monthly = Stats::monthlyAttendance($year);
        $monthlyPrev = Stats::monthlyAttendance($year - 1);
        $sunday = Stats::monthlyAttendance($year, $sundayId);
        $from = "$year-01-01";
        $to = "$year-12-31";
        $byCategory = Stats::byCategory($from, $to);
        $byMinistry = Stats::byMinistry($from, $to);
        $weekly = Stats::weeklyAttendance(12);
        $daily = Stats::dailyAttendance(14);
        $yearly = Stats::yearlyAttendance(5);
        $recent = $this->sessionQuery('1=1', [], 'ORDER BY s.session_date DESC, s.id DESC LIMIT 8');
        $top = DB::all(
            "SELECT m.id, m.first_name, m.last_name, m.middle_name, m.suffix, m.member_code, COUNT(*) present
               FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id JOIN members m ON m.id = r.member_id
              WHERE r.status = 'present' AND s.session_date BETWEEN ? AND ? AND m.archived_at IS NULL
              GROUP BY m.id ORDER BY present DESC, m.last_name LIMIT 10",
            [$from, $to]
        );
        $years = DB::column("SELECT DISTINCT strftime('%Y', session_date) FROM attendance_sessions ORDER BY 1 DESC") ?: [date('Y')];
        if (!in_array((string) $year, $years, true)) {
            $years[] = (string) $year;
        }
        $this->view('attendance/index', compact('year', 'cards', 'prevMonth', 'categories', 'monthly', 'monthlyPrev', 'sunday', 'byCategory', 'byMinistry', 'weekly', 'daily', 'yearly', 'recent', 'top', 'years') + ['title' => 'Attendance']);
    }

    // ------------------------------------------------------------ sessions

    private function sessionQuery(string $where, array $params, string $tail): array
    {
        if (!can('attendance.view') && !can('attendance.record')) {
            $led = Auth::ledMinistryIds() ?: [0];
            $where .= ' AND s.ministry_id IN (' . implode(',', $led) . ')';
        }
        return DB::all(
            "SELECT s.*, c.name AS category, c.color, mi.name AS ministry, u.full_name AS recorded_by_name,
                    (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status = 'present') present,
                    (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status = 'absent') absent,
                    (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status = 'excused') excused
               FROM attendance_sessions s JOIN categories c ON c.id = s.category_id
               LEFT JOIN ministries mi ON mi.id = s.ministry_id LEFT JOIN users u ON u.id = s.created_by
              WHERE $where $tail",
            $params
        );
    }

    private function sessionFilters(): array
    {
        $w = ['1=1'];
        $p = [];
        if ($c = input_int('category')) { $w[] = 's.category_id = :cat'; $p['cat'] = $c; }
        if ($m = input_int('ministry')) { $w[] = 's.ministry_id = :min'; $p['min'] = $m; }
        if ($f = input_date('from')) { $w[] = 's.session_date >= :from'; $p['from'] = $f; }
        if ($t = input_date('to')) { $w[] = 's.session_date <= :to'; $p['to'] = $t; }
        if (($q = query_str('q')) !== '') { $w[] = "(s.title LIKE :q ESCAPE '\\' OR s.session_code LIKE :q ESCAPE '\\')"; $p['q'] = like($q); }
        return [implode(' AND ', $w), $p];
    }

    public function sessions(): void
    {
        [$where, $params] = $this->sessionFilters();
        $all = $this->sessionQuery($where, $params, 'ORDER BY s.session_date DESC, s.id DESC');
        $p = new Paginator(count($all), 25);
        $sessions = array_slice($all, $p->offset, $p->perPage);
        $ministries = can('attendance.view') || can('attendance.record')
            ? DB::all('SELECT id, name FROM ministries WHERE archived_at IS NULL ORDER BY name')
            : DB::all('SELECT id, name FROM ministries WHERE id IN (' . (implode(',', Auth::ledMinistryIds()) ?: '0') . ')');
        $this->view('attendance/sessions', ['title' => 'Attendance sessions', 'sessions' => $sessions, 'p' => $p,
            'categories' => $this->categories('attendance'), 'ministries' => $ministries]);
    }

    public function create(): void
    {
        $ministries = $this->recordableMinistries();
        if (!can('attendance.record') && !$ministries) {
            throw new HttpException(403, 'You can record attendance only for ministries you lead.');
        }
        $events = DB::all("SELECT id, title, start_date FROM events WHERE archived_at IS NULL AND cancelled_at IS NULL AND is_activity = 1 AND start_date BETWEEN date('now','localtime','-30 days') AND date('now','localtime','+7 days') ORDER BY start_date DESC");
        $this->view('attendance/create', ['title' => 'Record attendance', 'categories' => $this->categories('attendance'),
            'ministries' => $ministries, 'events' => $events, 'presetMinistry' => input_int('ministry'), 'presetEvent' => input_int('event')]);
    }

    public function store(): void
    {
        $catId = input_int('category_id');
        $cat = $catId ? DB::one("SELECT * FROM categories WHERE id = ? AND type = 'attendance'", [$catId]) : null;
        $date = input_date('session_date');
        $ministryId = input_int('ministry_id');
        $eventId = input_int('event_id');
        $title = input_str('title', 150) ?: ($cat['name'] ?? '');
        $errors = [];
        if (!$cat) { $errors['category_id'] = 'Choose the type of activity.'; }
        if (!$date) { $errors['session_date'] = 'Enter the date of the activity.'; }
        elseif ($date > date('Y-m-d', strtotime('+1 day'))) { $errors['session_date'] = 'Attendance cannot be recorded for a future date.'; }
        if ($ministryId && !DB::value('SELECT 1 FROM ministries WHERE id = ? AND archived_at IS NULL', [$ministryId])) { $ministryId = null; }
        if (!can('attendance.record') && (!$ministryId || !Auth::leads($ministryId))) {
            $errors['ministry_id'] = 'Select one of the ministries you lead.';
        }
        if ($eventId && !DB::value('SELECT 1 FROM events WHERE id = ?', [$eventId])) { $eventId = null; }
        if ($errors) {
            $this->failed($errors, '/attendance/new' . ($ministryId ? '?ministry=' . $ministryId : ''));
        }
        $existing = DB::value('SELECT id FROM attendance_sessions WHERE category_id = ? AND session_date = ? AND title = ? COLLATE NOCASE AND ministry_id IS ?', [$catId, $date, $title, $ministryId]);
        if ($existing) {
            flash('info', 'Attendance for this activity and date already exists. You can continue recording it here.');
            redirect("/attendance/$existing/mark");
        }
        $id = DB::transaction(function () use ($catId, $date, $title, $ministryId, $eventId) {
            return DB::insert('attendance_sessions', [
                'session_code' => Ids::next('attendance', $date), 'category_id' => $catId, 'title' => $title,
                'session_date' => $date, 'session_time' => input_time('session_time'), 'ministry_id' => $ministryId,
                'event_id' => $eventId, 'notes' => input_text('notes', 1000) ?: null, 'created_by' => Auth::id(),
            ]);
        });
        Audit::log('create', 'attendance', 'session', $id, $title . ' · ' . $date);
        redirect("/attendance/$id/mark");
    }

    public function show(int $id): void
    {
        $s = $this->session($id);
        if (!$this->canViewSession($s)) {
            throw new HttpException(403);
        }
        $records = DB::all(
            'SELECT r.*, m.first_name, m.last_name, m.middle_name, m.suffix, m.member_code, m.photo_path, u.full_name AS recorder
               FROM attendance_records r JOIN members m ON m.id = r.member_id LEFT JOIN users u ON u.id = r.recorded_by
              WHERE r.session_id = ? ORDER BY r.status, m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE',
            [$id]
        );
        $this->view('attendance/show', ['title' => $s['title'], 's' => $s, 'records' => $records,
            'canRecord' => $this->canRecordSession($s), 'canCorrect' => self::canCorrect($s)]);
    }

    public function mark(int $id): void
    {
        $s = $this->session($id);
        if (!$this->canRecordSession($s)) {
            throw new HttpException(403);
        }
        $existing = [];
        foreach (DB::all('SELECT * FROM attendance_records WHERE session_id = ?', [$id]) as $r) {
            $existing[(int) $r['member_id']] = $r;
        }
        $members = $this->markableMembers($s, $existing);
        $this->view('attendance/mark', ['title' => 'Record attendance', 's' => $s, 'members' => $members,
            'existing' => $existing, 'canCorrect' => self::canCorrect($s)]);
    }

    public function saveMarks(int $id): void
    {
        $s = $this->session($id);
        if (!$this->canRecordSession($s)) {
            throw new HttpException(403);
        }
        $status = (array) ($_POST['status'] ?? []);
        $remarks = (array) ($_POST['remarks'] ?? []);
        $correct = self::canCorrect($s);
        $allowed = array_flip(array_map(static fn($m) => (int) $m['id'], $this->markableMembers($s, [], true)));
        $existing = [];
        foreach (DB::all('SELECT * FROM attendance_records WHERE session_id = ?', [$id]) as $r) {
            $existing[(int) $r['member_id']] = $r;
            $allowed[(int) $r['member_id']] = true;
        }
        $added = $changed = $removed = $blocked = 0;
        DB::transaction(function () use ($id, $status, $remarks, $existing, $allowed, $correct, &$added, &$changed, &$removed, &$blocked) {
            foreach ($status as $mid => $st) {
                $mid = (int) $mid;
                if (!isset($allowed[$mid]) || !is_string($st)) {
                    continue;
                }
                $rem = mb_substr(trim((string) ($remarks[$mid] ?? '')), 0, 200) ?: null;
                $old = $existing[$mid] ?? null;
                if ($st === '') {
                    if ($old) {
                        if (!$correct) { $blocked++; continue; }
                        DB::query('DELETE FROM attendance_records WHERE id = ?', [$old['id']]);
                        $removed++;
                    }
                    continue;
                }
                if (!in_array($st, ['present', 'absent', 'excused'], true)) {
                    continue;
                }
                if (!$old) {
                    DB::insert('attendance_records', ['session_id' => $id, 'member_id' => $mid, 'status' => $st, 'remarks' => $rem, 'recorded_by' => Auth::id()]);
                    $added++;
                } elseif ($old['status'] !== $st || (string) $old['remarks'] !== (string) $rem) {
                    if (!$correct) { $blocked++; continue; }
                    DB::update('attendance_records', ['status' => $st, 'remarks' => $rem, 'recorded_by' => Auth::id(), 'updated_at' => now()], 'id = :id', ['id' => $old['id']]);
                    $changed++;
                }
            }
            DB::update('attendance_sessions', ['updated_at' => now()], 'id = :id', ['id' => $id]);
        });
        $summary = "$added added, $changed corrected, $removed removed";
        Audit::log($changed || $removed ? 'correct' : 'record', 'attendance', 'session', $id, $s['title'] . ' · ' . $s['session_date'], $summary);
        $msg = 'Attendance saved: ' . $summary . '.';
        if ($blocked) {
            $msg .= " $blocked change(s) to records older than " . self::CORRECTION_WINDOW_HOURS . ' hours were not applied — ask a user with correction permission.';
            flash('warning', $msg);
        } else {
            flash('success', $msg);
        }
        redirect("/attendance/$id");
    }

    public function destroy(int $id): void
    {
        $s = $this->session($id);
        $count = (int) DB::value('SELECT COUNT(*) FROM attendance_records WHERE session_id = ?', [$id]);
        DB::query('DELETE FROM attendance_sessions WHERE id = ?', [$id]);
        Audit::log('delete', 'attendance', 'session', $id, $s['session_code'] . ' ' . $s['title'] . ' · ' . $s['session_date'], "Deleted session with $count record(s)");
        flash('success', 'The attendance session and its records were deleted.');
        redirect('/attendance/sessions');
    }

    // ------------------------------------------------------------ record history & exports

    private function recordFilters(): array
    {
        $w = ['1=1'];
        $p = [];
        if ($m = input_int('member')) { $w[] = 'r.member_id = :member'; $p['member'] = $m; }
        if ($c = input_int('category')) { $w[] = 's.category_id = :cat'; $p['cat'] = $c; }
        if ($mi = input_int('ministry')) { $w[] = 's.ministry_id = :min'; $p['min'] = $mi; }
        if ($f = input_date('from')) { $w[] = 's.session_date >= :from'; $p['from'] = $f; }
        if ($t = input_date('to')) { $w[] = 's.session_date <= :to'; $p['to'] = $t; }
        if (in_array($st = query_str('status'), ['present', 'absent', 'excused'], true)) { $w[] = 'r.status = :st'; $p['st'] = $st; }
        return [implode(' AND ', $w), $p];
    }

    private const RECORD_SQL = "SELECT r.*, s.session_code, s.title, s.session_date, s.session_time, c.name AS category, mi.name AS ministry,
            m.first_name, m.last_name, m.middle_name, m.suffix, m.member_code
          FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id JOIN categories c ON c.id = s.category_id
          JOIN members m ON m.id = r.member_id LEFT JOIN ministries mi ON mi.id = s.ministry_id";

    public function records(): void
    {
        [$where, $params] = $this->recordFilters();
        $p = new Paginator((int) DB::value("SELECT COUNT(*) FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id WHERE $where", $params), 30);
        $records = DB::all(self::RECORD_SQL . " WHERE $where ORDER BY s.session_date DESC, s.id DESC, m.last_name" . $p->sql(), $params);
        $member = ($mid = input_int('member')) ? DB::one('SELECT * FROM members WHERE id = ?', [$mid]) : null;
        $memberSummary = $member ? DB::one(
            "SELECT COUNT(*) total, SUM(status='present') present, SUM(status='absent') absent, SUM(status='excused') excused FROM attendance_records WHERE member_id = ?",
            [$mid]
        ) : null;
        $this->view('attendance/records', ['title' => 'Attendance history', 'records' => $records, 'p' => $p, 'member' => $member,
            'memberSummary' => $memberSummary, 'members' => $this->memberOptions(true), 'categories' => $this->categories('attendance'),
            'ministries' => DB::all('SELECT id, name FROM ministries WHERE archived_at IS NULL ORDER BY name')]);
    }

    public function exportCsv(): void
    {
        [$where, $params] = $this->recordFilters();
        $rows = DB::all(self::RECORD_SQL . " WHERE $where ORDER BY s.session_date DESC, s.id, m.last_name", $params);
        Audit::log('export', 'attendance', null, null, 'Attendance records', count($rows) . ' rows, CSV');
        Csv::download('attendance-' . today() . '.csv', ['Session ID', 'Date', 'Time', 'Activity', 'Category', 'Ministry', 'Member ID', 'Member name', 'Status', 'Remarks'],
            array_map(static fn($r) => [$r['session_code'], $r['session_date'], $r['session_time'], $r['title'], $r['category'], $r['ministry'], $r['member_code'], member_name($r, true), ucfirst($r['status']), $r['remarks']], $rows));
    }

    public function exportPdf(): void
    {
        [$where, $params] = $this->recordFilters();
        $rows = DB::all(self::RECORD_SQL . " WHERE $where ORDER BY s.session_date DESC, s.id, m.last_name", $params);
        $counts = array_count_values(array_column($rows, 'status'));
        $sub = [];
        if ($f = input_date('from')) { $sub[] = 'From ' . fmt_date($f); }
        if ($t = input_date('to')) { $sub[] = 'to ' . fmt_date($t); }
        if ($m = input_int('member')) { $mm = DB::one('SELECT * FROM members WHERE id = ?', [$m]); $sub[] = 'Member: ' . ($mm ? member_name($mm) : ''); }
        if ($c = input_int('category')) { $sub[] = 'Activity: ' . DB::value('SELECT name FROM categories WHERE id = ?', [$c]); }
        $pdf = new PdfReport('Attendance Report', ($sub ? implode(' ', $sub) . ' · ' : 'All records · ') . count($rows) . ' record(s)', 'L');
        $pdf->summary([['Present', $counts['present'] ?? 0], ['Absent', $counts['absent'] ?? 0], ['Excused', $counts['excused'] ?? 0], ['Sessions', count(array_unique(array_column($rows, 'session_id')))]]);
        $pdf->table([['Date', 1], ['Activity', 2.2], ['Ministry', 1.4], ['Member ID', 1.1], ['Member', 2], ['Status', 0.8], ['Remarks', 1.6]],
            array_map(static fn($r) => [fmt_date($r['session_date']), $r['title'], $r['ministry'], $r['member_code'], member_name($r, true), ucfirst($r['status']), $r['remarks']], $rows));
        Audit::log('export', 'attendance', null, null, 'Attendance records', count($rows) . ' rows, PDF');
        $pdf->download('attendance-' . today() . '.pdf');
    }

    public function sessionPdf(int $id): void
    {
        $s = $this->session($id);
        if (!can('attendance.export') && !Auth::leads((int) $s['ministry_id'])) {
            throw new HttpException(403);
        }
        $rows = DB::all('SELECT r.*, m.first_name, m.last_name, m.middle_name, m.suffix, m.member_code FROM attendance_records r JOIN members m ON m.id = r.member_id WHERE r.session_id = ? ORDER BY r.status, m.last_name, m.first_name', [$id]);
        $counts = array_count_values(array_column($rows, 'status'));
        $pdf = new PdfReport('Attendance — ' . $s['title'], $s['session_code'] . ' · ' . fmt_date($s['session_date'], 'l, j F Y') . ($s['session_time'] ? ' · ' . fmt_time($s['session_time']) : '') . ($s['ministry'] ? ' · ' . $s['ministry'] : ''));
        $pdf->summary([['Present', $counts['present'] ?? 0], ['Absent', $counts['absent'] ?? 0], ['Excused', $counts['excused'] ?? 0]]);
        $pdf->table([['#', 0.4, 'R'], ['Member ID', 1.3], ['Name', 3], ['Status', 1], ['Remarks', 2.3]],
            array_map(static fn($r, $i) => [$i + 1, $r['member_code'], member_name($r, true), ucfirst($r['status']), $r['remarks']], $rows, array_keys($rows)));
        Audit::log('export', 'attendance', 'session', $id, $s['title'] . ' · ' . $s['session_date'], 'Session PDF');
        $pdf->download($s['session_code'] . '.pdf', true);
    }

    // ------------------------------------------------------------ helpers

    private function session(int $id): array
    {
        return $this->find(
            'SELECT s.*, c.name AS category, c.code AS category_code, mi.name AS ministry, e.title AS event_title, u.full_name AS created_by_name
               FROM attendance_sessions s JOIN categories c ON c.id = s.category_id LEFT JOIN ministries mi ON mi.id = s.ministry_id
               LEFT JOIN events e ON e.id = s.event_id LEFT JOIN users u ON u.id = s.created_by WHERE s.id = ?',
            [$id]
        );
    }

    private function recordableMinistries(): array
    {
        if (can('attendance.record')) {
            return DB::all("SELECT id, name FROM ministries WHERE archived_at IS NULL AND status = 'active' ORDER BY name");
        }
        $led = Auth::ledMinistryIds();
        return $led ? DB::all('SELECT id, name FROM ministries WHERE id IN (' . implode(',', $led) . ') ORDER BY name') : [];
    }

    /**
     * Members shown on the marking sheet: for a ministry session the ministry's members first,
     * then (for full recorders) every other active member. Already-recorded members are always included.
     */
    private function markableMembers(array $s, array $existing, ?bool $includeInactive = null): array
    {
        $includeInactive ??= query_str('inactive') !== '';
        $ids = array_keys($existing) ?: [0];
        $inList = implode(',', array_map('intval', $ids));
        $ministryOnly = !can('attendance.record');
        $sql = "SELECT m.id, m.member_code, m.first_name, m.middle_name, m.last_name, m.suffix, m.membership_status, m.photo_path,
                       " . ($s['ministry_id'] ? 'EXISTS(SELECT 1 FROM ministry_members mm WHERE mm.member_id = m.id AND mm.ministry_id = ' . (int) $s['ministry_id'] . ')' : '0') . " AS in_ministry
                  FROM members m
                 WHERE (m.archived_at IS NULL AND (m.membership_status = 'active' OR " . ($includeInactive ? '1' : '0') . ")) OR m.id IN ($inList)";
        $rows = DB::all($sql . ' ORDER BY in_ministry DESC, m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE');
        if ($ministryOnly) {
            $rows = array_values(array_filter($rows, static fn($r) => $r['in_ministry'] || isset($existing[(int) $r['id']])));
        }
        return $rows;
    }
}
