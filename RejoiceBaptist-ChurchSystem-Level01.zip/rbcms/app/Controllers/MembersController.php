<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Ids;
use App\Core\Paginator;
use App\Core\PdfReport;
use App\Core\Upload;

final class MembersController extends Controller
{
    /** Classification tabs. Baptism and activity are separate fields, so they combine freely. */
    public const VIEWS = [
        'all'               => ['All members', "m.archived_at IS NULL"],
        'active'            => ['Active', "m.archived_at IS NULL AND m.membership_status = 'active'"],
        'inactive'          => ['Inactive', "m.archived_at IS NULL AND m.membership_status = 'inactive'"],
        'active_unbaptized' => ['Active unbaptized', "m.archived_at IS NULL AND m.membership_status = 'active' AND m.baptism_status = 'unbaptized'"],
        'baptized'          => ['Baptized', "m.archived_at IS NULL AND m.baptism_status = 'baptized'"],
        'no_ministry'       => ['No ministry', "m.archived_at IS NULL AND NOT EXISTS (SELECT 1 FROM ministry_members mm JOIN ministries mi ON mi.id = mm.ministry_id AND mi.archived_at IS NULL WHERE mm.member_id = m.id)"],
        'archived'          => ['Archived', "m.archived_at IS NOT NULL"],
    ];

    private const FIELDS = [
        'first_name' => 'First name', 'middle_name' => 'Middle name', 'last_name' => 'Last name', 'suffix' => 'Suffix',
        'gender' => 'Gender', 'birth_date' => 'Birth date', 'civil_status' => 'Civil status', 'contact_number' => 'Contact number',
        'email' => 'E-mail', 'address' => 'Address', 'date_joined' => 'Date joined', 'membership_status' => 'Membership status',
        'baptism_status' => 'Baptism status', 'baptism_date' => 'Baptism date', 'baptism_place' => 'Baptism place',
        'baptized_by' => 'Baptized by', 'emergency_name' => 'Emergency contact', 'emergency_contact' => 'Emergency number',
        'emergency_relation' => 'Emergency relation', 'notes' => 'Notes',
    ];

    /** Build WHERE clause and params from the current filters. */
    private function filters(): array
    {
        $view = array_key_exists(query_str('view'), self::VIEWS) ? query_str('view') : 'all';
        $where = [self::VIEWS[$view][1]];
        $params = [];
        if (($q = query_str('q')) !== '') {
            $where[] = "(m.member_code LIKE :q ESCAPE '\\' OR (m.first_name || ' ' || m.last_name) LIKE :q ESCAPE '\\'
                        OR (m.last_name || ', ' || m.first_name) LIKE :q ESCAPE '\\' OR m.contact_number LIKE :q ESCAPE '\\' OR m.middle_name LIKE :q ESCAPE '\\')";
            $params['q'] = like($q);
        }
        if (in_array(query_str('gender'), ['male', 'female'], true)) {
            $where[] = 'm.gender = :gender';
            $params['gender'] = query_str('gender');
        }
        if ($mid = input_int('ministry')) {
            $where[] = 'EXISTS (SELECT 1 FROM ministry_members mm WHERE mm.member_id = m.id AND mm.ministry_id = :ministry)';
            $params['ministry'] = $mid;
        }
        $sorts = ['name' => 'm.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE', 'code' => 'm.member_code', 'joined' => 'm.date_joined DESC, m.id DESC', 'recent' => 'm.created_at DESC, m.id DESC'];
        $sort = $sorts[query_str('sort')] ?? $sorts['name'];
        return [$view, implode(' AND ', $where), $params, $sort];
    }

    public function index(): void
    {
        [$view, $where, $params, $sort] = $this->filters();
        $counts = [];
        foreach (self::VIEWS as $key => [, $cond]) {
            $counts[$key] = (int) DB::value("SELECT COUNT(*) FROM members m WHERE $cond");
        }
        $p = new Paginator((int) DB::value("SELECT COUNT(*) FROM members m WHERE $where", $params), 25);
        $members = DB::all(
            "SELECT m.*, (SELECT GROUP_CONCAT(mi.name, ', ') FROM ministry_members mm JOIN ministries mi ON mi.id = mm.ministry_id AND mi.archived_at IS NULL WHERE mm.member_id = m.id) AS ministries
               FROM members m WHERE $where ORDER BY $sort" . $p->sql(),
            $params
        );
        $ministries = DB::all('SELECT id, name FROM ministries WHERE archived_at IS NULL ORDER BY name');
        $this->view('members/index', compact('members', 'counts', 'view', 'p', 'ministries') + ['title' => 'Members']);
    }

    public function create(): void
    {
        $this->view('members/form', [
            'title' => 'Add member', 'm' => [], 'memberMinistries' => [],
            'ministries' => DB::all("SELECT id, name FROM ministries WHERE archived_at IS NULL AND status = 'active' ORDER BY name"),
            'nextCode' => Ids::preview('member'), 'duplicates' => $_SESSION['_dupes'] ?? [],
        ]);
        unset($_SESSION['_dupes']);
    }

    public function store(): void
    {
        [$data, $errors] = $this->validate();
        [$photo, $photoErr] = Upload::image('photo', 'members', 800);
        if ($photoErr) {
            $errors['photo'] = $photoErr;
        }
        if ($errors) {
            Upload::delete($photo);
            $this->failed($errors, '/members/new');
        }
        $dupes = $this->possibleDuplicates($data);
        if ($dupes && empty($_POST['confirm_duplicate'])) {
            Upload::delete($photo);
            $_SESSION['_dupes'] = $dupes;
            $this->failed(['confirm_duplicate' => 'A member with the same name already exists. Review the list and tick the confirmation box if this is a different person.'], '/members/new');
        }
        $ministryIds = $this->postedMinistries();
        $id = DB::transaction(function () use ($data, $photo, $ministryIds) {
            $data['member_code'] = Ids::next('member', $data['date_joined'] ?: today());
            $data['photo_path'] = $photo;
            $data['created_by'] = $data['updated_by'] = Auth::id();
            $id = DB::insert('members', $data);
            foreach ($ministryIds as $mid) {
                DB::insert('ministry_members', ['ministry_id' => $mid, 'member_id' => $id]);
            }
            $this->history($id, 'created', 'Member record created with ID ' . $data['member_code']);
            return $id;
        });
        $code = DB::value('SELECT member_code FROM members WHERE id = ?', [$id]);
        Audit::log('create', 'members', 'member', $id, $code . ' ' . $data['first_name'] . ' ' . $data['last_name']);
        flash('success', "Member {$data['first_name']} {$data['last_name']} was added with ID $code.");
        redirect(isset($_POST['save_new']) ? '/members/new' : "/members/$id");
    }

    public function show(int $id): void
    {
        $m = $this->find('SELECT * FROM members WHERE id = ?', [$id]);
        $this->authorizeView($m);
        $ministries = DB::all(
            "SELECT mi.*, mm.joined_on,
                    CASE WHEN mi.leader_member_id = :id THEN 'Leader' WHEN mi.assistant_member_id = :id THEN 'Assistant leader' ELSE 'Member' END AS role
               FROM ministry_members mm JOIN ministries mi ON mi.id = mm.ministry_id
              WHERE mm.member_id = :id AND mi.archived_at IS NULL ORDER BY mi.name",
            ['id' => $id]
        );
        $att = DB::one(
            "SELECT COUNT(*) total, SUM(status = 'present') present, SUM(status = 'absent') absent, SUM(status = 'excused') excused,
                    MAX(CASE WHEN status = 'present' THEN s.session_date END) last_present
               FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id WHERE r.member_id = ?",
            [$id]
        );
        $recent = can('attendance.view') ? DB::all(
            "SELECT r.status, r.remarks, s.id session_id, s.title, s.session_date, c.name AS category
               FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id JOIN categories c ON c.id = s.category_id
              WHERE r.member_id = ? ORDER BY s.session_date DESC, s.id DESC LIMIT 12",
            [$id]
        ) : [];
        $music = can('music.view') ? DB::all(
            "SELECT l.id, l.service_date, l.service_type, 'Song leader' AS role FROM worship_lineups l WHERE l.song_leader_member_id = :id AND l.archived_at IS NULL
             UNION ALL
             SELECT l.id, l.service_date, l.service_type, CASE lm.role WHEN 'instrumentalist' THEN COALESCE(c.name, 'Instrumentalist') WHEN 'backup' THEN 'Backup singer' ELSE COALESCE(lm.note, 'Team member') END
               FROM lineup_members lm JOIN worship_lineups l ON l.id = lm.lineup_id LEFT JOIN categories c ON c.id = lm.instrument_id
              WHERE lm.member_id = :id AND l.archived_at IS NULL
             ORDER BY 2 DESC LIMIT 10",
            ['id' => $id]
        ) : [];
        $history = DB::all(
            'SELECT h.*, u.full_name AS user_name FROM member_history h LEFT JOIN users u ON u.id = h.user_id WHERE h.member_id = ? ORDER BY h.created_at DESC, h.id DESC LIMIT 50',
            [$id]
        );
        $account = DB::one('SELECT username FROM users WHERE member_id = ?', [$id]);
        $this->view('members/show', compact('m', 'ministries', 'att', 'recent', 'history', 'music', 'account') + ['title' => member_name($m)]);
    }

    public function edit(int $id): void
    {
        $m = $this->find('SELECT * FROM members WHERE id = ?', [$id]);
        $this->view('members/form', [
            'title' => 'Edit member', 'm' => $m, 'nextCode' => $m['member_code'], 'duplicates' => [],
            'memberMinistries' => array_map('intval', DB::column('SELECT ministry_id FROM ministry_members WHERE member_id = ?', [$id])),
            'ministries' => DB::all("SELECT id, name FROM ministries WHERE archived_at IS NULL AND (status = 'active' OR id IN (SELECT ministry_id FROM ministry_members WHERE member_id = ?)) ORDER BY name", [$id]),
        ]);
    }

    public function update(int $id): void
    {
        $before = $this->find('SELECT * FROM members WHERE id = ?', [$id]);
        [$data, $errors] = $this->validate($id);
        [$photo, $photoErr] = Upload::image('photo', 'members', 800);
        if ($photoErr) {
            $errors['photo'] = $photoErr;
        }
        if ($errors) {
            Upload::delete($photo);
            $this->failed($errors, "/members/$id/edit");
        }
        $removePhoto = !empty($_POST['remove_photo']);
        $ministryIds = $this->postedMinistries();
        DB::transaction(function () use ($id, $data, $before, $photo, $removePhoto, $ministryIds) {
            $data['updated_by'] = Auth::id();
            $data['updated_at'] = now();
            if ($photo || $removePhoto) {
                $data['photo_path'] = $photo;
            }
            DB::update('members', $data, 'id = :id', ['id' => $id]);

            if ($before['membership_status'] !== $data['membership_status']) {
                $this->history($id, 'status', 'Membership status changed from ' . ucfirst($before['membership_status']) . ' to ' . ucfirst($data['membership_status']));
            }
            if ($before['baptism_status'] !== $data['baptism_status'] || $before['baptism_date'] !== $data['baptism_date']) {
                $this->history($id, 'baptism', $data['baptism_status'] === 'baptized'
                    ? 'Baptism recorded' . ($data['baptism_date'] ? ' (' . fmt_date($data['baptism_date']) . ')' : '')
                    : 'Baptism status set to unbaptized');
            }
            $other = array_diff_key(self::FIELDS, ['membership_status' => 1, 'baptism_status' => 1, 'baptism_date' => 1]);
            $changed = [];
            foreach ($other as $f => $label) {
                if ((string) ($before[$f] ?? '') !== (string) ($data[$f] ?? '')) {
                    $changed[] = mb_strtolower($label);
                }
            }
            if ($photo || $removePhoto) {
                $changed[] = 'photo';
            }
            if ($changed) {
                $this->history($id, 'updated', 'Updated ' . implode(', ', $changed));
            }
            $this->syncMinistries($id, $ministryIds);
        });
        if ($photo || $removePhoto) {
            Upload::delete($before['photo_path']);
        }
        $after = DB::one('SELECT * FROM members WHERE id = ?', [$id]);
        Audit::log('update', 'members', 'member', $id, $before['member_code'] . ' ' . member_name($after), Audit::diff($before, $after, self::FIELDS));
        flash('success', 'Member record saved.');
        redirect("/members/$id");
    }

    public function archive(int $id): void
    {
        $m = $this->find('SELECT * FROM members WHERE id = ? AND archived_at IS NULL', [$id]);
        $reason = input_str('reason', 200);
        DB::update('members', ['archived_at' => now(), 'updated_by' => Auth::id()], 'id = :id', ['id' => $id]);
        $this->history($id, 'archived', 'Record archived' . ($reason ? ": $reason" : ''));
        Audit::log('archive', 'members', 'member', $id, $m['member_code'] . ' ' . member_name($m), $reason ?: null);
        flash('success', member_name($m) . ' was archived. Attendance and history are kept.');
        redirect("/members/$id");
    }

    public function restore(int $id): void
    {
        $m = $this->find('SELECT * FROM members WHERE id = ? AND archived_at IS NOT NULL', [$id]);
        DB::update('members', ['archived_at' => null, 'updated_by' => Auth::id()], 'id = :id', ['id' => $id]);
        $this->history($id, 'restored', 'Record restored from archive');
        Audit::log('restore', 'members', 'member', $id, $m['member_code'] . ' ' . member_name($m));
        flash('success', member_name($m) . ' was restored.');
        redirect("/members/$id");
    }

    public function duplicates(): void
    {
        $groups = DB::all(
            "SELECT lower(trim(first_name)) || ' ' || lower(trim(last_name)) AS k, COUNT(*) n, GROUP_CONCAT(id) ids
               FROM members WHERE archived_at IS NULL GROUP BY k HAVING n > 1 ORDER BY k"
        );
        $rows = [];
        foreach ($groups as $g) {
            $rows[] = DB::all('SELECT * FROM members WHERE id IN (' . implode(',', array_map('intval', explode(',', $g['ids']))) . ') ORDER BY id');
        }
        $this->view('members/duplicates', ['title' => 'Possible duplicates', 'groups' => $rows]);
    }

    // ------------------------------------------------------------ exports

    private function exportRows(): array
    {
        [$view, $where, $params, $sort] = $this->filters();
        $rows = DB::all(
            "SELECT m.*, (SELECT GROUP_CONCAT(mi.name, '; ') FROM ministry_members mm JOIN ministries mi ON mi.id = mm.ministry_id AND mi.archived_at IS NULL WHERE mm.member_id = m.id) AS ministries
               FROM members m WHERE $where ORDER BY $sort",
            $params
        );
        return [$view, $rows];
    }

    public function exportCsv(): void
    {
        [$view, $rows] = $this->exportRows();
        Audit::log('export', 'members', null, null, 'Member list (' . self::VIEWS[$view][0] . ')', count($rows) . ' records, CSV');
        Csv::download('members-' . $view . '-' . today() . '.csv',
            ['Member ID', 'Last name', 'First name', 'Middle name', 'Suffix', 'Gender', 'Birth date', 'Contact number', 'E-mail', 'Address', 'Date joined', 'Membership', 'Baptism', 'Baptism date', 'Ministries', 'Emergency contact', 'Emergency number'],
            array_map(static fn($m) => [$m['member_code'], $m['last_name'], $m['first_name'], $m['middle_name'], $m['suffix'], ucfirst((string) $m['gender']), $m['birth_date'], $m['contact_number'], $m['email'], $m['address'], $m['date_joined'], ucfirst($m['membership_status']), ucfirst($m['baptism_status']), $m['baptism_date'], $m['ministries'], $m['emergency_name'], $m['emergency_contact']], $rows)
        );
    }

    public function exportPdf(): void
    {
        [$view, $rows] = $this->exportRows();
        $subtitle = 'List: ' . self::VIEWS[$view][0] . (query_str('q') !== '' ? ' · Search: "' . query_str('q') . '"' : '') . ' · ' . count($rows) . ' member(s)';
        $pdf = new PdfReport('Member List', $subtitle, 'L');
        $pdf->table(
            [['Member ID', 1.1], ['Name', 2], ['Gender', 0.7], ['Contact', 1.1], ['Address', 2.2], ['Joined', 0.9], ['Status', 0.8], ['Baptism', 0.9], ['Ministries', 2]],
            array_map(static fn($m) => [$m['member_code'], member_name($m, true), ucfirst((string) $m['gender']), $m['contact_number'], $m['address'], fmt_date($m['date_joined']), ucfirst($m['membership_status']), ucfirst($m['baptism_status']), $m['ministries']], $rows)
        );
        Audit::log('export', 'members', null, null, 'Member list (' . self::VIEWS[$view][0] . ')', count($rows) . ' records, PDF');
        $pdf->download('members-' . $view . '-' . today() . '.pdf');
    }

    public function pdf(int $id): void
    {
        $m = $this->find('SELECT * FROM members WHERE id = ?', [$id]);
        $ministries = DB::column('SELECT mi.name FROM ministry_members mm JOIN ministries mi ON mi.id = mm.ministry_id WHERE mm.member_id = ? AND mi.archived_at IS NULL ORDER BY mi.name', [$id]);
        $att = DB::one("SELECT COUNT(*) total, SUM(status = 'present') present FROM attendance_records WHERE member_id = ?", [$id]);
        $pdf = new PdfReport('Member Information', $m['member_code'] . ' · ' . member_name($m), 'P', true);
        $x = $pdf->margin;
        $top = $pdf->y;
        if ($m['photo_path'] && ($photo = Upload::path($m['photo_path']))) {
            $pdf->image($photo, $pdf->w - $pdf->margin - 90, $top, 90, 90);
        }
        $rows = [
            ['Member ID', $m['member_code']], ['Full name', trim($m['first_name'] . ' ' . $m['middle_name'] . ' ' . $m['last_name'] . ' ' . $m['suffix'])],
            ['Gender', ucfirst((string) $m['gender']) ?: '—'], ['Birth date', fmt_date($m['birth_date']) . (age($m['birth_date']) !== null ? ' (age ' . age($m['birth_date']) . ')' : '')],
            ['Civil status', $m['civil_status'] ?: '—'], ['Contact number', $m['contact_number'] ?: '—'], ['E-mail', $m['email'] ?: '—'],
            ['Address', $m['address'] ?: '—'], ['Date joined', fmt_date($m['date_joined'])],
            ['Membership', ucfirst($m['membership_status'])], ['Baptism', ucfirst($m['baptism_status']) . ($m['baptism_date'] ? ' — ' . fmt_date($m['baptism_date']) : '')],
            ['Baptism place / by', trim(($m['baptism_place'] ?: '') . ($m['baptized_by'] ? ' / ' . $m['baptized_by'] : '')) ?: '—'],
            ['Ministries', $ministries ? implode(', ', $ministries) : 'None assigned'],
            ['Emergency contact', trim(($m['emergency_name'] ?: '—') . ($m['emergency_relation'] ? ' (' . $m['emergency_relation'] . ')' : '') . ($m['emergency_contact'] ? ' · ' . $m['emergency_contact'] : ''))],
            ['Attendance', ((int) $att['present']) . ' present out of ' . ((int) $att['total']) . ' recorded'],
        ];
        foreach ($rows as [$label, $value]) {
            $pdf->setFont('', 8.5);
            $pdf->color(110);
            $pdf->text($x, $pdf->y, mb_strtoupper($label));
            $pdf->setFont('', 10.5);
            $pdf->color(20);
            $pdf->paragraph((string) $value, $x + 130, $pdf->contentWidth() - 240, 13);
            $pdf->y += 5;
        }
        if ($m['notes']) {
            $pdf->heading('Notes');
            $pdf->note($m['notes']);
        }
        Audit::log('export', 'members', 'member', $id, $m['member_code'] . ' ' . member_name($m), 'Printed member information (PDF)');
        $pdf->download($m['member_code'] . '.pdf', true);
    }

    // ------------------------------------------------------------ helpers

    private function authorizeView(array $m): void
    {
        if (can('members.view')) {
            return;
        }
        $led = Auth::ledMinistryIds();
        if ($led && DB::value('SELECT 1 FROM ministry_members WHERE member_id = ? AND ministry_id IN (' . implode(',', $led) . ')', [$m['id']])) {
            return;
        }
        throw new HttpException(403);
    }

    private function validate(?int $id = null): array
    {
        $d = [
            'first_name' => input_str('first_name', 80), 'middle_name' => input_str('middle_name', 80) ?: null,
            'last_name' => input_str('last_name', 80), 'suffix' => input_str('suffix', 10) ?: null,
            'gender' => input_in('gender', ['male', 'female']), 'birth_date' => input_date('birth_date'),
            'civil_status' => input_in('civil_status', ['Single', 'Married', 'Widowed', 'Separated']),
            'contact_number' => input_str('contact_number', 40) ?: null, 'email' => input_str('email', 150) ?: null,
            'address' => input_str('address', 300) ?: null, 'date_joined' => input_date('date_joined'),
            'membership_status' => input_in('membership_status', ['active', 'inactive'], 'active'),
            'baptism_status' => input_in('baptism_status', ['baptized', 'unbaptized'], 'unbaptized'),
            'baptism_date' => input_date('baptism_date'), 'baptism_place' => input_str('baptism_place', 150) ?: null,
            'baptized_by' => input_str('baptized_by', 120) ?: null,
            'emergency_name' => input_str('emergency_name', 120) ?: null, 'emergency_contact' => input_str('emergency_contact', 40) ?: null,
            'emergency_relation' => input_str('emergency_relation', 60) ?: null, 'notes' => input_text('notes', 4000) ?: null,
        ];
        $e = [];
        if ($d['first_name'] === '') { $e['first_name'] = 'First name is required.'; }
        if ($d['last_name'] === '') { $e['last_name'] = 'Last name is required.'; }
        if (input_str('birth_date') !== '' && !$d['birth_date']) { $e['birth_date'] = 'Enter a valid date.'; }
        if ($d['birth_date'] && $d['birth_date'] > today()) { $e['birth_date'] = 'Birth date cannot be in the future.'; }
        if (input_str('date_joined') !== '' && !$d['date_joined']) { $e['date_joined'] = 'Enter a valid date.'; }
        if ($d['date_joined'] && $d['date_joined'] > today()) { $e['date_joined'] = 'Date joined cannot be in the future.'; }
        if ($d['email'] && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) { $e['email'] = 'Enter a valid e-mail address.'; }
        if ($d['contact_number'] && !preg_match('/^[0-9+()\-\s]{7,40}$/', $d['contact_number'])) { $e['contact_number'] = 'Use digits, spaces, +, - or parentheses only.'; }
        if ($d['baptism_status'] === 'baptized') {
            if (input_str('baptism_date') !== '' && !$d['baptism_date']) { $e['baptism_date'] = 'Enter a valid date.'; }
            if ($d['baptism_date'] && $d['baptism_date'] > today()) { $e['baptism_date'] = 'Baptism date cannot be in the future.'; }
            if ($d['baptism_date'] && $d['birth_date'] && $d['baptism_date'] < $d['birth_date']) { $e['baptism_date'] = 'Baptism date is before the birth date.'; }
        } else {
            $d['baptism_date'] = $d['baptism_place'] = $d['baptized_by'] = null;
        }
        return [$d, $e];
    }

    private function possibleDuplicates(array $d): array
    {
        return DB::all(
            "SELECT id, member_code, first_name, middle_name, last_name, suffix, birth_date, contact_number, archived_at FROM members
              WHERE lower(trim(first_name)) = lower(:f) AND lower(trim(last_name)) = lower(:l)
                 OR (:c IS NOT NULL AND replace(replace(contact_number,' ',''),'-','') = replace(replace(:c,' ',''),'-','') AND lower(trim(last_name)) = lower(:l))
              LIMIT 10",
            ['f' => trim($d['first_name']), 'l' => trim($d['last_name']), 'c' => $d['contact_number']]
        );
    }

    private function postedMinistries(): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['ministries'] ?? [])))));
        if (!$ids) {
            return [];
        }
        return array_map('intval', DB::column('SELECT id FROM ministries WHERE archived_at IS NULL AND id IN (' . implode(',', $ids) . ')'));
    }

    private function syncMinistries(int $memberId, array $ids): void
    {
        $current = array_map('intval', DB::column('SELECT ministry_id FROM ministry_members WHERE member_id = ?', [$memberId]));
        $names = DB::pairs('SELECT id, name FROM ministries');
        foreach (array_diff($ids, $current) as $mid) {
            DB::insert('ministry_members', ['ministry_id' => $mid, 'member_id' => $memberId]);
            $this->history($memberId, 'ministry', 'Added to ' . ($names[$mid] ?? 'ministry'));
        }
        foreach (array_diff($current, $ids) as $mid) {
            DB::query('DELETE FROM ministry_members WHERE ministry_id = ? AND member_id = ?', [$mid, $memberId]);
            $this->history($memberId, 'ministry', 'Removed from ' . ($names[$mid] ?? 'ministry'));
        }
    }

    private function history(int $memberId, string $event, string $summary): void
    {
        DB::insert('member_history', ['member_id' => $memberId, 'event' => $event, 'summary' => $summary, 'user_id' => Auth::id()]);
    }
}
