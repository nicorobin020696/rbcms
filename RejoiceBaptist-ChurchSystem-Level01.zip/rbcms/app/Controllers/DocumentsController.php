<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Ids;
use App\Core\Paginator;
use App\Core\View;
use App\Services\DocumentRenderer as R;
use App\Services\RichText;

/**
 * Document generator: letters and certificates from editable templates, with letterhead, logo and signatories.
 * Confidential documents are invisible (lists, search, direct URLs, PDFs) without documents.confidential.
 * Final documents are locked; make revisions with "Duplicate".
 */
final class DocumentsController extends Controller
{
    public const TYPES = [
        'recommendation' => 'Recommendation letter', 'request' => 'Request letter', 'solicitation' => 'Solicitation letter',
        'invitation' => 'Invitation letter', 'authorization' => 'Authorization letter', 'endorsement' => 'Endorsement letter',
        'certificate_membership' => 'Certificate of membership', 'certificate_baptism' => 'Certificate of baptism',
        'certificate_attendance' => 'Certificate of attendance', 'certificate_appreciation' => 'Certificate of appreciation',
        'transfer' => 'Transfer / dismissal letter', 'memo' => 'Memorandum', 'other' => 'Other',
    ];

    private function confidentialFilter(string $alias = 'd'): string
    {
        return can('documents.confidential') ? '1=1' : "$alias.confidential = 0";
    }

    private function load(int $id): array
    {
        $d = $this->find("SELECT d.*, t.name template_name, u.full_name created_by_name, u2.full_name updated_by_name,
                                 m.first_name m_first, m.last_name m_last, m.member_code m_code
                            FROM documents d LEFT JOIN document_templates t ON t.id = d.template_id
                            LEFT JOIN users u ON u.id = d.created_by LEFT JOIN users u2 ON u2.id = d.updated_by
                            LEFT JOIN members m ON m.id = d.member_id WHERE d.id = ?", [$id]);
        if ($d['confidential'] && !can('documents.confidential')) {
            Audit::log('denied', 'documents', 'document', $id, null, 'Confidential document requested without permission');
            throw new HttpException(404);
        }
        return $d;
    }

    public function index(): void
    {
        $where = [$this->confidentialFilter()];
        $params = [];
        $tab = input_in('tab', ['active', 'draft', 'final', 'archived', 'confidential'], 'active');
        $where[] = match ($tab) {
            'draft' => "d.status = 'draft'", 'final' => "d.status = 'final'", 'archived' => "d.status = 'archived'",
            'confidential' => "d.confidential = 1 AND d.status <> 'archived'", default => "d.status <> 'archived'",
        };
        if (($q = query_str('q')) !== '') {
            $where[] = "(d.doc_code LIKE :q ESCAPE '\\' OR d.title LIKE :q ESCAPE '\\' OR d.recipient_name LIKE :q ESCAPE '\\' OR d.purpose LIKE :q ESCAPE '\\')";
            $params['q'] = like($q);
        }
        if ($t = input_in('type', array_keys(self::TYPES), '')) { $where[] = 'd.doc_type = :t'; $params['t'] = $t; }
        if ($mem = input_int('member')) { $where[] = 'd.member_id = :m'; $params['m'] = $mem; }
        $w = implode(' AND ', $where);
        $p = new Paginator((int) DB::value("SELECT COUNT(*) FROM documents d WHERE $w", $params), 20);
        $docs = DB::all("SELECT d.id, d.doc_code, d.doc_type, d.title, d.recipient_name, d.doc_date, d.status, d.confidential, d.is_sample, u.full_name author
                           FROM documents d LEFT JOIN users u ON u.id = d.created_by WHERE $w ORDER BY d.doc_date DESC, d.id DESC" . $p->sql(), $params);
        $cf = $this->confidentialFilter();
        $counts = DB::one("SELECT SUM(status <> 'archived') active, SUM(status = 'draft') draft, SUM(status = 'final') final, SUM(status = 'archived') archived,
                                  SUM(confidential = 1 AND status <> 'archived') confidential FROM documents d WHERE $cf");
        $this->view('documents/index', ['title' => 'Document records', 'docs' => $docs, 'p' => $p, 'tab' => $tab, 'counts' => array_map('intval', $counts)]);
    }

    public function choose(): void
    {
        $cf = can('documents.confidential') ? '' : ' AND confidential = 0';
        $this->view('documents/choose', [
            'title' => 'Document generator',
            'templates' => DB::all("SELECT * FROM document_templates WHERE is_active = 1$cf ORDER BY is_certificate, name"),
            'member' => input_int('member'),
            'recent' => DB::all('SELECT d.id, d.doc_code, d.title, d.recipient_name, d.updated_at, d.status FROM documents d WHERE d.created_by = ? AND ' . $this->confidentialFilter() . ' ORDER BY d.updated_at DESC LIMIT 6', [Auth::id()]),
        ]);
    }

    public function create(): void
    {
        $tpl = null;
        if ($tid = input_int('template')) {
            $tpl = DB::one('SELECT * FROM document_templates WHERE id = ? AND is_active = 1', [$tid]);
            if ($tpl && $tpl['confidential'] && !can('documents.confidential')) {
                throw new HttpException(403);
            }
        }
        $member = ($mid = input_int('member')) ? DB::one('SELECT * FROM members WHERE id = ?', [$mid]) : null;
        $d = [
            'template_id' => $tpl['id'] ?? null, 'doc_type' => $tpl['doc_type'] ?? 'other', 'title' => $tpl['title'] ?? '',
            'body_html' => $tpl['body_html'] ?? '<p></p>', 'closing' => $tpl['closing'] ?? 'Sincerely,',
            'is_certificate' => (int) ($tpl['is_certificate'] ?? 0), 'confidential' => (int) ($tpl['confidential'] ?? 0),
            'doc_date' => today(), 'member_id' => $member['id'] ?? null, 'recipient_name' => $member ? member_name($member) : '',
            'show_logo' => 1, 'show_letterhead' => 1, 'show_signatures' => 1, 'status' => 'draft',
        ];
        $this->form($d, [], 'New ' . strtolower($tpl['name'] ?? 'document'));
    }

    public function edit(int $id): void
    {
        $d = $this->load($id);
        if ($d['status'] !== 'draft') {
            flash('warning', 'Only drafts can be edited. Use “Duplicate” to make a revised copy of a final document.');
            redirect("/documents/$id");
        }
        $this->form($d, DB::column('SELECT signatory_id FROM document_signatories WHERE document_id = ? ORDER BY sort_order', [$id]), 'Edit ' . $d['doc_code']);
    }

    private function form(array $d, array $sigIds, string $title): void
    {
        $oldSigs = old('signatories');
        $this->view('documents/form', [
            'title' => $title, 'd' => $d,
            'sigIds' => array_map('intval', is_array($oldSigs) ? $oldSigs : ($sigIds ?: (empty($d['id']) ? DB::column('SELECT id FROM signatories WHERE is_active = 1 ORDER BY sort_order LIMIT 2') : []))),
            'signatories' => DB::all('SELECT * FROM signatories WHERE is_active = 1 ORDER BY sort_order, name'),
            'members' => $this->memberOptions(true),
        ]);
    }

    public function store(): void
    {
        [$d, $sigs, $errors] = $this->validate();
        if ($errors) {
            $this->failed($errors, '/documents/compose' . ($d['template_id'] ? '?template=' . $d['template_id'] : ''));
        }
        $id = DB::transaction(function () use ($d, $sigs) {
            $d['doc_code'] = Ids::next('document', $d['doc_date']);
            $d['created_by'] = $d['updated_by'] = Auth::id();
            $id = DB::insert('documents', $d);
            $this->saveSignatories($id, $sigs);
            return $id;
        });
        Audit::log('create', 'documents', 'document', $id, $d['title'] . ($d['recipient_name'] ? ' · ' . $d['recipient_name'] : ''), 'Status: ' . $d['status'] . ($d['confidential'] ? ', confidential' : ''));
        $this->afterSave($id, $d);
    }

    public function update(int $id): void
    {
        $before = $this->load($id);
        if ($before['status'] !== 'draft') {
            throw new HttpException(403, 'Final documents are locked.');
        }
        [$d, $sigs, $errors] = $this->validate();
        if ($errors) {
            $this->failed($errors, "/documents/$id/edit");
        }
        unset($d['template_id']);
        $d['updated_by'] = Auth::id();
        $d['updated_at'] = now();
        DB::transaction(function () use ($id, $d, $sigs) {
            DB::update('documents', $d, 'id = :id', ['id' => $id]);
            DB::query('DELETE FROM document_signatories WHERE document_id = ?', [$id]);
            $this->saveSignatories($id, $sigs);
        });
        Audit::log('update', 'documents', 'document', $id, $before['doc_code'], Audit::diff($before, $d, ['title' => 'Title', 'recipient_name' => 'Recipient', 'status' => 'Status', 'confidential' => 'Confidential', 'doc_date' => 'Date']) ?: 'Content edited');
        $this->afterSave($id, $d);
    }

    private function afterSave(int $id, array $d): void
    {
        $left = R::unresolved($d['body_html']);
        if ($left) {
            flash('warning', 'Saved, but some placeholders have no value yet: ' . implode(', ', $left) . '. Fill in the related fields or edit the text.');
        } else {
            flash('success', $d['status'] === 'final' ? 'Document finalized. It is now locked.' : 'Draft saved.');
        }
        redirect("/documents/$id");
    }

    private function saveSignatories(int $id, array $sigs): void
    {
        foreach ($sigs as $i => $sid) {
            DB::insert('document_signatories', ['document_id' => $id, 'signatory_id' => $sid, 'sort_order' => $i]);
        }
    }

    private function validate(): array
    {
        $member = ($mid = input_int('member_id')) ? DB::one('SELECT * FROM members WHERE id = ?', [$mid]) : null;
        $d = [
            'template_id' => input_int('template_id'),
            'doc_type' => input_in('doc_type', array_keys(self::TYPES), 'other'),
            'title' => input_str('title', 150),
            'recipient_name' => input_str('recipient_name', 150) ?: null,
            'recipient_details' => input_text('recipient_details', 500) ?: null,
            'member_id' => $member['id'] ?? null,
            'purpose' => input_str('purpose', 300) ?: null,
            'doc_date' => input_date('doc_date'),
            'closing' => input_str('closing', 100) ?: null,
            'show_logo' => input_str('show_logo') === '1' ? 1 : 0,
            'show_letterhead' => input_str('show_letterhead') === '1' ? 1 : 0,
            'show_signatures' => input_str('show_signatures') === '1' ? 1 : 0,
            'is_certificate' => input_str('is_certificate') === '1' ? 1 : 0,
            'confidential' => can('documents.confidential') && input_str('confidential') === '1' ? 1 : 0,
            'status' => input_in('status', ['draft', 'final'], 'draft'),
        ];
        if ($d['template_id'] && !DB::value('SELECT 1 FROM document_templates WHERE id = ?', [$d['template_id']])) { $d['template_id'] = null; }
        $e = [];
        if ($d['title'] === '') { $e['title'] = 'Enter the document title.'; }
        if (!$d['doc_date']) { $e['doc_date'] = 'Enter the document date.'; }
        $raw = (string) ($_POST['body_html'] ?? '');
        if (strlen($raw) > 200000) { $e['body_html'] = 'The document is too long.'; $raw = ''; }
        $body = RichText::sanitize($raw);
        if (RichText::toText($body) === '') { $e['body_html'] = 'The document body is empty.'; }
        $d['body_html'] = $d['doc_date'] ? R::fill($body, $d, $member) : $body;
        $valid = array_flip(array_map('intval', DB::column('SELECT id FROM signatories WHERE is_active = 1')));
        $sigs = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['signatories'] ?? [])), static fn($s) => isset($valid[$s]))));
        if ($d['show_signatures'] && !$sigs && $d['status'] === 'final') { $e['signatories'] = 'Choose at least one signatory, or turn off signatures.'; }
        return [$d, array_slice($sigs, 0, 4), $e];
    }

    public function show(int $id): void
    {
        $d = $this->load($id);
        $this->view('documents/show', ['title' => $d['doc_code'], 'd' => $d, 'sigs' => R::signatories($id), 'unresolved' => R::unresolved($d['body_html'])]);
    }

    public function print(int $id): void
    {
        $d = $this->load($id);
        Audit::log('print', 'documents', 'document', $id, $d['doc_code']);
        echo View::render('documents/print', ['title' => $d['title'] . ' · ' . $d['doc_code'], 'd' => $d, 'sigs' => R::signatories($id)], 'blank');
    }

    public function pdf(int $id): void
    {
        $d = $this->load($id);
        Audit::log('export', 'documents', 'document', $id, $d['doc_code'], 'PDF');
        R::pdf($d)->download(strtolower($d['doc_code']) . '.pdf', true);
    }

    public function archive(int $id): void
    {
        $d = $this->load($id);
        if ($d['status'] === 'archived') {
            DB::update('documents', ['status' => 'final', 'updated_by' => Auth::id(), 'updated_at' => now()], 'id = :id', ['id' => $id]);
            Audit::log('restore', 'documents', 'document', $id, $d['doc_code']);
            flash('success', 'Document restored (as final).');
        } else {
            DB::update('documents', ['status' => 'archived', 'updated_by' => Auth::id(), 'updated_at' => now()], 'id = :id', ['id' => $id]);
            Audit::log('archive', 'documents', 'document', $id, $d['doc_code']);
            flash('success', 'Document archived.');
        }
        redirect("/documents/$id");
    }

    public function duplicate(int $id): void
    {
        $d = $this->load($id);
        $new = DB::transaction(function () use ($d, $id) {
            $row = array_intersect_key($d, array_flip(['template_id', 'doc_type', 'title', 'recipient_name', 'recipient_details', 'member_id', 'purpose', 'body_html', 'closing', 'show_logo', 'show_letterhead', 'show_signatures', 'is_certificate', 'confidential']));
            $row += ['doc_code' => Ids::next('document'), 'doc_date' => today(), 'status' => 'draft', 'created_by' => Auth::id(), 'updated_by' => Auth::id()];
            $new = DB::insert('documents', $row);
            DB::query('INSERT INTO document_signatories (document_id, signatory_id, sort_order) SELECT ?, signatory_id, sort_order FROM document_signatories WHERE document_id = ?', [$new, $id]);
            return $new;
        });
        Audit::log('create', 'documents', 'document', $new, 'Copy of ' . $d['doc_code']);
        flash('success', 'A new draft was created from ' . $d['doc_code'] . '.');
        redirect("/documents/$new/edit");
    }
}
