<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\HttpException;
use App\Services\Backup;

final class BackupController extends Controller
{
    public function index(): void
    {
        $this->view('settings/backup', ['title' => 'Backup & restore', 'backups' => Backup::all(), 'history' => \App\Core\Database::all(
            "SELECT * FROM audit_logs WHERE module = 'backup' ORDER BY id DESC LIMIT 15")]);
    }

    public function create(): void
    {
        try {
            $r = Backup::create('manual', user()['full_name'] ?? null);
        } catch (\Throwable $e) {
            error_log('Backup failed: ' . $e->getMessage());
            flash('error', 'Backup failed: ' . $e->getMessage());
            redirect('/settings/backup');
        }
        Audit::log('backup', 'backup', null, null, $r['file'], 'Manual backup · ' . round($r['size'] / 1048576, 2) . ' MB');
        flash('success', 'Backup created: ' . $r['file'] . '. Download it and keep a copy on a USB drive or another computer.');
        redirect('/settings/backup');
    }

    public function download(): void
    {
        $p = Backup::path(query_str('file'));
        if (!$p) { throw new HttpException(404); }
        Audit::log('download', 'backup', null, null, basename($p));
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($p) . '"');
        header('Content-Length: ' . filesize($p));
        header('Cache-Control: no-store');
        readfile($p);
        exit;
    }

    public function delete(): void
    {
        $p = Backup::path(input_str('file', 100));
        if (!$p) { throw new HttpException(404); }
        @unlink($p);
        Audit::log('delete', 'backup', null, null, basename($p), 'Backup file deleted');
        flash('success', 'Backup deleted.');
        redirect('/settings/backup');
    }

    public function restore(): void
    {
        if (input_str('confirm') !== 'RESTORE') {
            flash('error', 'Type RESTORE (in capital letters) to confirm.');
            redirect('/settings/backup');
        }
        $uploaded = false;
        if (!empty($_FILES['backup_file']['tmp_name']) && is_uploaded_file($_FILES['backup_file']['tmp_name'])) {
            if ($_FILES['backup_file']['size'] > 1024 * 1024 * 1024) { flash('error', 'The file is too large.'); redirect('/settings/backup'); }
            $zip = $_FILES['backup_file']['tmp_name'];
            $uploaded = true;
        } else {
            $zip = Backup::path(input_str('file', 100));
        }
        if (!$zip) { flash('error', 'Choose a backup to restore.'); redirect('/settings/backup'); }
        $label = $uploaded ? 'Uploaded: ' . mb_substr((string) $_FILES['backup_file']['name'], 0, 100) : basename($zip);
        $by = user()['full_name'] ?? 'Unknown';
        try {
            $r = Backup::restore($zip, $by);
        } catch (\Throwable $e) {
            Audit::log('restore_failed', 'backup', null, null, $label, $e->getMessage());
            flash('error', 'Restore was cancelled: ' . $e->getMessage());
            redirect('/settings/backup');
        }
        Audit::log('restore_backup', 'backup', null, null, $label, 'Restored backup from ' . ($r['manifest']['created_at'] ?? '?') . '. Safety backup: ' . $r['safety'], null, $by);
        Auth::destroySession();
        flash('success', 'Restore complete. Please sign in again. A safety copy of the previous data was saved as ' . $r['safety'] . '.');
        redirect('/login');
    }
}
