<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Notify;
use App\Core\Permissions;

/**
 * User accounts. Safeguards:
 *  - only a Super Admin can create, edit or assign the Super Admin role;
 *  - a non-super-admin cannot grant permissions they do not have themselves;
 *  - the last active Super Admin cannot be deactivated or demoted, and nobody can deactivate themselves.
 */
final class UsersController extends Controller
{
    public function index(): void
    {
        $where = ['1=1'];
        $p = [];
        if (($q = query_str('q')) !== '') { $where[] = "(u.username LIKE :q ESCAPE '\\' OR u.full_name LIKE :q ESCAPE '\\' OR u.email LIKE :q ESCAPE '\\')"; $p['q'] = like($q); }
        if ($r = input_int('role')) { $where[] = 'u.role_id = :r'; $p['r'] = $r; }
        $st = input_in('status', ['active', 'inactive', 'locked', 'all'], 'all');
        if ($st === 'active') { $where[] = 'u.is_active = 1'; }
        if ($st === 'inactive') { $where[] = 'u.is_active = 0'; }
        if ($st === 'locked') { $where[] = "u.locked_until > datetime('now','localtime')"; }
        $users = DB::all('SELECT u.*, r.name role_name, r.code role_code, m.member_code, (SELECT COUNT(*) FROM user_permissions up WHERE up.user_id = u.id) overrides
                            FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN members m ON m.id = u.member_id WHERE ' . implode(' AND ', $where) . ' ORDER BY u.is_active DESC, u.full_name', $p);
        $this->view('users/index', ['title' => 'User management', 'users' => $users, 'roles' => DB::all('SELECT * FROM roles ORDER BY is_system DESC, name')]);
    }

    private function guard(?array $target): void
    {
        if ($target && $target['role_code'] === 'super_admin' && !Auth::isSuperAdmin()) {
            throw new HttpException(403, 'Only a Super Admin can change a Super Admin account.');
        }
    }

    private function roles(): array
    {
        return DB::all('SELECT * FROM roles' . (Auth::isSuperAdmin() ? '' : " WHERE code <> 'super_admin'") . ' ORDER BY is_system DESC, name');
    }

    public function create(): void
    {
        $this->form(['is_active' => 1, 'must_change_password' => 1, 'role_id' => DB::value("SELECT id FROM roles WHERE code = 'viewer'")], [], 'New user');
    }

    public function edit(int $id): void
    {
        $u = $this->find('SELECT u.*, r.code role_code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', [$id]);
        $this->guard($u);
        $this->form($u, DB::pairs('SELECT permission, allowed FROM user_permissions WHERE user_id = ?', [$id]), 'Edit user');
    }

    private function form(array $u, array $overrides, string $title): void
    {
        $rolePerms = [];
        foreach (DB::all('SELECT role_id, permission FROM role_permissions') as $r) { $rolePerms[$r['role_id']][] = $r['permission']; }
        $this->view('users/form', ['title' => $title, 'u' => $u, 'overrides' => $overrides, 'roles' => $this->roles(), 'rolePerms' => $rolePerms,
            'members' => $this->memberOptions(true),
            'recent' => !empty($u['id']) ? DB::all("SELECT * FROM audit_logs WHERE user_id = ? ORDER BY id DESC LIMIT 10", [$u['id']]) : []]);
    }

    public function store(): void
    {
        [$d, $ov, $e] = $this->validate(null);
        $pw = (string) ($_POST['password'] ?? '');
        if ($problem = Auth::passwordProblem($pw, $d['username'])) { $e['password'] = $problem; }
        elseif ($pw !== (string) ($_POST['password_confirm'] ?? '')) { $e['password_confirm'] = 'Passwords do not match.'; }
        if ($e) { $this->failed($e, '/users/new'); }
        $d['password_hash'] = Auth::hash($pw);
        $d['password_changed_at'] = now();
        $id = DB::transaction(function () use ($d, $ov) {
            $id = DB::insert('users', $d);
            $this->saveOverrides($id, $ov);
            return $id;
        });
        $role = DB::value('SELECT name FROM roles WHERE id = ?', [$d['role_id']]);
        Audit::log('create', 'users', 'user', $id, $d['username'], 'Role: ' . $role . ($ov ? ', ' . count($ov) . ' permission override(s)' : ''));
        Notify::user($id, 'system', 'Welcome to the Church Management System', 'Your account was created by ' . (user()['full_name'] ?? 'an administrator') . '.', '/profile');
        flash('success', 'User "' . $d['username'] . '" created.' . ($d['must_change_password'] ? ' They will be asked to change the password at first sign-in.' : ''));
        redirect('/users');
    }

    public function update(int $id): void
    {
        $before = $this->find('SELECT u.*, r.code role_code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', [$id]);
        $this->guard($before);
        [$d, $ov, $e] = $this->validate($id);
        $newRole = DB::value('SELECT code FROM roles WHERE id = ?', [$d['role_id']]);
        if ($before['role_code'] === 'super_admin' && $newRole !== 'super_admin' && $this->superAdminCount() <= 1) {
            $e['role_id'] = 'This is the only active Super Admin. Assign another Super Admin first.';
        }
        if ($id === Auth::id() && !$d['is_active']) { $e['is_active'] = 'You cannot deactivate your own account.'; }
        if ($before['role_code'] === 'super_admin' && !$d['is_active'] && $this->superAdminCount() <= 1) { $e['is_active'] = 'The last Super Admin cannot be deactivated.'; }
        if ($e) { $this->failed($e, "/users/$id/edit"); }
        $oldOv = DB::pairs('SELECT permission, allowed FROM user_permissions WHERE user_id = ?', [$id]);
        $securityChange = (int) $before['role_id'] !== (int) $d['role_id'] || $oldOv != $ov || ((int) $before['is_active'] && !$d['is_active']);
        DB::transaction(function () use ($id, $d, $ov, $securityChange) {
            DB::update('users', $d + ['updated_at' => now()], 'id = :id', ['id' => $id]);
            DB::query('DELETE FROM user_permissions WHERE user_id = ?', [$id]);
            $this->saveOverrides($id, $ov);
            if ($securityChange && $id !== Auth::id()) {
                DB::query('UPDATE users SET session_version = session_version + 1 WHERE id = ?', [$id]);
            }
        });
        $diff = Audit::diff($before, $d, ['username' => 'Username', 'full_name' => 'Name', 'email' => 'Email', 'role_id' => 'Role ID', 'is_active' => 'Active', 'member_id' => 'Linked member', 'position' => 'Position']);
        if ($oldOv != $ov) { $diff .= ($diff ? '; ' : '') . 'Permission overrides changed (' . count($ov) . ' now)'; }
        Audit::log('update', 'users', 'user', $id, $d['username'], $diff ?: null);
        Auth::forgetCache();
        flash('success', 'User saved.' . ($securityChange && $id !== Auth::id() ? ' Their access changed, so they must sign in again.' : ''));
        redirect('/users');
    }

    public function resetPassword(int $id): void
    {
        $u = $this->find('SELECT u.*, r.code role_code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', [$id]);
        $this->guard($u);
        $pw = (string) ($_POST['new_password'] ?? '');
        if ($problem = Auth::passwordProblem($pw, $u['username'])) {
            flash('error', $problem);
            redirect("/users/$id/edit");
        }
        DB::query("UPDATE users SET password_hash = ?, must_change_password = 1, failed_attempts = 0, locked_until = NULL, session_version = session_version + 1,
                          password_changed_at = datetime('now','localtime'), updated_at = datetime('now','localtime') WHERE id = ?", [Auth::hash($pw), $id]);
        Audit::log('reset_password', 'users', 'user', $id, $u['username'], 'Temporary password set; must change at next sign-in');
        flash('success', 'Password reset. Give the temporary password to ' . $u['full_name'] . ' privately — they must change it at sign-in.');
        redirect("/users/$id/edit");
    }

    /** Activate / deactivate / unlock. */
    public function toggle(int $id): void
    {
        $u = $this->find('SELECT u.*, r.code role_code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', [$id]);
        $this->guard($u);
        $action = input_in('action', ['activate', 'deactivate', 'unlock'], '');
        if ($action === 'unlock') {
            DB::query('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?', [$id]);
            Audit::log('unlock', 'users', 'user', $id, $u['username']);
            flash('success', 'Account unlocked.');
        } elseif ($action === 'deactivate') {
            if ($id === Auth::id()) { flash('error', 'You cannot deactivate your own account.'); redirect('/users'); }
            if ($u['role_code'] === 'super_admin' && $this->superAdminCount() <= 1) { flash('error', 'The last Super Admin cannot be deactivated.'); redirect('/users'); }
            DB::query('UPDATE users SET is_active = 0, session_version = session_version + 1 WHERE id = ?', [$id]);
            Audit::log('deactivate', 'users', 'user', $id, $u['username']);
            flash('success', $u['full_name'] . ' was deactivated and signed out.');
        } elseif ($action === 'activate') {
            DB::query('UPDATE users SET is_active = 1, failed_attempts = 0, locked_until = NULL WHERE id = ?', [$id]);
            Audit::log('activate', 'users', 'user', $id, $u['username']);
            flash('success', $u['full_name'] . ' can sign in again.');
        }
        redirect('/users');
    }

    private function superAdminCount(): int
    {
        return (int) DB::value("SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = 'super_admin' AND u.is_active = 1");
    }

    private function saveOverrides(int $id, array $ov): void
    {
        foreach ($ov as $perm => $allowed) {
            DB::insert('user_permissions', ['user_id' => $id, 'permission' => $perm, 'allowed' => $allowed]);
        }
    }

    private function validate(?int $id): array
    {
        $d = [
            'username' => strtolower(input_str('username', 40)), 'full_name' => input_str('full_name', 120),
            'email' => input_str('email', 150) ?: null, 'position' => input_str('position', 100) ?: null,
            'role_id' => input_int('role_id'), 'member_id' => input_int('member_id'),
            'is_active' => input_str('is_active') === '1' ? 1 : 0, 'must_change_password' => input_str('must_change_password') === '1' ? 1 : 0,
        ];
        $e = [];
        if (!preg_match('/^[a-z0-9._-]{3,40}$/', $d['username'])) { $e['username'] = 'Use 3–40 letters, numbers, dots, dashes or underscores.'; }
        elseif (DB::value('SELECT 1 FROM users WHERE username = ? COLLATE NOCASE AND id <> ?', [$d['username'], $id ?? 0])) { $e['username'] = 'This username is already taken.'; }
        if ($d['full_name'] === '') { $e['full_name'] = 'Full name is required.'; }
        if ($d['email'] && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) { $e['email'] = 'Enter a valid email address.'; }
        elseif ($d['email'] && DB::value('SELECT 1 FROM users WHERE email = ? COLLATE NOCASE AND id <> ?', [$d['email'], $id ?? 0])) { $e['email'] = 'Another user already uses this email.'; }
        $role = $d['role_id'] ? DB::one('SELECT * FROM roles WHERE id = ?', [$d['role_id']]) : null;
        if (!$role) { $e['role_id'] = 'Choose a role.'; }
        elseif ($role['code'] === 'super_admin' && !Auth::isSuperAdmin()) { $e['role_id'] = 'Only a Super Admin can assign the Super Admin role.'; }
        if ($d['member_id'] && !DB::value('SELECT 1 FROM members WHERE id = ?', [$d['member_id']])) { $d['member_id'] = null; }

        // Permission overrides: grant/revoke relative to the role. Non-super-admins cannot grant what they lack.
        $ov = [];
        foreach ((array) ($_POST['perm'] ?? []) as $perm => $val) {
            if (!is_string($perm) || !Permissions::exists($perm) || !in_array($val, ['grant', 'revoke'], true)) { continue; }
            if ($val === 'grant' && !Auth::isSuperAdmin() && !can($perm)) {
                $e['perm'] = 'You cannot grant a permission you do not have yourself (' . $perm . ').';
                continue;
            }
            $ov[$perm] = $val === 'grant' ? 1 : 0;
        }
        if ($role && $role['code'] === 'super_admin') { $ov = []; }
        ksort($ov);
        return [$d, $ov, $e];
    }
}
