<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Notify;
use App\Core\Paginator;
use App\Core\Upload;

/** Announcements and free messages (devotionals, reminders, pastoral notes). */
final class AnnouncementsController extends Controller
{
    public function index(): void
    {
        $manage = can('announcements.manage');
        $tab = $manage ? input_in('tab', ['published', 'draft', 'archived'], 'published') : 'published';
        $params = ['s' => $tab];
        $where = 'a.status = :s';
        if (($q = query_str('q')) !== '') { $where .= " AND (a.title LIKE :q ESCAPE '\\' OR a.body LIKE :q ESCAPE '\\')"; $params['q'] = like($q); }
        $p = new Paginator((int) DB::value("SELECT COUNT(*) FROM announcements a WHERE $where", $params), 12);
        $items = DB::all("SELECT a.*, u.full_name AS author FROM announcements a LEFT JOIN users u ON u.id = a.author_user_id
                           WHERE $where ORDER BY a.is_pinned DESC, COALESCE(a.published_at, a.updated_at) DESC" . $p->sql(), $params);
        $counts = DB::pairs('SELECT status, COUNT(*) FROM announcements GROUP BY status');
        $this->view('announcements/index', ['title' => 'Announcements', 'items' => $items, 'tab' => $tab, 'p' => $p, 'counts' => $counts]);
    }

    public function show(int $id): void
    {
        $a = $this->find('SELECT a.*, u.full_name AS author FROM announcements a LEFT JOIN users u ON u.id = a.author_user_id WHERE a.id = ?', [$id]);
        if ($a['status'] !== 'published' && !can('announcements.manage')) {
            throw new HttpException(404);
        }
        $this->view('announcements/show', ['title' => $a['title'], 'a' => $a]);
    }

    public function create(): void
    {
        $this->view('announcements/form', ['title' => 'New announcement', 'a' => ['status' => 'published']]);
    }

    public function edit(int $id): void
    {
        $this->view('announcements/form', ['title' => 'Edit announcement', 'a' => $this->find('SELECT * FROM announcements WHERE id = ?', [$id])]);
    }

    public function store(): void
    {
        [$d, $errors] = $this->validate();
        [$img, $err] = Upload::image('image', 'announcements', 1600);
        if ($err) { $errors['image'] = $err; }
        if ($errors) { Upload::delete($img); $this->failed($errors, '/announcements/new'); }
        $d['image_path'] = $img;
        $d['author_user_id'] = Auth::id();
        $d['published_at'] = $d['status'] === 'published' ? now() : null;
        $id = DB::insert('announcements', $d);
        Audit::log('create', 'announcements', 'announcement', $id, $d['title'], 'Status: ' . $d['status']);
        if ($d['status'] === 'published') { $this->notify($id, $d['title']); }
        flash('success', $d['status'] === 'published' ? 'Announcement published.' : 'Draft saved.');
        redirect("/announcements/$id");
    }

    public function update(int $id): void
    {
        $before = $this->find('SELECT * FROM announcements WHERE id = ?', [$id]);
        [$d, $errors] = $this->validate();
        [$img, $err] = Upload::image('image', 'announcements', 1600);
        if ($err) { $errors['image'] = $err; }
        if ($errors) { Upload::delete($img); $this->failed($errors, "/announcements/$id/edit"); }
        $remove = !empty($_POST['remove_image']);
        if ($img || $remove) { $d['image_path'] = $img; }
        if ($d['status'] === 'published' && !$before['published_at']) { $d['published_at'] = now(); }
        $d['updated_at'] = now();
        DB::update('announcements', $d, 'id = :id', ['id' => $id]);
        if ($img || $remove) { Upload::delete($before['image_path']); }
        Audit::log('update', 'announcements', 'announcement', $id, $d['title'], Audit::diff($before, $d, ['title' => 'Title', 'status' => 'Status', 'is_pinned' => 'Pinned']) ?: 'Content edited');
        if ($d['status'] === 'published' && $before['status'] !== 'published') { $this->notify($id, $d['title']); }
        flash('success', 'Announcement saved.');
        redirect("/announcements/$id");
    }

    public function status(int $id): void
    {
        $a = $this->find('SELECT * FROM announcements WHERE id = ?', [$id]);
        $action = input_in('action', ['publish', 'archive', 'draft', 'pin', 'unpin'], '');
        $set = match ($action) {
            'publish' => ['status' => 'published', 'published_at' => $a['published_at'] ?: now()],
            'archive' => ['status' => 'archived', 'is_pinned' => 0],
            'draft' => ['status' => 'draft'],
            'pin' => ['is_pinned' => 1],
            'unpin' => ['is_pinned' => 0],
            default => throw new HttpException(400),
        };
        DB::update('announcements', $set + ['updated_at' => now()], 'id = :id', ['id' => $id]);
        Audit::log($action, 'announcements', 'announcement', $id, $a['title']);
        if ($action === 'publish' && $a['status'] !== 'published') { $this->notify($id, $a['title']); }
        flash('success', match ($action) { 'publish' => 'Published.', 'archive' => 'Archived.', 'draft' => 'Moved back to drafts.', 'pin' => 'Pinned to the top.', default => 'Unpinned.' });
        redirect("/announcements/$id");
    }

    private function notify(int $id, string $title): void
    {
        Notify::permission('announcements.view', 'announcement', 'New announcement', $title, '/announcements/' . $id);
    }

    private function validate(): array
    {
        $d = ['title' => input_str('title', 150), 'body' => input_text('body', 20000),
            'status' => input_in('status', ['draft', 'published', 'archived'], 'draft'), 'is_pinned' => input_str('is_pinned') === '1' ? 1 : 0];
        $e = [];
        if ($d['title'] === '') { $e['title'] = 'Title is required.'; }
        if ($d['body'] === '') { $e['body'] = 'Write the message.'; }
        return [$d, $e];
    }
}
