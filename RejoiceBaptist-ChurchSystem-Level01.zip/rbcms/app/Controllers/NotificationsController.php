<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\Paginator;

final class NotificationsController extends Controller
{
    private const ICONS = ['event' => 'calendar', 'announcement' => 'megaphone', 'ministry' => 'layers', 'attendance' => 'clipboard',
        'document' => 'file', 'finance' => 'wallet', 'admin' => 'shield', 'music' => 'music', 'member' => 'users'];

    public function index(): void
    {
        $filter = query_str('filter') === 'unread' ? 'unread' : 'all';
        $where = 'user_id = ?' . ($filter === 'unread' ? ' AND read_at IS NULL' : '');
        $p = new Paginator((int) DB::value("SELECT COUNT(*) FROM notifications WHERE $where", [Auth::id()]), 30);
        $items = DB::all("SELECT * FROM notifications WHERE $where ORDER BY created_at DESC, id DESC" . $p->sql(), [Auth::id()]);
        $this->view('notifications/index', ['title' => 'Notifications', 'items' => $items, 'p' => $p, 'filter' => $filter, 'icons' => self::ICONS, 'narrow' => true]);
    }

    public function feed(): void
    {
        $rows = DB::all('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 8', [Auth::id()]);
        $items = array_map(fn($n) => [
            'id' => (int) $n['id'], 'title' => $n['title'], 'body' => $n['body'], 'ago' => time_ago($n['created_at']),
            'read' => $n['read_at'] !== null, 'icon' => icon(self::ICONS[$n['type']] ?? 'bell'),
        ], $rows);
        $this->json(['items' => $items, 'unread' => \App\Core\Notify::unreadCount((int) Auth::id())]);
    }

    public function open(int $id): void
    {
        $n = $this->find('SELECT * FROM notifications WHERE id = ? AND user_id = ?', [$id, Auth::id()]);
        DB::query("UPDATE notifications SET read_at = COALESCE(read_at, datetime('now','localtime')) WHERE id = ?", [$id]);
        $link = $n['link'] && str_starts_with($n['link'], '/') ? $n['link'] : '/notifications';
        redirect($link);
    }

    public function readAll(): void
    {
        DB::query("UPDATE notifications SET read_at = datetime('now','localtime') WHERE user_id = ? AND read_at IS NULL", [Auth::id()]);
        if (str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')) {
            $this->json(['ok' => true]);
        }
        flash('success', 'All notifications marked as read.');
        back('/notifications');
    }
}
