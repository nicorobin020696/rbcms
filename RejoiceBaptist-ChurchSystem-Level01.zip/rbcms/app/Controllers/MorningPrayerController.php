<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\Ids;
use App\Services\Stats;

/**
 * Morning prayer uses the main attendance tables (category "Morning Prayer"), so its records
 * appear in member histories and attendance reports without being stored twice.
 */
final class MorningPrayerController extends Controller
{
    private function categoryId(): int
    {
        return (int) DB::value("SELECT id FROM categories WHERE type = 'attendance' AND code = 'morning_prayer'");
    }

    public function index(): void
    {
        $cat = $this->categoryId();
        $date = input_date('date') ?: today();
        if ($date > today()) {
            $date = today();
        }
        $year = (int) substr($date, 0, 4);
        $session = DB::one('SELECT * FROM attendance_sessions WHERE category_id = ? AND session_date = ? ORDER BY id LIMIT 1', [$cat, $date]);
        $marks = $session ? DB::pairs('SELECT member_id, status FROM attendance_records WHERE session_id = ?', [$session['id']]) : [];
        $members = DB::all(
            "SELECT id, member_code, first_name, middle_name, last_name, suffix, membership_status FROM members
              WHERE archived_at IS NULL AND membership_status = 'active' OR id IN (" . (implode(',', array_map('intval', array_keys($marks))) ?: '0') . ")
              ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE"
        );
        $monthStart = substr($date, 0, 7) . '-01';
        $monthEnd = date('Y-m-t', strtotime($monthStart));
        $q = static fn(string $from, string $to) => DB::one(
            "SELECT COUNT(DISTINCT s.id) days, COUNT(r.id) present FROM attendance_sessions s
               LEFT JOIN attendance_records r ON r.session_id = s.id AND r.status = 'present'
              WHERE s.category_id = ? AND s.session_date BETWEEN ? AND ?",
            [$cat, $from, $to]
        );
        $month = $q($monthStart, $monthEnd);
        $yearStats = $q("$year-01-01", "$year-12-31");
        $dailyRows = DB::pairs(
            "SELECT s.session_date, COUNT(r.id) FROM attendance_sessions s LEFT JOIN attendance_records r ON r.session_id = s.id AND r.status = 'present'
              WHERE s.category_id = ? AND s.session_date BETWEEN ? AND ? GROUP BY s.session_date",
            [$cat, $monthStart, $monthEnd]
        );
        $daily = [];
        for ($d = strtotime($monthStart); $d <= strtotime(min($monthEnd, today())); $d += 86400) {
            $daily[date('j', $d)] = (int) ($dailyRows[date('Y-m-d', $d)] ?? 0);
        }
        $consistent = DB::all(
            "SELECT m.id, m.first_name, m.last_name, m.middle_name, m.suffix, m.member_code, COUNT(*) present
               FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id JOIN members m ON m.id = r.member_id
              WHERE s.category_id = ? AND r.status = 'present' AND strftime('%Y', s.session_date) = ? AND m.archived_at IS NULL
              GROUP BY m.id ORDER BY present DESC, m.last_name LIMIT 10",
            [$cat, (string) $year]
        );
        $history = DB::all(
            "SELECT s.id, s.session_date, s.session_time, SUM(r.status = 'present') present, SUM(r.status = 'absent') absent
               FROM attendance_sessions s LEFT JOIN attendance_records r ON r.session_id = s.id
              WHERE s.category_id = ? GROUP BY s.id ORDER BY s.session_date DESC LIMIT 14",
            [$cat]
        );
        $this->view('prayer/index', [
            'title' => 'Morning Prayer', 'date' => $date, 'session' => $session, 'marks' => $marks, 'members' => $members,
            'month' => $month, 'yearStats' => $yearStats, 'year' => $year, 'daily' => $daily, 'consistent' => $consistent,
            'monthly' => Stats::monthlyAttendance($year, $cat), 'history' => $history,
            'canEdit' => !$session || AttendanceController::canCorrect($session),
        ]);
    }

    public function save(): void
    {
        $cat = $this->categoryId();
        $date = input_date('date');
        if (!$date || $date > today()) {
            flash('error', 'Choose a valid date (today or earlier).');
            redirect('/morning-prayer');
        }
        $present = array_flip(array_map('intval', (array) ($_POST['present'] ?? [])));
        $shown = array_map('intval', (array) ($_POST['shown'] ?? []));
        $time = input_time('session_time');
        $result = DB::transaction(function () use ($cat, $date, $present, $shown, $time) {
            $session = DB::one('SELECT * FROM attendance_sessions WHERE category_id = ? AND session_date = ? ORDER BY id LIMIT 1', [$cat, $date]);
            if (!$session) {
                $id = DB::insert('attendance_sessions', ['session_code' => Ids::next('attendance', $date), 'category_id' => $cat,
                    'title' => 'Morning Prayer', 'session_date' => $date, 'session_time' => $time, 'created_by' => Auth::id()]);
                $session = DB::one('SELECT * FROM attendance_sessions WHERE id = ?', [$id]);
            } elseif ($time && $time !== $session['session_time']) {
                DB::update('attendance_sessions', ['session_time' => $time], 'id = :id', ['id' => $session['id']]);
            }
            $correct = AttendanceController::canCorrect($session);
            $existing = DB::pairs('SELECT member_id, status FROM attendance_records WHERE session_id = ?', [$session['id']]);
            $valid = array_flip(array_map('intval', DB::column('SELECT id FROM members WHERE archived_at IS NULL')));
            $n = ['added' => 0, 'changed' => 0, 'blocked' => 0];
            foreach ($shown as $mid) {
                if (!isset($valid[$mid]) && !isset($existing[$mid])) {
                    continue;
                }
                $status = isset($present[$mid]) ? 'present' : 'absent';
                $old = $existing[$mid] ?? null;
                if ($old === $status) {
                    continue;
                }
                if ($old === null) {
                    DB::insert('attendance_records', ['session_id' => $session['id'], 'member_id' => $mid, 'status' => $status, 'recorded_by' => Auth::id()]);
                    $n['added']++;
                } elseif ($correct) {
                    DB::query("UPDATE attendance_records SET status = ?, recorded_by = ?, updated_at = datetime('now','localtime') WHERE session_id = ? AND member_id = ?", [$status, Auth::id(), $session['id'], $mid]);
                    $n['changed']++;
                } else {
                    $n['blocked']++;
                }
            }
            return [$session, $n];
        });
        [$session, $n] = $result;
        $presentCount = (int) DB::value("SELECT COUNT(*) FROM attendance_records WHERE session_id = ? AND status = 'present'", [$session['id']]);
        Audit::log('record', 'attendance', 'session', (int) $session['id'], 'Morning Prayer · ' . $date, "{$n['added']} added, {$n['changed']} corrected");
        flash($n['blocked'] ? 'warning' : 'success', "Morning prayer for " . fmt_date($date) . " saved — $presentCount present." . ($n['blocked'] ? " {$n['blocked']} locked change(s) were not applied." : ''));
        redirect('/morning-prayer', ['date' => $date]);
    }
}
