<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\HttpException;
use App\Core\Permissions;

/** Roles and their permission matrix. The Super Admin role always has everything and cannot be edited. */
final class RolesController extends Controller
{
    public function index(): void
    {
        $roles = DB::all('SELECT r.*, (SELECT COUNT(*) FROM users u WHERE u.role_id = r.id) users, (SELECT COUNT(*) FROM role_permissions p WHERE p.role_id = r.id) perms FROM roles r ORDER BY r.is_system DESC, r.name');
        $matrix = [];
        foreach (DB::all('SELECT role_id, permission FROM role_permissions') as $r) { $matrix[$r['role_id']][$r['permission']] = true; }
        $this->view('users/roles', ['title' => 'Roles & permissions', 'roles' => $roles, 'matrix' => $matrix]);
    }

    public function create(): void
    {
        $this->view('users/role_form', ['title' => 'New role', 'r' => [], 'perms' => []]);
    }

    public function edit(int $id): void
    {
        $r = $this->find('SELECT * FROM roles WHERE id = ?', [$id]);
        if ($r['code'] === 'super_admin') {
            flash('info', 'The Super Admin role always has full access and cannot be changed.');
            redirect('/users/roles');
        }
        $this->view('users/role_form', ['title' => 'Edit role', 'r' => $r, 'perms' => DB::column('SELECT permission FROM role_permissions WHERE role_id = ?', [$id])]);
    }

    public function store(): void
    {
        [$d, $perms, $e] = $this->validate(null);
        if ($e) { $this->failed($e, '/users/roles/new'); }
        $id = DB::transaction(function () use ($d, $perms) {
            $id = DB::insert('roles', $d + ['code' => $this->code($d['name']), 'is_system' => 0]);
            foreach ($perms as $p) { DB::insert('role_permissions', ['role_id' => $id, 'permission' => $p]); }
            return $id;
        });
        Audit::log('create', 'users', 'role', $id, $d['name'], count($perms) . ' permissions: ' . implode(', ', $perms));
        flash('success', 'Role created.');
        redirect('/users/roles');
    }

    public function update(int $id): void
    {
        $r = $this->find('SELECT * FROM roles WHERE id = ?', [$id]);
        if ($r['code'] === 'super_admin') { throw new HttpException(403); }
        [$d, $perms, $e] = $this->validate($id);
        if ($e) { $this->failed($e, "/users/roles/$id"); }
        $old = DB::column('SELECT permission FROM role_permissions WHERE role_id = ?', [$id]);
        DB::transaction(function () use ($id, $d, $perms) {
            DB::update('roles', $d, 'id = :id', ['id' => $id]);
            DB::query('DELETE FROM role_permissions WHERE role_id = ?', [$id]);
            foreach ($perms as $p) { DB::insert('role_permissions', ['role_id' => $id, 'permission' => $p]); }
            // Everyone with this role must sign in again so the new access applies immediately.
            DB::query('UPDATE users SET session_version = session_version + 1 WHERE role_id = ? AND id <> ?', [$id, Auth::id() ?? 0]);
        });
        $added = array_diff($perms, $old);
        $removed = array_diff($old, $perms);
        Audit::log('update', 'users', 'role', $id, $d['name'], trim(($added ? 'Added: ' . implode(', ', $added) . '. ' : '') . ($removed ? 'Removed: ' . implode(', ', $removed) . '.' : '')) ?: null);
        Auth::forgetCache();
        flash('success', 'Role saved. Users with this role will be asked to sign in again.');
        redirect('/users/roles');
    }

    private function code(string $name): string
    {
        $base = trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($name)), '_') ?: 'role';
        $code = $base;
        $i = 2;
        while (DB::value('SELECT 1 FROM roles WHERE code = ?', [$code])) { $code = $base . '_' . $i++; }
        return $code;
    }

    private function validate(?int $id): array
    {
        $d = ['name' => input_str('name', 60), 'description' => input_str('description', 250) ?: null];
        $e = [];
        if ($d['name'] === '') { $e['name'] = 'Name is required.'; }
        elseif (DB::value('SELECT 1 FROM roles WHERE name = ? COLLATE NOCASE AND id <> ?', [$d['name'], $id ?? 0])) { $e['name'] = 'A role with this name exists.'; }
        $perms = [];
        foreach ((array) ($_POST['perms'] ?? []) as $p) {
            if (!is_string($p) || !Permissions::exists($p)) { continue; }
            if (!Auth::isSuperAdmin() && !can($p)) { $e['perms'] = 'You cannot give a role a permission you do not have yourself (' . $p . ').'; continue; }
            $perms[] = $p;
        }
        sort($perms);
        return [$d, array_values(array_unique($perms)), $e];
    }
}
