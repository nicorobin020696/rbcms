<div style="max-width:520px;margin:12vh auto;padding:0 20px;text-align:center">
  <div class="code" style="font-size:13px;color:var(--muted)">Error <?= (int) $status ?></div>
  <h1 style="margin:6px 0 10px"><?= e($title) ?></h1>
  <p class="muted" style="white-space:pre-line"><?= e($message) ?></p>
  <div class="row" style="justify-content:center;margin-top:18px">
    <a class="btn" href="<?= url('/') ?>" data-back><?= icon('chevron-left') ?> Go back</a>
    <a class="btn btn-primary" href="<?= url('/') ?>">Go to dashboard</a>
  </div>
</div>
