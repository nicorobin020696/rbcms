<div class="page-head"><div><h1>Profile &amp; appearance</h1><p>How you appear in the system and how it looks for you.</p></div></div>
<form method="post" action="<?= url('/profile') ?>" class="card">
  <?= csrf_field() ?>
  <div class="card-body">
    <div class="field" style="margin-bottom:16px"><label for="full_name">Full name<span class="req">*</span></label>
      <input id="full_name" name="full_name" value="<?= e(old('full_name', $u['full_name'])) ?>" class="<?= has_error('full_name') ?>" required><?= field_error('full_name') ?></div>
    <dl class="kv">
      <dt>Username</dt><dd class="mono"><?= e($u['username']) ?></dd>
      <dt>E-mail</dt><dd><?= e($u['email'] ?: '—') ?></dd>
      <dt>Role</dt><dd><?= e($u['role_name']) ?></dd>
      <dt>Position</dt><dd><?= e($u['position'] ?: '—') ?></dd>
      <dt>Last sign-in</dt><dd><?= e(fmt_datetime($u['last_login_at'])) ?></dd>
    </dl>
    <p class="help" style="margin-top:12px">Username, e-mail, position and role are managed by the system administrator.</p>
    <div class="label" style="margin-top:20px">Theme</div>
    <div class="choice-cards">
      <?php foreach (['system' => ['monitor', 'Match this computer'], 'light' => ['sun', 'Light'], 'dark' => ['moon', 'Dark']] as $val => [$ic, $lab]): ?>
        <label><input type="radio" name="theme" value="<?= $val ?>" <?= $u['theme'] === $val ? 'checked' : '' ?>> <?= icon($ic) ?> <?= e($lab) ?></label>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="card-footer">
    <a class="btn btn-ghost" href="<?= url('/password') ?>"><?= icon('key') ?> Change password</a>
    <button class="btn btn-primary" type="submit">Save</button>
  </div>
</form>
