<div class="page-head"><div><h1>Change password</h1><p>Pick a new password. Other computers signed in as you will be signed out.</p></div></div>
<?php if ($forced): ?><div class="callout warn mb"><?= icon('alert') ?><div>Your administrator set a temporary password. Please choose your own password to continue.</div></div><?php endif; ?>
<form method="post" action="<?= url('/password') ?>" class="card" style="max-width:480px" novalidate>
  <?= csrf_field() ?>
  <div class="card-body stack" style="gap:14px">
    <div class="field"><label for="current_password">Current password<span class="req">*</span></label><input id="current_password" name="current_password" type="password" autocomplete="current-password" class="<?= has_error('current_password') ?>" required autofocus><?= field_error('current_password') ?></div>
    <div class="field"><label for="password">New password<span class="req">*</span></label><input id="password" name="password" type="password" autocomplete="new-password" class="<?= has_error('password') ?>" required><p class="help">At least 10 characters with letters and numbers.</p><?= field_error('password') ?></div>
    <div class="field"><label for="password_confirm">Confirm new password<span class="req">*</span></label><input id="password_confirm" name="password_confirm" type="password" autocomplete="new-password" class="<?= has_error('password_confirm') ?>" required><?= field_error('password_confirm') ?></div>
  </div>
  <div class="card-footer"><span class="muted small">You will stay signed in on this computer.</span><button class="btn btn-primary" type="submit">Save password</button></div>
</form>
