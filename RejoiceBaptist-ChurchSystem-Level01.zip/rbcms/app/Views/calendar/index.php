<?php
$q = fn(array $o) => url('/calendar', array_merge(['view' => $view, 'date' => $date, 'category' => $cat ?: null], $o));
$item = function (array $i): string {
    $t = $i['start_time'] ? '<span class="t">' . e(fmt_time($i['start_time'])) . '</span>' : '';
    return '<span class="cal-item c-' . e($i['color']) . ($i['cancelled'] ? ' cancelled' : '') . '" title="' . e($i['title'] . ' · ' . time_range($i['start_time'], $i['end_time'])) . '">' . $t . e($i['title']) . '</span>';
};
?>
<div class="page-head">
  <div><h1>Calendar</h1><p>Events, weekly services and ministry meetings. Click a day to see everything scheduled.</p></div>
  <div class="page-actions">
    <?php if (can('events.manage')): ?><a class="btn" href="<?= url('/events/new') ?>"><?= icon('flag') ?> New event</a><?php endif; ?>
    <?php if ($canAdd): ?><a class="btn btn-primary" href="<?= url('/events/new', ['type' => 'schedule']) ?>"><?= icon('plus') ?> Add schedule</a><?php endif; ?>
  </div>
</div>
<div class="card">
  <div class="cal-toolbar">
    <div class="row">
      <a class="btn btn-sm" href="<?= $q(['date' => today()]) ?>">Today</a>
      <a class="icon-btn" href="<?= $q(['date' => $prev]) ?>" aria-label="Previous"><?= icon('chevron-left') ?></a>
      <a class="icon-btn" href="<?= $q(['date' => $next]) ?>" aria-label="Next"><?= icon('chevron-right') ?></a>
      <span class="cal-title"><?= e($label) ?></span>
    </div>
    <div class="row">
      <form method="get" class="row"><input type="hidden" name="view" value="<?= e($view) ?>"><input type="hidden" name="date" value="<?= e($date) ?>">
        <select name="category" data-autosubmit><option value="">All categories</option><option value="ministry" <?= $cat === 'ministry' ? 'selected' : '' ?>>Weekly ministries only</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $cat === (string) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
      </form>
      <div class="seg-tabs"><?php foreach (['month' => 'Month', 'week' => 'Week', 'list' => 'List'] as $k => $l): ?><a href="<?= $q(['view' => $k]) ?>" class="<?= $view === $k ? 'active' : '' ?>"><?= $l ?></a><?php endforeach; ?></div>
    </div>
  </div>

  <?php if ($view === 'month' || $view === 'week'): ?>
  <div class="cal <?= $view === 'week' ? 'cal-weekview' : '' ?>" data-calendar data-category="<?= e($cat) ?>">
    <div class="cal-head"><?php foreach (['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'] as $d): ?><div><?= $d ?></div><?php endforeach; ?></div>
    <div class="cal-week">
    <?php $month = substr($date, 0, 7); $max = $view === 'week' ? 12 : 3;
    for ($d = strtotime($from); $d <= strtotime($to); $d += 86400):
      $ds = date('Y-m-d', $d); $items = $entries[$ds] ?? []; ?>
      <div class="cal-day<?= $view === 'month' && substr($ds, 0, 7) !== $month ? ' other' : '' ?><?= $ds === today() ? ' today' : '' ?>" data-day="<?= $ds ?>" tabindex="0" role="button" aria-label="<?= e(fmt_date($ds, 'l, j F Y')) ?>: <?= count($items) ?> item(s)" <?= $view === 'week' ? 'style="min-height:260px"' : '' ?>>
        <span class="cal-num"><span><?= date('j', $d) ?></span></span>
        <?php foreach (array_slice($items, 0, $max) as $i) { echo $item($i); } ?>
        <?php if (count($items) > $max): ?><span class="cal-more">+<?= count($items) - $max ?> more</span><?php endif; ?>
      </div>
    <?php endfor; ?>
    </div>
  </div>
  <?php else: ?>
  <div class="cal-list" data-calendar>
    <?php if (!$entries): ?><div class="empty"><?= icon('calendar') ?><strong>Nothing scheduled</strong>No events in this period.</div><?php endif; ?>
    <?php foreach ($entries as $ds => $items): ?>
      <div class="day-group"><div class="day-label <?= $ds === today() ? 'today' : '' ?>"><span><?= e(fmt_date($ds, 'l, j F Y')) ?></span><span class="muted small"><?= e(App\Services\Calendar::relative($ds)) ?></span></div>
        <?php foreach ($items as $i): ?>
          <a class="cal-entry" href="<?= url($i['kind'] === 'ministry' ? '/ministries/' . $i['id'] : '/events/' . $i['id']) ?>">
            <span class="time"><?= e(time_range($i['start_time'], $i['end_time'])) ?></span>
            <span><strong class="<?= $i['cancelled'] ? 'strike' : '' ?>"><?= e($i['title']) ?></strong><?= $i['cancelled'] ? ' ' . badge('Cancelled', 'red') : '' ?><span class="sub"><?= e($i['location'] ?: '') ?></span></span>
            <span class="tag"><span class="cat-dot c-<?= e($i['color']) ?>"></span><?= e($i['category']) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <div class="cal-legend"><span><span class="cat-dot c-green"></span>Weekly ministry</span><?php foreach ($legend as $l): ?><span><span class="cat-dot c-<?= e($l['color']) ?>"></span><?= e($l['name']) ?></span><?php endforeach; ?></div>
</div>

<dialog class="modal" id="day-modal" aria-labelledby="day-modal-title">
  <div class="modal-head"><h2 id="day-modal-title">—</h2><button class="icon-btn" type="button" data-close-modal aria-label="Close"><?= icon('x') ?></button></div>
  <div class="modal-body" id="day-modal-body"><div class="empty small">Loading…</div></div>
  <div class="modal-foot"><a class="btn hidden" id="day-modal-add" href="#"><?= icon('plus') ?> Add on this day</a><button class="btn" type="button" data-close-modal>Close</button></div>
</dialog>
