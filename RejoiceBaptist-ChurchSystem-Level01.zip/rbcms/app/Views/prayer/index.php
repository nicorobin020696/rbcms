<?php use App\Services\Stats; $presentNow = count(array_filter($marks, fn($s) => $s === 'present')); ?>
<div class="page-head">
  <div><h1>Morning Prayer</h1><p>Quick daily sheet. Records are saved in the main attendance system under “Morning Prayer”.</p></div>
  <form method="get" class="row"><label class="muted small" for="date">Date</label><input id="date" type="date" name="date" value="<?= e($date) ?>" max="<?= today() ?>" data-autosubmit style="width:auto"></form>
</div>
<div class="stats mb">
  <div class="stat"><div class="stat-label"><?= $date === today() ? 'Today' : e(fmt_date($date, 'D, j M')) ?></div><div class="stat-value"><?= $presentNow ?></div><div class="stat-note"><?= $session ? 'present' : 'not yet recorded' ?></div></div>
  <div class="stat"><div class="stat-label"><?= e(fmt_date($date, 'F')) ?> total</div><div class="stat-value"><?= (int) $month['present'] ?></div><div class="stat-note"><?= (int) $month['days'] ?> prayer day(s)</div></div>
  <div class="stat"><div class="stat-label">Average per day</div><div class="stat-value"><?= $month['days'] ? number_format($month['present'] / $month['days'], 1) : '0' ?></div><div class="stat-note">this month</div></div>
  <div class="stat"><div class="stat-label"><?= $year ?> total</div><div class="stat-value"><?= (int) $yearStats['present'] ?></div><div class="stat-note"><?= (int) $yearStats['days'] ?> prayer day(s)</div></div>
</div>
<div class="split">
  <div class="stack">
    <?php if (can('attendance.record')): ?>
    <form method="post" action="<?= url('/morning-prayer') ?>" class="card">
      <?= csrf_field() ?><input type="hidden" name="date" value="<?= e($date) ?>">
      <div class="card-header"><h2>Attendance sheet — <?= e(fmt_date($date, 'l, j F Y')) ?></h2><?= $session ? '<span class="code">' . e($session['session_code']) . '</span>' : badge('New', 'blue') ?></div>
      <?php if (!$canEdit): ?><div class="callout warn" style="margin:12px 16px 0"><?= icon('lock') ?><div>This sheet is older than <?= App\Controllers\AttendanceController::CORRECTION_WINDOW_HOURS ?> hours. New names can be added; changing saved marks requires correction permission.</div></div><?php endif; ?>
      <div class="filters">
        <div class="input-icon"><?= icon('search') ?><input type="search" placeholder="Find member…" data-filter-list="prayer-list"></div>
        <label class="muted small" for="session_time">Time</label><input id="session_time" type="time" name="session_time" value="<?= e($session['session_time'] ?? '05:00') ?>" style="width:auto">
      </div>
      <div id="prayer-list" style="max-height:520px;overflow-y:auto">
        <?php foreach ($members as $m): $isP = ($marks[$m['id']] ?? null) === 'present'; ?>
          <label class="mark-row check" data-text="<?= e(mb_strtolower(member_name($m) . ' ' . $m['member_code'])) ?>" style="grid-template-columns:auto 1fr auto;padding:8px 16px;border-bottom:1px solid var(--border)">
            <input type="hidden" name="shown[]" value="<?= (int) $m['id'] ?>">
            <input type="checkbox" name="present[]" value="<?= (int) $m['id'] ?>" <?= $isP ? 'checked' : '' ?>>
            <span><?= e(member_name($m, true)) ?> <span class="code muted"><?= e($m['member_code']) ?></span></span>
            <span><?= isset($marks[$m['id']]) ? status_badge($marks[$m['id']]) : '' ?></span>
          </label>
        <?php endforeach; ?>
        <?php if (!$members): ?><div class="empty small">No active members yet.</div><?php endif; ?>
      </div>
      <div class="sticky-bar"><span class="muted small">Ticked = present. Unticked members are saved as absent.</span><button class="btn btn-primary" type="submit"><?= icon('check') ?> Save morning prayer</button></div>
    </form>
    <?php endif; ?>
    <div class="card"><div class="card-header"><h2>Daily attendance — <?= e(fmt_date($date, 'F Y')) ?></h2></div><div class="card-body">
      <div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'labels' => array_map('strval', array_keys($daily)), 'series' => [['name' => 'Present', 'values' => array_values($daily), 'color' => '#1aa7c7']]]) ?>"></div>
    </div></div>
    <div class="card"><div class="card-header"><h2>Monthly attendance — <?= $year ?></h2></div><div class="card-body">
      <div class="chart" data-chart="<?= json_attr(['type' => 'line', 'labels' => Stats::monthLabels(), 'series' => [['name' => 'Present', 'values' => $monthly, 'color' => '#1aa7c7']]]) ?>"></div>
    </div></div>
  </div>
  <div class="stack">
    <div class="card"><div class="card-header"><h2>Most consistent — <?= $year ?></h2></div>
      <?php if (!$consistent): ?><div class="empty small">No morning prayer records yet.</div><?php else: ?>
      <table class="table table-compact"><tbody><?php foreach ($consistent as $i => $c): $rate = $yearStats['days'] ? round($c['present'] / $yearStats['days'] * 100) : 0; ?>
        <tr><td class="muted mono" style="width:24px"><?= $i + 1 ?></td><td><?= e(member_name($c)) ?><div class="progress" style="margin-top:4px"><span style="width:<?= $rate ?>%"></span></div></td><td class="num"><?= (int) $c['present'] ?><span class="sub"><?= $rate ?>%</span></td></tr>
      <?php endforeach; ?></tbody></table><?php endif; ?>
    </div>
    <div class="card"><div class="card-header"><h2>Recent days</h2></div>
      <?php if (!$history): ?><div class="empty small">Nothing recorded yet.</div><?php else: ?>
      <table class="table table-compact"><tbody><?php foreach ($history as $h): ?>
        <tr class="clickable" data-href="<?= url('/morning-prayer', ['date' => $h['session_date']]) ?>"><td><?= e(fmt_date($h['session_date'], 'D, j M Y')) ?></td><td class="num"><span class="text-green strong"><?= (int) $h['present'] ?></span> <span class="faint">/ <?= (int) $h['present'] + (int) $h['absent'] ?></span></td></tr>
      <?php endforeach; ?></tbody></table><?php endif; ?>
    </div>
  </div>
</div>
