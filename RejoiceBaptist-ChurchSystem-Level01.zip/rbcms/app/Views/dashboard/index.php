<?php use App\Services\Stats; $months = Stats::monthLabels(); $hour = (int) date('G');
$greet = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening'); $first = explode(' ', (string) (user()['full_name'] ?? ''))[0]; ?>
<div class="page-head">
  <div><h1><?= e($greet) ?>, <?= e($first) ?></h1><p><?= e(date('l, F j, Y')) ?> · <?= e(user()['role_name'] ?? '') ?></p></div>
  <div class="page-actions">
    <?php if (isset($w['attendance']) || isset($w['leader'])): ?><form method="get"><select name="year" data-autosubmit aria-label="Year"><?php foreach ($years as $y): ?><option <?= (int) $y === $year ? 'selected' : '' ?>><?= e($y) ?></option><?php endforeach; ?></select></form><?php endif; ?>
    <?php if (can('attendance.record')): ?><a class="btn" href="<?= url('/attendance/new') ?>"><?= icon('clipboard') ?> Record attendance</a><?php endif; ?>
    <?php if (can('members.manage')): ?><a class="btn btn-primary" href="<?= url('/members/new') ?>"><?= icon('plus') ?> Add member</a><?php elseif (can('music.manage')): ?><a class="btn btn-primary" href="<?= url('/music/new') ?>"><?= icon('plus') ?> New lineup</a><?php endif; ?>
  </div>
</div>

<?php if (isset($w['members']) || isset($w['attendance']) || isset($w['finance'])): ?>
<div class="stats mb">
  <?php if (isset($w['members'])): $m = $w['members']; ?>
    <a class="stat link" href="<?= url('/members') ?>"><div class="stat-label">Total members</div><div class="stat-value"><?= number_format($m['total']) ?></div><div class="stat-note"><?= $w['newMembers'] ?> joined this month</div></a>
    <a class="stat link" href="<?= url('/members', ['view' => 'active']) ?>"><div class="stat-label">Active</div><div class="stat-value"><?= number_format($m['active']) ?></div><div class="stat-note"><?= number_format($m['inactive']) ?> inactive</div></a>
    <a class="stat link" href="<?= url('/members', ['view' => 'baptized']) ?>"><div class="stat-label">Baptized</div><div class="stat-value"><?= number_format($m['baptized']) ?></div><div class="stat-note"><?= number_format($m['active_unbaptized']) ?> active, not yet baptized</div></a>
  <?php endif; ?>
  <?php if (isset($w['attendance'])): $a = $w['attendance']; ?>
    <a class="stat link" href="<?= $a['lastSunday'] ? url('/attendance/' . $a['lastSunday']['id']) : url('/attendance') ?>"><div class="stat-label">Last Sunday</div><div class="stat-value"><?= $a['lastSunday'] ? (int) $a['lastSunday']['present'] : '—' ?></div><div class="stat-note"><?= $a['lastSunday'] ? e(fmt_date($a['lastSunday']['session_date'], 'M j')) . ' · avg ' . $a['avgSunday'] . ' (3 mos)' : 'not recorded yet' ?></div></a>
  <?php endif; ?>
  <?php if (isset($w['finance'])): $f = $w['finance']; ?>
    <a class="stat link" href="<?= url('/finance') ?>"><div class="stat-label">Fund balance <?= icon('lock') ?></div><div class="stat-value"><?= e(money($f['balance'])) ?></div><div class="stat-note"><?= e(money($f['month']['income'])) ?> in · <?= e(money($f['month']['expense'])) ?> out this month</div></a>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="split-wide mb">
  <div class="stack">
    <?php if (isset($w['attendance'])): ?>
    <div class="card"><div class="card-header"><h2>Attendance by month — <?= $year ?></h2><a class="more" href="<?= url('/attendance', ['year' => $year]) ?>">Details <?= icon('arrow-right') ?></a></div><div class="card-body">
      <div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'labels' => $months, 'series' => [['name' => (string) ($year - 1), 'values' => $w['attendance']['prev'], 'color' => '#b8c0cc'], ['name' => (string) $year, 'values' => $w['attendance']['monthly']]]]) ?>"></div>
    </div></div>
    <div class="grid cols-2">
      <div class="card"><div class="card-header"><h2>Attendance by year</h2></div><div class="card-body"><div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'height' => 170, 'labels' => array_map('strval', array_keys($w['attendance']['yearly'])), 'series' => [['name' => 'Present', 'values' => array_values($w['attendance']['yearly']), 'color' => '#22a061']]]) ?>"></div></div></div>
      <div class="card"><div class="card-header"><h2>Recent attendance</h2><a class="more" href="<?= url('/attendance/sessions') ?>">All</a></div>
        <?php if (!$w['attendance']['recent']): ?><div class="empty small">Nothing recorded yet.</div><?php else: ?><table class="table table-compact"><tbody><?php foreach ($w['attendance']['recent'] as $s): ?><tr class="clickable" data-href="<?= url('/attendance/' . $s['id']) ?>"><td><?= e($s['title']) ?><span class="sub"><?= e(fmt_date($s['session_date'], 'D, M j')) ?></span></td><td class="num strong"><?= (int) $s['present'] ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></div>
    </div>
    <?php elseif (isset($w['leader'])): ?>
    <div class="card"><div class="card-header"><h2>My ministry attendance — <?= $year ?></h2></div><div class="card-body">
      <div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'labels' => $months, 'series' => [['name' => 'Present', 'values' => $w['leader']['monthly']]]]) ?>"></div>
      <div class="row mt" style="gap:8px;flex-wrap:wrap"><?php foreach ($w['leader']['ministries'] as $mi): ?><a class="btn btn-sm" href="<?= url('/ministries/' . $mi['id']) ?>"><?= e($mi['name']) ?></a><a class="btn btn-sm btn-primary" href="<?= url('/attendance/new', ['ministry' => $mi['id']]) ?>"><?= icon('clipboard') ?> Record</a><?php endforeach; ?></div>
    </div></div>
    <?php endif; ?>

    <?php if (isset($w['finance'])): ?>
    <div class="card"><div class="card-header"><h2>Income vs expenses — <?= $year ?> <?= badge('Confidential', 'red') ?></h2><a class="more" href="<?= url('/finance') ?>">Finance <?= icon('arrow-right') ?></a></div><div class="card-body">
      <div class="chart" data-chart="<?= json_attr(['type' => 'line', 'money' => true, 'height' => 200, 'labels' => $months, 'series' => [['name' => 'Income', 'values' => $w['finance']['monthly']['income'], 'color' => '#22a061'], ['name' => 'Expenses', 'values' => $w['finance']['monthly']['expense'], 'color' => '#d9423a']]]) ?>"></div>
    </div></div>
    <?php endif; ?>

    <?php if (isset($w['music'])): ?>
    <div class="grid cols-2">
      <div class="card"><div class="card-header"><h2>Recent lineups</h2><a class="more" href="<?= url('/music') ?>">All</a></div>
        <?php if (!$w['music']['recent']): ?><div class="empty small">No lineups yet.</div><?php else: ?><table class="table table-compact"><tbody><?php foreach ($w['music']['recent'] as $l): ?><tr class="clickable" data-href="<?= url('/music/' . $l['id']) ?>"><td><?= e(fmt_date($l['service_date'], 'D, M j')) ?><span class="sub"><?= e($l['service_title'] ?: App\Controllers\MusicController::SERVICE_TYPES[$l['service_type']]) ?></span></td><td class="small"><?= $l['first_name'] ? e($l['first_name'] . ' ' . $l['last_name']) : '—' ?><span class="sub"><?= (int) $l['songs'] ?> songs</span></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></div>
      <div class="card"><div class="card-header"><h2>Most lined-up songs — <?= $year ?></h2><a class="more" href="<?= url('/music/stats') ?>">Stats</a></div>
        <?php if (!$w['music']['top']): ?><div class="empty small">No data yet.</div><?php else: $max = max(array_column($w['music']['top'], 'uses')); ?><ul class="list"><?php foreach ($w['music']['top'] as $i => $s): ?><li><div class="row" style="justify-content:space-between"><span class="strong small"><?= $i + 1 ?>. <?= e($s['title']) ?></span><span class="num small"><?= (int) $s['uses'] ?>×</span></div><div class="progress" style="margin-top:5px"><span style="width:<?= round($s['uses'] / $max * 100) ?>%"></span></div></li><?php endforeach; ?></ul><?php endif; ?></div>
    </div>
    <?php endif; ?>
  </div>

  <div class="stack">
    <?php if (isset($w['upcoming'])): ?>
    <div class="card"><div class="card-header"><h2>Coming up</h2><a class="more" href="<?= url('/calendar') ?>">Calendar <?= icon('arrow-right') ?></a></div>
      <?php if (!$w['upcoming']): ?><div class="empty small">Nothing scheduled in the next two weeks.</div><?php else: ?>
      <ul class="list"><?php foreach ($w['upcoming'] as $i): ?><li><a class="list-item" href="<?= url($i['kind'] === 'ministry' ? '/ministries/' . $i['id'] : '/events/' . $i['id']) ?>" style="text-decoration:none">
        <span class="date-chip c-<?= e($i['color']) ?>"><span><?= e(fmt_date($i['date'], 'M')) ?></span><strong><?= e(fmt_date($i['date'], 'j')) ?></strong></span>
        <span class="grow"><span class="title"><?= e($i['title']) ?></span><span class="sub"><?= e(App\Services\Calendar::relative($i['date'])) ?> · <?= e(time_range($i['start_time'], $i['end_time'])) ?><?= $i['location'] ? ' · ' . e($i['location']) : '' ?></span></span></a></li><?php endforeach; ?></ul><?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if (isset($w['announcements'])): ?>
    <div class="card"><div class="card-header"><h2>Announcements</h2><a class="more" href="<?= url('/announcements') ?>">All</a></div>
      <?php if (!$w['announcements']): ?><div class="empty small">No announcements.</div><?php else: ?><ul class="list"><?php foreach ($w['announcements'] as $a): ?><li><a class="strong" href="<?= url('/announcements/' . $a['id']) ?>"><?= $a['is_pinned'] ? icon('pin') . ' ' : '' ?><?= e($a['title']) ?></a><span class="sub"><?= e(mb_strimwidth(preg_replace('/\s+/', ' ', $a['body']), 0, 100, '…')) ?></span><span class="sub faint"><?= e(time_ago($a['published_at'])) ?></span></li><?php endforeach; ?></ul><?php endif; ?></div>
    <?php endif; ?>
    <?php if (isset($w['ministries'])): ?>
    <div class="card"><div class="card-header"><h2>Ministries</h2><span class="muted small"><?= $w['ministryCount'] ?> active</span></div>
      <?php if (!$w['ministries']): ?><div class="empty small">No ministries yet.</div><?php else: ?><table class="table table-compact"><tbody><?php foreach ($w['ministries'] as $mi): ?><tr class="clickable" data-href="<?= url('/ministries/' . $mi['id']) ?>"><td><?= e($mi['name']) ?></td><td class="num muted"><?= (int) $mi['n'] ?> members</td></tr><?php endforeach; ?></tbody></table><?php endif; ?></div>
    <?php endif; ?>
    <?php if (!empty($w['documents'])): ?><a class="callout info" href="<?= url('/documents', ['tab' => 'draft']) ?>" style="text-decoration:none"><?= icon('file') ?><div><?= (int) $w['documents'] ?> document draft(s) waiting to be finalized.</div></a><?php endif; ?>
    <?php if (isset($w['activity'])): ?>
    <div class="card"><div class="card-header"><h2>Recent activity</h2><a class="more" href="<?= url('/audit') ?>">Audit log</a></div>
      <?php if (!$w['activity']): ?><div class="empty small">No activity yet.</div><?php else: ?><ul class="list"><?php foreach ($w['activity'] as $a): ?><li class="small"><strong><?= e($a['user_name'] ?: 'System') ?></strong> <?= e(str_replace('_', ' ', $a['action'])) ?> · <?= e($a['module']) ?><?= $a['record_label'] ? ' · ' . e(mb_strimwidth($a['record_label'], 0, 40, '…')) : '' ?><span class="sub faint"><?= e(time_ago($a['created_at'])) ?></span></li><?php endforeach; ?></ul><?php endif; ?></div>
    <?php endif; ?>
  </div>
</div>
