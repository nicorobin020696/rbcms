<?php use App\Core\View; ?>
<div class="page-head">
  <div><h1>Ministries</h1><p><?= can('ministries.view') ? 'Every ministry of the church, its leaders, members and weekly schedule.' : 'The ministries you lead.' ?></p></div>
  <div class="page-actions">
    <?php if (can('ministries.view')): ?><a class="btn" href="<?= url('/ministries/export.csv') ?>"><?= icon('download') ?> CSV</a><?php endif; ?>
    <?php if (can('ministries.manage')): ?><a class="btn btn-primary" href="<?= url('/ministries/new') ?>"><?= icon('plus') ?> Add ministry</a><?php endif; ?>
  </div>
</div>
<?php if ($stats): ?>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Ministries</div><div class="stat-value"><?= $stats['total'] ?></div><div class="stat-note"><?= $stats['active'] ?> active</div></div>
  <div class="stat"><div class="stat-label">Members serving</div><div class="stat-value"><?= $stats['assigned'] ?></div><div class="stat-note">in at least one ministry</div></div>
  <a class="stat" href="<?= url('/members', ['view' => 'no_ministry']) ?>"><div class="stat-label">Without a ministry</div><div class="stat-value"><?= $stats['unassigned'] ?></div><div class="stat-note">View list →</div></a>
</div>
<?php endif; ?>
<?php if ($ministries && can('ministries.view')): ?>
<div class="card mb"><div class="card-header"><h2>Members per ministry</h2></div><div class="card-body">
  <div class="chart" data-chart="<?= json_attr(['type' => 'hbar', 'labels' => array_column($ministries, 'name'), 'series' => [['name' => 'Members', 'values' => array_map('intval', array_column($ministries, 'member_count'))]]]) ?>"></div>
</div></div>
<?php endif; ?>
<div class="card">
  <form class="filters" method="get">
    <div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="Search ministry"></div>
    <select name="status" data-autosubmit><option value="">All statuses</option><option value="active" <?= query_str('status') === 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= query_str('status') === 'inactive' ? 'selected' : '' ?>>Inactive</option></select>
  </form>
  <?php if (!$ministries): ?>
    <?= View::partial('partials/empty', ['icon' => 'layers', 'title' => 'No ministries found', 'text' => can('ministries.view') ? 'Add the church ministries so members can be assigned to them.' : 'You are not assigned as leader of any ministry yet. Ask the secretary to set you as ministry leader and link your account to your member record.', 'action' => can('ministries.manage') ? ['Add ministry', url('/ministries/new')] : null]) ?>
  <?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Ministry</th><th>Leader</th><th>Schedule</th><th class="right">Members</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($ministries as $mi): ?>
      <tr class="clickable" data-href="<?= url('/ministries/' . $mi['id']) ?>">
        <td><a class="title-cell" href="<?= url('/ministries/' . $mi['id']) ?>"><?= e($mi['name']) ?></a><?= sample_tag($mi) ?><span class="sub"><span class="code"><?= e($mi['ministry_code']) ?></span><?= $mi['category'] ? ' · ' . e($mi['category']) : '' ?></span></td>
        <td><?= $mi['l_first'] ? e($mi['l_first'] . ' ' . $mi['l_last']) : '<span class="faint">Not assigned</span>' ?><?php if ($mi['a_first']): ?><span class="sub">Asst. <?= e($mi['a_first'] . ' ' . $mi['a_last']) ?></span><?php endif; ?></td>
        <td class="nowrap"><?= $mi['schedule_day'] !== null ? e(weekday_name((int) $mi['schedule_day'])) . '<span class="sub">' . e(time_range($mi['schedule_start'], $mi['schedule_end'])) . '</span>' : '<span class="faint">—</span>' ?></td>
        <td class="num"><?= (int) $mi['member_count'] ?></td>
        <td><?= status_badge($mi['status']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
  <?php endif; ?>
</div>
