<?php use App\Core\View; $leader = $mi['l_first'] ? trim($mi['l_first'] . ' ' . $mi['l_last']) : null; $asst = $mi['a_first'] ? trim($mi['a_first'] . ' ' . $mi['a_last']) : null; ?>
<div class="crumbs"><a href="<?= url('/ministries') ?>">Ministries</a> / <?= e($mi['ministry_code']) ?></div>
<div class="page-head">
  <div><h1><?= e($mi['name']) ?><?= sample_tag($mi) ?></h1><div class="row" style="margin-top:6px"><span class="code"><?= e($mi['ministry_code']) ?></span><?= status_badge($mi['status']) ?><?= $mi['category'] ? '<span class="tag">' . e($mi['category']) . '</span>' : '' ?></div></div>
  <div class="page-actions">
    <a class="btn" href="<?= url('/ministries/' . $mi['id'] . '/report.pdf') ?>" target="_blank"><?= icon('printer') ?> Ministry report</a>
    <?php if ($manage && (can('attendance.record') || App\Core\Auth::leads((int) $mi['id']))): ?><a class="btn" href="<?= url('/attendance/new', ['ministry' => $mi['id']]) ?>"><?= icon('clipboard') ?> Record attendance</a><?php endif; ?>
    <?php if (can('ministries.manage')): ?><form method="post" action="<?= url('/ministries/' . $mi['id'] . '/archive') ?>" data-confirm="Archive this ministry? It will be hidden from lists and the calendar. Member and attendance history is kept." data-danger data-confirm-ok="Archive"><?= csrf_field() ?><button class="btn" type="submit"><?= icon('archive') ?> Archive</button></form><?php endif; ?>
    <?php if ($manage): ?><a class="btn btn-primary" href="<?= url('/ministries/' . $mi['id'] . '/edit') ?>"><?= icon('pencil') ?> Edit</a><?php endif; ?>
  </div>
</div>
<div class="split">
  <div class="stack">
    <div class="card">
      <div class="card-header"><h2>Members</h2><span class="sub"><?= count($members) ?> assigned</span></div>
      <?php if ($manage && $available): ?>
      <form method="post" action="<?= url('/ministries/' . $mi['id'] . '/members') ?>" class="filters">
        <?= csrf_field() ?>
        <div style="flex:1;min-width:240px"><?= View::partial('partials/member_select', ['name' => 'member_ids[]', 'id' => 'add-member', 'members' => $available, 'placeholder' => 'Search a member to add…', 'emptyLabel' => 'Select member']) ?></div>
        <button class="btn" type="submit"><?= icon('plus') ?> Add to ministry</button>
      </form>
      <?php endif; ?>
      <?php if (!$members): ?><div class="empty small">No members assigned yet.</div><?php else: ?>
      <table class="table"><thead><tr><th>Member</th><th>Contact</th><th>Role</th><th>Since</th><?php if ($manage): ?><th></th><?php endif; ?></tr></thead><tbody>
        <?php foreach ($members as $m): $role = (int) $m['id'] === (int) $mi['leader_member_id'] ? 'Leader' : ((int) $m['id'] === (int) $mi['assistant_member_id'] ? 'Assistant' : ''); ?>
        <tr>
          <td><div class="person"><span class="avatar avatar-sm"><?= e(initials($m['first_name'] . ' ' . $m['last_name'])) ?></span><div><a href="<?= url('/members/' . $m['id']) ?>"><?= e(member_name($m, true)) ?></a><span class="sub code"><?= e($m['member_code']) ?></span></div></div></td>
          <td class="nowrap"><?= e($m['contact_number'] ?: '—') ?></td>
          <td><?= $role ? '<span class="tag">' . $role . '</span>' : '<span class="faint">Member</span>' ?></td>
          <td class="muted nowrap"><?= e(fmt_date($m['joined_on'])) ?></td>
          <?php if ($manage): ?><td class="actions"><?php if (!$role): ?><form method="post" action="<?= url('/ministries/' . $mi['id'] . '/members/remove') ?>" data-confirm="Remove <?= e(member_name($m)) ?> from <?= e($mi['name']) ?>?" data-confirm-ok="Remove" data-danger><?= csrf_field() ?><input type="hidden" name="member_id" value="<?= $m['id'] ?>"><button class="btn btn-ghost btn-xs" type="submit" title="Remove from ministry"><?= icon('x') ?></button></form><?php endif; ?></td><?php endif; ?>
        </tr>
        <?php endforeach; ?>
      </tbody></table><?php endif; ?>
    </div>
    <div class="card">
      <div class="card-header"><h2>Ministry attendance</h2><a class="more" href="<?= url('/attendance/sessions', ['ministry' => $mi['id']]) ?>">All records <?= icon('arrow-right') ?></a></div>
      <?php if (!$sessions): ?><div class="empty small">No ministry attendance recorded yet.</div><?php else: ?>
      <table class="table table-compact"><thead><tr><th>Date</th><th>Activity</th><th class="right">Present</th></tr></thead><tbody>
        <?php foreach ($sessions as $s): ?><tr class="clickable" data-href="<?= url('/attendance/' . $s['id']) ?>"><td class="nowrap"><?= e(fmt_date($s['session_date'], 'D, j M Y')) ?></td><td><?= e($s['title']) ?></td><td class="num"><?= (int) $s['present'] ?> / <?= (int) $s['total'] ?></td></tr><?php endforeach; ?>
      </tbody></table><?php endif; ?>
    </div>
  </div>
  <div class="stack">
    <div class="card"><div class="card-header"><h2>Details</h2></div><div class="card-body">
      <dl class="kv">
        <dt>Leader</dt><dd><?= $leader ? '<a href="' . url('/members/' . $mi['leader_member_id']) . '">' . e($leader) . '</a>' : '<span class="faint">Not assigned</span>' ?></dd>
        <dt>Assistant</dt><dd><?= $asst ? '<a href="' . url('/members/' . $mi['assistant_member_id']) . '">' . e($asst) . '</a>' : '<span class="faint">Not assigned</span>' ?></dd>
        <dt>Schedule</dt><dd><?= $mi['schedule_day'] !== null ? 'Every ' . e(weekday_name((int) $mi['schedule_day'])) . '<br><span class="muted">' . e(time_range($mi['schedule_start'], $mi['schedule_end'])) . '</span>' : '<span class="faint">No regular meeting</span>' ?><?= $mi['schedule_note'] ? '<br><span class="muted small">' . e($mi['schedule_note']) . '</span>' : '' ?></dd>
        <dt>Location</dt><dd><?= e($mi['schedule_location'] ?: '—') ?></dd>
        <dt>Contact</dt><dd><?= e($mi['contact_info'] ?: '—') ?></dd>
      </dl>
      <?php if ($mi['description']): ?><hr><div class="prose"><?= nl2p($mi['description']) ?></div><?php endif; ?>
    </div></div>
    <?php if ($upcoming): ?><div class="card"><div class="card-header"><h2>Upcoming activities</h2></div><ul class="list">
      <?php foreach ($upcoming as $u): ?><li><a href="<?= url('/events/' . $u['id']) ?>" class="strong"><?= e($u['title']) ?></a><div class="muted small"><?= e(fmt_date($u['start_date'], 'D, j M Y')) ?><?= $u['start_time'] ? ' · ' . e(fmt_time($u['start_time'])) : '' ?></div></li><?php endforeach; ?>
    </ul></div><?php endif; ?>
  </div>
</div>
