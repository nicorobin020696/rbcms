<?php $editing = !empty($mi['id']); $v = fn($k, $d = '') => old($k, $mi[$k] ?? $d); use App\Core\View; ?>
<div class="crumbs"><a href="<?= url('/ministries') ?>">Ministries</a> / <?= $editing ? e($mi['name']) : 'New ministry' ?></div>
<div class="page-head"><div><h1><?= $editing ? 'Edit ministry' : 'Add ministry' ?></h1><?php if (!$full): ?><p>As ministry leader you can update the description, schedule and contact details.</p><?php endif; ?></div></div>
<form method="post" action="<?= url($editing ? '/ministries/' . $mi['id'] : '/ministries') ?>" class="card" novalidate>
  <?= csrf_field() ?>
  <?php if ($full): ?>
  <div class="form-section">
    <h3>Ministry</h3><p class="muted">Name, category and leadership.</p>
    <div class="form-grid">
      <div class="field span-6"><label for="name">Ministry name<span class="req">*</span></label><input id="name" name="name" value="<?= e($v('name')) ?>" class="<?= has_error('name') ?>" required maxlength="120"><?= field_error('name') ?></div>
      <div class="field span-3"><label for="category_id">Category</label><select id="category_id" name="category_id"><option value="">—</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= (int) $v('category_id') === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
      <div class="field span-3"><label for="status">Status</label><select id="status" name="status"><option value="active" <?= $v('status', 'active') === 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= $v('status') === 'inactive' ? 'selected' : '' ?>>Inactive</option></select></div>
      <div class="field span-6"><label for="leader_member_id">Ministry leader</label><?= View::partial('partials/member_select', ['name' => 'leader_member_id', 'members' => $members, 'selected' => $v('leader_member_id'), 'class' => has_error('leader_member_id')]) ?><?= field_error('leader_member_id') ?><p class="help">Link the leader's user account to this member record so they can manage the ministry.</p></div>
      <div class="field span-6"><label for="assistant_member_id">Assistant leader</label><?= View::partial('partials/member_select', ['name' => 'assistant_member_id', 'members' => $members, 'selected' => $v('assistant_member_id'), 'class' => has_error('assistant_member_id')]) ?><?= field_error('assistant_member_id') ?></div>
    </div>
  </div>
  <?php endif; ?>
  <div class="form-section">
    <h3>Description</h3>
    <div class="field"><textarea name="description" rows="4" maxlength="3000" placeholder="Purpose and activities of the ministry"><?= e($v('description')) ?></textarea></div>
  </div>
  <div class="form-section">
    <h3>Weekly schedule</h3><p class="muted">When set, the meeting appears on the church calendar every week.</p>
    <div class="form-grid">
      <div class="field span-3"><label for="schedule_day">Meeting day</label><select id="schedule_day" name="schedule_day"><option value="">No regular meeting</option><?php for ($d = 0; $d < 7; $d++): ?><option value="<?= $d ?>" <?= $v('schedule_day') !== '' && $v('schedule_day') !== null && (int) $v('schedule_day') === $d ? 'selected' : '' ?>><?= weekday_name($d) ?></option><?php endfor; ?></select></div>
      <div class="field span-3"><label for="schedule_start">Start time</label><input id="schedule_start" type="time" name="schedule_start" value="<?= e($v('schedule_start')) ?>"></div>
      <div class="field span-3"><label for="schedule_end">End time</label><input id="schedule_end" type="time" name="schedule_end" value="<?= e($v('schedule_end')) ?>" class="<?= has_error('schedule_end') ?>"><?= field_error('schedule_end') ?></div>
      <div class="field span-3"><label for="schedule_location">Location</label><input id="schedule_location" name="schedule_location" value="<?= e($v('schedule_location')) ?>" placeholder="e.g. Main sanctuary"></div>
      <div class="field span-6"><label for="schedule_note">Schedule notes</label><input id="schedule_note" name="schedule_note" value="<?= e($v('schedule_note')) ?>" placeholder="e.g. Every 1st and 3rd week"></div>
      <div class="field span-6"><label for="contact_info">Contact information</label><input id="contact_info" name="contact_info" value="<?= e($v('contact_info')) ?>" placeholder="Phone or e-mail for inquiries"></div>
    </div>
  </div>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url($editing ? '/ministries/' . $mi['id'] : '/ministries') ?>">Cancel</a><button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Create ministry' ?></button></div>
</form>
