<?php use App\Controllers\DocumentsController as DC; ?>
<div class="crumbs"><a href="<?= url('/documents') ?>">Documents</a> / <?= e($d['doc_code']) ?></div>
<div class="page-head">
  <div><h1><?= e($d['title']) ?><?= sample_tag($d) ?></h1><div class="row" style="margin-top:6px"><span class="code"><?= e($d['doc_code']) ?></span><?= status_badge($d['status']) ?><?= $d['confidential'] ? badge('Confidential', 'red') : '' ?><span class="muted small"><?= e(DC::TYPES[$d['doc_type']] ?? '') ?></span></div></div>
  <div class="page-actions">
    <a class="btn" href="<?= url('/documents/' . $d['id'] . '/print') ?>" target="_blank"><?= icon('printer') ?> Print</a>
    <a class="btn" href="<?= url('/documents/' . $d['id'] . '/pdf') ?>" target="_blank"><?= icon('download') ?> PDF</a>
    <?php if (can('documents.create')): ?>
      <form method="post" action="<?= url('/documents/' . $d['id'] . '/duplicate') ?>"><?= csrf_field() ?><button class="btn" type="submit"><?= icon('copy') ?> Duplicate</button></form>
      <form method="post" action="<?= url('/documents/' . $d['id'] . '/archive') ?>" <?= $d['status'] !== 'archived' ? 'data-confirm="Archive this document?" data-confirm-ok="Archive"' : '' ?>><?= csrf_field() ?><button class="btn" type="submit"><?= icon($d['status'] === 'archived' ? 'refresh' : 'archive') ?> <?= $d['status'] === 'archived' ? 'Restore' : 'Archive' ?></button></form>
      <?php if ($d['status'] === 'draft'): ?><a class="btn btn-primary" href="<?= url('/documents/' . $d['id'] . '/edit') ?>"><?= icon('pencil') ?> Edit</a><?php endif; ?>
    <?php endif; ?>
  </div>
</div>
<?php if ($unresolved): ?><div class="callout warn mb"><?= icon('alert') ?><div>These placeholders have no value yet: <strong><?= e(implode(', ', $unresolved)) ?></strong>. Edit the draft to fill them in before printing.</div></div><?php endif; ?>
<div class="split-wide">
  <div class="paper-wrap"><?= App\Core\View::partial('documents/_paper', ['d' => $d, 'sigs' => $sigs]) ?></div>
  <div class="card"><div class="card-body"><dl class="kv">
    <dt>Recipient</dt><dd><?= e($d['recipient_name'] ?: '—') ?></dd>
    <?php if ($d['member_id']): ?><dt>Member</dt><dd><?= can('members.view') ? '<a href="' . url('/members/' . $d['member_id']) . '">' . e($d['m_first'] . ' ' . $d['m_last']) . '</a>' : e($d['m_first'] . ' ' . $d['m_last']) ?> <span class="code muted"><?= e($d['m_code']) ?></span></dd><?php endif; ?>
    <dt>Purpose</dt><dd><?= e($d['purpose'] ?: '—') ?></dd>
    <dt>Template</dt><dd><?= e($d['template_name'] ?: 'Blank') ?></dd>
    <dt>Prepared by</dt><dd class="small"><?= e($d['created_by_name'] ?: '—') ?><br><span class="muted"><?= e(fmt_datetime($d['created_at'])) ?></span></dd>
    <?php if ($d['updated_at'] !== $d['created_at']): ?><dt>Last updated</dt><dd class="small"><?= e($d['updated_by_name'] ?: '—') ?><br><span class="muted"><?= e(fmt_datetime($d['updated_at'])) ?></span></dd><?php endif; ?>
  </dl>
  <?php if ($d['status'] === 'final'): ?><p class="help mt"><?= icon('lock') ?> Final documents are locked. Use Duplicate to prepare a revised version.</p><?php endif; ?>
  </div></div>
</div>
