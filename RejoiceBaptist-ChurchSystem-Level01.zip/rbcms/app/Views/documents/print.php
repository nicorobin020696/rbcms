<div class="print-bar"><button class="btn btn-primary" type="button" data-print><?= icon('printer') ?> Print</button><button class="btn" type="button" data-back><?= icon('x') ?> Close</button></div>
<div class="paper-wrap" style="border-radius:0;min-height:100vh"><?= App\Core\View::partial('documents/_paper', ['d' => $d, 'sigs' => $sigs]) ?></div>
