<?php /** Sub-tabs for the Documents area. $active: 'create' or 'history'. */ $active = $active ?? ''; ?>
<div class="tabs">
  <?php if (can('documents.create')): ?><a href="<?= url('/documents/new') ?>" class="<?= $active === 'create' ? 'active' : '' ?>">Create document</a><?php endif; ?>
  <?php if (can('documents.view')): ?><a href="<?= url('/documents') ?>" class="<?= $active === 'history' ? 'active' : '' ?>">Document history</a><?php endif; ?>
  <?php if (can('documents.templates')): ?><a href="<?= url('/settings/templates') ?>">Templates</a><?php endif; ?>
</div>
