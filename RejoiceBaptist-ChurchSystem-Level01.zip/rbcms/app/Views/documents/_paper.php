<?php $logo = setting('church.logo') ? file_url(setting('church.logo')) : asset('img/logo.png'); $cert = (int) $d['is_certificate'] === 1;
$sub = array_filter([setting('church.address'), implode(' · ', array_filter([setting('church.phone'), setting('church.email')]))]); ?>
<div class="paper <?= $cert ? 'cert' : '' ?>">
  <?php if ($d['status'] === 'draft'): ?><div class="watermark">DRAFT</div><?php endif; ?>
  <?php if ($d['show_letterhead'] || $d['show_logo']): ?>
    <div class="lh" style="<?= $cert ? 'flex-direction:column;text-align:center;border-bottom:0' : '' ?>">
      <?php if ($d['show_logo']): ?><img src="<?= e($logo) ?>" alt=""><?php endif; ?>
      <?php if ($d['show_letterhead']): ?><div style="<?= $cert ? '' : 'flex:1;text-align:center;padding-right:' . ($d['show_logo'] ? '94px' : '0') ?>"><div class="lh-name"><?= e(setting('church.name', 'Rejoice Baptist Church')) ?></div><?php foreach ($sub as $s): ?><div class="lh-sub"><?= e($s) ?></div><?php endforeach; ?></div><?php endif; ?>
    </div>
  <?php endif; ?>
  <?php if ($cert): ?>
    <div class="doc-title" style="font-size:28px;margin:30px 0 40px"><?= e($d['title']) ?></div>
  <?php else: ?>
    <div class="doc-date"><?= e(fmt_date($d['doc_date'], 'F j, Y')) ?></div>
    <?php if ($d['recipient_name'] || $d['recipient_details']): ?><div class="doc-recipient" style="margin-bottom:22px"><?= $d['recipient_name'] ? '<strong>' . e($d['recipient_name']) . '</strong><br>' : '' ?><?= nl2br(e((string) $d['recipient_details'])) ?></div><?php endif; ?>
    <?php if ($d['title']): ?><div class="doc-title"><?= e($d['title']) ?></div><?php endif; ?>
  <?php endif; ?>
  <div class="doc-body"><?= $d['body_html'] /* sanitized by RichText on save */ ?></div>
  <?php if ($d['closing'] && !$cert): ?><div class="closing"><?= e($d['closing']) ?></div><?php endif; ?>
  <?php if ($d['show_signatures'] && $sigs): ?>
    <div class="sigs"><?php foreach ($sigs as $s): ?><div class="sig"><?php if ($s['signature_path']): ?><img src="<?= e(file_url($s['signature_path'])) ?>" alt=""><?php else: ?><div class="sig-space"></div><?php endif; ?><div class="sig-name"><?= e($s['name']) ?></div><div class="sig-pos"><?= e($s['position']) ?></div></div><?php endforeach; ?></div>
  <?php endif; ?>
  <div class="doc-ref"><span><?= e($d['doc_code'] ?? '') ?></span><span><?= $d['confidential'] ? 'CONFIDENTIAL' : '' ?></span></div>
</div>
