<?php use App\Controllers\DocumentsController as DC; ?>
<div class="page-head">
  <div><h1>Document generator</h1><p>Choose the kind of document. Each one opens in the editor with the church letterhead, logo and signatories ready.</p></div>
  <div class="page-actions"><?php if (can('documents.templates')): ?><a class="btn" href="<?= url('/settings/templates') ?>"><?= icon('sliders') ?> Manage templates</a><?php endif; ?><a class="btn" href="<?= url('/documents') ?>"><?= icon('folder') ?> Document records</a></div>
</div>
<?php $active = 'create'; include __DIR__ . '/_tabs.php'; ?>
<?php foreach (['Letters' => 0, 'Certificates' => 1] as $group => $isCert): $list = array_filter($templates, fn($t) => (int) $t['is_certificate'] === $isCert); if (!$list) continue; ?>
  <div class="section-label mb-sm"><?= $group ?></div>
  <div class="tpl-grid mb">
    <?php foreach ($list as $t): ?>
      <a class="tpl-card" href="<?= url('/documents/compose', array_filter(['template' => $t['id'], 'member' => $member ?: null])) ?>">
        <span class="tpl-icon"><?= icon($isCert ? 'shield' : 'file') ?></span>
        <strong><?= e($t['name']) ?></strong>
        <span class="small muted"><?= e(DC::TYPES[$t['doc_type']] ?? 'Other') ?><?= $t['confidential'] ? ' · ' . badge('Confidential', 'red') : '' ?></span>
        <span class="small faint"><?= e(mb_strimwidth(App\Services\RichText::toText($t['body_html']), 0, 110, '…')) ?></span>
      </a>
    <?php endforeach; ?>
  </div>
<?php endforeach; ?>
<a class="tpl-card blank mb" href="<?= url('/documents/compose', array_filter(['member' => $member ?: null])) ?>"><span class="tpl-icon"><?= icon('plus') ?></span><strong>Blank document</strong><span class="small muted">Start from an empty page</span></a>
<?php if ($recent): ?>
<div class="card mt"><div class="card-header"><h2>Your recent documents</h2></div><table class="table table-compact"><tbody>
  <?php foreach ($recent as $r): ?><tr class="clickable" data-href="<?= url('/documents/' . $r['id']) ?>"><td><span class="code"><?= e($r['doc_code']) ?></span></td><td><?= e($r['title']) ?></td><td class="muted"><?= e($r['recipient_name'] ?: '') ?></td><td><?= status_badge($r['status']) ?></td><td class="muted small right"><?= e(time_ago($r['updated_at'])) ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?>
