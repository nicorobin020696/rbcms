<?php use App\Controllers\DocumentsController as DC; use App\Services\DocumentRenderer as R;
$editing = !empty($d['id']); $v = fn($k, $def = '') => old($k, $d[$k] ?? $def); $chk = fn($k) => (int) $v($k, 0) === 1 ? 'checked' : ''; ?>
<div class="crumbs"><a href="<?= url('/documents') ?>">Documents</a> / <?= $editing ? e($d['doc_code']) : '<a href="' . url('/documents/new') . '">Generator</a> / Compose' ?></div>
<div class="page-head"><div><h1><?= e($title) ?></h1><p>Placeholders such as <code>{{recipient_name}}</code> are filled in automatically when you save.</p></div></div>
<form method="post" action="<?= url($editing ? '/documents/' . $d['id'] : '/documents') ?>" novalidate data-rte-form>
  <?= csrf_field() ?>
  <input type="hidden" name="template_id" value="<?= (int) ($d['template_id'] ?? 0) ?: '' ?>">
  <div class="doc-editor">
    <div class="stack">
      <div class="card"><div class="card-body"><div class="form-grid">
        <div class="field span-8"><label for="title">Document title<span class="req">*</span></label><input id="title" name="title" value="<?= e($v('title')) ?>" maxlength="150" class="<?= has_error('title') ?>" required><?= field_error('title') ?></div>
        <div class="field span-4"><label for="doc_date">Date<span class="req">*</span></label><input id="doc_date" type="date" name="doc_date" value="<?= e($v('doc_date', today())) ?>" class="<?= has_error('doc_date') ?>" required><?= field_error('doc_date') ?></div>
        <div class="field span-6"><label for="member_id">Member <span class="muted">(optional — fills member details)</span></label><?= App\Core\View::partial('partials/member_select', ['name' => 'member_id', 'members' => $members, 'selected' => $v('member_id'), 'emptyLabel' => '— Not a member / none —']) ?></div>
        <div class="field span-6"><label for="recipient_name">Recipient name</label><input id="recipient_name" name="recipient_name" value="<?= e($v('recipient_name')) ?>" maxlength="150" placeholder="Defaults to the member's name"></div>
        <div class="field span-6"><label for="recipient_details">Recipient position / address <span class="muted">(letters)</span></label><textarea id="recipient_details" name="recipient_details" rows="2" maxlength="500" placeholder="e.g. Principal&#10;San Isidro National High School"><?= e($v('recipient_details')) ?></textarea></div>
        <div class="field span-6"><label for="purpose">Purpose</label><textarea id="purpose" name="purpose" rows="2" maxlength="300" placeholder="Fills {{purpose}}, e.g. scholarship application"><?= e($v('purpose')) ?></textarea></div>
      </div></div></div>
      <div>
        <div class="rte-toolbar" role="toolbar" aria-label="Formatting">
          <button type="button" data-cmd="bold" title="Bold (Ctrl+B)"><b>B</b></button><button type="button" data-cmd="italic" title="Italic (Ctrl+I)"><i>I</i></button><button type="button" data-cmd="underline" title="Underline (Ctrl+U)"><u>U</u></button>
          <span class="sep"></span><button type="button" data-cmd="justifyLeft" title="Align left">⯇</button><button type="button" data-cmd="justifyCenter" title="Center">≡</button><button type="button" data-cmd="justifyRight" title="Align right">⯈</button><button type="button" data-cmd="justifyFull" title="Justify">☰</button>
          <span class="sep"></span><button type="button" data-cmd="insertUnorderedList" title="Bulleted list">• List</button><button type="button" data-cmd="insertOrderedList" title="Numbered list">1. List</button>
          <span class="sep"></span><button type="button" data-cmd="removeFormat" title="Clear formatting">Clear</button><button type="button" data-cmd="undo" title="Undo">↶</button><button type="button" data-cmd="redo" title="Redo">↷</button>
        </div>
        <div class="rte" contenteditable="true" data-rte spellcheck="true" aria-label="Document body"><?= App\Services\RichText::sanitize((string) $v('body_html')) ?></div>
        <textarea name="body_html" class="hidden" data-rte-input></textarea>
        <?= field_error('body_html') ?>
      </div>
      <div class="card"><div class="card-body"><div class="form-grid">
        <div class="field span-6"><label for="closing">Closing <span class="muted">(letters)</span></label><input id="closing" name="closing" value="<?= e($v('closing')) ?>" maxlength="100" placeholder="e.g. Sincerely yours,"></div>
        <div class="field span-6"><label for="doc_type">Document type</label><select id="doc_type" name="doc_type"><?php foreach (DC::TYPES as $k => $l): ?><option value="<?= $k ?>" <?= $v('doc_type') === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
      </div></div></div>
    </div>
    <div class="stack" style="position:sticky;top:76px">
      <div class="card"><div class="card-header"><h2>Layout</h2></div><div class="card-body stack-sm">
        <label class="check"><input type="checkbox" name="show_logo" value="1" <?= $chk('show_logo') ?>> Church logo</label>
        <label class="check"><input type="checkbox" name="show_letterhead" value="1" <?= $chk('show_letterhead') ?>> Letterhead (name, address)</label>
        <label class="check"><input type="checkbox" name="show_signatures" value="1" <?= $chk('show_signatures') ?>> Signature block</label>
        <label class="check"><input type="checkbox" name="is_certificate" value="1" <?= $chk('is_certificate') ?>> Certificate layout (centered)</label>
        <?php if (can('documents.confidential')): ?><label class="check"><input type="checkbox" name="confidential" value="1" <?= $chk('confidential') ?>> <span>Confidential <span class="muted small">— only users with confidential access can see it</span></span></label><?php endif; ?>
      </div></div>
      <div class="card"><div class="card-header"><h2>Signatories</h2><?php if (can('documents.templates')): ?><a class="more" href="<?= url('/settings/signatories') ?>">Manage</a><?php endif; ?></div><div class="card-body stack-sm">
        <?php if (!$signatories): ?><p class="muted small">No signatories yet. <?= can('documents.templates') ? 'Add the pastor and church secretary under Settings › Signatories.' : 'Ask an administrator to add them.' ?></p><?php endif; ?>
        <?php foreach ($signatories as $s): ?><label class="check"><input type="checkbox" name="signatories[]" value="<?= $s['id'] ?>" <?= in_array((int) $s['id'], $sigIds, true) ? 'checked' : '' ?>> <span><?= e($s['name']) ?><span class="sub"><?= e($s['position']) ?><?= $s['signature_path'] ? ' · e-signature' : '' ?></span></span></label><?php endforeach; ?>
        <?= field_error('signatories') ?>
      </div></div>
      <div class="card"><div class="card-header"><h2>Placeholders</h2></div><div class="card-body"><p class="small muted" style="margin-top:0">Click to insert at the cursor.</p>
        <div class="placeholder-list"><?php foreach (R::PLACEHOLDERS as $k => $l): ?><code data-insert="<?= e($k) ?>" title="<?= e($l) ?>"><?= e($k) ?></code><?php endforeach; ?></div></div></div>
      <div class="card"><div class="card-body stack-sm">
        <label class="check"><input type="radio" name="status" value="draft" <?= $v('status', 'draft') !== 'final' ? 'checked' : '' ?>> Save as draft <span class="muted small">— can still be edited</span></label>
        <label class="check"><input type="radio" name="status" value="final" <?= $v('status') === 'final' ? 'checked' : '' ?>> Finalize <span class="muted small">— locks the document</span></label>
        <div class="row mt-sm" style="justify-content:flex-end"><a class="btn btn-ghost" href="<?= url($editing ? '/documents/' . $d['id'] : '/documents/new') ?>">Cancel</a><button class="btn btn-primary" type="submit">Save document</button></div>
      </div></div>
    </div>
  </div>
</form>
