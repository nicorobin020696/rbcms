<?php $editing = !empty($e['id']); $v = fn($k, $d = '') => old($k, $e[$k] ?? $d); $isActivity = (int) $v('is_activity', 1) === 1; ?>
<div class="crumbs"><a href="<?= url($isActivity ? '/events' : '/calendar') ?>"><?= $isActivity ? 'Events' : 'Calendar' ?></a> / <?= $editing ? e($e['title']) : 'New' ?></div>
<div class="page-head"><div><h1><?= e($title) ?></h1><p><?= $isActivity ? 'Events are listed under Events & Activities and shown on the calendar.' : 'Schedules appear on the calendar only — use them for regular services, prayer meetings and other meetings.' ?></p></div></div>
<?php if ($conflicts): ?>
<div class="callout warn mb"><?= icon('alert') ?><div><strong>Overlapping schedule.</strong> On this date the following are already scheduled at an overlapping time:
  <ul style="margin:6px 0 0;padding-left:18px"><?php foreach ($conflicts as $c): ?><li><?= e($c['title']) ?> — <?= e(time_range($c['start_time'], $c['end_time'])) ?> <span class="muted">(<?= e($c['category']) ?>)</span></li><?php endforeach; ?></ul></div></div>
<?php endif; ?>
<form method="post" action="<?= url($editing ? '/events/' . $e['id'] : '/events') ?>" enctype="multipart/form-data" class="card" novalidate data-event-form data-event-id="<?= (int) ($e['id'] ?? 0) ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="is_activity" value="<?= $isActivity ? '1' : '0' ?>">
  <div class="form-section">
    <div class="form-grid">
      <div class="field span-8"><label for="title">Title<span class="req">*</span></label><input id="title" name="title" value="<?= e($v('title')) ?>" class="<?= has_error('title') ?>" required maxlength="150" placeholder="<?= $isActivity ? 'e.g. Youth Jam 2026' : 'e.g. Sunday Worship Service' ?>"><?= field_error('title') ?></div>
      <div class="field span-4"><label for="category_id">Category</label><select id="category_id" name="category_id"><option value="">—</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= (int) $v('category_id') === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
      <div class="field span-12"><label for="description">Description</label><textarea id="description" name="description" rows="4" maxlength="5000"><?= e($v('description')) ?></textarea></div>
    </div>
  </div>
  <div class="form-section">
    <h3>Date &amp; time</h3><p class="muted">Leave the time empty for whole-day activities.</p>
    <div class="form-grid">
      <div class="field span-3"><label for="start_date">Date<span class="req">*</span></label><input id="start_date" type="date" name="start_date" value="<?= e($v('start_date')) ?>" class="<?= has_error('start_date') ?>" required><?= field_error('start_date') ?></div>
      <div class="field span-3"><label for="start_time">Start time</label><input id="start_time" type="time" name="start_time" value="<?= e($v('start_time')) ?>"></div>
      <div class="field span-3"><label for="end_time">End time</label><input id="end_time" type="time" name="end_time" value="<?= e($v('end_time')) ?>" class="<?= has_error('end_time') ?>"><?= field_error('end_time') ?></div>
      <div class="field span-3"><label for="recurrence">Repeats</label><select id="recurrence" name="recurrence"><option value="none" <?= $v('recurrence', 'none') === 'none' ? 'selected' : '' ?>>Does not repeat</option><option value="weekly" <?= $v('recurrence') === 'weekly' ? 'selected' : '' ?>>Every week</option></select></div>
      <div class="field span-3" data-show-when="none"><label for="end_date">End date <span class="muted">(multi-day)</span></label><input id="end_date" type="date" name="end_date" value="<?= e($v('end_date')) ?>" class="<?= has_error('end_date') ?>"><?= field_error('end_date') ?></div>
      <div class="field span-3" data-show-when="weekly"><label for="recur_until">Repeat until <span class="muted">(optional)</span></label><input id="recur_until" type="date" name="recur_until" value="<?= e($v('recur_until')) ?>" class="<?= has_error('recur_until') ?>"><?= field_error('recur_until') ?></div>
      <div class="field span-6"><label for="location">Location</label><input id="location" name="location" value="<?= e($v('location')) ?>" maxlength="150" placeholder="e.g. Church sanctuary"></div>
      <div class="field span-6"><label for="ministry_id">Organizing ministry</label><select id="ministry_id" name="ministry_id"><option value="">—</option><?php foreach ($ministries as $m): ?><option value="<?= $m['id'] ?>" <?= (int) $v('ministry_id') === (int) $m['id'] ? 'selected' : '' ?>><?= e($m['name']) ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="callout warn mt hidden" data-overlap-box><?= icon('alert') ?><div data-overlap-text></div></div>
    <?php if ($conflicts): ?><label class="check mt"><input type="checkbox" name="confirm_overlap" value="1"> I understand the overlap and want to save this schedule anyway.</label><?= field_error('confirm_overlap') ?><?php endif; ?>
  </div>
  <?php if ($isActivity): ?>
  <div class="form-section">
    <h3>Poster or image</h3>
    <div class="form-grid">
      <div class="field span-12">
        <?= App\Core\View::partial('partials/image_field', ['img_name' => 'poster', 'img_current' => $e['poster_path'] ?? null, 'img_remove' => 'remove_poster', 'img_variant' => 'wide', 'img_label' => 'poster', 'img_empty' => 'No poster']) ?>
      </div>
    </div>
  </div>
  <?php endif; ?>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url($editing ? '/events/' . $e['id'] : ($isActivity ? '/events' : '/calendar')) ?>">Cancel</a><button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Save' ?></button></div>
</form>
