<?php use App\Core\View; ?>
<div class="page-head">
  <div><h1>Events &amp; activities</h1><p>Youth Jam, Sunday School, VBS, Fun Run, Family Day, anniversaries, Night of Worship and other church activities.</p></div>
  <div class="page-actions">
    <a class="btn" href="<?= url('/calendar') ?>"><?= icon('calendar') ?> Calendar</a>
    <?php if (can('events.manage')): ?><a class="btn btn-primary" href="<?= url('/events/new') ?>"><?= icon('plus') ?> New event</a><?php endif; ?>
  </div>
</div>
<div class="tabs">
  <?php foreach (['upcoming' => 'Upcoming', 'past' => 'Past events', 'cancelled' => 'Cancelled', 'archived' => 'Archived'] as $k => $l): ?>
    <a href="<?= url('/events', ['tab' => $k === 'upcoming' ? null : $k]) ?>" class="<?= $tab === $k ? 'active' : '' ?>"><?= $l ?><span class="count"><?= $counts[$k] ?? 0 ?></span></a>
  <?php endforeach; ?>
</div>
<div class="card">
  <form class="filters" method="get">
    <?php if ($tab !== 'upcoming'): ?><input type="hidden" name="tab" value="<?= e($tab) ?>"><?php endif; ?>
    <div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="Search title, location or ID"></div>
    <select name="category" data-autosubmit><option value="">All categories</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= input_int('category') === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
    <?php if ($years): ?><select name="year" data-autosubmit><option value="">Any year</option><?php foreach ($years as $y): ?><option <?= (string) input_int('year') === $y ? 'selected' : '' ?>><?= e($y) ?></option><?php endforeach; ?></select><?php endif; ?>
  </form>
  <?php if (!$events): ?>
    <?= View::partial('partials/empty', ['icon' => 'flag', 'title' => 'No events here', 'text' => $tab === 'upcoming' ? 'There are no upcoming events. Add one so it appears on the calendar.' : 'Nothing matches this view.', 'action' => can('events.manage') && $tab === 'upcoming' ? ['New event', url('/events/new')] : null]) ?>
  <?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th style="width:64px"></th><th>Event</th><th>Date &amp; time</th><th>Location</th><th>Status</th></tr></thead>
    <tbody><?php foreach ($events as $ev): ?>
      <tr class="clickable" data-href="<?= url('/events/' . $ev['id']) ?>">
        <td><?php if ($ev['poster_path']): ?><img class="thumb-sm" src="<?= e(file_url($ev['poster_path'])) ?>" alt="" loading="lazy"><?php else: ?><span class="avatar" style="width:52px;height:36px"><span class="cat-dot c-<?= e($ev['color'] ?? 'slate') ?>" style="margin:0"></span></span><?php endif; ?></td>
        <td><a class="title-cell" href="<?= url('/events/' . $ev['id']) ?>"><?= e($ev['title']) ?></a><?= sample_tag($ev) ?><span class="sub"><span class="cat-dot c-<?= e($ev['color'] ?? 'slate') ?>"></span><?= e($ev['category'] ?? 'Uncategorized') ?><?= $ev['ministry'] ? ' · ' . e($ev['ministry']) : '' ?></span></td>
        <td class="nowrap"><?= e(fmt_date($ev['start_date'], 'D, j M Y')) ?><?= $ev['end_date'] ? ' – ' . e(fmt_date($ev['end_date'], 'j M')) : '' ?><span class="sub"><?= $ev['recurrence'] === 'weekly' ? 'Every ' . e(fmt_date($ev['start_date'], 'l')) . ' · ' : '' ?><?= e(time_range($ev['start_time'], $ev['end_time'])) ?></span></td>
        <td><?= e($ev['location'] ?: '—') ?></td>
        <td><?= status_badge($ev['status']) ?></td>
      </tr>
    <?php endforeach; ?></tbody></table></div>
  <?= View::partial('partials/pagination', ['p' => $p]) ?>
  <?php endif; ?>
</div>
