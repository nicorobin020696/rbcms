<div class="crumbs"><a href="<?= url($e['is_activity'] ? '/events' : '/calendar') ?>"><?= $e['is_activity'] ? 'Events' : 'Calendar' ?></a> / <?= e($e['event_code']) ?></div>
<div class="page-head">
  <div><h1><?= e($e['title']) ?><?= sample_tag($e) ?></h1><div class="row" style="margin-top:6px"><span class="code"><?= e($e['event_code']) ?></span><?= status_badge($e['status']) ?><?php if ($e['category']): ?><span class="tag"><span class="cat-dot c-<?= e($e['color']) ?>"></span><?= e($e['category']) ?></span><?php endif; ?><?= $e['archived_at'] ? badge('Archived', 'neutral') : '' ?></div></div>
  <div class="page-actions">
    <?php if ($canManage): ?>
      <?php if ($e['archived_at']): ?>
        <form method="post" action="<?= url('/events/' . $e['id'] . '/restore') ?>"><?= csrf_field() ?><button class="btn" type="submit"><?= icon('refresh') ?> Restore</button></form>
      <?php else: ?>
        <?php if ($e['cancelled_at']): ?>
          <form method="post" action="<?= url('/events/' . $e['id'] . '/cancel') ?>"><?= csrf_field() ?><button class="btn" type="submit"><?= icon('refresh') ?> Undo cancellation</button></form>
        <?php else: ?>
          <button class="btn" type="button" data-open-modal="cancel-modal"><?= icon('x') ?> Cancel event</button>
        <?php endif; ?>
        <form method="post" action="<?= url('/events/' . $e['id'] . '/archive') ?>" data-confirm="Archive this <?= $e['is_activity'] ? 'event' : 'schedule' ?>? It will be removed from the calendar but kept in the archive." data-confirm-ok="Archive" data-danger><?= csrf_field() ?><button class="btn" type="submit"><?= icon('archive') ?> Archive</button></form>
        <a class="btn btn-primary" href="<?= url('/events/' . $e['id'] . '/edit') ?>"><?= icon('pencil') ?> Edit</a>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>
<?php if ($e['cancelled_at']): ?><div class="callout danger mb"><?= icon('alert') ?><div>This activity was cancelled on <?= e(fmt_datetime($e['cancelled_at'])) ?><?= $e['cancel_reason'] ? ': ' . e($e['cancel_reason']) : '.' ?></div></div><?php endif; ?>
<div class="split">
  <div class="stack">
    <?php if ($e['poster_path']): ?><div class="photo-frame"><img src="<?= e(file_url($e['poster_path'])) ?>" alt="Event poster"></div><?php endif; ?>
    <div class="card"><div class="card-header"><h2>About this <?= $e['is_activity'] ? 'event' : 'schedule' ?></h2></div><div class="card-body prose"><?= $e['description'] ? nl2p($e['description']) : '<p class="not-set">No description.</p>' ?></div></div>
    <?php if ($sessions || (can('attendance.record') && $e['is_activity'])): ?>
    <div class="card"><div class="card-header"><h2>Attendance</h2><?php if (can('attendance.record') && !$e['cancelled_at']): ?><a class="btn btn-sm" href="<?= url('/attendance/new', ['event' => $e['id']]) ?>"><?= icon('plus') ?> Record attendance</a><?php endif; ?></div>
      <?php if (!$sessions): ?><div class="empty small">No attendance linked to this event yet.</div><?php else: ?>
      <table class="table table-compact"><tbody><?php foreach ($sessions as $s): ?><tr class="clickable" data-href="<?= url('/attendance/' . $s['id']) ?>"><td><?= e(fmt_date($s['session_date'])) ?></td><td><?= e($s['title']) ?></td><td class="num"><?= (int) $s['present'] ?> present</td></tr><?php endforeach; ?></tbody></table><?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
  <div class="stack">
    <div class="card"><div class="card-body">
      <dl class="kv">
        <dt>Date</dt><dd><?php if ($e['recurrence'] === 'weekly'): ?>Every <?= e(fmt_date($e['start_date'], 'l')) ?><br><span class="muted small">from <?= e(fmt_date($e['start_date'])) ?><?= $e['recur_until'] ? ' until ' . e(fmt_date($e['recur_until'])) : '' ?></span><?php else: ?><?= e(fmt_date($e['start_date'], 'l, j F Y')) ?><?= $e['end_date'] ? '<br>to ' . e(fmt_date($e['end_date'], 'l, j F Y')) : '' ?><?php endif; ?></dd>
        <dt>Time</dt><dd><?= e(time_range($e['start_time'], $e['end_time'])) ?></dd>
        <dt>Location</dt><dd><?= e($e['location'] ?: '—') ?></dd>
        <dt>Ministry</dt><dd><?= e($e['ministry'] ?: '—') ?></dd>
        <dt>Created</dt><dd class="small"><?= e($e['created_by_name'] ?: '—') ?><br><span class="muted"><?= e(fmt_datetime($e['created_at'])) ?></span></dd>
        <?php if ($e['updated_at'] !== $e['created_at']): ?><dt>Last updated</dt><dd class="small"><?= e($e['updated_by_name'] ?: '—') ?><br><span class="muted"><?= e(fmt_datetime($e['updated_at'])) ?></span></dd><?php endif; ?>
      </dl>
    </div></div>
    <?php if ($next): ?><div class="card"><div class="card-header"><h2>Next dates</h2></div><ul class="list"><?php foreach ($next as $d): ?><li><a href="<?= url('/calendar', ['view' => 'day', 'date' => $d]) ?>"><?= e(fmt_date($d, 'l, j F Y')) ?></a></li><?php endforeach; ?></ul></div><?php endif; ?>
  </div>
</div>
<?php if ($canManage && !$e['cancelled_at']): ?>
<dialog class="modal" id="cancel-modal"><form method="post" action="<?= url('/events/' . $e['id'] . '/cancel') ?>"><?= csrf_field() ?>
  <div class="modal-head"><h2>Cancel “<?= e($e['title']) ?>”?</h2><button class="icon-btn" type="button" data-close-modal><?= icon('x') ?></button></div>
  <div class="modal-body"><p>The event stays on the calendar marked as cancelled, and users are notified.</p><div class="field"><label for="reason">Reason <span class="muted">(optional)</span></label><input id="reason" name="reason" maxlength="250"></div></div>
  <div class="modal-foot"><button class="btn" type="button" data-close-modal>Keep event</button><button class="btn btn-danger solid" type="submit">Cancel event</button></div>
</form></dialog>
<?php endif; ?>
