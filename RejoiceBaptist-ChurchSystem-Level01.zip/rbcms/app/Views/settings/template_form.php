<?php use App\Controllers\DocumentsController as DC; use App\Services\DocumentRenderer as R; $editing = !empty($t['id']); $v = fn($k, $d = '') => old($k, $t[$k] ?? $d); $chk = fn($k) => (int) $v($k, 0) ? 'checked' : ''; ?>
<div class="crumbs"><a href="<?= url('/settings/templates') ?>">Templates</a> / <?= $editing ? e($t['name']) : 'New' ?></div>
<div class="page-head"><div><h1><?= e($title) ?></h1></div></div>
<form method="post" action="<?= url($editing ? '/settings/templates/' . $t['id'] : '/settings/templates') ?>" novalidate>
  <?= csrf_field() ?>
  <div class="doc-editor">
    <div class="stack">
      <div class="card"><div class="card-body"><div class="form-grid">
        <div class="field span-6"><label for="name">Template name<span class="req">*</span></label><input id="name" name="name" value="<?= e($v('name')) ?>" maxlength="100" class="<?= has_error('name') ?>"><?= field_error('name') ?></div>
        <div class="field span-6"><label for="title">Printed title<span class="req">*</span></label><input id="title" name="title" value="<?= e($v('title')) ?>" maxlength="150" class="<?= has_error('title') ?>"><?= field_error('title') ?></div>
        <div class="field span-6"><label for="doc_type">Type</label><select id="doc_type" name="doc_type"><?php foreach (DC::TYPES as $k => $l): ?><option value="<?= $k ?>" <?= $v('doc_type') === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
        <div class="field span-6"><label for="closing">Closing</label><input id="closing" name="closing" value="<?= e($v('closing')) ?>" maxlength="100"></div>
      </div></div></div>
      <div>
        <div class="rte-toolbar"><button type="button" data-cmd="bold"><b>B</b></button><button type="button" data-cmd="italic"><i>I</i></button><button type="button" data-cmd="underline"><u>U</u></button><span class="sep"></span><button type="button" data-cmd="justifyLeft">⯇</button><button type="button" data-cmd="justifyCenter">≡</button><button type="button" data-cmd="justifyFull">☰</button><span class="sep"></span><button type="button" data-cmd="insertUnorderedList">• List</button><button type="button" data-cmd="insertOrderedList">1. List</button></div>
        <div class="rte" contenteditable="true" data-rte><?= App\Services\RichText::sanitize((string) $v('body_html')) ?></div>
        <textarea name="body_html" class="hidden" data-rte-input></textarea><?= field_error('body_html') ?>
      </div>
    </div>
    <div class="stack">
      <div class="card"><div class="card-body stack-sm">
        <label class="check"><input type="checkbox" name="is_certificate" value="1" <?= $chk('is_certificate') ?>> Certificate layout</label>
        <label class="check"><input type="checkbox" name="confidential" value="1" <?= $chk('confidential') ?>> Confidential by default</label>
        <label class="check"><input type="checkbox" name="is_active" value="1" <?= $chk('is_active') ?>> Show in the document generator</label>
      </div></div>
      <div class="card"><div class="card-header"><h2>Placeholders</h2></div><div class="card-body"><div class="placeholder-list"><?php foreach (R::PLACEHOLDERS as $k => $l): ?><code data-insert="<?= e($k) ?>" title="<?= e($l) ?>"><?= e($k) ?></code><?php endforeach; ?></div></div></div>
      <div class="row" style="justify-content:flex-end"><a class="btn btn-ghost" href="<?= url('/settings/templates') ?>">Cancel</a><button class="btn btn-primary" type="submit">Save template</button></div>
    </div>
  </div>
</form>
