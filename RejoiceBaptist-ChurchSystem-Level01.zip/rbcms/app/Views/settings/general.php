<?php $g = fn($k, $d = '') => old(str_replace(['ids.', 'security.', 'backup.', 'app.'], '', $k), $s[$k] ?? $d); $logo = setting('church.logo') ? file_url(setting('church.logo')) : asset('img/logo-128.png'); ?>
<div class="page-head"><div><h1>Settings</h1><p>System-wide options. Church details (name, address, history, mission) are edited under <a href="<?= url('/church/edit') ?>">Church Information</a>.</p></div></div>
<?php include __DIR__ . '/_nav.php'; ?>
<div class="grid cols-2">
  <form method="post" action="<?= url('/settings/general') ?>" enctype="multipart/form-data" class="card" id="branding"><?= csrf_field() ?><input type="hidden" name="section" value="branding">
    <div class="card-header"><h2>Church logo</h2></div>
    <div class="card-body">
      <?= App\Core\View::partial('partials/image_field', ['img_name' => 'logo', 'img_current' => setting('church.logo') ?: null, 'img_remove' => 'remove_logo', 'img_variant' => 'logo', 'img_label' => 'logo', 'img_fallback' => asset('img/logo-128.png'), 'img_empty' => 'Default logo', 'img_accept' => 'image/png,image/jpeg,image/webp', 'img_help' => 'Used on the sign-in page, sidebar, letters, certificates and PDF reports. Square PNG with transparent background works best.']) ?>
    </div>
    <div class="card-footer"><button class="btn btn-primary" type="submit">Save logo</button></div>
  </form>
  <form method="post" action="<?= url('/settings/general') ?>" class="card" id="ids"><?= csrf_field() ?><input type="hidden" name="section" value="ids">
    <div class="card-header"><h2>Member ID format</h2><span class="code" title="Next IDs look like this"><?= e(App\Controllers\SettingsController::idPreview()) ?></span></div>
    <div class="card-body"><div class="form-grid">
      <div class="field span-4"><label for="member_prefix">Prefix</label><input id="member_prefix" name="member_prefix" value="<?= e($g('ids.member_prefix', 'RBC')) ?>" maxlength="10" class="mono <?= has_error('member_prefix') ?>"><?= field_error('member_prefix') ?></div>
      <div class="field span-4"><label for="member_digits">Number digits</label><input id="member_digits" type="number" min="3" max="8" name="member_digits" value="<?= e($g('ids.member_digits', '4')) ?>" class="<?= has_error('member_digits') ?>"><?= field_error('member_digits') ?></div>
      <div class="field span-4"><label for="separator">Separator</label><select id="separator" name="separator"><?php foreach (['-' => 'Dash (-)', '/' => 'Slash (/)', '.' => 'Dot (.)', '' => 'None'] as $k => $l): ?><option value="<?= e($k) ?>" <?= $g('ids.separator', '-') === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></div>
      <div class="field span-12"><label class="check"><input type="checkbox" name="member_year" value="1" <?= $g('ids.member_year', '1') === '1' ? 'checked' : '' ?>> Include the year (numbering restarts every year)</label><p class="help">Existing member IDs never change. Only new members use the new format.</p></div>
    </div></div>
    <div class="card-footer"><button class="btn btn-primary" type="submit">Save ID format</button></div>
  </form>
  <form method="post" action="<?= url('/settings/general') ?>" class="card" id="security"><?= csrf_field() ?><input type="hidden" name="section" value="security">
    <div class="card-header"><h2>Sign-in security</h2></div>
    <div class="card-body"><div class="form-grid">
      <div class="field span-4"><label for="session_timeout">Auto sign-out after (minutes idle)</label><input id="session_timeout" type="number" name="session_timeout" min="5" max="480" value="<?= e($g('security.session_timeout', '30')) ?>" class="<?= has_error('session_timeout') ?>"><?= field_error('session_timeout') ?></div>
      <div class="field span-4"><label for="max_attempts">Lock account after (failed attempts)</label><input id="max_attempts" type="number" name="max_attempts" min="3" max="20" value="<?= e($g('security.max_attempts', '5')) ?>" class="<?= has_error('max_attempts') ?>"><?= field_error('max_attempts') ?></div>
      <div class="field span-4"><label for="lockout_minutes">Lock for (minutes)</label><input id="lockout_minutes" type="number" name="lockout_minutes" min="1" max="1440" value="<?= e($g('security.lockout_minutes', '15')) ?>" class="<?= has_error('lockout_minutes') ?>"><?= field_error('lockout_minutes') ?></div>
    </div><p class="help">Passwords are stored with Argon2id hashing. Too many failures from one computer are also throttled.</p></div>
    <div class="card-footer"><button class="btn btn-primary" type="submit">Save security settings</button></div>
  </form>
  <form method="post" action="<?= url('/settings/general') ?>" class="card" id="system"><?= csrf_field() ?><input type="hidden" name="section" value="system">
    <div class="card-header"><h2>Appearance &amp; backups</h2></div>
    <div class="card-body"><div class="form-grid">
      <div class="field span-6"><label for="default_theme">Default theme</label><select id="default_theme" name="default_theme"><?php foreach (['system' => 'Follow device', 'light' => 'Light', 'dark' => 'Dark'] as $k => $l): ?><option value="<?= $k ?>" <?= $g('app.default_theme', 'system') === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select><p class="help">Each user can still switch light/dark for themselves.</p></div>
      <div class="field span-6"><label for="keep">Backups to keep</label><input id="keep" type="number" name="keep" min="3" max="365" value="<?= e($g('backup.keep', '30')) ?>" class="<?= has_error('keep') ?>"><?= field_error('keep') ?></div>
      <div class="field span-12"><label class="check"><input type="checkbox" name="auto_daily" value="1" <?= $g('backup.auto_daily', '1') === '1' ? 'checked' : '' ?>> Make an automatic backup once a day (on the first page load of the day)</label></div>
    </div></div>
    <div class="card-footer"><button class="btn btn-primary" type="submit">Save</button></div>
  </form>
  <div class="card" id="sample" style="grid-column:1/-1">
    <div class="card-header"><h2>Sample data</h2><?= $samples['all'] ? badge($samples['all'] . ' sample records', 'amber') : badge('None loaded', 'neutral') ?></div>
    <div class="card-body"><p style="margin-top:0">Load clearly-marked demo records (members, ministries, attendance, lineups, events, documents and finance) to try the system or train users. Sample records show a <?= sample_tag(['is_sample' => 1]) ?> tag and can be removed in one step without touching real records.</p>
      <div class="row" style="gap:10px;flex-wrap:wrap">
        <form method="post" action="<?= url('/settings/sample') ?>" data-confirm="Load sample records into the system?" data-confirm-ok="Load sample data"><?= csrf_field() ?><input type="hidden" name="action" value="load"><button class="btn" type="submit" <?= $samples['members'] ? 'disabled title="Sample data is already loaded"' : '' ?>><?= icon('database') ?> Load sample data</button></form>
        <?php if ($samples['all']): ?><form method="post" action="<?= url('/settings/sample') ?>" class="row"><?= csrf_field() ?><input type="hidden" name="action" value="remove"><input name="confirm" placeholder="Type REMOVE" style="width:140px" autocomplete="off"><button class="btn btn-danger" type="submit"><?= icon('trash') ?> Remove all sample data</button></form><?php endif; ?>
      </div></div>
  </div>
</div>
