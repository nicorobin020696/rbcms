<?php $s = $edit ?? []; $v = fn($k, $d = '') => old($k, $s[$k] ?? $d); ?>
<div class="page-head"><div><h1>Settings</h1><p>People who sign church documents. Upload a transparent PNG of the signature to print it automatically (optional).</p></div></div>
<?php include __DIR__ . '/_nav.php'; ?>
<div class="split">
  <div class="card"><table class="table"><thead><tr><th>Name</th><th>Position</th><th>Signature</th><th>Status</th><th></th></tr></thead><tbody>
    <?php if (!$list): ?><tr><td colspan="5"><div class="empty small">No signatories yet. Add the pastor and church secretary.</div></td></tr><?php endif; ?>
    <?php foreach ($list as $r): ?><tr><td class="strong"><?= e($r['name']) ?></td><td><?= e($r['position']) ?></td><td><?= $r['signature_path'] ? '<img src="' . e(file_url($r['signature_path'])) . '" alt="" style="height:30px;background:#fff;border-radius:3px">' : '<span class="faint">—</span>' ?></td><td><?= $r['is_active'] ? badge('Active', 'green') : badge('Inactive', 'neutral') ?></td><td class="right"><a class="btn btn-sm" href="<?= url('/settings/signatories', ['edit' => $r['id']]) ?>">Edit</a></td></tr><?php endforeach; ?>
  </tbody></table></div>
  <form method="post" action="<?= url('/settings/signatories') ?>" enctype="multipart/form-data" class="card" novalidate>
    <?= csrf_field() ?><?php if ($s): ?><input type="hidden" name="id" value="<?= (int) $s['id'] ?>"><?php endif; ?>
    <div class="card-header"><h2><?= $s ? 'Edit signatory' : 'Add signatory' ?></h2><?php if ($s): ?><a class="more" href="<?= url('/settings/signatories') ?>">New instead</a><?php endif; ?></div>
    <div class="card-body stack-sm">
      <div class="field"><label for="name">Full name<span class="req">*</span></label><input id="name" name="name" value="<?= e($v('name')) ?>" maxlength="120" class="<?= has_error('name') ?>"><?= field_error('name') ?></div>
      <div class="field"><label for="position">Position<span class="req">*</span></label><input id="position" name="position" value="<?= e($v('position')) ?>" maxlength="120" placeholder="e.g. Senior Pastor" class="<?= has_error('position') ?>"><?= field_error('position') ?></div>
      <div class="field"><label for="sort_order">Order</label><input id="sort_order" type="number" name="sort_order" value="<?= e($v('sort_order', 0)) ?>" min="0" max="99"></div>
      <div class="field"><label>Signature image</label>
        <?= App\Core\View::partial('partials/image_field', ['img_name' => 'signature', 'img_current' => $s['signature_path'] ?? null, 'img_remove' => 'remove_signature', 'img_variant' => 'logo', 'img_label' => 'signature', 'img_empty' => 'No signature', 'img_accept' => 'image/png,image/jpeg', 'img_help' => 'Transparent PNG works best. It is printed above the name on documents.']) ?>
      </div>
      <label class="check"><input type="checkbox" name="is_active" value="1" <?= (int) $v('is_active', 1) ? 'checked' : '' ?>> Active</label>
    </div>
    <div class="card-footer"><button class="btn btn-primary" type="submit">Save</button></div>
  </form>
</div>
