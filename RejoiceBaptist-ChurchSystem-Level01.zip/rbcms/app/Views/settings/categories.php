<?php use App\Controllers\SettingsController as SC; $c = $edit ?? []; $v = fn($k, $d = '') => old($k, $c[$k] ?? $d); $finance = in_array($type, ['income', 'expense'], true); ?>
<div class="page-head"><div><h1>Settings</h1><p>Lists used across the system. Categories in use can be hidden but not deleted, so history stays intact.</p></div></div>
<?php include __DIR__ . '/_nav.php'; ?>
<div class="seg-tabs mb"><?php foreach (SC::CAT_TYPES as $k => $l): if (in_array($k, ['income', 'expense'], true) && !can('finance.view')) continue; ?><a href="<?= url('/settings/categories', ['type' => $k]) ?>" class="<?= $type === $k ? 'active' : '' ?>"><?= $l ?></a><?php endforeach; ?></div>
<div class="split">
  <div class="card"><table class="table"><thead><tr><th>Name</th><th class="right">Used</th><th>Status</th><th></th></tr></thead><tbody>
    <?php foreach ($list as $r): ?><tr><td><span class="cat-dot c-<?= e($r['color']) ?>"></span><span class="strong"><?= e($r['name']) ?></span><?= $r['is_system'] ? ' ' . badge('System', 'neutral') : '' ?><?= $r['grp'] === 'giving' ? ' ' . badge('Giving', 'green') : '' ?></td><td class="num"><?= (int) $r['used'] ?></td><td><?= $r['is_active'] ? badge('Active', 'green') : badge('Hidden', 'neutral') ?></td>
      <td class="right"><?php if (!$finance || can('finance.manage')): ?><a class="btn btn-sm" href="<?= url('/settings/categories', ['type' => $type, 'edit' => $r['id']]) ?>">Edit</a><?php endif; ?></td></tr><?php endforeach; ?>
  </tbody></table></div>
  <?php if (!$finance || can('finance.manage')): ?>
  <form method="post" action="<?= url('/settings/categories') ?>" class="card" novalidate><?= csrf_field() ?><input type="hidden" name="type" value="<?= e($type) ?>"><?php if ($c): ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>"><?php endif; ?>
    <div class="card-header"><h2><?= $c ? 'Edit' : 'Add' ?> — <?= e(SC::CAT_TYPES[$type]) ?></h2><?php if ($c): ?><a class="more" href="<?= url('/settings/categories', ['type' => $type]) ?>">New instead</a><?php endif; ?></div>
    <div class="card-body stack-sm">
      <div class="field"><label for="name">Name<span class="req">*</span></label><input id="name" name="name" value="<?= e($v('name')) ?>" maxlength="60" class="<?= has_error('name') ?>"><?= field_error('name') ?></div>
      <div class="field"><label>Color</label><div class="row" style="gap:6px;flex-wrap:wrap"><?php foreach (SC::COLORS as $col): ?><label class="swatch c-<?= $col ?>" title="<?= $col ?>"><input type="radio" name="color" value="<?= $col ?>" <?= $v('color', 'slate') === $col ? 'checked' : '' ?>><span></span></label><?php endforeach; ?></div></div>
      <div class="field"><label for="sort_order">Order</label><input id="sort_order" type="number" name="sort_order" value="<?= e($v('sort_order', 0)) ?>" min="0" max="999"></div>
      <?php if ($type === 'income'): ?><label class="check"><input type="checkbox" name="grp" value="giving" <?= $v('grp') === 'giving' ? 'checked' : '' ?>> Counts as giving (tithes, offerings, donations)</label><?php endif; ?>
      <label class="check"><input type="checkbox" name="is_active" value="1" <?= (int) $v('is_active', 1) ? 'checked' : '' ?> <?= !empty($c['is_system']) ? 'disabled' : '' ?>> Active</label>
    </div>
    <div class="card-footer"><button class="btn btn-primary" type="submit">Save</button></div>
  </form>
  <?php endif; ?>
</div>
