<?php use App\Controllers\DocumentsController as DC; ?>
<div class="page-head"><div><h1>Settings</h1><p>Templates used by the document generator. Editing a template does not change documents already created.</p></div><div class="page-actions"><a class="btn btn-primary" href="<?= url('/settings/templates/new') ?>"><?= icon('plus') ?> New template</a></div></div>
<?php include __DIR__ . '/_nav.php'; ?>
<div class="card"><table class="table"><thead><tr><th>Template</th><th>Type</th><th>Layout</th><th class="right">Used</th><th>Status</th></tr></thead><tbody>
<?php foreach ($templates as $t): ?>
  <tr class="clickable" data-href="<?= url('/settings/templates/' . $t['id']) ?>"><td><a class="title-cell" href="<?= url('/settings/templates/' . $t['id']) ?>"><?= e($t['name']) ?></a><span class="sub"><?= e($t['title']) ?></span></td>
    <td class="muted"><?= e(DC::TYPES[$t['doc_type']] ?? $t['doc_type']) ?></td><td><?= $t['is_certificate'] ? 'Certificate' : 'Letter' ?><?= $t['confidential'] ? ' ' . badge('Confidential', 'red') : '' ?></td>
    <td class="num"><?= (int) $t['used'] ?></td><td><?= $t['is_active'] ? badge('Active', 'green') : badge('Hidden', 'neutral') ?></td></tr>
<?php endforeach; ?></tbody></table></div>
