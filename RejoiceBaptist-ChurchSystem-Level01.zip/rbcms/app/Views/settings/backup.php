<div class="page-head"><div><h1>Settings</h1><p>A backup contains the whole database and every uploaded photo, logo, signature and receipt.</p></div>
  <div class="page-actions"><form method="post" action="<?= url('/settings/backup') ?>"><?= csrf_field() ?><button class="btn btn-primary" type="submit"><?= icon('database') ?> Back up now</button></form></div></div>
<?php include __DIR__ . '/_nav.php'; ?>
<div class="callout info mb"><?= icon('info') ?><div>Keep copies <strong>outside this computer</strong> (USB drive or another PC). <?= setting('backup.auto_daily', '1') === '1' ? 'An automatic backup is made once a day; the newest ' . (int) setting('backup.keep', '30') . ' are kept.' : 'Automatic daily backups are turned off.' ?></div></div>
<div class="split-wide">
  <div class="card"><div class="card-header"><h2>Saved backups</h2><span class="muted small"><?= count($backups) ?> file(s)</span></div>
    <?php if (!$backups): ?><div class="empty"><?= icon('database') ?><strong>No backups yet</strong>Click “Back up now” to create the first one.</div><?php else: ?>
    <div class="table-wrap"><table class="table"><thead><tr><th>Backup</th><th>Type</th><th class="right">Size</th><th class="right">Actions</th></tr></thead><tbody>
    <?php foreach ($backups as $b): $m = $b['manifest']; ?>
      <tr><td><span class="strong"><?= e(date('M j, Y g:i A', $b['time'])) ?></span><span class="sub mono"><?= e($b['file']) ?></span><?php if ($m): ?><span class="sub"><?= (int) ($m['counts']['members'] ?? 0) ?> members · <?= (int) ($m['uploads'] ?? 0) ?> files<?= !empty($m['created_by']) ? ' · by ' . e($m['created_by']) : '' ?></span><?php else: ?><span class="sub text-red">Unreadable manifest</span><?php endif; ?></td>
        <td><?= badge(ucfirst(str_replace('-', ' ', $m['kind'] ?? '?')), ($m['kind'] ?? '') === 'manual' ? 'blue' : 'neutral') ?></td>
        <td class="num"><?= number_format($b['size'] / 1048576, 2) ?> MB</td>
        <td class="right nowrap"><a class="btn btn-sm" href="<?= url('/settings/backup/download', ['file' => $b['file']]) ?>"><?= icon('download') ?> Download</a>
          <form method="post" action="<?= url('/settings/backup/delete') ?>" class="inline" data-confirm="Delete this backup file permanently?" data-confirm-ok="Delete" data-danger><?= csrf_field() ?><input type="hidden" name="file" value="<?= e($b['file']) ?>"><button class="btn btn-sm btn-ghost" type="submit" title="Delete"><?= icon('trash') ?></button></form></td></tr>
    <?php endforeach; ?></tbody></table></div><?php endif; ?>
  </div>
  <div class="stack">
    <form method="post" action="<?= url('/settings/backup/restore') ?>" enctype="multipart/form-data" class="card" data-confirm="Restore this backup? ALL current data and uploaded files will be replaced by the backup. A safety backup of the current data is made first. Everyone will need to sign in again." data-confirm-ok="Restore now" data-danger>
      <?= csrf_field() ?>
      <div class="card-header"><h2>Restore</h2><?= badge('Replaces all data', 'red') ?></div>
      <div class="card-body stack-sm">
        <div class="field"><label for="file">From a saved backup</label><select id="file" name="file"><option value="">Choose…</option><?php foreach ($backups as $b): ?><option value="<?= e($b['file']) ?>"><?= e(date('M j, Y g:i A', $b['time'])) ?> (<?= e($b['manifest']['kind'] ?? '?') ?>)</option><?php endforeach; ?></select></div>
        <div class="field"><label for="backup_file">…or upload a backup file (.zip)</label><input id="backup_file" type="file" name="backup_file" accept=".zip,application/zip"></div>
        <p class="help" style="margin:0">The file is checked first (manifest, checksum, database integrity, required tables and at least one Super Admin). If anything is wrong, nothing is changed.</p>
        <div class="field"><label for="confirm">Type <strong>RESTORE</strong> to confirm</label><input id="confirm" name="confirm" autocomplete="off" class="mono"></div>
      </div>
      <div class="card-footer"><button class="btn btn-danger solid" type="submit"><?= icon('refresh') ?> Restore backup</button></div>
    </form>
    <div class="card"><div class="card-header"><h2>Backup history</h2></div><?php if (!$history): ?><div class="empty small">No activity yet.</div><?php else: ?><ul class="list"><?php foreach ($history as $h): ?><li class="small"><strong><?= e(ucfirst(str_replace('_', ' ', $h['action']))) ?></strong> · <?= e($h['user_name'] ?: 'System') ?><span class="sub"><?= e(fmt_datetime($h['created_at'])) ?> · <?= e(mb_strimwidth((string) ($h['details'] ?: $h['record_label']), 0, 90, '…')) ?></span></li><?php endforeach; ?></ul><?php endif; ?></div>
  </div>
</div>
