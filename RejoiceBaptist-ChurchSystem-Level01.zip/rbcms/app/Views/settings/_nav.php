<?php $items = [];
if (can('settings.manage')) { $items['/settings/general'] = ['sliders', 'General']; $items['/settings/categories'] = ['layers', 'Categories']; }
if (can('documents.templates')) { $items['/settings/templates'] = ['file', 'Document templates']; $items['/settings/signatories'] = ['pencil', 'Signatories']; }
if (can('backup.manage')) { $items['/settings/backup'] = ['database', 'Backup & restore']; }
$cur = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH); ?>
<div class="tabs"><?php foreach ($items as $href => [$ic, $label]): ?><a href="<?= url($href) ?>" class="<?= str_ends_with((string) $cur, $href) || str_contains((string) $cur, $href . '/') ? 'active' : '' ?>"><?= $label ?></a><?php endforeach; ?></div>
