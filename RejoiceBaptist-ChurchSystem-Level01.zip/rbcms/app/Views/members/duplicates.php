<div class="crumbs"><a href="<?= url('/members') ?>">Members</a> / Possible duplicates</div>
<div class="page-head"><div><h1>Possible duplicate records</h1><p>Active records that share the same first and last name. Open each one to compare, then archive the duplicate.</p></div></div>
<?php if (!$groups): ?><div class="card"><?= App\Core\View::partial('partials/empty', ['icon' => 'check-circle', 'title' => 'No duplicates found', 'text' => 'Every active member has a unique name.']) ?></div><?php endif; ?>
<?php foreach ($groups as $g): ?>
<div class="card mb"><table class="table table-compact"><thead><tr><th>Member</th><th>ID</th><th>Birth date</th><th>Contact</th><th>Joined</th><th>Added</th></tr></thead><tbody>
<?php foreach ($g as $m): ?><tr class="clickable" data-href="<?= url('/members/' . $m['id']) ?>"><td><a href="<?= url('/members/' . $m['id']) ?>"><?= e(member_name($m)) ?></a></td><td class="code"><?= e($m['member_code']) ?></td><td><?= e(fmt_date($m['birth_date'])) ?></td><td><?= e($m['contact_number'] ?: '—') ?></td><td><?= e(fmt_date($m['date_joined'])) ?></td><td class="muted"><?= e(fmt_datetime($m['created_at'])) ?></td></tr><?php endforeach; ?>
</tbody></table></div>
<?php endforeach; ?>
