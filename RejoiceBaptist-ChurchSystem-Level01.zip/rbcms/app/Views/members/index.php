<?php use App\Controllers\MembersController; use App\Core\View; ?>
<div class="page-head">
  <div><h1>Members</h1><p>Central record of church members, their status, baptism and ministries.</p></div>
  <div class="page-actions">
    <?php if (can('members.export')): ?>
      <a class="btn" href="<?= url('/members/export.csv') . e(query_with(['page' => null])) ?>"><?= icon('download') ?> CSV</a>
      <a class="btn" href="<?= url('/members/export.pdf') . e(query_with(['page' => null])) ?>"><?= icon('printer') ?> PDF</a>
    <?php endif; ?>
    <?php if (can('members.manage')): ?><a class="btn btn-primary" href="<?= url('/members/new') ?>"><?= icon('plus') ?> Add member</a><?php endif; ?>
  </div>
</div>

<div class="stats mb">
  <a class="stat" href="<?= url('/members') ?>"><div class="stat-label">Total members</div><div class="stat-value"><?= $counts['all'] ?></div></a>
  <a class="stat" href="<?= url('/members', ['view' => 'active']) ?>"><div class="stat-label">Active</div><div class="stat-value"><?= $counts['active'] ?></div></a>
  <a class="stat" href="<?= url('/members', ['view' => 'inactive']) ?>"><div class="stat-label">Inactive</div><div class="stat-value"><?= $counts['inactive'] ?></div></a>
  <a class="stat" href="<?= url('/members', ['view' => 'active_unbaptized']) ?>"><div class="stat-label">Active unbaptized</div><div class="stat-value"><?= $counts['active_unbaptized'] ?></div></a>
  <a class="stat" href="<?= url('/members', ['view' => 'baptized']) ?>"><div class="stat-label">Baptized</div><div class="stat-value"><?= $counts['baptized'] ?></div></a>
</div>

<div class="tabs">
  <?php foreach (MembersController::VIEWS as $key => [$label]): ?>
    <a href="<?= url('/members', ['view' => $key === 'all' ? null : $key]) ?>" class="<?= $view === $key ? 'active' : '' ?>"><?= e($label) ?><span class="count"><?= $counts[$key] ?></span></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <form class="filters" method="get" action="<?= url('/members') ?>">
    <?php if ($view !== 'all'): ?><input type="hidden" name="view" value="<?= e($view) ?>"><?php endif; ?>
    <div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="Search name, member ID or contact number"></div>
    <select name="ministry" data-autosubmit>
      <option value="">All ministries</option>
      <?php foreach ($ministries as $mi): ?><option value="<?= $mi['id'] ?>" <?= input_int('ministry') === (int) $mi['id'] ? 'selected' : '' ?>><?= e($mi['name']) ?></option><?php endforeach; ?>
    </select>
    <select name="gender" data-autosubmit>
      <option value="">Any gender</option>
      <option value="male" <?= query_str('gender') === 'male' ? 'selected' : '' ?>>Male</option>
      <option value="female" <?= query_str('gender') === 'female' ? 'selected' : '' ?>>Female</option>
    </select>
    <select name="sort" data-autosubmit>
      <?php foreach (['name' => 'Sort: Name', 'code' => 'Sort: Member ID', 'joined' => 'Sort: Date joined', 'recent' => 'Sort: Recently added'] as $k => $l): ?>
        <option value="<?= $k ?>" <?= (query_str('sort') ?: 'name') === $k ? 'selected' : '' ?>><?= $l ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn" type="submit">Search</button>
    <?php if (query_str('q') !== '' || input_int('ministry') || query_str('gender') !== ''): ?><a class="btn btn-ghost" href="<?= url('/members', ['view' => $view === 'all' ? null : $view]) ?>">Clear</a><?php endif; ?>
  </form>
  <?php if (!$members): ?>
    <?= View::partial('partials/empty', ['icon' => 'users', 'title' => query_str('q') !== '' ? 'No members match your search' : 'No members in this list',
      'text' => query_str('q') !== '' ? 'Try a different name, ID or filter.' : 'Members you add will appear here.',
      'action' => can('members.manage') && $view === 'all' && query_str('q') === '' ? ['Add member', url('/members/new')] : null]) ?>
  <?php else: ?>
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>Member</th><th>Member ID</th><th>Contact</th><th>Ministries</th><th>Status</th><th>Baptism</th><th>Joined</th></tr></thead>
      <tbody>
      <?php foreach ($members as $m): ?>
        <tr class="clickable" data-href="<?= url('/members/' . $m['id']) ?>">
          <td><div class="person">
            <span class="avatar"><?php if ($m['photo_path']): ?><img src="<?= e(file_url($m['photo_path'])) ?>" alt="" loading="lazy"><?php else: ?><?= e(initials($m['first_name'] . ' ' . $m['last_name'])) ?><?php endif; ?></span>
            <div><a href="<?= url('/members/' . $m['id']) ?>"><?= e(member_name($m, true)) ?></a><?= sample_tag($m) ?>
              <span class="sub"><?= e(ucfirst((string) $m['gender'])) ?><?= age($m['birth_date']) !== null ? ' · ' . age($m['birth_date']) . ' yrs' : '' ?></span></div>
          </div></td>
          <td class="code"><?= e($m['member_code']) ?></td>
          <td class="nowrap"><?= e($m['contact_number'] ?: '—') ?></td>
          <td><?= $m['ministries'] ? e($m['ministries']) : '<span class="faint">None</span>' ?></td>
          <td><?= $m['archived_at'] ? badge('Archived', 'neutral') : status_badge($m['membership_status']) ?></td>
          <td><?= status_badge($m['baptism_status']) ?></td>
          <td class="nowrap muted"><?= e(fmt_date($m['date_joined'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= View::partial('partials/pagination', ['p' => $p]) ?>
  <?php endif; ?>
</div>
<?php if (can('members.manage')): ?><p class="small muted mt"><a href="<?= url('/members/duplicates') ?>">Check for possible duplicate records</a></p><?php endif; ?>
