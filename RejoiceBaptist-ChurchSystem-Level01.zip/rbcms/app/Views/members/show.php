<?php $rate = ($att['total'] ?? 0) ? round($att['present'] / $att['total'] * 100) : null; ?>
<div class="crumbs"><a href="<?= url('/members') ?>">Members</a> / <?= e($m['member_code']) ?></div>
<div class="page-head">
  <div class="person" style="gap:16px">
    <span class="avatar avatar-lg"><?php if ($m['photo_path']): ?><img src="<?= e(file_url($m['photo_path'])) ?>" alt=""><?php else: ?><?= e(initials($m['first_name'] . ' ' . $m['last_name'])) ?><?php endif; ?></span>
    <div>
      <h1><?= e(trim($m['first_name'] . ' ' . ($m['middle_name'] ? $m['middle_name'] . ' ' : '') . $m['last_name'] . ' ' . $m['suffix'])) ?><?= sample_tag($m) ?></h1>
      <div class="row" style="margin-top:6px">
        <span class="code"><?= e($m['member_code']) ?></span>
        <?= $m['archived_at'] ? badge('Archived', 'neutral') : status_badge($m['membership_status']) ?>
        <?= status_badge($m['baptism_status']) ?>
      </div>
    </div>
  </div>
  <div class="page-actions">
    <?php if (can('members.export')): ?><a class="btn" href="<?= url('/members/' . $m['id'] . '/pdf') ?>" target="_blank"><?= icon('printer') ?> Print</a><?php endif; ?>
    <?php if (can('documents.create')): ?><a class="btn" href="<?= url('/documents/new', ['member' => $m['id']]) ?>"><?= icon('file-plus') ?> Create document</a><?php endif; ?>
    <?php if (can('members.manage')): ?>
      <?php if ($m['archived_at']): ?>
        <form method="post" action="<?= url('/members/' . $m['id'] . '/restore') ?>"><?= csrf_field() ?><button class="btn" type="submit"><?= icon('refresh') ?> Restore</button></form>
      <?php else: ?>
        <button class="btn" type="button" data-open-modal="archive-modal"><?= icon('archive') ?> Archive</button>
        <a class="btn btn-primary" href="<?= url('/members/' . $m['id'] . '/edit') ?>"><?= icon('pencil') ?> Edit</a>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>
<?php if ($m['archived_at']): ?><div class="callout mb"><?= icon('archive') ?><div>This record was archived on <?= e(fmt_datetime($m['archived_at'])) ?>. It is hidden from lists and cannot be selected for attendance, but its history is kept.</div></div><?php endif; ?>

<div class="split">
  <div class="stack">
    <div class="card">
      <div class="card-header"><h2>Profile</h2></div>
      <div class="card-body">
        <dl class="kv">
          <dt>Gender</dt><dd><?= e(ucfirst((string) $m['gender']) ?: '—') ?></dd>
          <dt>Date of birth</dt><dd><?= e(fmt_date($m['birth_date'])) ?><?= age($m['birth_date']) !== null ? ' <span class="muted">(' . age($m['birth_date']) . ' years old)</span>' : '' ?></dd>
          <dt>Civil status</dt><dd><?= e($m['civil_status'] ?: '—') ?></dd>
          <dt>Contact number</dt><dd><?= e($m['contact_number'] ?: '—') ?></dd>
          <dt>E-mail</dt><dd><?= e($m['email'] ?: '—') ?></dd>
          <dt>Address</dt><dd><?= e($m['address'] ?: '—') ?></dd>
          <dt>Emergency contact</dt><dd><?= e($m['emergency_name'] ?: '—') ?><?= $m['emergency_relation'] ? ' <span class="muted">(' . e($m['emergency_relation']) . ')</span>' : '' ?><?= $m['emergency_contact'] ? ' · ' . e($m['emergency_contact']) : '' ?></dd>
          <dt>Date joined</dt><dd><?= e(fmt_date($m['date_joined'])) ?></dd>
          <dt>Baptism</dt><dd><?php if ($m['baptism_status'] === 'baptized'): ?>Baptized<?= $m['baptism_date'] ? ' on ' . e(fmt_date($m['baptism_date'], 'j F Y')) : '' ?><?= $m['baptism_place'] ? ' at ' . e($m['baptism_place']) : '' ?><?= $m['baptized_by'] ? ' by ' . e($m['baptized_by']) : '' ?><?php else: ?>Not yet baptized<?php endif; ?></dd>
          <?php if ($account): ?><dt>System account</dt><dd class="mono"><?= e($account['username']) ?></dd><?php endif; ?>
        </dl>
        <?php if ($m['notes']): ?><hr><div class="section-label">Notes</div><div class="prose"><?= nl2p($m['notes']) ?></div><?php endif; ?>
      </div>
    </div>

    <?php if (can('attendance.view')): ?>
    <div class="card">
      <div class="card-header"><h2>Recent attendance</h2><a class="more" href="<?= url('/attendance/records', ['member' => $m['id']]) ?>">Full history <?= icon('arrow-right') ?></a></div>
      <?php if (!$recent): ?><div class="empty small" style="padding:24px">No attendance recorded yet.</div><?php else: ?>
      <table class="table table-compact"><thead><tr><th>Date</th><th>Activity</th><th>Status</th><th>Remarks</th></tr></thead><tbody>
        <?php foreach ($recent as $r): ?><tr><td class="nowrap"><?= e(fmt_date($r['session_date'], 'D, j M Y')) ?></td><td><a href="<?= url('/attendance/' . $r['session_id']) ?>"><?= e($r['title']) ?></a><span class="sub"><?= e($r['category']) ?></span></td><td><?= status_badge($r['status']) ?></td><td class="muted"><?= e($r['remarks'] ?: '') ?></td></tr><?php endforeach; ?>
      </tbody></table><?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($music): ?>
    <div class="card">
      <div class="card-header"><h2>Music team assignments</h2></div>
      <table class="table table-compact"><tbody>
        <?php foreach ($music as $mu): ?><tr><td class="nowrap"><a href="<?= url('/music/' . $mu['id']) ?>"><?= e(fmt_date($mu['service_date'], 'D, j M Y')) ?></a></td><td><?= e(ucfirst($mu['service_type'])) ?> service</td><td><?= e($mu['role']) ?></td></tr><?php endforeach; ?>
      </tbody></table>
    </div>
    <?php endif; ?>
  </div>

  <div class="stack">
    <?php if (can('attendance.view')): ?>
    <div class="stats" style="grid-template-columns:1fr 1fr">
      <div class="stat"><div class="stat-label">Attendance rate</div><div class="stat-value"><?= $rate === null ? '—' : $rate . '%' ?></div><div class="stat-note"><?= (int) $att['present'] ?> of <?= (int) $att['total'] ?> recorded</div></div>
      <div class="stat"><div class="stat-label">Last attended</div><div class="stat-value" style="font-size:15px;padding-top:6px"><?= e($att['last_present'] ? fmt_date($att['last_present']) : '—') ?></div></div>
    </div>
    <?php endif; ?>
    <div class="card">
      <div class="card-header"><h2>Ministries</h2><span class="sub"><?= count($ministries) ?></span></div>
      <?php if (!$ministries): ?><div class="empty small" style="padding:20px">Not assigned to any ministry.</div><?php else: ?>
      <ul class="list"><?php foreach ($ministries as $mi): ?>
        <li class="row-between"><a href="<?= url('/ministries/' . $mi['id']) ?>" class="strong" style="color:var(--text)"><?= e($mi['name']) ?></a><span class="tag"><?= e($mi['role']) ?></span></li>
      <?php endforeach; ?></ul><?php endif; ?>
    </div>
    <div class="card">
      <div class="card-header"><h2>Member history</h2></div>
      <div class="card-body">
        <?php if (!$history): ?><p class="muted small">No history yet.</p><?php else: ?>
        <ul class="timeline"><?php foreach ($history as $h): ?>
          <li><div><?= e($h['summary']) ?></div><div class="meta"><?= e($h['user_name'] ?: 'System') ?> · <?= e(fmt_datetime($h['created_at'])) ?></div></li>
        <?php endforeach; ?></ul><?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php if (can('members.manage') && !$m['archived_at']): ?>
<dialog class="modal" id="archive-modal">
  <form method="post" action="<?= url('/members/' . $m['id'] . '/archive') ?>">
    <?= csrf_field() ?>
    <div class="modal-head"><h2>Archive <?= e(member_name($m)) ?>?</h2><button class="icon-btn" type="button" data-close-modal><?= icon('x') ?></button></div>
    <div class="modal-body">
      <p>The record will be hidden from member lists and attendance sheets. Attendance, ministry and music history are kept, and the record can be restored at any time.</p>
      <div class="field"><label for="reason">Reason <span class="muted">(optional)</span></label><input id="reason" name="reason" placeholder="e.g. Transferred to another church, deceased, duplicate"></div>
    </div>
    <div class="modal-foot"><button class="btn" type="button" data-close-modal>Cancel</button><button class="btn btn-danger solid" type="submit"><?= icon('archive') ?> Archive member</button></div>
  </form>
</dialog>
<?php endif; ?>
