<?php use App\Core\Permissions; $editing = !empty($u['id']); $v = fn($k, $d = '') => old($k, $u[$k] ?? $d); $oldPerm = old('perm'); ?>
<div class="crumbs"><a href="<?= url('/users') ?>">Users</a> / <?= $editing ? e($u['username']) : 'New' ?></div>
<div class="page-head"><div><h1><?= e($title) ?></h1><p>Assign a role, then fine-tune individual permissions if needed. Everything is enforced on the server.</p></div></div>
<div class="split-wide">
<form method="post" action="<?= url($editing ? '/users/' . $u['id'] : '/users') ?>" class="card" novalidate data-user-form data-role-perms="<?= json_attr($rolePerms) ?>">
  <?= csrf_field() ?>
  <div class="form-section"><h3>Account</h3><div class="form-grid">
    <div class="field span-6"><label for="full_name">Full name<span class="req">*</span></label><input id="full_name" name="full_name" value="<?= e($v('full_name')) ?>" maxlength="120" class="<?= has_error('full_name') ?>" required><?= field_error('full_name') ?></div>
    <div class="field span-6"><label for="username">Username<span class="req">*</span></label><input id="username" name="username" value="<?= e($v('username')) ?>" maxlength="40" autocomplete="off" class="mono <?= has_error('username') ?>" required><?= field_error('username') ?></div>
    <div class="field span-6"><label for="email">Email <span class="muted">(optional)</span></label><input id="email" type="email" name="email" value="<?= e($v('email')) ?>" maxlength="150" class="<?= has_error('email') ?>"><?= field_error('email') ?></div>
    <div class="field span-6"><label for="position">Position</label><input id="position" name="position" value="<?= e($v('position')) ?>" maxlength="100" placeholder="e.g. Church Secretary"></div>
    <div class="field span-6"><label for="role_id">Role<span class="req">*</span></label><select id="role_id" name="role_id" class="<?= has_error('role_id') ?>"><?php foreach ($roles as $r): ?><option value="<?= $r['id'] ?>" data-code="<?= e($r['code']) ?>" <?= (int) $v('role_id') === (int) $r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?></select><?= field_error('role_id') ?></div>
    <div class="field span-6"><label for="member_id">Linked member record</label><?= App\Core\View::partial('partials/member_select', ['name' => 'member_id', 'members' => $members, 'selected' => $v('member_id')]) ?><p class="help">Needed for ministry leaders — they manage the ministries where they are leader or assistant.</p></div>
    <?php if (!$editing): ?>
      <div class="field span-6"><label for="password">Temporary password<span class="req">*</span></label><input id="password" type="password" name="password" autocomplete="new-password" class="<?= has_error('password') ?>"><p class="help">At least 10 characters with letters and numbers.</p><?= field_error('password') ?></div>
      <div class="field span-6"><label for="password_confirm">Confirm password<span class="req">*</span></label><input id="password_confirm" type="password" name="password_confirm" autocomplete="new-password" class="<?= has_error('password_confirm') ?>"><?= field_error('password_confirm') ?></div>
    <?php endif; ?>
    <div class="field span-12 row" style="gap:20px">
      <label class="check"><input type="checkbox" name="is_active" value="1" <?= (int) $v('is_active', 1) ? 'checked' : '' ?>> Account active</label>
      <label class="check"><input type="checkbox" name="must_change_password" value="1" <?= (int) $v('must_change_password', 0) ? 'checked' : '' ?>> Require password change at next sign-in</label>
    </div><?= field_error('is_active') ?>
  </div></div>
  <div class="form-section" data-perm-section><h3>Permissions</h3><p class="muted">“Role” follows the selected role. Choose Allow or Deny to override it for this user only. <span class="badge red">Confidential</span> items expose finances, private documents or system controls.</p><?= field_error('perm') ?>
    <div class="callout info hidden" data-sa-note><?= icon('shield') ?><div>Super Admins always have every permission.</div></div>
    <?php foreach (Permissions::GROUPS as $group => $perms): ?>
      <div class="perm-group"><div class="section-label"><?= e($group) ?></div>
      <?php foreach ($perms as $key => $label): $cur = is_array($oldPerm) ? ($oldPerm[$key] ?? '') : (isset($overrides[$key]) ? ($overrides[$key] ? 'grant' : 'revoke') : ''); ?>
        <div class="perm-row" data-perm="<?= e($key) ?>">
          <div><span><?= e($label) ?></span><?= Permissions::isConfidential($key) ? ' <span class="badge red">Confidential</span>' : '' ?><span class="sub mono"><?= e($key) ?> · role: <span data-role-state>—</span></span></div>
          <div class="seg"><label><input type="radio" name="perm[<?= e($key) ?>]" value="" <?= $cur === '' ? 'checked' : '' ?>>Role</label><label><input type="radio" name="perm[<?= e($key) ?>]" value="grant" <?= $cur === 'grant' ? 'checked' : '' ?>>Allow</label><label><input type="radio" name="perm[<?= e($key) ?>]" value="revoke" <?= $cur === 'revoke' ? 'checked' : '' ?>>Deny</label></div>
        </div>
      <?php endforeach; ?></div>
    <?php endforeach; ?>
  </div>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url('/users') ?>">Cancel</a><button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Create user' ?></button></div>
</form>
<?php if ($editing): ?>
<div class="stack">
  <form method="post" action="<?= url('/users/' . $u['id'] . '/password') ?>" class="card" data-confirm="Reset the password for <?= e($u['full_name']) ?>? They will be signed out and must set a new password at next sign-in." data-confirm-ok="Reset password">
    <?= csrf_field() ?>
    <div class="card-header"><h2>Reset password</h2></div>
    <div class="card-body"><div class="field"><label for="new_password">New temporary password</label><input id="new_password" type="password" name="new_password" autocomplete="new-password" required></div><p class="help">The user must change it at next sign-in.</p></div>
    <div class="card-footer"><button class="btn" type="submit"><?= icon('key') ?> Reset password</button></div>
  </form>
  <div class="card"><div class="card-body"><dl class="kv">
    <dt>Last sign-in</dt><dd><?= $u['last_login_at'] ? e(fmt_datetime($u['last_login_at'])) : 'Never' ?></dd>
    <dt>Password changed</dt><dd><?= $u['password_changed_at'] ? e(fmt_datetime($u['password_changed_at'])) : '—' ?></dd>
    <dt>Failed attempts</dt><dd><?= (int) $u['failed_attempts'] ?><?= $u['locked_until'] && $u['locked_until'] > now() ? ' · locked until ' . e(fmt_datetime($u['locked_until'])) : '' ?></dd>
    <dt>Created</dt><dd><?= e(fmt_datetime($u['created_at'])) ?></dd>
  </dl></div></div>
  <?php if ($recent && can('audit.view')): ?><div class="card"><div class="card-header"><h2>Recent activity</h2><a class="more" href="<?= url('/audit', ['user' => $u['id']]) ?>">All</a></div><ul class="list"><?php foreach ($recent as $a): ?><li class="small"><strong><?= e(ucfirst(str_replace('_', ' ', $a['action']))) ?></strong> · <?= e($a['module']) ?><?= $a['record_label'] ? ' · ' . e(mb_strimwidth($a['record_label'], 0, 40, '…')) : '' ?><span class="sub"><?= e(fmt_datetime($a['created_at'])) ?></span></li><?php endforeach; ?></ul></div><?php endif; ?>
</div>
<?php endif; ?>
</div>
