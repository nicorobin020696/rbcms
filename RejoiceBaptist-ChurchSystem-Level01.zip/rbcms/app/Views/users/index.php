<div class="page-head">
  <div><h1>User management</h1><p>Accounts that can sign in to the system. Access is controlled by role plus optional per-user permissions.</p></div>
  <div class="page-actions"><a class="btn btn-primary" href="<?= url('/users/new') ?>"><?= icon('plus') ?> New user</a></div>
</div>
<?php $active = 'users'; include __DIR__ . '/_tabs.php'; ?>
<div class="card">
  <form class="filters" method="get">
    <div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="Name, username or email"></div>
    <select name="role" data-autosubmit><option value="">All roles</option><?php foreach ($roles as $r): ?><option value="<?= $r['id'] ?>" <?= input_int('role') === (int) $r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?></select>
    <select name="status" data-autosubmit><?php foreach (['all' => 'Any status', 'active' => 'Active', 'inactive' => 'Deactivated', 'locked' => 'Locked'] as $k => $l): ?><option value="<?= $k ?>" <?= query_str('status') === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select>
  </form>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Last sign-in</th><th class="right">Actions</th></tr></thead>
    <tbody><?php foreach ($users as $u): $locked = $u['locked_until'] && $u['locked_until'] > now(); $isSA = $u['role_code'] === 'super_admin'; $canEdit = !$isSA || App\Core\Auth::isSuperAdmin(); ?>
      <tr>
        <td><div class="row" style="gap:10px;flex-wrap:nowrap"><span class="avatar avatar-sm"><?= e(initials($u['full_name'])) ?></span><div><span class="strong"><?= e($u['full_name']) ?></span><?= (int) $u['id'] === App\Core\Auth::id() ? ' ' . badge('You', 'blue') : '' ?><span class="sub"><span class="mono"><?= e($u['username']) ?></span><?= $u['position'] ? ' · ' . e($u['position']) : '' ?><?= $u['member_code'] ? ' · ' . e($u['member_code']) : '' ?></span></div></div></td>
        <td><?= $isSA ? badge($u['role_name'], 'violet') : e($u['role_name']) ?><?= $u['overrides'] ? '<span class="sub">+' . (int) $u['overrides'] . ' custom permission(s)</span>' : '' ?></td>
        <td><?= !$u['is_active'] ? badge('Deactivated', 'neutral') : ($locked ? badge('Locked', 'red') : badge('Active', 'green')) ?><?= $u['must_change_password'] ? '<span class="sub">must change password</span>' : '' ?></td>
        <td class="muted small"><?= $u['last_login_at'] ? e(time_ago($u['last_login_at'])) : 'Never' ?></td>
        <td class="right nowrap"><?php if ($canEdit): ?>
          <?php if ($locked): ?><form method="post" action="<?= url('/users/' . $u['id'] . '/status') ?>" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="unlock"><button class="btn btn-sm" type="submit"><?= icon('key') ?> Unlock</button></form><?php endif; ?>
          <?php if ((int) $u['id'] !== App\Core\Auth::id()): ?><form method="post" action="<?= url('/users/' . $u['id'] . '/status') ?>" class="inline" <?= $u['is_active'] ? 'data-confirm="Deactivate ' . e($u['full_name']) . '? They will be signed out immediately and cannot sign in until reactivated." data-confirm-ok="Deactivate" data-danger' : '' ?>><?= csrf_field() ?><input type="hidden" name="action" value="<?= $u['is_active'] ? 'deactivate' : 'activate' ?>"><button class="btn btn-sm" type="submit"><?= $u['is_active'] ? 'Deactivate' : 'Activate' ?></button></form><?php endif; ?>
          <a class="btn btn-sm" href="<?= url('/users/' . $u['id'] . '/edit') ?>"><?= icon('pencil') ?> Edit</a>
        <?php else: ?><span class="faint small">Super Admin only</span><?php endif; ?></td>
      </tr>
    <?php endforeach; ?></tbody></table></div>
</div>
