<?php use App\Core\Permissions; ?>
<div class="page-head">
  <div><h1>User management</h1><p>What each role can do. Changing a role signs out its users so the new access applies immediately.</p></div>
  <div class="page-actions"><a class="btn btn-primary" href="<?= url('/users/roles/new') ?>"><?= icon('plus') ?> New role</a></div>
</div>
<?php $active = 'roles'; include __DIR__ . '/_tabs.php'; ?>
<div class="grid cols-3 mb">
  <?php foreach ($roles as $r): ?>
    <a class="card role-card" href="<?= url('/users/roles/' . $r['id']) ?>"><div class="card-body">
      <div class="row" style="justify-content:space-between"><strong><?= e($r['name']) ?></strong><?= $r['code'] === 'super_admin' ? badge('Full access', 'violet') : '' ?></div>
      <p class="small muted" style="margin:6px 0"><?= e($r['description'] ?? '') ?></p>
      <span class="small faint"><?= (int) $r['users'] ?> user(s) · <?= $r['code'] === 'super_admin' ? 'all' : (int) $r['perms'] ?> permissions</span>
    </div></a>
  <?php endforeach; ?>
</div>
<div class="card"><div class="card-header"><h2>Permission matrix</h2></div><div class="table-wrap"><table class="table table-compact matrix">
  <thead><tr><th>Permission</th><?php foreach ($roles as $r): ?><th class="center" title="<?= e($r['name']) ?>"><?= e($r['name']) ?></th><?php endforeach; ?></tr></thead>
  <tbody><?php foreach (Permissions::GROUPS as $g => $perms): ?><tr class="group-row"><td colspan="<?= count($roles) + 1 ?>"><?= e($g) ?></td></tr>
    <?php foreach ($perms as $k => $l): ?><tr><td><?= e($l) ?><?= Permissions::isConfidential($k) ? ' <span class="badge red">C</span>' : '' ?></td><?php foreach ($roles as $r): $has = $r['code'] === 'super_admin' || isset($matrix[$r['id']][$k]); ?><td class="center"><?= $has ? '<span class="text-green">' . icon('check') . '</span>' : '<span class="faint">·</span>' ?></td><?php endforeach; ?></tr><?php endforeach; ?>
  <?php endforeach; ?></tbody></table></div></div>
