<?php use App\Core\Permissions; $editing = !empty($r['id']); $v = fn($k) => old($k, $r[$k] ?? ''); $sel = is_array(old('perms')) ? old('perms') : $perms; ?>
<div class="crumbs"><a href="<?= url('/users/roles') ?>">Roles</a> / <?= $editing ? e($r['name']) : 'New' ?></div>
<div class="page-head"><div><h1><?= e($title) ?></h1></div></div>
<form method="post" action="<?= url($editing ? '/users/roles/' . $r['id'] : '/users/roles') ?>" class="card" style="max-width:900px" novalidate>
  <?= csrf_field() ?>
  <div class="form-section"><div class="form-grid">
    <div class="field span-5"><label for="name">Role name<span class="req">*</span></label><input id="name" name="name" value="<?= e($v('name')) ?>" maxlength="60" class="<?= has_error('name') ?>"><?= field_error('name') ?></div>
    <div class="field span-7"><label for="description">Description</label><input id="description" name="description" value="<?= e($v('description')) ?>" maxlength="250"></div>
  </div></div>
  <div class="form-section"><h3>Permissions</h3><?= field_error('perms') ?>
    <?php foreach (Permissions::GROUPS as $g => $list): ?><div class="perm-group"><div class="section-label"><?= e($g) ?></div><div class="perm-checks">
      <?php foreach ($list as $k => $l): ?><label class="check"><input type="checkbox" name="perms[]" value="<?= e($k) ?>" <?= in_array($k, $sel, true) ? 'checked' : '' ?>> <span><?= e($l) ?><?= Permissions::isConfidential($k) ? ' <span class="badge red">Confidential</span>' : '' ?></span></label><?php endforeach; ?>
    </div></div><?php endforeach; ?>
  </div>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url('/users/roles') ?>">Cancel</a><button class="btn btn-primary" type="submit">Save role</button></div>
</form>
