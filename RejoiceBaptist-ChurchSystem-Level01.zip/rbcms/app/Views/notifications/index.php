<div class="page-head">
  <div><h1>Notifications</h1><p>Updates about events, announcements, schedules and records you can access.</p></div>
  <div class="page-actions"><form method="post" action="<?= url('/notifications/read-all') ?>"><?= csrf_field() ?><button class="btn" type="submit"><?= icon('check') ?> Mark all as read</button></form></div>
</div>
<div class="tabs">
  <a href="<?= url('/notifications') ?>" class="<?= $filter === 'all' ? 'active' : '' ?>">All</a>
  <a href="<?= url('/notifications', ['filter' => 'unread']) ?>" class="<?= $filter === 'unread' ? 'active' : '' ?>">Unread</a>
</div>
<div class="card">
  <?php if (!$items): ?>
    <?= App\Core\View::partial('partials/empty', ['icon' => 'bell', 'title' => $filter === 'unread' ? 'No unread notifications' : 'No notifications yet', 'text' => 'You will see updates here when something relevant happens.']) ?>
  <?php else: ?>
    <?php foreach ($items as $n): ?>
      <a class="notif<?= $n['read_at'] ? '' : ' unread' ?>" href="<?= url('/notifications/' . $n['id'] . '/open') ?>">
        <span class="ni"><?= icon($icons[$n['type']] ?? 'bell') ?></span>
        <span><div class="nt"><?= e($n['title']) ?></div><?php if ($n['body']): ?><div class="nb"><?= e($n['body']) ?></div><?php endif; ?>
        <div class="nm"><?= e(time_ago($n['created_at'])) ?> · <?= e(fmt_datetime($n['created_at'])) ?></div></span>
      </a>
    <?php endforeach; ?>
    <?= App\Core\View::partial('partials/pagination', ['p' => $p]) ?>
  <?php endif; ?>
</div>
