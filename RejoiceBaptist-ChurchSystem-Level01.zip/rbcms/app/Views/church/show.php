<?php
$g = fn(string $k) => trim((string) ($s['church.' . $k] ?? ''));
$block = function (string $k, string $hint) use ($g) { $v = $g($k); return $v !== '' ? nl2p($v) : '<p class="not-set">' . e($hint) . '</p>'; };
$logo = setting('church.logo') ? file_url(setting('church.logo')) : asset('img/logo.png');
$manage = can('church.manage');
$hint = $manage ? 'Not set yet — click “Edit information” to add it.' : 'Not set yet.';
?>
<div class="card mb">
  <div class="info-hero">
    <img src="<?= e($logo) ?>" alt="Church logo">
    <div style="flex:1;min-width:0">
      <h1><?= e($g('name') ?: 'Church name not set') ?></h1>
      <p class="muted" style="margin:4px 0 0"><?= $g('founded') ? 'Established ' . e($g('founded')) : '' ?><?= $g('address') ? ($g('founded') ? ' · ' : '') . e($g('address')) : '' ?></p>
      <div class="row mt-sm small muted" style="gap:16px;flex-wrap:wrap">
        <?php if ($g('phone')): ?><span><?= icon('info') ?> <?= e($g('phone')) ?></span><?php endif; ?>
        <?php if ($g('email')): ?><span>✉ <?= e($g('email')) ?></span><?php endif; ?>
        <?php if ($g('facebook')): ?><span>f <?= e($g('facebook')) ?></span><?php endif; ?>
      </div>
    </div>
    <?php if ($manage): ?><a class="btn" href="<?= url('/church/edit') ?>"><?= icon('pencil') ?> Edit information</a><?php endif; ?>
  </div>
</div>
<div class="grid cols-2 mb">
  <div class="card mv"><div class="section-label">Our Mission</div><?= $block('mission', $hint) ?></div>
  <div class="card mv"><div class="section-label">Our Vision</div><?= $block('vision', $hint) ?></div>
</div>
<div class="split">
  <div class="stack">
    <div class="card"><div class="card-header"><h2>Our History</h2></div><div class="card-body prose"><?= $block('history', $hint) ?></div></div>
    <div class="card"><div class="card-header"><h2>What We Believe</h2></div><div class="card-body prose"><?= $block('beliefs', $hint) ?></div></div>
    <?php if ($g('background')): ?><div class="card"><div class="card-header"><h2>Church Background</h2></div><div class="card-body prose"><?= nl2p($g('background')) ?></div></div><?php endif; ?>
    <div class="card">
      <div class="card-header"><h2>Present Ministries</h2><?php if (can('ministries.view')): ?><a class="more" href="<?= url('/ministries') ?>">Manage <?= icon('arrow-right') ?></a><?php endif; ?></div>
      <?php if (!$ministries): ?><div class="empty small">No active ministries recorded yet.</div><?php else: ?>
      <div class="ministry-grid">
        <?php foreach ($ministries as $m): ?>
          <div class="ministry-tile">
            <strong><?= e($m['name']) ?></strong>
            <?php if ($m['description']): ?><p><?= e(mb_strimwidth($m['description'], 0, 140, '…')) ?></p><?php endif; ?>
            <span class="small muted"><?= $m['schedule_day'] !== null ? 'Every ' . e(weekday_name((int) $m['schedule_day'])) . ($m['schedule_start'] ? ', ' . e(time_range($m['schedule_start'], $m['schedule_end'])) : '') : 'No regular schedule' ?> · <?= (int) $m['members'] ?> member<?= (int) $m['members'] === 1 ? '' : 's' ?></span>
          </div>
        <?php endforeach; ?>
      </div><?php endif; ?>
    </div>
    <div class="card">
      <div class="card-header"><h2>Past Events &amp; Activities</h2><a class="more" href="<?= url('/events', ['tab' => 'past']) ?>">All past events <?= icon('arrow-right') ?></a></div>
      <?php if (!$past): ?><div class="empty small">Completed activities such as Youth Jam, VBS, Family Day and anniversaries will be listed here once recorded under Events.</div><?php else: ?>
      <div class="past-grid">
        <?php foreach ($past as $p): ?>
          <a class="past-tile" href="<?= url('/events/' . $p['id']) ?>">
            <?php if ($p['poster_path']): ?><img src="<?= e(file_url($p['poster_path'])) ?>" alt="" loading="lazy"><?php else: ?><span class="past-ph c-<?= e($p['color'] ?? 'slate') ?>"><?= icon('flag') ?></span><?php endif; ?>
            <span class="past-body"><strong><?= e($p['title']) ?></strong><span class="small muted"><?= e(fmt_date($p['start_date'], 'j M Y')) ?><?= $p['category'] ? ' · ' . e($p['category']) : '' ?></span></span>
          </a>
        <?php endforeach; ?>
      </div><?php endif; ?>
    </div>
  </div>
  <div class="stack">
    <div class="card"><div class="card-header"><h2>Worship Services</h2></div><div class="card-body prose"><?= $block('service_times', $hint) ?></div></div>
    <div class="card"><div class="card-header"><h2>Pastors &amp; Leadership</h2></div><div class="card-body prose"><?= $block('leadership', $hint) ?></div></div>
    <div class="card"><div class="card-header"><h2>Coming Up</h2><a class="more" href="<?= url('/calendar') ?>">Calendar</a></div>
      <?php if (!$upcoming): ?><div class="empty small">No upcoming activities.</div><?php else: ?>
      <ul class="list"><?php foreach ($upcoming as $u): ?><li><a href="<?= url('/events/' . $u['id']) ?>" class="strong"><?= e($u['title']) ?></a><span class="sub"><?= e(fmt_date($u['start_date'], 'D, j M Y')) ?><?= $u['start_time'] ? ' · ' . e(fmt_time($u['start_time'])) : '' ?></span></li><?php endforeach; ?></ul><?php endif; ?>
    </div>
    <?php if ($messages): ?><div class="card"><div class="card-header"><h2>Latest Messages</h2><a class="more" href="<?= url('/announcements') ?>">All</a></div>
      <ul class="list"><?php foreach ($messages as $m): ?><li><a class="strong" href="<?= url('/announcements/' . $m['id']) ?>"><?= e($m['title']) ?></a><span class="sub"><?= e(mb_strimwidth(preg_replace('/\s+/', ' ', $m['body']), 0, 110, '…')) ?></span></li><?php endforeach; ?></ul></div><?php endif; ?>
  </div>
</div>
