<?php
/** Searchable member <select>. Vars: $name, $members, $selected, $placeholder, $id, $required, $class */
$id ??= $name; $selected = (int) ($selected ?? 0);
?>
<select id="<?= e($id) ?>" name="<?= e($name) ?>" data-search data-placeholder="<?= e($placeholder ?? 'Search member…') ?>" class="<?= e($class ?? '') ?>" <?= !empty($required) ? 'required' : '' ?>>
  <option value=""><?= e($emptyLabel ?? '— None —') ?></option>
  <?php foreach ($members as $mm): ?>
    <option value="<?= (int) $mm['id'] ?>" data-sub="<?= e($mm['member_code']) ?>" <?= $selected === (int) $mm['id'] ? 'selected' : '' ?>><?= e(member_name($mm, true)) ?></option>
  <?php endforeach; ?>
</select>
