<div class="empty">
  <?= icon($icon ?? 'folder') ?>
  <strong><?= e($title ?? 'Nothing here yet') ?></strong>
  <?php if (!empty($text)): ?><div><?= e($text) ?></div><?php endif; ?>
  <?php if (!empty($action)): ?><a class="btn btn-primary btn-sm" href="<?= e($action[1]) ?>"><?= icon('plus') ?> <?= e($action[0]) ?></a><?php endif; ?>
</div>
