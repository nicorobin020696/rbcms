<?php /** @var App\Core\Paginator $p */ ?>
<div class="table-meta">
  <span>Showing <?= $p->from() ?>–<?= $p->to() ?> of <?= number_format($p->total) ?></span>
  <?php if ($p->pages > 1): ?>
  <nav class="pagination" aria-label="Pages">
    <?php if ($p->page > 1): ?><a href="<?= e(query_with(['page' => $p->page - 1])) ?>" aria-label="Previous"><?= icon('chevron-left') ?></a><?php else: ?><span class="disabled"><?= icon('chevron-left') ?></span><?php endif; ?>
    <?php
    $start = max(1, $p->page - 2); $end = min($p->pages, $p->page + 2);
    if ($start > 1) { echo '<a href="' . e(query_with(['page' => 1])) . '">1</a>' . ($start > 2 ? '<span class="disabled">…</span>' : ''); }
    for ($i = $start; $i <= $end; $i++) {
        echo $i === $p->page ? '<span class="current">' . $i . '</span>' : '<a href="' . e(query_with(['page' => $i])) . '">' . $i . '</a>';
    }
    if ($end < $p->pages) { echo ($end < $p->pages - 1 ? '<span class="disabled">…</span>' : '') . '<a href="' . e(query_with(['page' => $p->pages])) . '">' . $p->pages . '</a>'; }
    ?>
    <?php if ($p->page < $p->pages): ?><a href="<?= e(query_with(['page' => $p->page + 1])) ?>" aria-label="Next"><?= icon('chevron-right') ?></a><?php else: ?><span class="disabled"><?= icon('chevron-right') ?></span><?php endif; ?>
  </nav>
  <?php endif; ?>
</div>
