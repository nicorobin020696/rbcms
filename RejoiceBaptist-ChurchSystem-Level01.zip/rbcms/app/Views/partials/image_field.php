<?php
/**
 * Reusable image upload control: preview, empty state, drag-and-drop, size/type checks, undo.
 * Behaviour lives in public/assets/js/app.js (RBC.ImageField); the field is still a normal file input, so the
 * controllers and Upload service receive the file exactly as before.
 *
 * Variables:
 *   $img_name     file input name (photo, image, poster, logo ...)            required
 *   $img_current  stored path of the current image, or null
 *   $img_remove   name of the "remove current image" checkbox, or null
 *   $img_variant  'square' (default), 'wide' (posters, 16:9) or 'logo' (contained, no cropping)
 *   $img_label    noun shown on the buttons, e.g. 'picture'
 *   $img_empty    text under the empty-state icon
 *   $img_help     help text under the buttons
 *   $img_accept   accepted MIME types
 *   $img_fallback URL of a default image shown while nothing is uploaded (e.g. the default church logo), or null
 */
$img_variant = $img_variant ?? 'square';
$img_label   = $img_label ?? 'image';
$img_empty   = $img_empty ?? 'No ' . $img_label;
$img_accept  = $img_accept ?? 'image/jpeg,image/png,image/webp';
$img_current = $img_current ?? null;
$img_remove  = $img_remove ?? null;
$img_help    = $img_help ?? 'JPG, PNG or WebP, up to ' . (int) config('upload_max_mb') . ' MB.';
$img_fallback = $img_fallback ?? null;
$img_src     = $img_current ? (string) file_url($img_current) : '';
$img_shown   = $img_src !== '' ? $img_src : (string) $img_fallback;
?>
<div class="img-field <?= $img_variant === 'wide' ? 'is-wide' : ($img_variant === 'logo' ? 'is-logo' : 'is-square') ?><?= $img_src !== '' ? ' has-image' : '' ?>"
     data-image-field data-max-mb="<?= (int) config('upload_max_mb') ?>"
     data-pick-label="Upload <?= e($img_label) ?>" data-change-label="Change <?= e($img_label) ?>">
  <div class="img-field-preview">
    <img data-if-img data-original="<?= e($img_src) ?>" data-fallback="<?= e((string) $img_fallback) ?>" src="<?= e($img_shown) ?>" alt="" class="<?= $img_shown === '' ? 'hidden' : '' ?>">
    <span class="img-field-empty <?= $img_shown !== '' ? 'hidden' : '' ?>" data-if-empty><?= icon('image') ?><span><?= e($img_empty) ?></span></span>
  </div>
  <div class="img-field-body">
    <div class="img-field-actions">
      <button type="button" class="btn btn-sm" data-if-pick><?= icon('upload') ?> <?= $img_src !== '' ? 'Change ' : 'Upload ' ?><?= e($img_label) ?></button>
      <button type="button" class="btn btn-sm btn-ghost hidden" data-if-clear>Clear selection</button>
      <?php if ($img_remove): ?><button type="button" class="btn btn-sm btn-ghost <?= $img_src === '' ? 'hidden' : '' ?>" data-if-remove>Remove</button><?php endif; ?>
    </div>
    <p class="img-field-note" data-if-note><?= e($img_help) ?></p>
    <p class="field-error hidden" data-if-error role="alert"></p>
    <?= field_error($img_name) ?>
    <input class="img-field-input" type="file" name="<?= e($img_name) ?>" accept="<?= e($img_accept) ?>" tabindex="-1" data-if-input>
    <?php if ($img_remove): ?><input class="hidden" type="checkbox" name="<?= e($img_remove) ?>" value="1" data-if-remove-input><?php endif; ?>
  </div>
</div>
