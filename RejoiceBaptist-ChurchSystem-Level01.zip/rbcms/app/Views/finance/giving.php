<?php use App\Services\Stats; $months = Stats::monthLabels(); $colTotals = array_fill(0, 12, 0); $grand = 0;
foreach ($grid as $vals) { foreach ($vals as $i => $v) { $colTotals[$i] += $v; } $grand += array_sum($vals); } ?>
<div class="page-head">
  <div><h1>Finance</h1><p>Tithes, offerings, donations and love gifts by month.</p></div>
  <div class="page-actions"><form method="get"><select name="year" data-autosubmit><?php foreach ($years as $y): ?><option <?= (int) $y === $year ? 'selected' : '' ?>><?= e($y) ?></option><?php endforeach; ?></select></form>
    <?php if (can('finance.export')): ?><a class="btn" href="<?= url('/finance/reports/pdf', ['type' => 'giving', 'period' => 'year', 'year' => $year]) ?>" target="_blank"><?= icon('printer') ?> PDF</a><?php endif; ?></div>
</div>
<?php $active = '/finance/giving'; include __DIR__ . '/_tabs.php'; ?>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Total giving · <?= $year ?></div><div class="stat-value"><?= e(money($grand)) ?></div><div class="stat-note"><?= $prevTotal ? (($grand >= $prevTotal ? '+' : '') . round(($grand - $prevTotal) / $prevTotal * 100) . '% vs ' . ($year - 1)) : 'no data for ' . ($year - 1) ?></div></div>
  <?php foreach (array_slice($cats, 0, 3) as $c): ?><div class="stat"><div class="stat-label"><?= e($c['name']) ?></div><div class="stat-value"><?= e(money(array_sum($grid[$c['id']]))) ?></div></div><?php endforeach; ?>
</div>
<div class="grid cols-2 mb">
  <div class="card"><div class="card-header"><h2>Monthly giving — <?= $year ?></h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'stacked' => true, 'money' => true, 'labels' => $months, 'series' => array_map(fn($c) => ['name' => $c['name'], 'values' => $grid[$c['id']]], $cats)]) ?>"></div></div></div>
  <div class="card"><div class="card-header"><h2>Sunday giving — last 12 Sundays</h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'line', 'money' => true, 'labels' => array_map(fn($s) => fmt_date($s['txn_date'], 'j M'), $sundays), 'series' => [['name' => 'Giving', 'values' => array_map(fn($s) => (int) $s['s'], $sundays), 'color' => '#22a061']], 'empty' => 'No Sunday giving recorded.']) ?>"></div></div></div>
</div>
<div class="card"><div class="table-wrap"><table class="table table-compact">
  <thead><tr><th>Type</th><?php foreach ($months as $m): ?><th class="right"><?= $m ?></th><?php endforeach; ?><th class="right">Total</th></tr></thead>
  <tbody><?php foreach ($cats as $c): ?><tr><td class="strong nowrap"><?= e($c['name']) ?></td><?php foreach ($grid[$c['id']] as $v): ?><td class="num small"><?= $v ? e(money($v, false)) : '<span class="faint">—</span>' ?></td><?php endforeach; ?><td class="num strong"><?= e(money(array_sum($grid[$c['id']]), false)) ?></td></tr><?php endforeach; ?></tbody>
  <tfoot><tr><td class="strong">Total</td><?php foreach ($colTotals as $v): ?><td class="num strong small"><?= e(money($v, false)) ?></td><?php endforeach; ?><td class="num strong"><?= e(money($grand)) ?></td></tr></tfoot>
</table></div></div>
