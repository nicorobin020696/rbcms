<div class="callout danger mb" style="padding:8px 12px"><?= icon('lock') ?><div class="small"><strong>Confidential.</strong> Financial records are visible only to authorized finance users. Every export is logged.</div></div>
<div class="tabs">
  <?php foreach (['/finance' => 'Dashboard', '/finance/transactions' => 'Transactions', '/finance/giving' => 'Donations & offerings', '/finance/budgets' => 'Budgets', '/finance/reports' => 'Financial reports'] as $h => $l): ?>
    <a href="<?= url($h) ?>" class="<?= ($active ?? '') === $h ? 'active' : '' ?>"><?= $l ?></a>
  <?php endforeach; ?>
</div>
