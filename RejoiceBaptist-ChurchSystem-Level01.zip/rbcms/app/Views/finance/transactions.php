<?php use App\Core\View; ?>
<div class="page-head">
  <div><h1>Finance</h1><p>All income and expense entries.</p></div>
  <div class="page-actions">
    <?php if (can('finance.export')): ?><a class="btn" href="<?= url('/finance/transactions/export.csv') . e(query_with(['page' => null])) ?>"><?= icon('download') ?> CSV</a><?php endif; ?>
    <?php if (can('finance.manage')): ?><a class="btn btn-primary" href="<?= url('/finance/transactions/new') ?>"><?= icon('plus') ?> Record transaction</a><?php endif; ?>
  </div>
</div>
<?php $active = '/finance/transactions'; include __DIR__ . '/_tabs.php'; ?>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Income (filtered)</div><div class="stat-value text-green"><?= e(money($sum['income'])) ?></div></div>
  <div class="stat"><div class="stat-label">Expenses (filtered)</div><div class="stat-value text-red"><?= e(money($sum['expense'])) ?></div></div>
  <div class="stat"><div class="stat-label">Net</div><div class="stat-value"><?= e(money($sum['income'] - $sum['expense'])) ?></div></div>
  <div class="stat"><div class="stat-label">Entries</div><div class="stat-value"><?= number_format($p->total) ?></div></div>
</div>
<div class="card">
  <form class="filters" method="get">
    <div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="ID, description, payer or reference"></div>
    <select name="type"><option value="">Income &amp; expenses</option><option value="income" <?= query_str('type') === 'income' ? 'selected' : '' ?>>Income</option><option value="expense" <?= query_str('type') === 'expense' ? 'selected' : '' ?>>Expenses</option></select>
    <select name="category"><option value="">All categories</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= input_int('category') === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?> (<?= $c['type'] ?>)</option><?php endforeach; ?></select>
    <select name="ministry"><option value="">Any ministry</option><?php foreach ($ministries as $m): ?><option value="<?= $m['id'] ?>" <?= input_int('ministry') === (int) $m['id'] ? 'selected' : '' ?>><?= e($m['name']) ?></option><?php endforeach; ?></select>
    <select name="status"><option value="active">Active</option><option value="voided" <?= query_str('status') === 'voided' ? 'selected' : '' ?>>Voided</option><option value="all" <?= query_str('status') === 'all' ? 'selected' : '' ?>>All</option></select>
    <input type="date" name="from" value="<?= e(input_date('from')) ?>" title="From"><input type="date" name="to" value="<?= e(input_date('to')) ?>" title="To">
    <button class="btn" type="submit">Filter</button><a class="btn btn-ghost" href="<?= url('/finance/transactions') ?>">Reset</a>
  </form>
  <?php if (!$rows): ?><?= View::partial('partials/empty', ['icon' => 'wallet', 'title' => 'No transactions found', 'text' => 'Record tithes, offerings, donations and expenses here.', 'action' => can('finance.manage') ? ['Record transaction', url('/finance/transactions/new')] : null]) ?>
  <?php else: ?><?= View::partial('finance/_txn_table', ['rows' => $rows]) ?><?= View::partial('partials/pagination', ['p' => $p]) ?><?php endif; ?>
</div>
