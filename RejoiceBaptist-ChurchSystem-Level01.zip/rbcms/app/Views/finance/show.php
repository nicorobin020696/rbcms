<div class="crumbs"><a href="<?= url('/finance/transactions') ?>">Transactions</a> / <?= e($t['txn_code']) ?></div>
<div class="page-head">
  <div><h1><?= e($t['description']) ?><?= sample_tag($t) ?></h1><div class="row" style="margin-top:6px"><span class="code"><?= e($t['txn_code']) ?></span><?= badge(ucfirst($t['txn_type']), $t['txn_type'] === 'income' ? 'green' : 'red') ?><?= $t['voided_at'] ? badge('Voided', 'neutral') : '' ?></div></div>
  <?php if (can('finance.manage') && !$t['voided_at']): ?><div class="page-actions"><button class="btn btn-danger" type="button" data-open-modal="void-modal"><?= icon('x') ?> Void</button><a class="btn btn-primary" href="<?= url('/finance/transactions/' . $t['id'] . '/edit') ?>"><?= icon('pencil') ?> Edit</a></div><?php endif; ?>
</div>
<?php if ($t['voided_at']): ?><div class="callout danger mb"><?= icon('alert') ?><div>Voided on <?= e(fmt_datetime($t['voided_at'])) ?> by <?= e($t['voided_by_name'] ?: '—') ?>. Reason: <?= e($t['void_reason']) ?></div></div><?php endif; ?>
<div class="split">
  <div class="card"><div class="card-body"><dl class="kv">
    <dt>Amount</dt><dd><span style="font-size:20px" class="strong <?= $t['txn_type'] === 'income' ? 'text-green' : 'text-red' ?>"><?= e(money($t['amount_cents'])) ?></span></dd>
    <dt>Date</dt><dd><?= e(fmt_date($t['txn_date'], 'l, j F Y')) ?></dd>
    <dt>Category</dt><dd><?= e($t['category']) ?></dd>
    <dt><?= $t['txn_type'] === 'income' ? 'Received from' : 'Paid to' ?></dt><dd><?= e($t['payer_payee'] ?: '—') ?></dd>
    <dt>Reference / OR no.</dt><dd><?= e($t['reference_no'] ?: '—') ?></dd>
    <dt>Ministry</dt><dd><?= e($t['ministry'] ?: '—') ?></dd>
    <dt>Event</dt><dd><?= e($t['event'] ?: '—') ?></dd>
    <?php if ($t['txn_type'] === 'expense'): ?><dt>Budget</dt><dd><?= $t['budget_id'] ? '<a href="' . url('/finance/budgets/' . $t['budget_id']) . '">' . e($t['budget']) . '</a>' : '—' ?></dd><?php endif; ?>
    <dt>Remarks</dt><dd><?= $t['remarks'] ? nl2br(e($t['remarks'])) : '—' ?></dd>
    <dt>Recorded by</dt><dd class="small"><?= e($t['recorder'] ?: '—') ?> · <?= e(fmt_datetime($t['created_at'])) ?><?= $t['updated_at'] !== $t['created_at'] ? '<br><span class="muted">Edited ' . e(fmt_datetime($t['updated_at'])) . '</span>' : '' ?></dd>
  </dl></div></div>
  <div class="card"><div class="card-header"><h2>Receipt / attachment</h2></div><div class="card-body">
    <?php if (!$t['attachment_path']): ?><p class="muted">No attachment.</p>
    <?php elseif (preg_match('/\.(jpe?g|png|webp|gif)$/i', $t['attachment_path'])): ?><a href="<?= e(file_url($t['attachment_path'])) ?>" target="_blank"><img src="<?= e(file_url($t['attachment_path'])) ?>" alt="Receipt" style="max-width:100%;border:1px solid var(--border);border-radius:6px"></a>
    <?php else: ?><a class="btn" href="<?= e(file_url($t['attachment_path'])) ?>" target="_blank"><?= icon('file') ?> <?= e($t['attachment_name'] ?: 'Open attachment') ?></a><?php endif; ?>
  </div></div>
</div>
<?php if (can('finance.manage') && !$t['voided_at']): ?>
<dialog class="modal" id="void-modal"><form method="post" action="<?= url('/finance/transactions/' . $t['id'] . '/void') ?>"><?= csrf_field() ?>
  <div class="modal-head"><h2>Void <?= e($t['txn_code']) ?>?</h2><button class="icon-btn" type="button" data-close-modal><?= icon('x') ?></button></div>
  <div class="modal-body"><p>Voided transactions stay in the records for auditing but no longer count in balances and reports. This cannot be undone — record a new transaction if needed.</p>
    <div class="field"><label for="reason">Reason<span class="req">*</span></label><input id="reason" name="reason" required maxlength="250" placeholder="e.g. Duplicate entry, wrong amount"></div></div>
  <div class="modal-foot"><button class="btn" type="button" data-close-modal>Cancel</button><button class="btn btn-danger solid" type="submit">Void transaction</button></div>
</form></dialog>
<?php endif; ?>
