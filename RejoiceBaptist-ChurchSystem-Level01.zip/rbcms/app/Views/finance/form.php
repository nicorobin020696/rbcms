<?php $editing = !empty($t['id']); $v = fn($k, $d = '') => old($k, $t[$k] ?? $d); $type = $v('txn_type', 'income');
$amt = old('amount', isset($t['amount_cents']) ? number_format($t['amount_cents'] / 100, 2, '.', ',') : ''); ?>
<div class="crumbs"><a href="<?= url('/finance/transactions') ?>">Transactions</a> / <?= $editing ? e($t['txn_code']) : 'New' ?></div>
<div class="page-head"><div><h1><?= e($title) ?></h1></div></div>
<form method="post" action="<?= url($editing ? '/finance/transactions/' . $t['id'] : '/finance/transactions') ?>" enctype="multipart/form-data" class="card" style="max-width:860px" novalidate data-txn-form>
  <?= csrf_field() ?>
  <div class="card-body"><div class="form-grid">
    <div class="field span-12"><div class="seg seg-lg" role="radiogroup" aria-label="Type">
      <label><input type="radio" name="txn_type" value="income" <?= $type === 'income' ? 'checked' : '' ?>>Income</label>
      <label><input type="radio" name="txn_type" value="expense" <?= $type === 'expense' ? 'checked' : '' ?>>Expense</label></div></div>
    <div class="field span-4"><label for="amount">Amount (₱)<span class="req">*</span></label><input id="amount" name="amount" value="<?= e($amt) ?>" inputmode="decimal" placeholder="0.00" class="<?= has_error('amount') ?> mono" required autofocus><?= field_error('amount') ?></div>
    <div class="field span-4"><label for="txn_date">Date<span class="req">*</span></label><input id="txn_date" type="date" name="txn_date" value="<?= e($v('txn_date')) ?>" max="<?= today() ?>" class="<?= has_error('txn_date') ?>" required><?= field_error('txn_date') ?></div>
    <div class="field span-4"><label for="category_id">Category<span class="req">*</span></label>
      <select id="category_id" name="category_id" class="<?= has_error('category_id') ?>" required><option value="">Select…</option>
        <optgroup label="Income" data-kind="income"><?php foreach ($income as $c): ?><option value="<?= $c['id'] ?>" <?= (int) $v('category_id') === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></optgroup>
        <optgroup label="Expenses" data-kind="expense"><?php foreach ($expense as $c): ?><option value="<?= $c['id'] ?>" <?= (int) $v('category_id') === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></optgroup>
      </select><?= field_error('category_id') ?></div>
    <div class="field span-8"><label for="description">Description<span class="req">*</span></label><input id="description" name="description" value="<?= e($v('description')) ?>" maxlength="200" placeholder="e.g. Sunday tithes and offerings" class="<?= has_error('description') ?>" required><?= field_error('description') ?></div>
    <div class="field span-4"><label for="reference_no">Reference / OR no.</label><input id="reference_no" name="reference_no" value="<?= e($v('reference_no')) ?>" maxlength="60"></div>
    <div class="field span-6"><label for="payer_payee"><span data-when="income">Received from</span><span data-when="expense">Paid to</span></label><input id="payer_payee" name="payer_payee" value="<?= e($v('payer_payee')) ?>" maxlength="150" placeholder="Optional"></div>
    <div class="field span-6"><label for="ministry_id">Ministry</label><select id="ministry_id" name="ministry_id"><option value="">—</option><?php foreach ($ministries as $m): ?><option value="<?= $m['id'] ?>" <?= (int) $v('ministry_id') === (int) $m['id'] ? 'selected' : '' ?>><?= e($m['name']) ?></option><?php endforeach; ?></select></div>
    <div class="field span-6"><label for="event_id">Event</label><select id="event_id" name="event_id"><option value="">—</option><?php foreach ($events as $ev): ?><option value="<?= $ev['id'] ?>" <?= (int) $v('event_id') === (int) $ev['id'] ? 'selected' : '' ?>><?= e($ev['title']) ?> · <?= e(fmt_date($ev['start_date'], 'M Y')) ?></option><?php endforeach; ?></select></div>
    <div class="field span-6" data-when="expense"><label for="budget_id">Charge to budget</label><select id="budget_id" name="budget_id"><option value="">—</option><?php foreach ($budgets as $b): ?><option value="<?= $b['id'] ?>" <?= (int) $v('budget_id') === (int) $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?> (<?= e($b['budget_code']) ?>)</option><?php endforeach; ?></select></div>
    <div class="field span-12"><label for="remarks">Remarks</label><textarea id="remarks" name="remarks" rows="2" maxlength="1000"><?= e($v('remarks')) ?></textarea></div>
    <div class="field span-12"><label>Receipt / attachment <span class="muted">(image or PDF)</span></label><input type="file" name="attachment" accept="image/jpeg,image/png,image/webp,application/pdf"><?= field_error('attachment') ?>
      <?php if (!empty($t['attachment_path'])): ?><label class="check small mt-sm"><input type="checkbox" name="remove_attachment" value="1"> Remove current attachment (<?= e($t['attachment_name'] ?: 'file') ?>)</label><?php endif; ?></div>
  </div></div>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url($editing ? '/finance/transactions/' . $t['id'] : '/finance/transactions') ?>">Cancel</a>
    <?php if (!$editing): ?><button class="btn" type="submit" name="again" value="1">Save &amp; add another</button><?php endif; ?>
    <button class="btn btn-primary" type="submit">Save</button></div>
</form>
