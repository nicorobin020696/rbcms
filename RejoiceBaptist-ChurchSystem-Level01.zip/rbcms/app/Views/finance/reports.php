<?php use App\Controllers\FinanceReportsController as FR; $q = ['type' => $type, 'period' => $mode, 'month' => query_str('month') ?: null, 'year' => input_int('year'), 'from' => input_date('from'), 'to' => input_date('to')]; ?>
<div class="page-head">
  <div><h1>Finance</h1><p>Choose a report and period. PDFs are marked confidential and every export is logged.</p></div>
  <?php if (can('finance.export')): ?><div class="page-actions"><a class="btn" href="<?= url('/finance/reports/csv', array_filter($q)) ?>"><?= icon('download') ?> CSV</a><a class="btn btn-primary" href="<?= url('/finance/reports/pdf', array_filter($q)) ?>" target="_blank"><?= icon('printer') ?> PDF</a></div><?php endif; ?>
</div>
<?php $active = '/finance/reports'; include __DIR__ . '/_tabs.php'; ?>
<div class="report-layout">
  <div class="card report-menu"><ul class="list"><?php foreach (FR::TYPES as $k => $l): ?><li class="<?= $type === $k ? 'active' : '' ?>"><a href="<?= url('/finance/reports', array_filter(array_merge($q, ['type' => $k]))) ?>"><?= e($l) ?></a></li><?php endforeach; ?></ul></div>
  <div class="stack">
    <form class="card filters" method="get" style="border-radius:var(--radius)"><input type="hidden" name="type" value="<?= e($type) ?>">
      <select name="period" data-period><option value="month">Monthly</option><option value="year" <?= $mode === 'year' ? 'selected' : '' ?>>Annual</option><option value="custom" <?= $mode === 'custom' ? 'selected' : '' ?>>Custom range</option></select>
      <input type="month" name="month" value="<?= e(substr($from, 0, 7)) ?>" data-for="month">
      <input type="number" name="year" value="<?= e(substr($from, 0, 4)) ?>" min="2000" max="2100" style="width:100px" data-for="year">
      <input type="date" name="from" value="<?= e($from) ?>" data-for="custom"><input type="date" name="to" value="<?= e($to) ?>" data-for="custom">
      <button class="btn" type="submit">Show report</button>
    </form>
    <div class="card">
      <div class="card-header"><div><h2><?= e(FR::TYPES[$type]) ?></h2><span class="muted small"><?= e($label) ?></span></div><?= badge('Confidential', 'red') ?></div>
      <div class="card-body">
        <div class="stats mb"><?php foreach ($report['summary'] as [$k, $v]): ?><div class="stat"><div class="stat-label"><?= e($k) ?></div><div class="stat-value" style="font-size:18px"><?= e($v) ?></div></div><?php endforeach; ?></div>
        <?php if (!empty($report['note'])): ?><p class="help"><?= e($report['note']) ?></p><?php endif; ?>
        <?php foreach ($report['tables'] as [$h, $cols, $rows, $totals]): ?>
          <h3 class="section-label mt"><?= e($h) ?></h3>
          <?php if (!$rows): ?><div class="empty small">No transactions in this period.</div><?php else: ?>
          <div class="table-wrap"><table class="table table-compact"><thead><tr><?php foreach ($cols as $c): ?><th class="<?= ($c[2] ?? 'L') === 'R' ? 'right' : '' ?>"><?= e($c[0]) ?></th><?php endforeach; ?></tr></thead>
            <tbody><?php foreach ($rows as $r): ?><tr><?php foreach ($r as $i => $cell): ?><td class="<?= ($cols[$i][2] ?? 'L') === 'R' ? 'num' : '' ?>"><?= e((string) $cell) ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody>
            <tfoot><tr><?php foreach ($totals as $i => $cell): ?><td class="strong <?= ($cols[$i][2] ?? 'L') === 'R' ? 'num' : '' ?>"><?= e((string) $cell) ?></td><?php endforeach; ?></tr></tfoot></table></div>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
