<div class="page-head">
  <div><h1>Finance</h1><p>Planned amounts vs actual spending. Link expenses to a budget when recording them.</p></div>
  <?php if (can('finance.manage')): ?><div class="page-actions"><a class="btn btn-primary" href="<?= url('/finance/budgets/new') ?>"><?= icon('plus') ?> New budget</a></div><?php endif; ?>
</div>
<?php $active = '/finance/budgets'; include __DIR__ . '/_tabs.php'; ?>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Planned</div><div class="stat-value"><?= e(money($planned)) ?></div></div>
  <div class="stat"><div class="stat-label">Spent</div><div class="stat-value"><?= e(money($spent)) ?></div></div>
  <div class="stat"><div class="stat-label">Remaining</div><div class="stat-value <?= $planned - $spent < 0 ? 'text-red' : '' ?>"><?= e(money($planned - $spent)) ?></div></div>
  <div class="stat"><div class="stat-label">Utilization</div><div class="stat-value"><?= $planned ? round($spent / $planned * 100) . '%' : '—' ?></div></div>
</div>
<div class="card">
  <div class="filters"><div class="seg-tabs"><?php foreach (['active' => 'Active', 'closed' => 'Closed', 'all' => 'All'] as $k => $l): ?><a href="<?= url('/finance/budgets', ['status' => $k === 'active' ? null : $k]) ?>" class="<?= $status === $k ? 'active' : '' ?>"><?= $l ?></a><?php endforeach; ?></div></div>
  <?php if (!$list): ?><div class="empty"><?= icon('pie') ?><strong>No budgets</strong>Create budgets for ministries, events or the whole year.</div><?php else: ?>
  <div class="table-wrap"><table class="table"><thead><tr><th>Budget</th><th>Period</th><th class="right">Planned</th><th class="right">Spent</th><th style="width:180px">Utilization</th><th>Status</th></tr></thead><tbody>
  <?php foreach ($list as $b): $u = $b['amount_cents'] ? $b['spent'] / $b['amount_cents'] * 100 : 0; ?>
    <tr class="clickable" data-href="<?= url('/finance/budgets/' . $b['id']) ?>"><td><a class="title-cell" href="<?= url('/finance/budgets/' . $b['id']) ?>"><?= e($b['name']) ?></a><?= sample_tag($b) ?><span class="sub"><span class="code"><?= e($b['budget_code']) ?></span><?= $b['ministry'] ? ' · ' . e($b['ministry']) : '' ?><?= $b['event'] ? ' · ' . e($b['event']) : '' ?></span></td>
      <td class="nowrap small"><?= e(fmt_date($b['period_start'], 'j M Y')) ?> – <?= e(fmt_date($b['period_end'], 'j M Y')) ?></td>
      <td class="num"><?= e(money($b['amount_cents'])) ?></td><td class="num"><?= e(money($b['spent'])) ?></td>
      <td><div class="progress <?= $u > 100 ? 'red' : ($u > 85 ? 'amber' : 'green') ?>"><span style="width:<?= min(100, round($u)) ?>%"></span></div><span class="sub <?= $u > 100 ? 'text-red' : '' ?>"><?= round($u) ?>%</span></td>
      <td><?= status_badge($b['status']) ?></td></tr>
  <?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
