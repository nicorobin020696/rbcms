<?php use App\Services\Stats; $pct = fn($a, $b) => $b ? (($a - $b) / $b * 100) : null; $chg = function ($v) { if ($v === null) return 'no data last month'; return ($v >= 0 ? '+' : '') . round($v) . '% vs last month'; }; ?>
<div class="page-head">
  <div><h1>Finance</h1><p>Church funds overview. Totals exclude voided transactions.</p></div>
  <div class="page-actions">
    <form method="get"><select name="year" data-autosubmit><?php foreach ($years as $y): ?><option <?= (int) $y === $year ? 'selected' : '' ?>><?= e($y) ?></option><?php endforeach; ?></select></form>
    <?php if (can('finance.manage')): ?><a class="btn" href="<?= url('/finance/transactions/new', ['type' => 'expense']) ?>"><?= icon('arrow-up') ?> Record expense</a><a class="btn btn-primary" href="<?= url('/finance/transactions/new', ['type' => 'income']) ?>"><?= icon('arrow-down') ?> Record income</a><?php endif; ?>
  </div>
</div>
<?php $active = '/finance'; include __DIR__ . '/_tabs.php'; ?>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Fund balance</div><div class="stat-value"><?= e(money($balance)) ?></div><div class="stat-note">all recorded income − expenses</div></div>
  <div class="stat"><div class="stat-label">Income · <?= date('F') ?></div><div class="stat-value text-green"><?= e(money($month['income'])) ?></div><div class="stat-note"><?= $chg($pct($month['income'], $prev['income'])) ?></div></div>
  <div class="stat"><div class="stat-label">Expenses · <?= date('F') ?></div><div class="stat-value text-red"><?= e(money($month['expense'])) ?></div><div class="stat-note"><?= $chg($pct($month['expense'], $prev['expense'])) ?></div></div>
  <div class="stat"><div class="stat-label">Net · <?= $year ?></div><div class="stat-value"><?= e(money($yearTotals['net'])) ?></div><div class="stat-note"><?= e(money($yearTotals['income'])) ?> in · <?= e(money($yearTotals['expense'])) ?> out</div></div>
</div>
<div class="split-wide mb">
  <div class="card"><div class="card-header"><h2>Income vs expenses — <?= $year ?></h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'money' => true, 'labels' => Stats::monthLabels(), 'series' => [['name' => 'Income', 'values' => $monthly['income'], 'color' => '#22a061'], ['name' => 'Expenses', 'values' => $monthly['expense'], 'color' => '#d9423a']]]) ?>"></div>
  </div></div>
  <div class="card"><div class="card-header"><h2>Budgets</h2><a class="more" href="<?= url('/finance/budgets') ?>">All</a></div>
    <?php if (!$budgets): ?><div class="empty small">No active budgets.</div><?php else: ?><ul class="list"><?php foreach ($budgets as $b): $u = $b['amount_cents'] ? $b['spent'] / $b['amount_cents'] * 100 : 0; ?>
      <li><div class="row" style="justify-content:space-between"><a class="strong" href="<?= url('/finance/budgets/' . $b['id']) ?>"><?= e($b['name']) ?></a><span class="small <?= $u > 100 ? 'text-red' : 'muted' ?>"><?= round($u) ?>%</span></div>
        <div class="progress <?= $u > 100 ? 'red' : ($u > 85 ? 'amber' : 'green') ?>" style="margin:6px 0 3px"><span style="width:<?= min(100, round($u)) ?>%"></span></div>
        <span class="sub"><?= e(money($b['spent'])) ?> of <?= e(money($b['amount_cents'])) ?></span></li>
    <?php endforeach; ?></ul><?php endif; ?>
  </div>
</div>
<div class="grid cols-3">
  <div class="card"><div class="card-header"><h2>Income by category — <?= $year ?></h2></div><div class="card-body"><div class="chart" data-chart="<?= json_attr(['type' => 'hbar', 'money' => true, 'labels' => array_column($byIncome, 'name'), 'series' => [['name' => 'Income', 'values' => array_map('intval', array_column($byIncome, 'total')), 'color' => '#22a061']], 'empty' => 'No income recorded.']) ?>"></div></div></div>
  <div class="card"><div class="card-header"><h2>Expenses by category — <?= $year ?></h2></div><div class="card-body"><div class="chart" data-chart="<?= json_attr(['type' => 'hbar', 'money' => true, 'labels' => array_column($byExpense, 'name'), 'series' => [['name' => 'Expenses', 'values' => array_map('intval', array_column($byExpense, 'total')), 'color' => '#d9423a']], 'empty' => 'No expenses recorded.']) ?>"></div></div></div>
  <div class="card"><div class="card-header"><h2>Recent transactions</h2><a class="more" href="<?= url('/finance/transactions') ?>">All</a></div><?= App\Core\View::partial('finance/_txn_table', ['rows' => $recent]) ?></div>
</div>
