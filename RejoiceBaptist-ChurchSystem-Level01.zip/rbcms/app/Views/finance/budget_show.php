<?php $u = $b['amount_cents'] ? $b['spent'] / $b['amount_cents'] * 100 : 0; ?>
<div class="crumbs"><a href="<?= url('/finance/budgets') ?>">Budgets</a> / <?= e($b['budget_code']) ?></div>
<div class="page-head">
  <div><h1><?= e($b['name']) ?><?= sample_tag($b) ?></h1><p><?= e(fmt_date($b['period_start'])) ?> – <?= e(fmt_date($b['period_end'])) ?><?= $b['ministry'] ? ' · ' . e($b['ministry']) : '' ?><?= $b['event'] ? ' · ' . e($b['event']) : '' ?> · <?= status_badge($b['status']) ?></p></div>
  <?php if (can('finance.manage')): ?><div class="page-actions"><a class="btn" href="<?= url('/finance/transactions/new', ['type' => 'expense', 'budget' => $b['id']]) ?>"><?= icon('plus') ?> Add expense</a><a class="btn btn-primary" href="<?= url('/finance/budgets/' . $b['id'] . '/edit') ?>"><?= icon('pencil') ?> Edit</a></div><?php endif; ?>
</div>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Planned</div><div class="stat-value"><?= e(money($b['amount_cents'])) ?></div></div>
  <div class="stat"><div class="stat-label">Spent</div><div class="stat-value"><?= e(money($b['spent'])) ?></div></div>
  <div class="stat"><div class="stat-label">Remaining</div><div class="stat-value <?= $b['amount_cents'] - $b['spent'] < 0 ? 'text-red' : 'text-green' ?>"><?= e(money($b['amount_cents'] - $b['spent'])) ?></div></div>
  <div class="stat"><div class="stat-label">Used</div><div class="stat-value"><?= round($u) ?>%</div><div class="progress <?= $u > 100 ? 'red' : ($u > 85 ? 'amber' : 'green') ?>" style="margin-top:6px"><span style="width:<?= min(100, round($u)) ?>%"></span></div></div>
</div>
<?php if ($b['notes']): ?><div class="callout info mb"><?= icon('info') ?><div><?= nl2br(e($b['notes'])) ?></div></div><?php endif; ?>
<div class="split-wide">
  <div class="card"><div class="card-header"><h2>Linked transactions</h2></div><?= App\Core\View::partial('finance/_txn_table', ['rows' => $txns]) ?></div>
  <div class="card"><div class="card-header"><h2>Spending by category</h2></div><div class="card-body"><div class="chart" data-chart="<?= json_attr(['type' => 'hbar', 'money' => true, 'labels' => array_column($byCat, 'name'), 'series' => [['name' => 'Spent', 'values' => array_map('intval', array_column($byCat, 'total')), 'color' => '#d9423a']], 'empty' => 'No expenses yet.']) ?>"></div></div></div>
</div>
