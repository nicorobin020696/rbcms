<?php if (!$rows): ?><div class="empty small">No transactions.</div><?php else: ?>
<div class="table-wrap"><table class="table">
  <thead><tr><th>Date</th><th>Description</th><th>Category</th><th class="right">Amount</th></tr></thead>
  <tbody><?php foreach ($rows as $t): ?>
    <tr class="clickable <?= $t['voided_at'] ? 'voided' : '' ?>" data-href="<?= url('/finance/transactions/' . $t['id']) ?>">
      <td class="nowrap"><?= e(fmt_date($t['txn_date'])) ?><span class="sub code"><?= e($t['txn_code']) ?></span></td>
      <td><a class="title-cell" href="<?= url('/finance/transactions/' . $t['id']) ?>"><?= e($t['description']) ?></a><?= sample_tag($t) ?><?= $t['voided_at'] ? ' ' . badge('Voided', 'neutral') : '' ?><?= $t['attachment_path'] ? ' <span class="faint" title="Has attachment">' . icon('clip') . '</span>' : '' ?><?= !empty($t['payer_payee']) ? '<span class="sub">' . e($t['payer_payee']) . '</span>' : '' ?></td>
      <td><?= e($t['category']) ?></td>
      <td class="num strong <?= $t['txn_type'] === 'income' ? 'text-green' : 'text-red' ?>"><?= $t['txn_type'] === 'income' ? '+' : '−' ?><?= e(money($t['amount_cents'])) ?></td>
    </tr><?php endforeach; ?></tbody></table></div>
<?php endif; ?>
