<?php $editing = !empty($b['id']); $v = fn($k, $d = '') => old($k, $b[$k] ?? $d); $amt = old('amount', isset($b['amount_cents']) ? number_format($b['amount_cents'] / 100, 2, '.', ',') : ''); ?>
<div class="crumbs"><a href="<?= url('/finance/budgets') ?>">Budgets</a> / <?= $editing ? e($b['budget_code']) : 'New' ?></div>
<div class="page-head"><div><h1><?= e($title) ?></h1></div></div>
<form method="post" action="<?= url($editing ? '/finance/budgets/' . $b['id'] : '/finance/budgets') ?>" class="card" style="max-width:760px" novalidate>
  <?= csrf_field() ?>
  <div class="card-body"><div class="form-grid">
    <div class="field span-8"><label for="name">Budget name<span class="req">*</span></label><input id="name" name="name" value="<?= e($v('name')) ?>" maxlength="150" class="<?= has_error('name') ?>" required><?= field_error('name') ?></div>
    <div class="field span-4"><label for="amount">Planned amount (₱)<span class="req">*</span></label><input id="amount" name="amount" value="<?= e($amt) ?>" inputmode="decimal" class="mono <?= has_error('amount') ?>" required><?= field_error('amount') ?></div>
    <div class="field span-4"><label for="period_start">From<span class="req">*</span></label><input id="period_start" type="date" name="period_start" value="<?= e($v('period_start')) ?>" class="<?= has_error('period_start') ?>"><?= field_error('period_start') ?></div>
    <div class="field span-4"><label for="period_end">To<span class="req">*</span></label><input id="period_end" type="date" name="period_end" value="<?= e($v('period_end')) ?>" class="<?= has_error('period_end') ?>"><?= field_error('period_end') ?></div>
    <div class="field span-4"><label for="status">Status</label><select id="status" name="status"><option value="active">Active</option><option value="closed" <?= $v('status') === 'closed' ? 'selected' : '' ?>>Closed</option></select></div>
    <div class="field span-6"><label for="ministry_id">Ministry</label><select id="ministry_id" name="ministry_id"><option value="">— Whole church —</option><?php foreach ($ministries as $m): ?><option value="<?= $m['id'] ?>" <?= (int) $v('ministry_id') === (int) $m['id'] ? 'selected' : '' ?>><?= e($m['name']) ?></option><?php endforeach; ?></select></div>
    <div class="field span-6"><label for="event_id">Event</label><select id="event_id" name="event_id"><option value="">—</option><?php foreach ($events as $ev): ?><option value="<?= $ev['id'] ?>" <?= (int) $v('event_id') === (int) $ev['id'] ? 'selected' : '' ?>><?= e($ev['title']) ?> · <?= e(fmt_date($ev['start_date'], 'M Y')) ?></option><?php endforeach; ?></select></div>
    <div class="field span-12"><label for="notes">Notes</label><textarea id="notes" name="notes" rows="3" maxlength="1000"><?= e($v('notes')) ?></textarea></div>
  </div></div>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url($editing ? '/finance/budgets/' . $b['id'] : '/finance/budgets') ?>">Cancel</a><button class="btn btn-primary" type="submit">Save budget</button></div>
</form>
