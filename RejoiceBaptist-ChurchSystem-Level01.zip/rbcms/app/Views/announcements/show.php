<div class="crumbs"><a href="<?= url('/announcements') ?>">Announcements</a> / <?= e(mb_strimwidth($a['title'], 0, 50, '…')) ?></div>
<div class="page-head">
  <div><h1><?= e($a['title']) ?><?= sample_tag($a) ?></h1><p><?= e($a['author'] ?: '—') ?> · <?= e(fmt_datetime($a['published_at'] ?: $a['updated_at'])) ?> <?= $a['is_pinned'] ? badge('Pinned', 'amber') : '' ?> <?= status_badge($a['status']) ?></p></div>
  <?php if (can('announcements.manage')): ?>
  <div class="page-actions">
    <?php $act = function (string $action, string $label, string $icon, string $extra = '') use ($a) { return '<form method="post" action="' . url('/announcements/' . $a['id'] . '/status') . '" ' . $extra . '>' . csrf_field() . '<input type="hidden" name="action" value="' . $action . '"><button class="btn" type="submit">' . icon($icon) . ' ' . $label . '</button></form>'; }; ?>
    <?php if ($a['status'] === 'published'): ?><?= $act($a['is_pinned'] ? 'unpin' : 'pin', $a['is_pinned'] ? 'Unpin' : 'Pin', 'pin') ?><?= $act('archive', 'Archive', 'archive', 'data-confirm="Archive this announcement? It will no longer be shown to users." data-confirm-ok="Archive"') ?>
    <?php else: ?><?= $act('publish', 'Publish', 'megaphone') ?><?php endif; ?>
    <a class="btn btn-primary" href="<?= url('/announcements/' . $a['id'] . '/edit') ?>"><?= icon('pencil') ?> Edit</a>
  </div>
  <?php endif; ?>
</div>
<div class="card" style="max-width:820px">
  <?php if ($a['image_path']): ?><img src="<?= e(file_url($a['image_path'])) ?>" alt="" style="width:100%;display:block;border-radius:var(--radius) var(--radius) 0 0"><?php endif; ?>
  <div class="card-body prose"><?= nl2p($a['body']) ?></div>
</div>
