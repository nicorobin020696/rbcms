<?php use App\Core\View; $manage = can('announcements.manage'); ?>
<div class="page-head">
  <div><h1>Announcements</h1><p>Church announcements, reminders and free messages for everyone using the system.</p></div>
  <?php if ($manage): ?><div class="page-actions"><a class="btn btn-primary" href="<?= url('/announcements/new') ?>"><?= icon('plus') ?> New announcement</a></div><?php endif; ?>
</div>
<?php if ($manage): ?><div class="tabs"><?php foreach (['published' => 'Published', 'draft' => 'Drafts', 'archived' => 'Archived'] as $k => $l): ?><a class="<?= $tab === $k ? 'active' : '' ?>" href="<?= url('/announcements', ['tab' => $k === 'published' ? null : $k]) ?>"><?= $l ?><span class="count"><?= (int) ($counts[$k] ?? 0) ?></span></a><?php endforeach; ?></div><?php endif; ?>
<form class="filters card mb" method="get" style="border-radius:var(--radius)"><?php if ($tab !== 'published'): ?><input type="hidden" name="tab" value="<?= e($tab) ?>"><?php endif; ?><div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="Search announcements"></div></form>
<?php if (!$items): ?>
  <div class="card"><?= View::partial('partials/empty', ['icon' => 'megaphone', 'title' => 'No announcements', 'text' => 'Nothing to show here yet.', 'action' => $manage ? ['New announcement', url('/announcements/new')] : null]) ?></div>
<?php else: ?>
<div class="stack">
<?php foreach ($items as $a): ?>
  <a class="card announce-card" href="<?= url('/announcements/' . $a['id']) ?>">
    <?php if ($a['image_path']): ?><img src="<?= e(file_url($a['image_path'])) ?>" alt="" loading="lazy"><?php endif; ?>
    <div class="card-body">
      <div class="row" style="gap:6px;margin-bottom:4px"><?= $a['is_pinned'] ? badge('Pinned', 'amber') : '' ?><?= $a['status'] !== 'published' ? status_badge($a['status']) : '' ?><?= sample_tag($a) ?></div>
      <h2 class="announce-title"><?= e($a['title']) ?></h2>
      <p class="muted small"><?= e($a['author'] ?: '—') ?> · <?= e(fmt_datetime($a['published_at'] ?: $a['updated_at'])) ?></p>
      <p class="announce-excerpt"><?= e(mb_strimwidth(preg_replace('/\s+/', ' ', $a['body']), 0, 260, '…')) ?></p>
    </div>
  </a>
<?php endforeach; ?>
</div>
<?= View::partial('partials/pagination', ['p' => $p]) ?>
<?php endif; ?>
