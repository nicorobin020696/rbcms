<!doctype html>
<html lang="en" data-theme="light" data-theme-pref="<?= e(setting('app.default_theme', 'system')) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e(($title ?? 'Sign in') . ' · ' . setting('church.name', 'Rejoice Baptist Church')) ?></title>
<link rel="icon" href="<?= asset('img/favicon.png') ?>">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
<script src="<?= asset('js/theme.js') ?>"></script>
</head>
<body>
<?= $content ?>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
