<?php
use App\Core\Auth;
use App\Core\Nav;
use App\Core\Notify;
use App\Services\Calendar;

$u = Auth::user();
$theme = $u['theme'] ?? 'system';
$unread = Notify::unreadCount((int) $u['id']);
$churchName = setting('church.name', 'Rejoice Baptist Church');
$next = can('calendar.view') ? Calendar::nextUpcoming() : null;
$logo = setting('church.logo') ? file_url(setting('church.logo')) : asset('img/logo-128.png');
?><!doctype html>
<html lang="en" data-theme="<?= e($theme === 'system' ? 'light' : $theme) ?>" data-theme-pref="<?= e($theme) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= e(App\Core\Csrf::token()) ?>">
<meta name="base-url" content="<?= e(base_url()) ?>">
<title><?= e(($title ?? 'Dashboard') . ' · ' . $churchName) ?></title>
<link rel="icon" href="<?= asset('img/favicon.png') ?>">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
<script src="<?= asset('js/theme.js') ?>"></script>
</head>
<body>
<div class="app" id="app">
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="<?= url('/') ?>" style="text-decoration:none">
      <img src="<?= e($logo) ?>" alt="">
      <div class="brand-text">
        <div class="brand-name"><?= e($churchName) ?></div>
        <div class="brand-sub">Church Management System</div>
      </div>
    </a>
    <nav class="nav" aria-label="Main navigation">
      <?php foreach (Nav::groups() as $label => $items): ?>
        <div class="nav-label"><?= e($label) ?></div>
        <?php foreach ($items as [$text, $href, $ico]): ?>
          <a href="<?= url($href) ?>" class="<?= Nav::isActive($href) ? 'active' : '' ?>" title="<?= e($text) ?>">
            <?= icon($ico) ?><span><?= e($text) ?></span>
            <?php if ($href === '/notifications' && $unread): ?><span class="count"><?= $unread ?></span><?php endif; ?>
          </a>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-user dropdown" data-dropdown>
      <button class="user-button" type="button" data-dropdown-toggle aria-haspopup="true">
        <span class="avatar"><?= e(initials($u['full_name'])) ?></span>
        <span class="user-meta"><strong><?= e($u['full_name']) ?></strong><span><?= e($u['role_name']) ?></span></span>
        <?= icon('chevrons') ?>
      </button>
      <div class="dropdown-panel up">
        <div style="padding:10px 12px;border-bottom:1px solid var(--border)">
          <strong style="display:block;font-size:13px"><?= e($u['full_name']) ?></strong>
          <span class="muted small"><?= e($u['username']) ?> · <?= e($u['role_name']) ?></span>
        </div>
        <div style="padding:4px 0">
          <a class="menu-item" href="<?= url('/profile') ?>"><?= icon('user') ?> Profile &amp; appearance</a>
          <a class="menu-item" href="<?= url('/password') ?>"><?= icon('key') ?> Change password</a>
          <div class="menu-sep"></div>
          <button class="menu-item" type="button" data-open-modal="logout-modal"><?= icon('logout') ?> Sign out</button>
        </div>
      </div>
    </div>
  </aside>

  <div class="main">
    <header class="topbar">
      <button class="icon-btn menu-toggle" type="button" data-nav-toggle aria-label="Open menu"><?= icon('menu') ?></button>
      <button class="icon-btn hide-sm" type="button" data-collapse-toggle aria-label="Collapse sidebar" title="Collapse sidebar"><?= icon('panel') ?></button>
      <div class="topbar-context">
        <strong><?= e(date('l')) ?></strong><span><?= e(date('j F Y')) ?></span>
        <?php if ($next): ?>
          <span class="sep hide-sm"></span>
          <span class="hide-sm">Next: <a href="<?= url('/calendar', ['view' => 'day', 'date' => $next['date']]) ?>" style="color:var(--text);font-weight:600"><?= e($next['title']) ?></a>
            · <?= e(fmt_date($next['date'], 'D j M')) ?><?= $next['start_time'] ? ', ' . e(fmt_time($next['start_time'])) : '' ?>
            · <?= e(App\Services\Calendar::relative($next['date'])) ?></span>
        <?php endif; ?>
      </div>
      <div class="topbar-actions">
        <button class="icon-btn" type="button" data-theme-toggle title="Switch light / dark mode" aria-label="Switch theme">
          <span class="theme-icon-light"><?= icon('sun') ?></span><span class="theme-icon-dark hidden"><?= icon('moon') ?></span>
        </button>
        <div class="dropdown" data-dropdown data-notifications>
          <button class="icon-btn" type="button" data-dropdown-toggle aria-label="Notifications" title="Notifications">
            <?= icon('bell') ?><?php if ($unread): ?><span class="dot-count" data-unread><?= $unread > 99 ? '99+' : $unread ?></span><?php endif; ?>
          </button>
          <div class="dropdown-panel notif-panel">
            <div class="notif-head"><strong>Notifications</strong><button class="link-btn small" type="button" data-mark-all>Mark all read</button></div>
            <div class="notif-list" data-notif-list><div class="empty small" style="padding:24px">Loading…</div></div>
            <a class="notif-foot" href="<?= url('/notifications') ?>" style="display:block;border-top:1px solid var(--border)">View all notifications</a>
          </div>
        </div>
      </div>
    </header>

    <main class="content<?= !empty($narrow) ? ' narrow' : '' ?>" id="content">
      <?= $content ?>
    </main>
  </div>
</div>

<dialog class="modal" id="logout-modal">
  <form method="post" action="<?= url('/logout') ?>">
    <?= csrf_field() ?>
    <div class="modal-head"><h2>Sign out?</h2><button class="icon-btn" type="button" data-close-modal aria-label="Close"><?= icon('x') ?></button></div>
    <div class="modal-body">You will need your username and password to sign in again.</div>
    <div class="modal-foot"><button class="btn" type="button" data-close-modal>Cancel</button><button class="btn btn-primary" type="submit"><?= icon('logout') ?> Sign out</button></div>
  </form>
</dialog>

<dialog class="modal" id="confirm-modal">
  <div class="modal-head"><h2 data-confirm-title>Please confirm</h2><button class="icon-btn" type="button" data-close-modal aria-label="Close"><?= icon('x') ?></button></div>
  <div class="modal-body" data-confirm-text></div>
  <div class="modal-foot"><button class="btn" type="button" data-close-modal>Cancel</button><button class="btn btn-primary" type="button" data-confirm-ok>Confirm</button></div>
</dialog>

<div class="toasts" id="toasts">
  <?php foreach (take_flashes() as $f): ?>
    <div class="toast <?= e($f['type']) ?>" role="status"><span><?= e($f['message']) ?></span><button class="icon-btn" type="button" data-dismiss aria-label="Dismiss"><?= icon('x') ?></button></div>
  <?php endforeach; ?>
</div>
<script src="<?= asset('js/charts.js') ?>"></script>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
