<div class="auth">
  <?php include __DIR__ . '/_brand.php'; ?>
  <section class="auth-form">
    <form method="post" action="<?= url('/login') ?>" autocomplete="on" novalidate>
      <?= csrf_field() ?>
      <h2>Sign in</h2>
      <p class="lead">Use the account your system administrator gave you.</p>
      <?php foreach ($flashes as $f): ?><div class="alert alert-<?= $f['type'] === 'error' ? 'error' : ($f['type'] === 'success' ? 'success' : 'info') ?>"><?= e($f['message']) ?></div><?php endforeach; ?>
      <?php if ($error): ?><div class="alert alert-error" role="alert"><?= e($error) ?></div><?php endif; ?>
      <div class="field">
        <label for="username">Username or e-mail</label>
        <input id="username" name="username" type="text" value="<?= e($username) ?>" autocomplete="username" autofocus required>
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>
      </div>
      <button class="btn btn-primary" type="submit">Sign in</button>
      <p class="note">Forgot your password? Ask the system administrator to reset it. There is no e-mail reset because the system runs without internet access.</p>
    </form>
  </section>
</div>
