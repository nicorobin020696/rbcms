<div class="auth">
  <?php include __DIR__ . '/_brand.php'; ?>
  <section class="auth-form">
    <form method="post" action="<?= url('/setup') ?>" novalidate>
      <?= csrf_field() ?>
      <h2>First-time setup</h2>
      <p class="lead">Create the Super Admin (IT administrator) account. This page disappears once the account exists.</p>
      <?php foreach (take_flashes() as $f): ?><div class="alert alert-error"><?= e($f['message']) ?></div><?php endforeach; ?>
      <div class="field"><label for="full_name">Full name</label><input id="full_name" name="full_name" value="<?= e(old('full_name')) ?>" class="<?= has_error('full_name') ?>" required><?= field_error('full_name') ?></div>
      <div class="field"><label for="username">Username</label><input id="username" name="username" value="<?= e(old('username', 'admin')) ?>" class="<?= has_error('username') ?>" autocomplete="username" required><?= field_error('username') ?></div>
      <div class="field"><label for="email">E-mail <span class="muted">(optional)</span></label><input id="email" name="email" type="email" value="<?= e(old('email')) ?>" class="<?= has_error('email') ?>"><?= field_error('email') ?></div>
      <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="new-password" class="<?= has_error('password') ?>" required><p class="help">At least 10 characters with letters and numbers.</p><?= field_error('password') ?></div>
      <div class="field"><label for="password_confirm">Confirm password</label><input id="password_confirm" name="password_confirm" type="password" autocomplete="new-password" class="<?= has_error('password_confirm') ?>" required><?= field_error('password_confirm') ?></div>
      <button class="btn btn-primary" type="submit">Create Super Admin</button>
    </form>
  </section>
</div>
