<?php $logoUrl = is_file(PUBLIC_PATH . '/assets/img/custom-logo.png') ? asset('img/custom-logo.png') : asset('img/logo-128.png'); ?>
<section class="auth-brand">
  <div class="auth-logo">
    <img src="<?= $logoUrl ?>" alt="<?= e(setting('church.name', 'Rejoice Baptist Church')) ?> logo">
    <div><div class="n"><?= e(mb_strtoupper(setting('church.name', 'Rejoice Baptist Church'))) ?></div><div class="s">Church Management System</div></div>
  </div>
  <div class="auth-copy">
    <h1>Members, ministries and worship,<br>kept in one place.</h1>
    <p>Record attendance, prepare Sunday lineups, publish announcements and issue official church documents — all on the church's own computer.</p>
    <div class="verse">“Rejoice in the Lord always. I will say it again: Rejoice!” — Philippians 4:4</div>
  </div>
  <div class="auth-foot">Internal system. Available on the church network only; no data is sent to the internet.</div>
</section>
