<?php use App\Core\View;
$tone = fn($a) => match (true) { in_array($a, ['denied', 'login_failed', 'locked', 'void', 'delete', 'restore_backup'], true) => 'red', in_array($a, ['create', 'login', 'activate', 'restore'], true) => 'green', in_array($a, ['update', 'record', 'reset_password', 'unlock'], true) => 'blue', in_array($a, ['export', 'print', 'backup'], true) => 'violet', in_array($a, ['archive', 'cancel', 'deactivate'], true) => 'amber', default => 'neutral' }; ?>
<div class="page-head">
  <div><h1>Audit logs</h1><p>Every sign-in, change, export and blocked access attempt. Logs cannot be edited or deleted from the system.</p></div>
  <div class="page-actions"><a class="btn" href="<?= url('/audit/export.csv') . e(query_with(['page' => null])) ?>"><?= icon('download') ?> CSV</a></div>
</div>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Entries (filtered)</div><div class="stat-value"><?= number_format($p->total) ?></div></div>
  <div class="stat"><div class="stat-label">Failed sign-ins · 24 h</div><div class="stat-value <?= $failed ? 'text-red' : '' ?>"><?= $failed ?></div></div>
  <div class="stat"><div class="stat-label">Blocked access · 7 days</div><div class="stat-value <?= $denied ? 'text-red' : '' ?>"><?= $denied ?></div><div class="stat-note"><a href="<?= url('/audit', ['action' => 'denied']) ?>">View</a></div></div>
</div>
<div class="card">
  <form class="filters" method="get">
    <div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="Record, details, user or IP"></div>
    <select name="user"><option value="">All users</option><?php foreach ($users as $u): ?><option value="<?= $u['id'] ?>" <?= input_int('user') === (int) $u['id'] ? 'selected' : '' ?>><?= e($u['full_name']) ?></option><?php endforeach; ?></select>
    <select name="module"><option value="">All modules</option><?php foreach ($modules as $m): ?><option <?= query_str('module') === $m ? 'selected' : '' ?>><?= e($m) ?></option><?php endforeach; ?></select>
    <select name="action"><option value="">All actions</option><?php foreach ($actions as $a): ?><option <?= query_str('action') === $a ? 'selected' : '' ?>><?= e($a) ?></option><?php endforeach; ?></select>
    <input type="date" name="from" value="<?= e(input_date('from')) ?>"><input type="date" name="to" value="<?= e(input_date('to')) ?>">
    <button class="btn" type="submit">Filter</button><a class="btn btn-ghost" href="<?= url('/audit') ?>">Reset</a>
  </form>
  <?php if (!$logs): ?><?= View::partial('partials/empty', ['icon' => 'history', 'title' => 'No log entries', 'text' => 'Nothing matches these filters.']) ?><?php else: ?>
  <div class="table-wrap"><table class="table table-compact">
    <thead><tr><th>Date &amp; time</th><th>User</th><th>Action</th><th>Module</th><th>Record</th><th>Details</th><th>IP</th></tr></thead>
    <tbody><?php foreach ($logs as $a): ?><tr>
      <td class="nowrap small mono"><?= e($a['created_at']) ?></td><td class="nowrap"><?= e($a['user_name'] ?: '—') ?></td>
      <td><?= badge(str_replace('_', ' ', $a['action']), $tone($a['action'])) ?></td><td class="muted"><?= e($a['module']) ?></td>
      <td><?= e($a['record_label'] ?? '') ?><?= $a['record_id'] ? '<span class="sub">' . e($a['record_type']) . ' #' . (int) $a['record_id'] . '</span>' : '' ?></td>
      <td class="small muted" style="max-width:360px"><?= e($a['details'] ?? '') ?></td><td class="mono small faint"><?= e($a['ip'] ?? '') ?></td></tr><?php endforeach; ?></tbody></table></div>
  <?= View::partial('partials/pagination', ['p' => $p]) ?><?php endif; ?>
</div>
