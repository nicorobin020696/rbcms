<div class="crumbs"><a href="<?= url('/attendance/sessions') ?>">Attendance</a> / <a href="<?= url('/attendance/' . $s['id']) ?>"><?= e($s['session_code']) ?></a> / Mark</div>
<div class="page-head">
  <div><h1><?= e($s['title']) ?></h1><p><?= e(fmt_date($s['session_date'], 'l, j F Y')) ?><?= $s['session_time'] ? ' · ' . e(fmt_time($s['session_time'])) : '' ?><?= $s['ministry'] ? ' · ' . e($s['ministry']) : '' ?> · <span class="code"><?= e($s['session_code']) ?></span></p></div>
  <div class="page-actions"><a class="btn" href="<?= url('/attendance/' . $s['id'] . '/mark', query_str('inactive') ? [] : ['inactive' => 1]) ?>"><?= query_str('inactive') ? 'Hide inactive members' : 'Include inactive members' ?></a></div>
</div>
<?php if (!$canCorrect && $existing): ?><div class="callout warn mb"><?= icon('lock') ?><div>Records saved more than <?= App\Controllers\AttendanceController::CORRECTION_WINDOW_HOURS ?> hours ago are locked. You can still add members who were not yet recorded. Corrections need the <em>Correct attendance</em> permission.</div></div><?php endif; ?>
<form method="post" action="<?= url('/attendance/' . $s['id'] . '/mark') ?>" class="card">
  <?= csrf_field() ?>
  <div class="filters">
    <div class="input-icon"><?= icon('search') ?><input type="search" placeholder="Find a member by name or ID…" data-filter-list="mark-list" autofocus></div>
    <span class="muted small">Mark visible:</span>
    <button class="btn btn-sm" type="button" data-mark-all-status="present" data-target="mark-list">All present</button>
    <button class="btn btn-sm" type="button" data-mark-all-status="absent" data-target="mark-list">All absent</button>
    <button class="btn btn-sm btn-ghost" type="button" data-mark-all-status="" data-target="mark-list">Clear</button>
  </div>
  <?php if (!$members): ?>
    <div class="empty"><?= icon('users') ?><strong>No members to mark</strong><?= $s['ministry_id'] ? 'This ministry has no members yet.' : 'Add members first.' ?></div>
  <?php endif; ?>
  <div class="mark-list" id="mark-list">
    <?php $shownMinistryHeader = false; $shownOthers = false; foreach ($members as $m):
      $r = $existing[(int) $m['id']] ?? null; $cur = $r['status'] ?? ''; $locked = $r && !$canCorrect;
      if ($s['ministry_id'] && $m['in_ministry'] && !$shownMinistryHeader) { $shownMinistryHeader = true; echo '<div class="section-label" style="padding:12px 16px 4px">' . e($s['ministry']) . ' members</div>'; }
      if ($s['ministry_id'] && !$m['in_ministry'] && !$shownOthers) { $shownOthers = true; echo '<div class="section-label" style="padding:14px 16px 4px">Other members</div>'; }
    ?>
      <div class="mark-row" data-text="<?= e(mb_strtolower(member_name($m) . ' ' . $m['last_name'] . ' ' . $m['member_code'])) ?>">
        <div class="person"><span class="avatar avatar-sm"><?= e(initials($m['first_name'] . ' ' . $m['last_name'])) ?></span><div><span class="strong"><?= e(member_name($m, true)) ?></span> <span class="code muted"><?= e($m['member_code']) ?></span><?= $m['membership_status'] === 'inactive' ? ' ' . badge('Inactive', 'neutral') : '' ?></div></div>
        <div class="seg" <?= $locked ? 'title="Locked — correction permission required"' : '' ?>>
          <?php foreach (['present' => 'Present', 'absent' => 'Absent', 'excused' => 'Excused', '' => '—'] as $val => $lab): ?>
            <label><input type="radio" name="status[<?= (int) $m['id'] ?>]" value="<?= $val ?>" <?= $cur === $val ? 'checked' : '' ?> <?= $locked && $cur !== $val ? 'disabled' : '' ?>><?= $lab ?></label>
          <?php endforeach; ?>
        </div>
        <input type="text" name="remarks[<?= (int) $m['id'] ?>]" value="<?= e($r['remarks'] ?? '') ?>" placeholder="Remarks" maxlength="200" <?= $locked ? 'readonly' : '' ?> style="height:28px">
      </div>
    <?php endforeach; ?>
  </div>
  <div class="sticky-bar"><span class="muted small" data-mark-counts></span><div class="row"><a class="btn btn-ghost" href="<?= url('/attendance/' . $s['id']) ?>">Cancel</a><button class="btn btn-primary" type="submit"><?= icon('check') ?> Save attendance</button></div></div>
</form>
