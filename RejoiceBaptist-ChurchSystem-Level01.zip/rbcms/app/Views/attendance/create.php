<div class="crumbs"><a href="<?= url('/attendance/sessions') ?>">Attendance</a> / New session</div>
<div class="page-head"><div><h1>Record attendance</h1><p>Step 1 of 2 — describe the service or activity. Next you will mark the members.</p></div></div>
<form method="post" action="<?= url('/attendance') ?>" class="card" style="max-width:760px" novalidate>
  <?= csrf_field() ?>
  <div class="card-body">
    <div class="form-grid">
      <div class="field span-6"><label for="category_id">Activity type<span class="req">*</span></label>
        <select id="category_id" name="category_id" class="<?= has_error('category_id') ?>" required>
          <option value="">Select…</option>
          <?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= (int) old('category_id', $presetMinistry ? ($c['code'] === 'ministry_meeting' ? $c['id'] : 0) : 0) === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
        </select><?= field_error('category_id') ?></div>
      <div class="field span-6"><label for="title">Title</label><input id="title" name="title" value="<?= e(old('title')) ?>" placeholder="Defaults to the activity type, e.g. Sunday Worship Service"><p class="help">Add detail for special activities, e.g. "Youth Jam 2026".</p></div>
      <div class="field span-4"><label for="session_date">Date<span class="req">*</span></label><input id="session_date" type="date" name="session_date" value="<?= e(old('session_date', today())) ?>" max="<?= date('Y-m-d', strtotime('+1 day')) ?>" class="<?= has_error('session_date') ?>" required><?= field_error('session_date') ?></div>
      <div class="field span-4"><label for="session_time">Time</label><input id="session_time" type="time" name="session_time" value="<?= e(old('session_time')) ?>"></div>
      <div class="field span-4"><label for="ministry_id">Ministry <?= can('attendance.record') ? '<span class="muted">(optional)</span>' : '<span class="req">*</span>' ?></label>
        <select id="ministry_id" name="ministry_id" class="<?= has_error('ministry_id') ?>"><option value="">— Whole church —</option><?php foreach ($ministries as $m): ?><option value="<?= $m['id'] ?>" <?= (int) old('ministry_id', $presetMinistry) === (int) $m['id'] ? 'selected' : '' ?>><?= e($m['name']) ?></option><?php endforeach; ?></select><?= field_error('ministry_id') ?></div>
      <?php if ($events): ?><div class="field span-12"><label for="event_id">Related event <span class="muted">(optional)</span></label><select id="event_id" name="event_id"><option value="">—</option><?php foreach ($events as $ev): ?><option value="<?= $ev['id'] ?>" <?= (int) old('event_id', $presetEvent) === (int) $ev['id'] ? 'selected' : '' ?>><?= e($ev['title']) ?> · <?= e(fmt_date($ev['start_date'])) ?></option><?php endforeach; ?></select></div><?php endif; ?>
      <div class="field span-12"><label for="notes">Notes</label><textarea id="notes" name="notes" rows="2" maxlength="1000"><?= e(old('notes')) ?></textarea></div>
    </div>
    <p class="help mt">Morning prayer has its own quick sheet under <a href="<?= url('/morning-prayer') ?>">Morning Prayer</a>.</p>
  </div>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url('/attendance/sessions') ?>">Cancel</a><button class="btn btn-primary" type="submit">Continue to marking <?= icon('arrow-right') ?></button></div>
</form>
