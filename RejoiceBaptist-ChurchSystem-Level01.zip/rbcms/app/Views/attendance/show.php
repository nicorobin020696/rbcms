<?php $groups = ['present' => [], 'absent' => [], 'excused' => []]; foreach ($records as $r) { $groups[$r['status']][] = $r; } ?>
<div class="crumbs"><a href="<?= url('/attendance/sessions') ?>">Attendance</a> / <?= e($s['session_code']) ?></div>
<div class="page-head">
  <div><h1><?= e($s['title']) ?><?= sample_tag($s) ?></h1><p><?= e(fmt_date($s['session_date'], 'l, j F Y')) ?><?= $s['session_time'] ? ' · ' . e(fmt_time($s['session_time'])) : '' ?> · <?= e($s['category']) ?><?= $s['ministry'] ? ' · ' . e($s['ministry']) : '' ?></p></div>
  <div class="page-actions">
    <?php if (can('attendance.export') || App\Core\Auth::leads((int) $s['ministry_id'])): ?><a class="btn" href="<?= url('/attendance/' . $s['id'] . '/pdf') ?>" target="_blank"><?= icon('printer') ?> PDF</a><?php endif; ?>
    <?php if (can('attendance.correct')): ?><form method="post" action="<?= url('/attendance/' . $s['id'] . '/delete') ?>" data-confirm="Delete this session and all <?= count($records) ?> attendance record(s)? This cannot be undone." data-danger data-confirm-ok="Delete session"><?= csrf_field() ?><button class="btn btn-danger" type="submit"><?= icon('trash') ?> Delete</button></form><?php endif; ?>
    <?php if ($canRecord): ?><a class="btn btn-primary" href="<?= url('/attendance/' . $s['id'] . '/mark') ?>"><?= icon('pencil') ?> <?= $records ? 'Add / correct' : 'Mark attendance' ?></a><?php endif; ?>
  </div>
</div>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Present</div><div class="stat-value text-green"><?= count($groups['present']) ?></div></div>
  <div class="stat"><div class="stat-label">Absent</div><div class="stat-value"><?= count($groups['absent']) ?></div></div>
  <div class="stat"><div class="stat-label">Excused</div><div class="stat-value"><?= count($groups['excused']) ?></div></div>
  <div class="stat"><div class="stat-label">Session ID</div><div class="stat-value" style="font-size:15px;padding-top:6px"><?= e($s['session_code']) ?></div><div class="stat-note">by <?= e($s['created_by_name'] ?: '—') ?></div></div>
</div>
<?php if ($s['notes'] || $s['event_title']): ?><div class="callout info mb"><?= icon('info') ?><div><?= $s['event_title'] ? 'Event: <a href="' . url('/events/' . $s['event_id']) . '">' . e($s['event_title']) . '</a>. ' : '' ?><?= e($s['notes'] ?? '') ?></div></div><?php endif; ?>
<div class="card">
  <?php if (!$records): ?>
    <?= App\Core\View::partial('partials/empty', ['icon' => 'clipboard', 'title' => 'No one has been marked yet', 'text' => 'Open the marking sheet to record who attended.', 'action' => $canRecord ? ['Mark attendance', url('/attendance/' . $s['id'] . '/mark')] : null]) ?>
  <?php else: ?>
  <table class="table"><thead><tr><th>Member</th><th>Member ID</th><th>Status</th><th>Remarks</th><th>Recorded</th></tr></thead><tbody>
    <?php foreach ($records as $r): ?>
      <tr><td><?= can('members.view') ? '<a href="' . url('/members/' . $r['member_id']) . '">' . e(member_name($r, true)) . '</a>' : e(member_name($r, true)) ?></td><td class="code"><?= e($r['member_code']) ?></td><td><?= status_badge($r['status']) ?></td><td class="muted"><?= e($r['remarks'] ?? '') ?></td><td class="muted small nowrap"><?= e($r['recorder'] ?: '—') ?> · <?= e(fmt_datetime($r['updated_at'])) ?></td></tr>
    <?php endforeach; ?>
  </tbody></table>
  <?php endif; ?>
</div>
