<?php use App\Services\Stats; $months = Stats::monthLabels();
$diff = $prevMonth > 0 ? round(($cards['month'] - $prevMonth) / $prevMonth * 100) : null; ?>
<div class="page-head">
  <div><h1>Attendance</h1><p>Figures count members marked <strong>present</strong>, computed from saved attendance records.</p></div>
  <div class="page-actions">
    <form method="get" class="row"><select name="year" data-autosubmit><?php foreach ($years as $y): ?><option value="<?= e($y) ?>" <?= (int) $y === $year ? 'selected' : '' ?>><?= e($y) ?></option><?php endforeach; ?></select></form>
    <?php if (can('attendance.record')): ?><a class="btn btn-primary" href="<?= url('/attendance/new') ?>"><?= icon('plus') ?> Record attendance</a><?php endif; ?>
  </div>
</div>
<?php $active = 'overview'; include __DIR__ . '/_tabs.php'; ?>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Today</div><div class="stat-value"><?= number_format($cards['today']) ?></div><div class="stat-note"><?= e(fmt_date(today(), 'D, j M')) ?></div></div>
  <div class="stat"><div class="stat-label">This week</div><div class="stat-value"><?= number_format($cards['week']) ?></div><div class="stat-note">since Monday</div></div>
  <div class="stat"><div class="stat-label">This month</div><div class="stat-value"><?= number_format($cards['month']) ?></div><div class="stat-note"><?= $diff === null ? 'no data last month' : ($diff >= 0 ? '+' : '') . $diff . '% vs last month' ?></div></div>
  <div class="stat"><div class="stat-label">This year</div><div class="stat-value"><?= number_format($cards['year']) ?></div><div class="stat-note"><?= date('Y') ?> to date</div></div>
</div>
<div class="split-wide mb">
  <div class="card"><div class="card-header"><h2>Monthly attendance — <?= $year ?> vs <?= $year - 1 ?></h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'labels' => $months, 'series' => [['name' => (string) ($year - 1), 'values' => $monthlyPrev, 'color' => '#b8c0cc'], ['name' => (string) $year, 'values' => $monthly]]]) ?>"></div>
  </div></div>
  <div class="card"><div class="card-header"><h2>Yearly attendance</h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'labels' => array_map('strval', array_keys($yearly)), 'series' => [['name' => 'Present', 'values' => array_values($yearly), 'color' => '#22a061']]]) ?>"></div>
  </div></div>
</div>
<div class="grid cols-2 mb">
  <div class="card"><div class="card-header"><h2>Weekly — last 12 weeks</h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'line', 'labels' => array_map(fn($d) => fmt_date($d, 'j M'), array_keys($weekly)), 'series' => [['name' => 'Present', 'values' => array_values($weekly)]]]) ?>"></div>
  </div></div>
  <div class="card"><div class="card-header"><h2>Daily — last 14 days</h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'labels' => array_map(fn($d) => fmt_date($d, 'j'), array_keys($daily)), 'series' => [['name' => 'Present', 'values' => array_values($daily), 'color' => '#8b5cf6']]]) ?>"></div>
  </div></div>
</div>
<div class="grid cols-3 mb">
  <div class="card"><div class="card-header"><h2>Sunday Worship — <?= $year ?></h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'line', 'labels' => $months, 'series' => [['name' => 'Present', 'values' => $sunday, 'color' => '#3b74e8']], 'height' => 180]) ?>"></div>
  </div></div>
  <div class="card"><div class="card-header"><h2>Per activity — <?= $year ?></h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'hbar', 'labels' => array_column($byCategory, 'name'), 'series' => [['name' => 'Present', 'values' => array_map('intval', array_column($byCategory, 'total'))]], 'empty' => 'No attendance recorded in ' . $year . '.']) ?>"></div>
  </div></div>
  <div class="card"><div class="card-header"><h2>Per ministry — <?= $year ?></h2></div><div class="card-body">
    <div class="chart" data-chart="<?= json_attr(['type' => 'hbar', 'labels' => array_column($byMinistry, 'name'), 'series' => [['name' => 'Present', 'values' => array_map('intval', array_column($byMinistry, 'total')), 'color' => '#14a39a']], 'empty' => 'No ministry attendance recorded in ' . $year . '.']) ?>"></div>
  </div></div>
</div>
<div class="split-wide">
  <div class="card">
    <div class="card-header"><h2>Recent sessions</h2><a class="more" href="<?= url('/attendance/sessions') ?>">View all <?= icon('arrow-right') ?></a></div>
    <?= App\Core\View::partial('attendance/_session_table', ['sessions' => $recent]) ?>
  </div>
  <div class="card">
    <div class="card-header"><h2>Most faithful attendees — <?= $year ?></h2></div>
    <?php if (!$top): ?><div class="empty small">No records yet.</div><?php else: ?>
    <table class="table table-compact"><tbody>
      <?php foreach ($top as $i => $t): ?><tr><td class="muted mono" style="width:28px"><?= $i + 1 ?></td><td><a href="<?= url('/attendance/records', ['member' => $t['id']]) ?>"><?= e(member_name($t)) ?></a></td><td class="num"><?= (int) $t['present'] ?></td></tr><?php endforeach; ?>
    </tbody></table><?php endif; ?>
  </div>
</div>
