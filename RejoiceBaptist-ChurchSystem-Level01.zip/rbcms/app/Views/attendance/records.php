<?php use App\Core\View; ?>
<div class="page-head">
  <div><h1>Attendance</h1><p>Every individual attendance record. Filter by member, activity, ministry or date.</p></div>
  <div class="page-actions"><?php if (can('attendance.export')): ?>
    <a class="btn" href="<?= url('/attendance/export.csv') . e(query_with(['page' => null])) ?>"><?= icon('download') ?> CSV</a>
    <a class="btn" href="<?= url('/attendance/export.pdf') . e(query_with(['page' => null])) ?>"><?= icon('printer') ?> PDF</a>
  <?php endif; ?></div>
</div>
<?php $active = 'records'; include __DIR__ . '/_tabs.php'; ?>
<?php if ($member): $rate = $memberSummary['total'] ? round($memberSummary['present'] / $memberSummary['total'] * 100) : 0; ?>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Member</div><div class="stat-value" style="font-size:15px;padding-top:6px"><a href="<?= url('/members/' . $member['id']) ?>"><?= e(member_name($member)) ?></a></div><div class="stat-note code"><?= e($member['member_code']) ?></div></div>
  <div class="stat"><div class="stat-label">Present</div><div class="stat-value"><?= (int) $memberSummary['present'] ?></div></div>
  <div class="stat"><div class="stat-label">Absent</div><div class="stat-value"><?= (int) $memberSummary['absent'] ?></div></div>
  <div class="stat"><div class="stat-label">Excused</div><div class="stat-value"><?= (int) $memberSummary['excused'] ?></div></div>
  <div class="stat"><div class="stat-label">Attendance rate</div><div class="stat-value"><?= $rate ?>%</div></div>
</div>
<?php endif; ?>
<div class="card">
  <form class="filters" method="get">
    <div style="min-width:240px;flex:1 1 240px;max-width:320px"><?= View::partial('partials/member_select', ['name' => 'member', 'members' => $members, 'selected' => input_int('member'), 'emptyLabel' => 'All members', 'placeholder' => 'Filter by member…']) ?></div>
    <select name="category"><option value="">All activities</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= input_int('category') === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
    <select name="ministry"><option value="">All ministries</option><?php foreach ($ministries as $m): ?><option value="<?= $m['id'] ?>" <?= input_int('ministry') === (int) $m['id'] ? 'selected' : '' ?>><?= e($m['name']) ?></option><?php endforeach; ?></select>
    <select name="status"><option value="">Any status</option><?php foreach (['present', 'absent', 'excused'] as $st): ?><option value="<?= $st ?>" <?= query_str('status') === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option><?php endforeach; ?></select>
    <input type="date" name="from" value="<?= e(input_date('from')) ?>" title="From"><input type="date" name="to" value="<?= e(input_date('to')) ?>" title="To">
    <button class="btn" type="submit">Filter</button>
    <a class="btn btn-ghost" href="<?= url('/attendance/records') ?>">Reset</a>
  </form>
  <?php if (!$records): ?>
    <?= View::partial('partials/empty', ['icon' => 'clipboard', 'title' => 'No attendance records found', 'text' => 'Adjust the filters or record attendance first.']) ?>
  <?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Date</th><th>Activity</th><th>Member</th><th>Status</th><th>Remarks</th></tr></thead>
    <tbody><?php foreach ($records as $r): ?>
      <tr><td class="nowrap"><?= e(fmt_date($r['session_date'], 'D, j M Y')) ?></td>
        <td><a href="<?= url('/attendance/' . $r['session_id']) ?>"><?= e($r['title']) ?></a><span class="sub"><?= e($r['category']) ?><?= $r['ministry'] ? ' · ' . e($r['ministry']) : '' ?></span></td>
        <td><a href="<?= url('/attendance/records', ['member' => $r['member_id']]) ?>"><?= e(member_name($r, true)) ?></a><span class="sub code"><?= e($r['member_code']) ?></span></td>
        <td><?= status_badge($r['status']) ?></td><td class="muted"><?= e($r['remarks'] ?? '') ?></td></tr>
    <?php endforeach; ?></tbody></table></div>
  <?= View::partial('partials/pagination', ['p' => $p]) ?>
  <?php endif; ?>
</div>
