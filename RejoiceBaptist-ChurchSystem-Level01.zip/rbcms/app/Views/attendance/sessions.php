<div class="page-head">
  <div><h1>Attendance</h1><p>Each session is one service or activity on one date.</p></div>
  <div class="page-actions"><?php if (can('attendance.record') || App\Core\Auth::ledMinistryIds()): ?><a class="btn btn-primary" href="<?= url('/attendance/new') ?>"><?= icon('plus') ?> Record attendance</a><?php endif; ?></div>
</div>
<?php $active = 'sessions'; include __DIR__ . '/_tabs.php'; ?>
<div class="card">
  <form class="filters" method="get">
    <div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="Search activity or session ID"></div>
    <select name="category" data-autosubmit><option value="">All activities</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= input_int('category') === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
    <select name="ministry" data-autosubmit><option value="">All ministries</option><?php foreach ($ministries as $m): ?><option value="<?= $m['id'] ?>" <?= input_int('ministry') === (int) $m['id'] ? 'selected' : '' ?>><?= e($m['name']) ?></option><?php endforeach; ?></select>
    <input type="date" name="from" value="<?= e(input_date('from')) ?>" title="From" data-autosubmit>
    <input type="date" name="to" value="<?= e(input_date('to')) ?>" title="To" data-autosubmit>
    <button class="btn" type="submit">Filter</button>
  </form>
  <?= App\Core\View::partial('attendance/_session_table', ['sessions' => $sessions]) ?>
  <?php if ($sessions): ?><?= App\Core\View::partial('partials/pagination', ['p' => $p]) ?><?php endif; ?>
</div>
