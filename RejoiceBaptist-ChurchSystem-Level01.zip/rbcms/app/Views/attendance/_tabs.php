<?php $cur = $active ?? ''; ?>
<div class="tabs">
  <?php if (can('attendance.view')): ?><a href="<?= url('/attendance') ?>" class="<?= $cur === 'overview' ? 'active' : '' ?>">Overview</a><?php endif; ?>
  <a href="<?= url('/attendance/sessions') ?>" class="<?= $cur === 'sessions' ? 'active' : '' ?>">Sessions</a>
  <?php if (can('attendance.view')): ?><a href="<?= url('/attendance/records') ?>" class="<?= $cur === 'records' ? 'active' : '' ?>">Attendance history</a><?php endif; ?>
  <a href="<?= url('/morning-prayer') ?>">Morning prayer</a>
</div>
