<?php if (!$sessions): ?>
  <?= App\Core\View::partial('partials/empty', ['icon' => 'clipboard', 'title' => 'No attendance sessions', 'text' => 'Recorded services and activities will appear here.']) ?>
<?php else: ?>
<div class="table-wrap"><table class="table">
  <thead><tr><th>Date</th><th>Activity</th><th>Ministry</th><th class="right">Present</th><th class="right">Absent</th><th class="right">Excused</th></tr></thead>
  <tbody>
  <?php foreach ($sessions as $s): ?>
    <tr class="clickable" data-href="<?= url('/attendance/' . $s['id']) ?>">
      <td class="nowrap"><?= e(fmt_date($s['session_date'], 'D, j M Y')) ?><span class="sub"><?= e(fmt_time($s['session_time'])) ?></span></td>
      <td><a class="title-cell" href="<?= url('/attendance/' . $s['id']) ?>"><?= e($s['title']) ?></a><?= sample_tag($s) ?><span class="sub"><span class="cat-dot c-<?= e($s['color']) ?>"></span><?= e($s['category']) ?> · <span class="code"><?= e($s['session_code']) ?></span></span></td>
      <td><?= e($s['ministry'] ?: '—') ?></td>
      <td class="num strong"><?= (int) $s['present'] ?></td><td class="num"><?= (int) $s['absent'] ?></td><td class="num"><?= (int) $s['excused'] ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody></table></div>
<?php endif; ?>
