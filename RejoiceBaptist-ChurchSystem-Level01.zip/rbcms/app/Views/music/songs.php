<?php use App\Core\View; ?>
<div class="page-head"><div><h1>Music Team</h1><p>Every song ever lined up, with how often and when it was last used.</p></div></div>
<?php $active = 'songs'; include __DIR__ . '/_tabs.php'; ?>
<div class="card">
  <form class="filters" method="get">
    <div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="Search song or artist"></div>
    <select name="sort" data-autosubmit><?php foreach (['uses' => 'Most used', 'last' => 'Recently used', 'title' => 'Title A–Z', 'artist' => 'Artist A–Z'] as $k => $l): ?><option value="<?= $k ?>" <?= $sort === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select>
  </form>
  <?php if (!$songs): ?><?= View::partial('partials/empty', ['icon' => 'music', 'title' => 'No songs yet', 'text' => 'Songs are added automatically when lineups are saved.']) ?>
  <?php else: ?>
  <div class="table-wrap"><table class="table"><thead><tr><th>Song</th><th>Artist</th><th class="right">Times lined up</th><th>Last used</th><th></th></tr></thead><tbody>
  <?php foreach ($songs as $s): ?>
    <tr><td><a class="strong" href="<?= url('/music', ['song' => $s['id']]) ?>"><?= e($s['title']) ?></a></td><td><?= e($s['artist'] ?: '—') ?></td><td class="num"><?= (int) $s['uses'] ?></td><td class="muted"><?= $s['last_used'] ? e(fmt_date($s['last_used'])) : '—' ?></td>
      <td class="right"><?php if ($s['youtube']): ?><a class="icon-btn" href="<?= e($s['youtube']) ?>" target="_blank" rel="noopener noreferrer" title="YouTube"><?= icon('play') ?></a><?php endif; ?></td></tr>
  <?php endforeach; ?></tbody></table></div>
  <?= View::partial('partials/pagination', ['p' => $p]) ?>
  <?php endif; ?>
</div>
