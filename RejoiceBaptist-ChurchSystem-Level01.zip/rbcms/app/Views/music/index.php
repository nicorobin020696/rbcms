<?php use App\Core\View; use App\Controllers\MusicController as MC; ?>
<div class="page-head">
  <div><h1>Music Team</h1><p>Sunday praise &amp; worship lineups — songs, artists, song leader, instrumentalists and backups.</p></div>
  <div class="page-actions">
    <a class="btn" href="<?= url('/music/export.csv') . e(query_with(['page' => null])) ?>"><?= icon('download') ?> CSV</a>
    <?php if (can('music.manage')): ?><a class="btn btn-primary" href="<?= url('/music/new') ?>"><?= icon('plus') ?> New lineup</a><?php endif; ?>
  </div>
</div>
<?php $active = 'lineups'; include __DIR__ . '/_tabs.php'; ?>
<div class="stats mb">
  <div class="stat"><div class="stat-label">Lineups recorded</div><div class="stat-value"><?= number_format($cards['total']) ?></div></div>
  <div class="stat"><div class="stat-label">This year</div><div class="stat-value"><?= number_format($cards['year']) ?></div></div>
  <div class="stat"><div class="stat-label">Different songs used</div><div class="stat-value"><?= number_format($cards['songs']) ?></div></div>
  <div class="stat"><div class="stat-label">Artists</div><div class="stat-value"><?= number_format($cards['artists']) ?></div></div>
</div>
<div class="split-wide">
  <div class="card">
    <form class="filters" method="get">
      <div class="input-icon"><?= icon('search') ?><input type="search" name="q" value="<?= e(query_str('q')) ?>" placeholder="Song, artist, title or lineup ID"></div>
      <select name="leader" data-autosubmit><option value="">Any song leader</option><?php foreach ($leaders as $m): ?><option value="<?= $m['id'] ?>" <?= input_int('leader') === (int) $m['id'] ? 'selected' : '' ?>><?= e(member_name($m)) ?></option><?php endforeach; ?></select>
      <select name="type" data-autosubmit><option value="">Any service</option><?php foreach (MC::SERVICE_TYPES as $k => $l): ?><option value="<?= $k ?>" <?= query_str('type') === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select>
      <input type="date" name="from" value="<?= e(input_date('from')) ?>" data-autosubmit title="From"><input type="date" name="to" value="<?= e(input_date('to')) ?>" data-autosubmit title="To">
      <label class="check small"><input type="checkbox" name="archived" value="1" <?= query_str('archived') ? 'checked' : '' ?> data-autosubmit> Archived</label>
      <?php if (input_int('song') || input_int('member')): ?><a class="btn btn-ghost btn-sm" href="<?= url('/music') ?>"><?= icon('x') ?> Clear filter</a><?php endif; ?>
    </form>
    <?php if (!$lineups): ?>
      <?= View::partial('partials/empty', ['icon' => 'music', 'title' => 'No lineups found', 'text' => 'Record each Sunday’s praise & worship lineup to build the history and statistics.', 'action' => can('music.manage') ? ['New lineup', url('/music/new')] : null]) ?>
    <?php else: ?>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>Date</th><th>Service</th><th>Song leader</th><th>Songs</th><th class="right">Team</th></tr></thead>
      <tbody><?php foreach ($lineups as $l): ?>
        <tr class="clickable" data-href="<?= url('/music/' . $l['id']) ?>">
          <td class="nowrap"><a class="title-cell" href="<?= url('/music/' . $l['id']) ?>"><?= e(fmt_date($l['service_date'], 'D, j M Y')) ?></a><span class="sub code"><?= e($l['lineup_code']) ?></span></td>
          <td><?= e($l['service_title'] ?: MC::SERVICE_TYPES[$l['service_type']]) ?><?= sample_tag($l) ?><?= $l['photo_path'] ? ' <span class="faint" title="Has team photo">' . icon('image') . '</span>' : '' ?></td>
          <td><?= $l['sl_first'] ? e($l['sl_first'] . ' ' . $l['sl_last']) : '—' ?></td>
          <td class="muted small" style="max-width:340px"><?= e(mb_strimwidth((string) $l['songs'], 0, 120, '…')) ?><span class="sub"><?= (int) $l['song_count'] ?> song(s)</span></td>
          <td class="num"><?= (int) $l['member_count'] + ($l['sl_first'] ? 1 : 0) ?></td>
        </tr>
      <?php endforeach; ?></tbody></table></div>
    <?= View::partial('partials/pagination', ['p' => $p]) ?>
    <?php endif; ?>
  </div>
  <div class="card">
    <div class="card-header"><h2>Most lined-up songs</h2><a class="more" href="<?= url('/music/stats') ?>">Statistics <?= icon('arrow-right') ?></a></div>
    <?php if (!$topSongs): ?><div class="empty small">No songs recorded yet.</div><?php else: $max = max(array_column($topSongs, 'uses')); ?>
    <ul class="list"><?php foreach ($topSongs as $i => $s): ?>
      <li><div class="row" style="justify-content:space-between"><a href="<?= url('/music', ['song' => $s['id']]) ?>" class="strong"><?= $i + 1 ?>. <?= e($s['title']) ?></a><span class="num strong"><?= (int) $s['uses'] ?>×</span></div>
        <span class="sub"><?= e($s['artist'] ?: 'Unknown artist') ?></span><div class="progress" style="margin-top:6px"><span style="width:<?= round($s['uses'] / $max * 100) ?>%"></span></div></li>
    <?php endforeach; ?></ul><?php endif; ?>
  </div>
</div>
