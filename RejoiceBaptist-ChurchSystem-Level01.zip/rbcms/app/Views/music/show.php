<?php use App\Controllers\MusicController as MC; $groups = ['instrumentalist' => [], 'backup' => [], 'other' => []]; foreach ($team as $t) { $groups[$t['role']][] = $t; } ?>
<div class="crumbs"><a href="<?= url('/music') ?>">Music Team</a> / <?= e($l['lineup_code']) ?></div>
<div class="page-head">
  <div><h1><?= e($l['service_title'] ?: MC::SERVICE_TYPES[$l['service_type']]) ?><?= sample_tag($l) ?></h1><p><?= e(fmt_date($l['service_date'], 'l, j F Y')) ?> · <span class="code"><?= e($l['lineup_code']) ?></span> <?= $l['archived_at'] ? badge('Archived', 'neutral') : '' ?></p></div>
  <div class="page-actions">
    <a class="btn" href="<?= url('/music/' . $l['id'] . '/pdf') ?>" target="_blank"><?= icon('printer') ?> PDF</a>
    <?php if (can('music.manage')): ?>
      <form method="post" action="<?= url('/music/' . $l['id'] . '/archive') ?>" <?= $l['archived_at'] ? '' : 'data-confirm="Archive this lineup? It will be hidden and excluded from statistics." data-confirm-ok="Archive"' ?>><?= csrf_field() ?><button class="btn" type="submit"><?= icon($l['archived_at'] ? 'refresh' : 'archive') ?> <?= $l['archived_at'] ? 'Restore' : 'Archive' ?></button></form>
      <a class="btn" href="<?= url('/music/new', ['copy' => $l['id']]) ?>" title="Start a new lineup with the same team"><?= icon('copy') ?> Reuse team</a>
      <?php if (!$l['archived_at']): ?><a class="btn btn-primary" href="<?= url('/music/' . $l['id'] . '/edit') ?>"><?= icon('pencil') ?> Edit</a><?php endif; ?>
    <?php endif; ?>
  </div>
</div>
<div class="split">
  <div class="stack">
    <?php if ($l['photo_path']): ?><div class="photo-frame"><img src="<?= e(file_url($l['photo_path'])) ?>" alt="Praise and worship team photo"></div><?php endif; ?>
    <div class="card"><div class="card-header"><h2>Lineup songs</h2><span class="muted small"><?= count($songs) ?> song(s)</span></div>
      <table class="table"><thead><tr><th style="width:36px">#</th><th>Song</th><th>Artist</th><th>Part</th><th></th></tr></thead><tbody>
      <?php foreach ($songs as $s): ?>
        <tr><td class="muted mono"><?= (int) $s['sort_order'] ?></td>
          <td><a class="strong" href="<?= url('/music', ['song' => $s['song_id']]) ?>"><?= e($s['title']) ?></a><?= $s['remarks'] ? '<span class="sub">' . e($s['remarks']) . '</span>' : '' ?></td>
          <td><?= e($s['artist'] ?: '—') ?></td><td><?= badge(MC::SONG_CATS[$s['category']], ['praise' => 'blue', 'worship' => 'violet', 'special' => 'amber'][$s['category']]) ?></td>
          <td class="right nowrap"><span class="faint small" title="Times this song has been lined up"><?= (int) $s['times'] ?>×</span><?php if ($s['youtube_url']): ?> <a class="icon-btn" href="<?= e($s['youtube_url']) ?>" target="_blank" rel="noopener noreferrer" title="Open on YouTube"><?= icon('play') ?></a><?php endif; ?></td></tr>
      <?php endforeach; ?></tbody></table>
    </div>
    <?php if ($l['remarks']): ?><div class="card"><div class="card-header"><h2>Remarks</h2></div><div class="card-body prose"><?= nl2p($l['remarks']) ?></div></div><?php endif; ?>
  </div>
  <div class="stack">
    <div class="card"><div class="card-header"><h2>Music team</h2></div>
      <div class="card-body">
        <div class="section-label">Song leader</div>
        <p class="strong" style="margin:4px 0 14px"><?= $l['sl_first'] ? e(trim($l['sl_first'] . ' ' . $l['sl_last'])) : '—' ?></p>
        <?php foreach (['instrumentalist' => 'Instrumentalists', 'backup' => 'Backup singers', 'other' => 'Others'] as $k => $lab): if (!$groups[$k]) continue; ?>
          <div class="section-label"><?= $lab ?></div>
          <ul class="plain-list mb"><?php foreach ($groups[$k] as $t): ?><li><span><?= e(member_name($t)) ?></span><span class="muted small"><?= e($t['instrument'] ?? '') ?><?= $t['note'] ? ($t['instrument'] ? ' · ' : '') . e($t['note']) : '' ?></span></li><?php endforeach; ?></ul>
        <?php endforeach; ?>
        <?php if (!$team): ?><p class="muted small">No instrumentalists or backups recorded.</p><?php endif; ?>
      </div>
    </div>
    <div class="card"><div class="card-body"><dl class="kv">
      <dt>Recorded by</dt><dd class="small"><?= e($l['created_by_name'] ?: '—') ?><br><span class="muted"><?= e(fmt_datetime($l['created_at'])) ?></span></dd>
      <?php if ($l['updated_at'] !== $l['created_at']): ?><dt>Last edited</dt><dd class="small"><?= e($l['updated_by_name'] ?: '—') ?><br><span class="muted"><?= e(fmt_datetime($l['updated_at'])) ?></span></dd><?php endif; ?>
    </dl></div></div>
  </div>
</div>
