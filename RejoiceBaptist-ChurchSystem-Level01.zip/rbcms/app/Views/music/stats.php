<?php use App\Services\Stats;
$rank = function (array $rows, callable $label, callable $sub = null) { if (!$rows) return '<div class="empty small">No data for this period.</div>'; $max = max(array_column($rows, 'uses')) ?: 1; $h = '<ul class="list">';
  foreach ($rows as $i => $r) { $h .= '<li><div class="row" style="justify-content:space-between"><span class="strong">' . ($i + 1) . '. ' . e($label($r)) . '</span><span class="num strong">' . (int) $r['uses'] . '</span></div>' . ($sub ? '<span class="sub">' . e($sub($r)) . '</span>' : '') . '<div class="progress" style="margin-top:6px"><span style="width:' . round($r['uses'] / $max * 100) . '%"></span></div></li>'; }
  return $h . '</ul>'; }; ?>
<div class="page-head">
  <div><h1>Music Team</h1><p>Statistics for <?= $from || $to ? e(fmt_date($from ?: '2000-01-01')) . ' – ' . e(fmt_date($to ?: today())) : 'all time' ?>.</p></div>
  <div class="page-actions">
    <form method="get" class="row"><select name="year" data-autosubmit><?php foreach ($years as $y): ?><option <?= (int) $y === $year && $from ? 'selected' : '' ?>><?= e($y) ?></option><?php endforeach; ?></select></form>
    <a class="btn <?= !$from && !$to ? 'btn-primary' : '' ?>" href="<?= url('/music/stats', ['range' => 'all']) ?>">All time</a>
    <a class="btn" href="<?= url('/music/stats.pdf') . e(query_with([])) ?>" target="_blank"><?= icon('printer') ?> PDF</a>
  </div>
</div>
<?php $active = 'stats'; include __DIR__ . '/_tabs.php'; ?>
<div class="grid cols-2 mb">
  <div class="card"><div class="card-header"><h2>Lineups per month — <?= $year ?></h2></div><div class="card-body"><div class="chart" data-chart="<?= json_attr(['type' => 'bar', 'labels' => Stats::monthLabels(), 'series' => [['name' => 'Lineups', 'values' => $perMonth, 'color' => '#8b5cf6']]]) ?>"></div></div></div>
  <div class="card"><div class="card-header"><h2>Most lined-up songs</h2></div><div class="card-body"><div class="chart" data-chart="<?= json_attr(['type' => 'hbar', 'labels' => array_map(fn($s) => $s['title'], array_slice($topSongs, 0, 8)), 'series' => [['name' => 'Times', 'values' => array_map('intval', array_column(array_slice($topSongs, 0, 8), 'uses')), 'color' => '#3b74e8']], 'empty' => 'No songs in this period.']) ?>"></div></div></div>
</div>
<div class="grid cols-3">
  <div class="card"><div class="card-header"><h2>Top songs</h2></div><?= $rank($topSongs, fn($r) => $r['title'], fn($r) => ($r['artist'] ?: 'Unknown artist') . ' · last ' . fmt_date($r['last_used'])) ?></div>
  <div class="stack">
    <div class="card"><div class="card-header"><h2>Top artists</h2></div><?= $rank($topArtists, fn($r) => $r['name'], fn($r) => $r['songs'] . ' different song(s)') ?></div>
    <div class="card"><div class="card-header"><h2>Song leaders</h2></div><?= $rank($leaders, fn($r) => member_name($r)) ?></div>
  </div>
  <div class="stack">
    <div class="card"><div class="card-header"><h2>Instrumentalists</h2></div><?= $rank($instrumentalists, fn($r) => member_name($r), fn($r) => (string) $r['instruments']) ?></div>
    <div class="card"><div class="card-header"><h2>Backup singers</h2></div><?= $rank($backups, fn($r) => member_name($r)) ?></div>
  </div>
</div>
