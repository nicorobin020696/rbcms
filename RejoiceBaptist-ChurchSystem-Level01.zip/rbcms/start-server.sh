#!/bin/sh
# Rejoice Baptist Church Management System - start on the local network (Linux / macOS).
cd "$(dirname "$0")" || exit 1
php bin/console.php check || { echo "Fix the items marked FAIL above, then run again."; exit 1; }
PORT="${PORT:-8080}"
echo ""
echo "Church system is running on http://localhost:$PORT (other computers: http://<this-computer-ip>:$PORT)"
echo "Press Ctrl+C to stop."
exec php -S 0.0.0.0:"$PORT" -t public public/index.php
