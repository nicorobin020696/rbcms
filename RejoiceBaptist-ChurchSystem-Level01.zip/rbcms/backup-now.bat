@echo off
REM Creates a full backup in storage\backups. Can be scheduled with Windows Task Scheduler.
cd /d "%~dp0"
php bin\console.php backup
