@echo off
REM Rejoice Baptist Church Management System - start on the local network.
REM Needs PHP 8.1+ (see docs\INSTALLATION.md). Close this window to stop the system.
cd /d "%~dp0"
where php >nul 2>nul
if errorlevel 1 (
  if exist "C:\php\php.exe" ( set "PATH=C:\php;%PATH%" ) else (
    echo PHP was not found. Install PHP 8.1 or newer to C:\php - see docs\INSTALLATION.md
    pause
    exit /b 1
  )
)
php bin\console.php check
if errorlevel 1 (
  echo.
  echo Fix the items marked FAIL above, then run this again.
  pause
  exit /b 1
)
set PORT=8080
echo.
echo ============================================================
echo  Church system is running.
echo  On this computer:      http://localhost:%PORT%
echo  On other computers:    http://THIS-PC-IP-ADDRESS:%PORT%
echo  (find the IP address with the command: ipconfig)
echo  Keep this window open. Close it to stop the system.
echo ============================================================
echo.
php -S 0.0.0.0:%PORT% -t public public\index.php
pause
