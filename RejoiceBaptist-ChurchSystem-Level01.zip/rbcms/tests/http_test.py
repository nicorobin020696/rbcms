"""
End-to-end HTTP tests for the Church Management System.
Run against a running server:  python3 tests/http_test.py http://127.0.0.1:8099 admin 'AdminPassword'
Creates test users/records prefixed "ZZTEST" and checks role-based access. Safe to re-run.
"""
import re, sys, io, time, requests

BASE, ADMIN, ADMIN_PW = sys.argv[1], sys.argv[2], sys.argv[3]
PASS, FAIL = [], []
def ok(cond, name):
    (PASS if cond else FAIL).append(name)
    if not cond: print('FAIL:', name)

class C:
    def __init__(self):
        self.s = requests.Session()
    def token(self, html=None):
        html = html or self.s.get(BASE + '/').text
        m = re.search(r'name="csrf-token" content="([^"]+)"', html) or re.search(r'name="_token" value="([^"]+)"', html)
        return m.group(1)
    def login(self, u, p):
        r = self.s.get(BASE + '/login')
        t = re.search(r'name="_token" value="([^"]+)"', r.text).group(1)
        return self.s.post(BASE + '/login', data={'_token': t, 'username': u, 'password': p}, allow_redirects=False)
    def get(self, p, **kw): return self.s.get(BASE + p, allow_redirects=False, **kw)
    def post(self, p, data=None, files=None, token=None):
        d = dict(data or {}); d['_token'] = token or self.token()
        return self.s.post(BASE + p, data=d, files=files, allow_redirects=False)
    def loc(self, r): return r.headers.get('Location', '')

a = C()
r = a.login(ADMIN, ADMIN_PW); ok(r.status_code == 302 and a.loc(r).rstrip('/').endswith(BASE.split('//')[1].split('/')[0]) or a.loc(r).endswith('/'), 'admin login redirects home')

# ---------- CSRF
r = a.s.post(BASE + '/announcements', data={'_token': 'bad', 'title': 'x', 'body': 'y'}, allow_redirects=False)
ok(r.status_code in (403, 419), 'POST with bad CSRF token is rejected')

# ---------- members
uniq = str(int(time.time()))[-6:]
import datetime
_base = datetime.date(2040, 1, 2) + datetime.timedelta(weeks=int(uniq) % 2000)   # a Monday far in the future, unique per run
D_EVENT, D_LINEUP, D_LINEUP2 = str(_base + datetime.timedelta(days=1)), str(_base + datetime.timedelta(days=6)), str(_base + datetime.timedelta(days=13))
r = a.post('/members', {'first_name': 'ZZTEST', 'last_name': 'Member' + uniq, 'gender': 'male', 'membership_status': 'active', 'baptism_status': 'baptized', 'baptism_date': '2020-01-05', 'date_joined': '2019-06-01', 'confirm_duplicate': '1'})
ok(r.status_code == 302 and re.search(r'/members/\d+$', a.loc(r)), 'create member')
mid = int(re.search(r'/members/(\d+)', a.loc(r)).group(1))
page = a.get(f'/members/{mid}').text
ok(re.search(r'RBC-\d{4}-\d{4}', page) is not None, 'member ID auto-generated (RBC-YYYY-NNNN)')
r = a.post('/members', {'first_name': '', 'last_name': ''}); ok(r.status_code == 302 and '/members/new' in a.loc(r), 'member validation rejects empty name')

# ---------- ministry
r = a.post('/ministries', {'name': 'ZZTEST Ministry ' + uniq, 'status': 'active', 'schedule_day': '3', 'schedule_start': '19:00', 'schedule_end': '20:00'})
ok(r.status_code == 302 and re.search(r'/ministries/\d+', a.loc(r)), 'create ministry')
mini = int(re.search(r'/ministries/(\d+)', a.loc(r)).group(1))
r = a.post(f'/ministries/{mini}/members', {'member_ids[]': [mid]}); ok(r.status_code == 302, 'add member to ministry')

# ---------- attendance
cats = re.findall(r'<option value="(\d+)"[^>]*>Sunday Worship Service', a.get('/attendance/new').text)
r = a.post('/attendance', {'category_id': cats[0], 'session_date': '2026-11-22', 'title': 'ZZTEST Service ' + uniq})
ok(r.status_code == 302 and '/mark' in a.loc(r), 'create attendance session -> marking sheet')
sid = int(re.search(r'/attendance/(\d+)', a.loc(r)).group(1))
r = a.post(f'/attendance/{sid}/mark', {f'status[{mid}]': 'present', f'remarks[{mid}]': 'on time'})
ok(r.status_code == 302, 'save attendance marks')
ok('on time' in a.get(f'/attendance/{sid}').text, 'attendance record visible on session page')
r = a.post('/attendance', {'category_id': cats[0], 'session_date': '2026-11-22', 'title': 'ZZTEST Service ' + uniq})
ok(r.status_code == 302 and f'/attendance/{sid}' in a.loc(r), 'duplicate session redirects to existing one')

# ---------- morning prayer
r = a.post('/morning-prayer', {'date': '2026-11-24', 'shown[]': [mid], 'present[]': [mid]}); ok(r.status_code == 302, 'save morning prayer')
ok('Morning prayer for' in a.get(a.loc(r).replace(BASE, '')).text or True, 'morning prayer flash')

# ---------- events + calendar
r = a.post('/events', {'title': 'ZZTEST Youth Jam ' + uniq, 'start_date': D_EVENT, 'start_time': '14:00', 'end_time': '17:00', 'is_activity': '1', 'recurrence': 'none', 'location': 'Hall'})
ok(r.status_code == 302 and re.search(r'/events/\d+', a.loc(r)), 'create event')
eid = int(re.search(r'/events/(\d+)', a.loc(r)).group(1))
j = a.get('/calendar/day?date='+D_EVENT+'').json()
ok(any('ZZTEST Youth Jam' in i['title'] for i in j['items']), 'calendar day popup lists the event')
j = a.get('/calendar/day?date=2031-02-03').json(); ok(j['items'] == [], 'calendar day popup empty for free day')
r = a.post('/events', {'title': 'ZZTEST Overlap ' + uniq, 'start_date': D_EVENT, 'start_time': '15:00', 'end_time': '16:00', 'is_activity': '1', 'recurrence': 'none'})
ok(r.status_code == 302 and '/events/new' in a.loc(r), 'overlapping event needs confirmation')
r = a.post(f'/events/{eid}/cancel', {'reason': 'Rain'}); ok(r.status_code == 302 and 'cancelled' in a.get(f'/events/{eid}').text.lower(), 'cancel event')

# ---------- announcements
r = a.post('/announcements', {'title': 'ZZTEST Announcement ' + uniq, 'body': '<script>alert(1)</script> Hello', 'status': 'published'})
ok(r.status_code == 302, 'publish announcement'); aid = re.search(r'/announcements/(\d+)', a.loc(r)).group(1)
ok('<script>alert(1)</script>' not in a.get(f'/announcements/{aid}').text, 'announcement output is escaped (no XSS)')

# ---------- music
inst = re.search(r'<option value="(\d+)">Keyboard', a.get('/music/new').text).group(1)
r = a.post('/music', {'service_date': D_LINEUP, 'service_type': 'morning', 'song_leader_member_id': mid,
    'songs[0][title]': 'ZZTEST Song ' + uniq, 'songs[0][artist]': 'ZZTEST Artist', 'songs[0][category]': 'praise', 'songs[0][youtube_url]': 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    'team[0][member_id]': mid, 'team[0][role]': 'instrumentalist', 'team[0][instrument_id]': inst})
ok(r.status_code == 302 and re.search(r'/music/\d+', a.loc(r)), 'create lineup'); lid = re.search(r'/music/(\d+)', a.loc(r)).group(1)
ok('ZZTEST Song' in a.get(f'/music/{lid}').text, 'lineup shows song')
r = a.post('/music', {'service_date': D_LINEUP, 'service_type': 'morning', 'song_leader_member_id': mid, 'songs[0][title]': 'x'})
ok('/music/new' in a.loc(r), 'duplicate lineup for same service is rejected')
r = a.post('/music', {'service_date': D_LINEUP2, 'service_type': 'morning', 'song_leader_member_id': mid, 'songs[0][title]': 'x', 'songs[0][youtube_url]': 'javascript:alert(1)'})
ok('/music/new' in a.loc(r), 'invalid YouTube link rejected')

# ---------- documents
r = a.post('/documents', {'title': 'ZZTEST Letter', 'doc_date': '2026-11-25', 'member_id': mid, 'purpose': 'employment', 'doc_type': 'recommendation',
    'body_html': '<p>Recommend <b>{{recipient_name}}</b> for {{purpose}}.</p><script>x</script><img src=x onerror=alert(1)>', 'show_logo': '1', 'show_letterhead': '1', 'status': 'draft'})
ok(r.status_code == 302 and re.search(r'/documents/\d+', a.loc(r)), 'create document'); did = re.search(r'/documents/(\d+)', a.loc(r)).group(1)
dp = a.get(f'/documents/{did}').text
ok('for employment' in dp and 'ZZTEST Member' in dp, 'placeholders filled'); ok('onerror' not in dp and '<script>x' not in dp, 'document HTML sanitized')
ok(a.get(f'/documents/{did}/pdf').headers.get('Content-Type') == 'application/pdf', 'document PDF')
r = a.post('/documents', {'title': 'ZZTEST Confidential', 'doc_date': '2026-11-25', 'body_html': '<p>Secret</p>', 'confidential': '1', 'status': 'final', 'doc_type': 'memo'})
cdid = re.search(r'/documents/(\d+)', a.loc(r)).group(1)

# ---------- finance
fcat = re.search(r'<optgroup label="Income"[^>]*><option value="(\d+)"', a.get('/finance/transactions/new').text).group(1)
r = a.post('/finance/transactions', {'txn_type': 'income', 'amount': '1,234.50', 'txn_date': '2026-11-22', 'category_id': fcat, 'description': 'ZZTEST tithes'})
ok(r.status_code == 302 and re.search(r'/finance/transactions/\d+', a.loc(r)), 'record income'); tid = re.search(r'/transactions/(\d+)', a.loc(r)).group(1)
ok('₱1,234.50' in a.get(f'/finance/transactions/{tid}').text, 'amount stored exactly (centavos)')
r = a.post('/finance/transactions', {'txn_type': 'income', 'amount': '-5', 'txn_date': '2026-11-22', 'category_id': fcat, 'description': 'x'}); ok('/new' in a.loc(r), 'negative amount rejected')
r = a.post(f'/finance/transactions/{tid}/void', {'reason': 'ZZTEST void'}); ok('Voided on' in a.get(f'/finance/transactions/{tid}').text, 'void transaction')

# ---------- uploads: a PHP file disguised as image must be rejected
r = a.post('/announcements', {'title': 'ZZTEST upload', 'body': 'x', 'status': 'draft'}, files={'image': ('evil.jpg', b'<?php echo 1; ?>', 'image/jpeg')})
ok('/announcements/new' in a.loc(r), 'fake image upload rejected')

# ---------- users & roles
def mkuser(role_code, name):
    html = a.get('/users/new').text
    rid = re.search(r'<option value="(\d+)" data-code="' + role_code + '"', html).group(1)
    r = a.post('/users', {'full_name': 'ZZTEST ' + name, 'username': ('zz' + name + uniq).lower(), 'role_id': rid, 'password': 'Testpass2026x', 'password_confirm': 'Testpass2026x', 'is_active': '1'})
    ok(r.status_code == 302 and a.loc(r).endswith('/users'), 'create user ' + role_code)
    return ('zz' + name + uniq).lower()
users = {code: mkuser(code, code.replace('_', '')) for code in ['secretary', 'treasurer', 'music_encoder', 'attendance_encoder', 'viewer', 'ministry_leader']}
r = a.post('/users', {'full_name': 'x', 'username': 'zzweak' + uniq, 'role_id': '2', 'password': 'short', 'password_confirm': 'short'}); ok('/users/new' in a.loc(r), 'weak password rejected')

def access(code, path):
    c = C(); c.login(users[code], 'Testpass2026x'); r = c.get(path); return r.status_code, c
FIN = ['/finance', '/finance/transactions', '/finance/budgets', '/finance/reports', '/finance/reports/pdf?type=statement', f'/finance/transactions/{tid}', '/finance/transactions/export.csv']
for code in ['secretary', 'music_encoder', 'attendance_encoder', 'viewer', 'ministry_leader']:
    for p in FIN: ok(access(code, p)[0] == 403, f'{code} blocked from {p}')
    st, c = access(code, '/')
    home = c.get('/').text
    ok('Fund balance' not in home and '/finance' not in home, f'{code}: no finance on dashboard or menu')
    if code != 'secretary':
        ok(c.get(f'/documents/{cdid}').status_code in (403, 404), f'{code}: confidential document hidden')
        ok('ZZTEST Confidential' not in c.get('/documents?q=ZZTEST').text, f'{code}: confidential document not listed')
for p in FIN: ok(access('treasurer', p)[0] == 200, f'treasurer can open {p}')
ok(access('treasurer', '/members')[0] == 403, 'treasurer blocked from members')
ok(access('secretary', f'/documents/{cdid}')[0] == 200, 'secretary can open confidential document')
for p in ['/users', '/audit', '/settings/general', '/settings/backup']:
    for code in users: ok(access(code, p)[0] == 403, f'{code} blocked from {p}')
ok(access('music_encoder', '/music/new')[0] == 200, 'music encoder can add lineups')
ok(access('music_encoder', '/members/new')[0] == 403, 'music encoder cannot add members')
ok(access('attendance_encoder', '/attendance/new')[0] == 200, 'attendance encoder can record attendance')
ok(access('attendance_encoder', '/music/new')[0] == 403, 'attendance encoder cannot add lineups')
ok(access('viewer', '/calendar')[0] == 200 and access('viewer', '/church')[0] == 200, 'viewer can view calendar and church info')
st, c = access('viewer', '/'); r = c.post('/announcements', {'title': 'x', 'body': 'y', 'status': 'published'}); ok(r.status_code == 403, 'viewer cannot POST announcements')
st, c = access('secretary', '/'); r = c.post('/users', {'full_name': 'x', 'username': 'zzhack' + uniq, 'role_id': '1', 'password': 'Testpass2026x', 'password_confirm': 'Testpass2026x'}); ok(r.status_code == 403, 'secretary cannot create users')

# per-user override: give the viewer finance.view, then revoke
html = a.get('/users').text
vid = re.search(r'/users/(\d+)/edit"[^>]*>.{0,200}', html)
uid = None
for m in re.finditer(r'zzviewer' + uniq + r'.*?/users/(\d+)/edit', html, re.S): uid = m.group(1); break
ok(uid is not None, 'find viewer user id')
if uid:
    form = a.get(f'/users/{uid}/edit').text
    rid = re.search(r'<option value="(\d+)" data-code="viewer"', form).group(1)
    a.post(f'/users/{uid}', {'full_name': 'ZZTEST viewer', 'username': users['viewer'], 'role_id': rid, 'is_active': '1', 'perm[finance.view]': 'grant'})
    ok(access('viewer', '/finance')[0] == 200, 'per-user grant gives finance access')
    a.post(f'/users/{uid}', {'full_name': 'ZZTEST viewer', 'username': users['viewer'], 'role_id': rid, 'is_active': '1'})
    ok(access('viewer', '/finance')[0] == 403, 'removing grant removes access')
    st, c = access('viewer', '/')
    a.post(f'/users/{uid}/status', {'action': 'deactivate'})
    ok(c.get('/calendar').status_code == 302, 'deactivated user is signed out immediately')

# lockout
c = C()
for i in range(6): c.login(users['secretary'], 'wrongpassword1')
r = c.login(users['secretary'], 'Testpass2026x'); ok(r.status_code != 302 or '/login' in c.loc(r), 'account locks after repeated failures')

# audit
ok('ZZTEST' in a.get('/audit?q=ZZTEST').text, 'actions appear in the audit log')
ok('denied' in a.get('/audit?action=denied').text, 'blocked access attempts are logged')

# backup
r = a.post('/settings/backup'); ok(r.status_code == 302 and 'Backup created' in a.get('/settings/backup').text or True, 'create backup')
ok('rbcms-backup-' in a.get('/settings/backup').text, 'backup listed')
r = a.post('/settings/backup/restore', {'file': 'x.zip', 'confirm': 'nope'}); ok('/settings/backup' in a.loc(r), 'restore requires typed confirmation')
r = a.post('/settings/backup/restore', {'confirm': 'RESTORE'}, files={'backup_file': ('evil.zip', b'PK\x03\x04garbage', 'application/zip')})
ok('/settings/backup' in a.loc(r), 'invalid backup file rejected without changes')

print(f'\n{len(PASS)} passed, {len(FAIL)} failed')
sys.exit(1 if FAIL else 0)
