<?php
declare(strict_types=1);

namespace App\Core;

/** Sidebar navigation. Items are shown only when the user holds one of the listed permissions. */
final class Nav
{
    public static function groups(): array
    {
        $groups = [
            'Main' => [
                ['Dashboard', '/', 'grid', ['dashboard.view']],
                ['Calendar', '/calendar', 'calendar', ['calendar.view']],
                ['Announcements', '/announcements', 'megaphone', ['announcements.view']],
                ['About the Church', '/church', 'church', ['church.view']],
            ],
            'Church Management' => [
                ['Members', '/members', 'users', ['members.view']],
                ['Ministries', '/ministries', 'layers', ['ministries.view', 'ministry.lead']],
                ['Attendance', '/attendance', 'clipboard', ['attendance.view', 'attendance.record']],
                ['Morning Prayer', '/morning-prayer', 'sunrise', ['attendance.view', 'attendance.record']],
            ],
            'Worship & Activities' => [
                ['Music Team', '/music', 'music', ['music.view']],
                ['Events', '/events', 'flag', ['events.view']],
            ],
            'Documents' => [
                ['Document Generator', '/documents/new', 'file-plus', ['documents.create']],
                ['Document Records', '/documents', 'folder', ['documents.view']],
            ],
            'Finance' => [
                ['Financial Dashboard', '/finance', 'chart', ['finance.view']],
                ['Income & Expenses', '/finance/transactions', 'swap', ['finance.view']],
                ['Donations & Offerings', '/finance/giving', 'gift', ['finance.view']],
                ['Budgets', '/finance/budgets', 'pie', ['finance.view']],
                ['Financial Reports', '/finance/reports', 'file', ['finance.view']],
            ],
            'System' => [
                ['Notifications', '/notifications', 'bell', []],
                ['User Management', '/users', 'shield', ['users.manage']],
                ['Audit Logs', '/audit', 'history', ['audit.view']],
                ['Settings', '/settings', 'sliders', ['settings.manage', 'backup.manage', 'documents.templates']],
            ],
        ];
        $out = [];
        foreach ($groups as $label => $items) {
            $visible = array_values(array_filter($items, static fn($i) => $i[3] === [] || Auth::canAny(...$i[3])));
            if ($visible) {
                $out[$label] = $visible;
            }
        }
        return $out;
    }

    public static function isActive(string $href): bool
    {
        $path = '/' . trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
        $base = base_url();
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = '/' . trim(substr($path, strlen($base)), '/');
        }
        if ($href === '/') {
            return $path === '/';
        }
        if ($href === '/documents') {
            return $path === '/documents' || (bool) preg_match('#^/documents/\d+#', $path);
        }
        if ($href === '/finance') {
            return $path === '/finance';
        }
        return $path === $href || str_starts_with($path, $href . '/');
    }
}
