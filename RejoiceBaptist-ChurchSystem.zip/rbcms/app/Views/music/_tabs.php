<div class="tabs">
  <a href="<?= url('/music') ?>" class="<?= $active === 'lineups' ? 'active' : '' ?>">Lineups</a>
  <a href="<?= url('/music/songs') ?>" class="<?= $active === 'songs' ? 'active' : '' ?>">Song library</a>
  <a href="<?= url('/music/stats') ?>" class="<?= $active === 'stats' ? 'active' : '' ?>">Statistics</a>
</div>
