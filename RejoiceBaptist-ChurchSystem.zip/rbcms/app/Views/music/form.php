<?php
use App\Controllers\MusicController as MC;
$editing = !empty($l['id']); $v = fn($k, $d = '') => old($k, $l[$k] ?? $d);
$memberOpts = function ($sel) use ($members) { $h = '<option value="">Select member…</option>'; foreach ($members as $m) { $h .= '<option value="' . (int) $m['id'] . '" data-sub="' . e($m['member_code']) . '"' . ((int) $sel === (int) $m['id'] ? ' selected' : '') . '>' . e(member_name($m, true)) . '</option>'; } return $h; };
$instOpts = function ($sel) use ($instruments) { $h = '<option value="">—</option>'; foreach ($instruments as $c) { $h .= '<option value="' . $c['id'] . '"' . ((int) $sel === (int) $c['id'] ? ' selected' : '') . '>' . e($c['name']) . '</option>'; } return $h; };
$opts = function (array $list, $sel) { $h = ''; foreach ($list as $k => $lab) { $h .= '<option value="' . $k . '"' . ($sel === $k ? ' selected' : '') . '>' . $lab . '</option>'; } return $h; };
$songRow = fn(array $s) => '<div class="dyn-row song-row">
  <span class="order-num"></span>
  <input data-name="songs[__i__][title]" value="' . e($s['title'] ?? '') . '" placeholder="Song title" list="dl-songs" maxlength="150" aria-label="Song title">
  <input data-name="songs[__i__][artist]" value="' . e($s['artist'] ?? '') . '" placeholder="Artist" list="dl-artists" maxlength="120" aria-label="Artist">
  <select data-name="songs[__i__][category]" aria-label="Part">' . $opts(MC::SONG_CATS, $s['category'] ?? 'praise') . '</select>
  <input data-name="songs[__i__][youtube_url]" value="' . e($s['youtube_url'] ?? '') . '" placeholder="YouTube link (optional)" maxlength="300" aria-label="YouTube link">
  <input data-name="songs[__i__][remarks]" value="' . e($s['remarks'] ?? '') . '" placeholder="Key / notes" maxlength="200" aria-label="Remarks">
  <span class="row-tools"><button type="button" class="icon-btn" data-move-up title="Move up">' . icon('chevron-up') . '</button><button type="button" class="icon-btn" data-move-down title="Move down">' . icon('chevron-down') . '</button><button type="button" class="icon-btn" data-remove-row title="Remove">' . icon('trash') . '</button></span>
</div>';
$teamRow = fn(array $t) => '<div class="dyn-row member-row">
  <select data-name="team[__i__][member_id]" data-search data-placeholder="Search member…" aria-label="Member">' . $memberOpts($t['member_id'] ?? 0) . '</select>
  <select data-name="team[__i__][role]" aria-label="Role">' . $opts(MC::ROLES, $t['role'] ?? 'instrumentalist') . '</select>
  <select data-name="team[__i__][instrument_id]" aria-label="Instrument">' . $instOpts($t['instrument_id'] ?? 0) . '</select>
  <input data-name="team[__i__][note]" value="' . e($t['note'] ?? '') . '" placeholder="Note (optional)" maxlength="120" aria-label="Note">
  <span class="row-tools"><button type="button" class="icon-btn" data-remove-row title="Remove">' . icon('trash') . '</button></span>
</div>';
if (!$songs) { $songs = [['category' => 'praise'], ['category' => 'praise'], ['category' => 'worship'], ['category' => 'worship']]; }
?>
<div class="crumbs"><a href="<?= url('/music') ?>">Music Team</a> / <?= $editing ? e($l['lineup_code']) : 'New lineup' ?></div>
<div class="page-head"><div><h1><?= e($title) ?></h1><p>Songs and team members are saved together. Song titles and artists you type are added to the song library automatically.</p></div></div>
<form method="post" action="<?= url($editing ? '/music/' . $l['id'] : '/music') ?>" enctype="multipart/form-data" class="card" novalidate>
  <?= csrf_field() ?>
  <div class="form-section"><h3>Service</h3><div class="form-grid">
    <div class="field span-3"><label for="service_date">Date<span class="req">*</span></label><input type="date" id="service_date" name="service_date" value="<?= e($v('service_date')) ?>" class="<?= has_error('service_date') ?>" required><?= field_error('service_date') ?></div>
    <div class="field span-3"><label for="service_type">Service<span class="req">*</span></label><select id="service_type" name="service_type"><?= $opts(MC::SERVICE_TYPES, $v('service_type', 'morning')) ?></select></div>
    <div class="field span-6"><label for="service_title">Title <span class="muted">(required for special services)</span></label><input id="service_title" name="service_title" value="<?= e($v('service_title')) ?>" maxlength="150" placeholder="e.g. Night of Worship, Church Anniversary" class="<?= has_error('service_title') ?>"><?= field_error('service_title') ?></div>
    <div class="field span-6"><label for="song_leader_member_id">Song leader<span class="req">*</span></label><?= App\Core\View::partial('partials/member_select', ['name' => 'song_leader_member_id', 'members' => $members, 'selected' => $v('song_leader_member_id'), 'class' => has_error('song_leader_member_id'), 'emptyLabel' => 'Select song leader…']) ?><?= field_error('song_leader_member_id') ?></div>
  </div></div>

  <div class="form-section"><div class="row" style="justify-content:space-between"><div><h3>Lineup songs<span class="req">*</span></h3><p class="muted" style="margin:0">In the order they will be sung. Empty rows are ignored.</p></div><button type="button" class="btn btn-sm" data-add-row="song-rows" data-template="tpl-song"><?= icon('plus') ?> Add song</button></div>
    <?= field_error('songs') ?>
    <div class="rows-head song-row mt" style="grid-template-columns:26px minmax(0,2fr) minmax(0,1.4fr) 130px minmax(0,1.3fr) minmax(0,1.2fr) 86px"><span>#</span><span>Song</span><span>Artist</span><span>Part</span><span>YouTube</span><span>Notes</span><span></span></div>
    <div class="rows-editor" id="song-rows"><?php foreach ($songs as $s) { echo $songRow($s); } ?></div>
  </div>

  <div class="form-section"><div class="row" style="justify-content:space-between"><div><h3>Instrumentalists &amp; backups</h3><p class="muted" style="margin:0">Add each person with their role. Instrument is required for instrumentalists.</p></div><button type="button" class="btn btn-sm" data-add-row="team-rows" data-template="tpl-team"><?= icon('plus') ?> Add person</button></div>
    <?= field_error('team') ?>
    <div class="rows-head member-row mt" style="grid-template-columns:minmax(0,2fr) 150px 160px minmax(0,1.2fr) 32px"><span>Member</span><span>Role</span><span>Instrument</span><span>Note</span><span></span></div>
    <div class="rows-editor" id="team-rows"><?php foreach ($team as $t) { echo $teamRow($t); } ?></div>
    <?php if (!$team): ?><p class="muted small" data-rows-empty>No one added yet.</p><?php endif; ?>
  </div>

  <div class="form-section"><h3>Praise &amp; worship photo</h3><div class="form-grid">
    <div class="field span-6"><input type="file" name="photo" accept="image/jpeg,image/png,image/webp" data-preview="photo-preview"><p class="help">JPG, PNG or WebP up to <?= (int) config('upload_max_mb') ?> MB. Large photos are resized automatically.</p><?= field_error('photo') ?>
      <?php if (!empty($l['photo_path'])): ?><label class="check small mt-sm"><input type="checkbox" name="remove_photo" value="1"> Remove current photo</label><?php endif; ?></div>
    <div class="span-6"><img id="photo-preview" class="thumb <?= empty($l['photo_path']) ? 'hidden' : '' ?>" src="<?= e(file_url($l['photo_path'] ?? null) ?? '') ?>" alt="" style="max-width:320px"></div>
    <div class="field span-12"><label for="remarks">Remarks</label><textarea id="remarks" name="remarks" rows="3" maxlength="2000"><?= e($v('remarks')) ?></textarea></div>
  </div></div>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url($editing ? '/music/' . $l['id'] : '/music') ?>">Cancel</a><button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Save lineup' ?></button></div>
</form>
<template id="tpl-song"><?= $songRow(['category' => 'worship']) ?></template>
<template id="tpl-team"><?= $teamRow([]) ?></template>
<datalist id="dl-songs"><?php foreach ($songTitles as $s): ?><option value="<?= e($s['title']) ?>"><?= e($s['artist'] ?? '') ?></option><?php endforeach; ?></datalist>
<datalist id="dl-artists"><?php foreach ($artists as $a): ?><option value="<?= e($a) ?>"><?php endforeach; ?></datalist>
