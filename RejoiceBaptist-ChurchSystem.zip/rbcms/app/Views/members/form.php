<?php $editing = !empty($m['id']); $v = fn($k, $d = '') => old($k, $m[$k] ?? $d); ?>
<div class="crumbs"><a href="<?= url('/members') ?>">Members</a> / <?= $editing ? e(member_name($m)) : 'New member' ?></div>
<div class="page-head">
  <div><h1><?= $editing ? 'Edit member' : 'Add member' ?></h1><p><?= $editing ? 'Member ID ' : 'The member ID will be generated automatically, e.g. ' ?><span class="code"><?= e($nextCode) ?></span></p></div>
</div>

<?php if ($duplicates): ?>
<div class="callout warn mb"><?= icon('alert') ?><div>
  <strong>Possible duplicate record.</strong> These members have the same name or contact number:
  <ul style="margin:6px 0 0;padding-left:18px">
    <?php foreach ($duplicates as $d): ?><li><a href="<?= url('/members/' . $d['id']) ?>" target="_blank"><?= e(member_name($d)) ?></a> · <span class="code"><?= e($d['member_code']) ?></span><?= $d['birth_date'] ? ' · born ' . e(fmt_date($d['birth_date'])) : '' ?><?= $d['archived_at'] ? ' · archived' : '' ?></li><?php endforeach; ?>
  </ul>
</div></div>
<?php endif; ?>

<form method="post" action="<?= url($editing ? '/members/' . $m['id'] : '/members') ?>" enctype="multipart/form-data" class="card" novalidate>
  <?= csrf_field() ?>
  <div class="form-section">
    <h3>Personal information</h3><p class="muted">Name and basic details as they should appear on church records and certificates.</p>
    <div class="form-grid">
      <div class="field span-4"><label for="first_name">First name<span class="req">*</span></label><input id="first_name" name="first_name" value="<?= e($v('first_name')) ?>" class="<?= has_error('first_name') ?>" required maxlength="80"><?= field_error('first_name') ?></div>
      <div class="field span-3"><label for="middle_name">Middle name</label><input id="middle_name" name="middle_name" value="<?= e($v('middle_name')) ?>" maxlength="80"></div>
      <div class="field span-3"><label for="last_name">Last name<span class="req">*</span></label><input id="last_name" name="last_name" value="<?= e($v('last_name')) ?>" class="<?= has_error('last_name') ?>" required maxlength="80"><?= field_error('last_name') ?></div>
      <div class="field span-2"><label for="suffix">Suffix</label><input id="suffix" name="suffix" value="<?= e($v('suffix')) ?>" placeholder="Jr., III" maxlength="10"></div>
      <div class="field span-3"><label for="gender">Gender</label><select id="gender" name="gender"><option value="">—</option><option value="male" <?= $v('gender') === 'male' ? 'selected' : '' ?>>Male</option><option value="female" <?= $v('gender') === 'female' ? 'selected' : '' ?>>Female</option></select></div>
      <div class="field span-3"><label for="birth_date">Date of birth</label><input id="birth_date" type="date" name="birth_date" value="<?= e($v('birth_date')) ?>" max="<?= today() ?>" class="<?= has_error('birth_date') ?>"><?= field_error('birth_date') ?></div>
      <div class="field span-3"><label for="civil_status">Civil status</label><select id="civil_status" name="civil_status"><option value="">—</option><?php foreach (['Single', 'Married', 'Widowed', 'Separated'] as $cs): ?><option <?= $v('civil_status') === $cs ? 'selected' : '' ?>><?= $cs ?></option><?php endforeach; ?></select></div>
      <div class="field span-3"><label for="photo">Profile picture</label><input id="photo" type="file" name="photo" accept="image/jpeg,image/png,image/webp" data-preview="photo-preview"><?= field_error('photo') ?>
        <?php if (!empty($m['photo_path'])): ?><label class="check small mt-sm"><input type="checkbox" name="remove_photo" value="1"> Remove current picture</label><?php endif; ?></div>
      <div class="span-12"><img id="photo-preview" class="<?= empty($m['photo_path']) ? 'hidden' : '' ?>" src="<?= e(file_url($m['photo_path'] ?? null) ?? '') ?>" alt="" style="width:88px;height:88px;object-fit:cover;border-radius:8px;border:1px solid var(--border)"></div>
    </div>
  </div>
  <div class="form-section">
    <h3>Contact</h3><p class="muted">How the church can reach this member.</p>
    <div class="form-grid">
      <div class="field span-4"><label for="contact_number">Contact number</label><input id="contact_number" name="contact_number" value="<?= e($v('contact_number')) ?>" placeholder="09XX XXX XXXX" class="<?= has_error('contact_number') ?>"><?= field_error('contact_number') ?></div>
      <div class="field span-4"><label for="email">E-mail</label><input id="email" type="email" name="email" value="<?= e($v('email')) ?>" class="<?= has_error('email') ?>"><?= field_error('email') ?></div>
      <div class="field span-12"><label for="address">Address</label><input id="address" name="address" value="<?= e($v('address')) ?>" maxlength="300"></div>
      <div class="field span-4"><label for="emergency_name">Emergency contact person</label><input id="emergency_name" name="emergency_name" value="<?= e($v('emergency_name')) ?>"></div>
      <div class="field span-4"><label for="emergency_relation">Relationship</label><input id="emergency_relation" name="emergency_relation" value="<?= e($v('emergency_relation')) ?>" placeholder="e.g. Mother, Spouse"></div>
      <div class="field span-4"><label for="emergency_contact">Emergency contact number</label><input id="emergency_contact" name="emergency_contact" value="<?= e($v('emergency_contact')) ?>"></div>
    </div>
  </div>
  <div class="form-section">
    <h3>Membership &amp; baptism</h3><p class="muted">Membership activity and baptism are recorded separately — a member can be active and unbaptized, inactive and baptized, and so on.</p>
    <div class="form-grid">
      <div class="field span-4"><label for="date_joined">Date joined</label><input id="date_joined" type="date" name="date_joined" value="<?= e($v('date_joined', $editing ? '' : today())) ?>" max="<?= today() ?>" class="<?= has_error('date_joined') ?>"><?= field_error('date_joined') ?></div>
      <div class="field span-4"><label for="membership_status">Membership status</label><select id="membership_status" name="membership_status"><option value="active" <?= $v('membership_status', 'active') === 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= $v('membership_status') === 'inactive' ? 'selected' : '' ?>>Inactive</option></select></div>
      <div class="field span-4"><label for="baptism_status">Baptism status</label><select id="baptism_status" name="baptism_status"><option value="unbaptized" <?= $v('baptism_status', 'unbaptized') === 'unbaptized' ? 'selected' : '' ?>>Unbaptized</option><option value="baptized" <?= $v('baptism_status') === 'baptized' ? 'selected' : '' ?>>Baptized</option></select></div>
      <div class="field span-4"><label for="baptism_date">Baptism date</label><input id="baptism_date" type="date" name="baptism_date" value="<?= e($v('baptism_date')) ?>" max="<?= today() ?>" class="<?= has_error('baptism_date') ?>"><?= field_error('baptism_date') ?><p class="help">Only saved when the status is Baptized.</p></div>
      <div class="field span-4"><label for="baptism_place">Place of baptism</label><input id="baptism_place" name="baptism_place" value="<?= e($v('baptism_place')) ?>"></div>
      <div class="field span-4"><label for="baptized_by">Baptized by</label><input id="baptized_by" name="baptized_by" value="<?= e($v('baptized_by')) ?>" placeholder="Officiating pastor"></div>
    </div>
  </div>
  <div class="form-section">
    <h3>Ministries</h3><p class="muted">Select every ministry this member serves in.</p>
    <?php $selected = array_map('intval', (array) old('ministries', $memberMinistries)); ?>
    <?php if (!$ministries): ?><p class="muted small">No ministries yet. <?php if (can('ministries.manage')): ?><a href="<?= url('/ministries/new') ?>">Add a ministry</a>.<?php endif; ?></p><?php endif; ?>
    <div class="grid cols-3" style="gap:8px">
      <?php foreach ($ministries as $mi): ?>
        <label class="check"><input type="checkbox" name="ministries[]" value="<?= $mi['id'] ?>" <?= in_array((int) $mi['id'], $selected, true) ? 'checked' : '' ?>> <?= e($mi['name']) ?></label>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="form-section">
    <div class="field"><label for="notes">Notes</label><textarea id="notes" name="notes" rows="3" maxlength="4000"><?= e($v('notes')) ?></textarea><p class="help">Visible to users who can view member records. Do not record sensitive pastoral matters here.</p></div>
    <?php if ($duplicates): ?><label class="check mt"><input type="checkbox" name="confirm_duplicate" value="1"> <span>I checked the records above and this is a <strong>different person</strong>.</span></label><?= field_error('confirm_duplicate') ?><?php endif; ?>
  </div>
  <div class="card-footer">
    <a class="btn btn-ghost" href="<?= url($editing ? '/members/' . $m['id'] : '/members') ?>">Cancel</a>
    <div class="row">
      <?php if (!$editing): ?><button class="btn" type="submit" name="save_new" value="1">Save and add another</button><?php endif; ?>
      <button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Save member' ?></button>
    </div>
  </div>
</form>
