<div class="callout danger mb" style="padding:8px 12px"><?= icon('lock') ?><div class="small"><strong>Confidential.</strong> Financial records are visible only to authorized finance users. Every export is logged.</div></div>
<div class="tabs">
  <?php foreach (['/finance' => 'Overview', '/finance/transactions' => 'Transactions', '/finance/giving' => 'Tithes & offerings', '/finance/budgets' => 'Budgets', '/finance/reports' => 'Reports'] as $h => $l): ?>
    <a href="<?= url($h) ?>" class="<?= ($active ?? '') === $h ? 'active' : '' ?>"><?= $l ?></a>
  <?php endforeach; ?>
</div>
