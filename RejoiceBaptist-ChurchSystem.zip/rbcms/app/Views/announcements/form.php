<?php $editing = !empty($a['id']); $v = fn($k, $d = '') => old($k, $a[$k] ?? $d); ?>
<div class="crumbs"><a href="<?= url('/announcements') ?>">Announcements</a> / <?= $editing ? 'Edit' : 'New' ?></div>
<div class="page-head"><div><h1><?= e($title) ?></h1><p>Published announcements notify all users and appear on the dashboard.</p></div></div>
<form method="post" action="<?= url($editing ? '/announcements/' . $a['id'] : '/announcements') ?>" enctype="multipart/form-data" class="card" style="max-width:820px" novalidate>
  <?= csrf_field() ?>
  <div class="card-body"><div class="form-grid">
    <div class="field span-12"><label for="title">Title<span class="req">*</span></label><input id="title" name="title" value="<?= e($v('title')) ?>" maxlength="150" class="<?= has_error('title') ?>" required><?= field_error('title') ?></div>
    <div class="field span-12"><label for="body">Message<span class="req">*</span></label><textarea id="body" name="body" rows="10" class="<?= has_error('body') ?>" required><?= e($v('body')) ?></textarea><p class="help">Plain text. Blank lines start a new paragraph.</p><?= field_error('body') ?></div>
    <div class="field span-6"><label>Image <span class="muted">(optional)</span></label><input type="file" name="image" accept="image/jpeg,image/png,image/webp" data-preview="ann-preview"><?= field_error('image') ?>
      <?php if (!empty($a['image_path'])): ?><label class="check small mt-sm"><input type="checkbox" name="remove_image" value="1"> Remove current image</label><?php endif; ?></div>
    <div class="span-6"><img id="ann-preview" class="thumb <?= empty($a['image_path']) ? 'hidden' : '' ?>" src="<?= e(file_url($a['image_path'] ?? null) ?? '') ?>" alt="" style="max-width:260px"></div>
    <div class="field span-4"><label for="status">Status</label><select id="status" name="status"><?php foreach (['published' => 'Published', 'draft' => 'Draft', 'archived' => 'Archived'] as $k => $l): ?><option value="<?= $k ?>" <?= $v('status') === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></div>
    <div class="field span-8" style="align-self:end"><label class="check"><input type="checkbox" name="is_pinned" value="1" <?= (int) $v('is_pinned', 0) ? 'checked' : '' ?>> Pin to the top of the list and dashboard</label></div>
  </div></div>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url($editing ? '/announcements/' . $a['id'] : '/announcements') ?>">Cancel</a><button class="btn btn-primary" type="submit">Save</button></div>
</form>
