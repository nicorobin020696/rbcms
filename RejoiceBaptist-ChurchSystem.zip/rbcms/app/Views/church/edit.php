<?php use App\Controllers\ChurchController; $f = function (string $key) use ($s) { [$label, $max, $multi] = ChurchController::FIELDS[$key]; $name = str_replace('.', '_', $key); $val = old($name, $s[$key] ?? '');
  return '<div class="field ' . ($multi ? 'span-12' : 'span-6') . '"><label for="' . $name . '">' . e($label) . '</label>' . ($multi ? '<textarea id="' . $name . '" name="' . $name . '" rows="' . ($max > 3000 ? 8 : 4) . '" maxlength="' . $max . '">' . e($val) . '</textarea>' : '<input id="' . $name . '" name="' . $name . '" value="' . e($val) . '" maxlength="' . $max . '" class="' . has_error($name) . '">') . field_error($name) . '</div>'; }; ?>
<div class="crumbs"><a href="<?= url('/church') ?>">About the Church</a> / Edit</div>
<div class="page-head"><div><h1>Edit church information</h1><p>Only enter official, confirmed details. Empty fields show as “Not set” — nothing is filled in automatically. The logo is changed under <a href="<?= url('/settings/general') ?>">Settings</a>.</p></div></div>
<form method="post" action="<?= url('/church') ?>" class="card" novalidate>
  <?= csrf_field() ?>
  <div class="form-section"><h3>Identity &amp; contact</h3><div class="form-grid"><?php foreach (['church.name', 'church.short_name', 'church.founded', 'church.phone', 'church.email', 'church.facebook', 'church.address'] as $k) { echo $f($k); } ?></div></div>
  <div class="form-section"><h3>Mission &amp; vision</h3><div class="form-grid"><?= $f('church.mission') . $f('church.vision') ?></div></div>
  <div class="form-section"><h3>History &amp; beliefs</h3><p class="muted">Plain text. Leave a blank line between paragraphs.</p><div class="form-grid"><?= $f('church.history') . $f('church.beliefs') . $f('church.background') ?></div></div>
  <div class="form-section"><h3>Services &amp; leadership</h3><div class="form-grid"><?= $f('church.service_times') . $f('church.leadership') ?></div></div>
  <div class="card-footer"><a class="btn btn-ghost" href="<?= url('/church') ?>">Cancel</a><button class="btn btn-primary" type="submit">Save changes</button></div>
</form>
