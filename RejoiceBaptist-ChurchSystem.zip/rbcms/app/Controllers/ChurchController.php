<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Database as DB;
use App\Core\Settings;

/** "About the Church" — content comes only from settings the church enters; nothing is invented. */
final class ChurchController extends Controller
{
    public const FIELDS = [
        'church.name' => ['Church name', 150, false], 'church.short_name' => ['Short name', 20, false], 'church.founded' => ['Year founded', 10, false],
        'church.address' => ['Address', 300, false], 'church.phone' => ['Phone', 60, false], 'church.email' => ['Email', 120, false],
        'church.facebook' => ['Facebook page', 200, false], 'church.service_times' => ['Service times', 1000, true],
        'church.mission' => ['Mission', 2000, true], 'church.vision' => ['Vision', 2000, true], 'church.background' => ['Church background', 5000, true],
        'church.history' => ['History', 10000, true], 'church.beliefs' => ['What we believe', 10000, true], 'church.leadership' => ['Pastors & leadership', 3000, true],
    ];

    public function show(): void
    {
        $status = EventsController::statusSql();
        $this->view('church/show', [
            'title' => 'About the Church',
            's' => Settings::many('church.'),
            'ministries' => DB::all("SELECT m.id, m.name, m.description, m.schedule_day, m.schedule_start, m.schedule_end, m.schedule_location,
                                            (SELECT COUNT(*) FROM ministry_members mm JOIN members x ON x.id = mm.member_id WHERE mm.ministry_id = m.id AND x.archived_at IS NULL) members
                                       FROM ministries m WHERE m.archived_at IS NULL AND m.status = 'active' ORDER BY m.name"),
            'past' => DB::all("SELECT e.id, e.title, e.start_date, e.end_date, e.poster_path, e.location, c.name category, c.color FROM events e LEFT JOIN categories c ON c.id = e.category_id
                                WHERE e.is_activity = 1 AND e.archived_at IS NULL AND ($status) = 'completed' ORDER BY e.start_date DESC LIMIT 12"),
            'upcoming' => DB::all("SELECT e.id, e.title, e.start_date, e.start_time, e.location, c.name category, c.color FROM events e LEFT JOIN categories c ON c.id = e.category_id
                                    WHERE e.is_activity = 1 AND e.archived_at IS NULL AND ($status) IN ('upcoming','ongoing') AND e.recurrence = 'none' ORDER BY e.start_date LIMIT 5"),
            'messages' => can('announcements.view') ? DB::all("SELECT id, title, body, published_at FROM announcements WHERE status = 'published' ORDER BY is_pinned DESC, published_at DESC LIMIT 3") : [],
        ]);
    }

    public function edit(): void
    {
        $this->view('church/edit', ['title' => 'Edit church information', 's' => Settings::many('church.')]);
    }

    public function update(): void
    {
        $errors = [];
        $vals = [];
        foreach (self::FIELDS as $key => [$label, $max, $multi]) {
            $name = str_replace('.', '_', $key);
            $vals[$key] = $multi ? input_text($name, $max) : input_str($name, $max);
        }
        if ($vals['church.name'] === '') { $errors['church_name'] = 'The church name is required.'; }
        if ($vals['church.email'] !== '' && !filter_var($vals['church.email'], FILTER_VALIDATE_EMAIL)) { $errors['church_email'] = 'Enter a valid email address.'; }
        if ($errors) { $this->failed($errors, '/church/edit'); }
        $changed = [];
        foreach ($vals as $k => $v) {
            if ((string) Settings::get($k) !== $v) { Settings::set($k, $v); $changed[] = self::FIELDS[$k][0]; }
        }
        if ($changed) { Audit::log('update', 'church', 'settings', null, 'Church information', 'Changed: ' . implode(', ', $changed)); }
        flash('success', $changed ? 'Church information updated.' : 'No changes to save.');
        redirect('/church');
    }
}
