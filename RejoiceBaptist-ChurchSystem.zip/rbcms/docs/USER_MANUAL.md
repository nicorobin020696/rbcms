# User manual

## Signing in

- Open the system address, for example `http://192.168.1.20:8080`, and sign in with the username and password from the Super Admin.
- After 5 wrong passwords (the number can be changed in Settings), the account locks for 15 minutes. The Super Admin can unlock it sooner from **Users & Roles**.
- You are signed out after 30 minutes without activity (changeable).
- **My account** (click your name at the bottom left) is where you change your password and choose a **light, dark or system** theme. The sun/moon button at the top also switches themes.
- The **bell** shows notifications, for example:
  - a lineup was submitted
  - a budget was exceeded
  - a backup is overdue
  - an event is today

  Each person only sees notifications for modules they can access.

## What each role can do

The Super Admin can adjust any role, or give or remove a single permission for one person (**Users & Roles → edit user → Permissions**).

| Role | Can do |
|---|---|
| **Super Admin** | Everything: users and roles, settings, backups, audit log, finance, confidential documents |
| **Secretary** | Members, ministries, attendance (including corrections), announcements, events and calendar, church information, documents (including confidential ones) and templates. **No finance** unless granted. |
| **Treasurer** | Finance: income and expenses, tithes and offerings, budgets, financial reports and exports. No member records. |
| **Ministry Leader** | Views schedules. Manages the members and attendance of the ministries they lead. |
| **Music Team Encoder** | Creates and edits Sunday lineups, songs and the team list. |
| **Attendance Encoder** | Records attendance and morning prayer. |
| **Viewer** | Read-only: dashboard, calendar, events, announcements, church information |

Finance is confidential. Users without finance permission do not see the finance menu, dashboard totals, finance exports, receipts or finance notifications. Typing a finance address directly shows "Access denied", and the attempt is recorded in the audit log.

---

## Dashboard

Shows only what your role allows:

- member counts: total, active, inactive, baptized, active but not baptized
- last Sunday's attendance
- attendance by month (this year compared with last year) and by year
- upcoming events
- recent attendance and announcements
- the most lined-up songs
- the fund balance and income/expenses, for finance users only

Use the year selector at the top to view earlier years. All numbers come from saved records, never from fixed values.

## Calendar

- **Month, Week and List** views. Filter by category using the dropdown.
- **Click any day** to see a pop-up of that day's events and weekly ministries with their times. If nothing is scheduled, it says so.
- **New event** adds a one-time or multi-day activity, for example Youth Jam, VBS, Fun Run, Family Day, an anniversary or a Night of Worship.
- **Add schedule** adds a weekly ministry or service time, for example Sunday Worship 9:30 AM or Wednesday Prayer Meeting.
- If a new item overlaps another one, the system lists the conflicts and asks you to tick *Save anyway*.

## Events

- Each event has a title, category, ministry, date(s), time, location, poster image and description.
- The status is automatic: Upcoming, Ongoing or Completed.
- An event can be marked **Cancelled** with a reason, or archived and later restored.
- Completed events appear under **About the Church → Past events**.

## Announcements

- Write a title and message, with an optional image.
- Save it as a **Draft**, or **Publish** it to show it on everyone's dashboard. It can be pinned or archived.

## About the Church

- Shows history, what we believe, mission, vision, contact details, present ministries with schedules, and past events.
- Users with the *church.manage* permission click **Edit** to update the text.

## Members

- **Add member** takes the name, birth date, gender, contact, address, emergency contact, membership status (active/inactive), baptism status and details, date joined, ministries and a photo.
- The **member ID is generated automatically**, for example `RBC-2026-0001`. The format is set in Settings → General → IDs.
- If a member with the same name and birth date exists, the system warns you before saving.
- Tabs and filters:
  - All, Active, Inactive, **Active unbaptized**, Baptized, No ministry, Archived
  - search by name, ID or phone
  - filter by ministry and gender
- **CSV** and **PDF** buttons export exactly the list you are viewing.
- Members are **archived**, not deleted, so history is never lost. Archived members can be restored.
- Each member page shows their attendance history and a change history.

## Ministries

- The list of ministries, with leader, schedule (day and time), location and members.
- Weekly schedules appear on the calendar automatically.
- Add or remove members from the ministry page.

## Attendance

1. **Record attendance**: choose the service or ministry and the date.
2. The marking sheet lists members. Mark each one **Present, Absent, Late or Excused**, with an optional remark. Use *Mark all present* to speed things up.
3. **Save.** Recording the same service on the same date again opens the existing sheet instead of creating a duplicate.

Tabs:

- **Overview**: charts by month and year, the last 12 weeks, and the last 14 days.
- **Sessions**: all recorded services.
- **Attendance history**: every record, filterable and exportable to CSV or PDF.
- Changing an already-saved sheet needs the *attendance.correct* permission and is logged.

## Morning prayer

- Choose the date, tick the members who attended, and save. Unticked members are recorded as absent.
- Totals and history appear on the same page and in the attendance charts.

## Music team lineups

1. **New lineup**: enter the date and service (Morning Worship, Evening, Special…) and choose the **song leader**.
2. Add each **song** with its **artist**, part (Praise / Worship / Offertory / Special / Closing), an optional YouTube link and notes. New songs and artists are added to the song library automatically.
3. Add **instrumentalists** (with their instrument) and **backup singers**.
4. Upload the **Sunday praise & worship photo**.
5. Save.

Other options:

- **Copy** creates a lineup from an earlier one.
- **Song library** lists every song, with times used and last used.
- **Statistics** shows the most lined-up songs, artists and song leaders for any period, with a PDF export.

## Documents (letters and certificates)

1. **Document Generator → choose a type**: recommendation, request, solicitation, invitation, certificate of membership or baptism, endorsement, memo, and others.
2. The form opens with that type's **template**. Choose the member or recipient, purpose and date. Placeholders such as `{{recipient_name}}` and `{{purpose}}` fill in automatically.
3. Edit the body in the editor (bold, italic, underline, alignment, lists). Choose whether to show the **logo and letterhead**, and pick the **signatories**. Their signature images are printed.
4. Tick **Confidential** to hide the document from everyone without the confidential-documents permission.
5. Save as **Draft** while editing. **Finalize** locks it: final documents cannot be changed, but they can be **duplicated**.
6. **Print** or **PDF**. Every document gets a code, for example `DOC-2026-0001`.

Templates and signatories are managed in **Settings → Document templates / Signatories**. This needs the *documents.templates* permission.

## Finance (treasurer and authorized users only)

- **Overview**: fund balance, this month's income and expenses, income vs expenses by month, categories, and budgets.
- **Record income / Record expense**: amount, date, category, ministry or event, payment method, reference number, description and an optional receipt image. Amounts are stored to the exact centavo.
- **Tithes & offerings**: giving records, with an optional donor (member).
- Entries are never deleted. A wrong entry is **voided** with a reason. It stays visible, crossed out, and is excluded from totals.
- **Budgets**: set a budget per ministry or event with a period. Actual spending is computed from expenses. The treasurer is notified when spending goes over the budget.
- **Reports** (PDF or CSV):
  - income and expense statement
  - income report
  - expense report
  - tithes and offerings
  - budget vs actual
  - by ministry
  - by event
  - fund balance

  Each can be run for a month, quarter, year or custom period. Every PDF is marked CONFIDENTIAL, and every export is logged.

## Users & Roles (Super Admin)

- **Create a user**: name, username, role, password, and an optional link to a member record.
- From the user list you can:
  - **reset the password** (the person must change it at next sign-in)
  - **deactivate** the account (they are signed out immediately)
  - **unlock** a locked account
- **Roles** shows the permission matrix. Edit a role to change what everyone in it can do.
- Safety rules:
  - only a Super Admin can create or edit Super Admins
  - nobody can grant permissions they do not have
  - the last active Super Admin cannot be deactivated

## Audit log (Super Admin)

Every sign-in, sign-out, failed sign-in, create, edit, archive, void, export, backup, restore and denied access is recorded, with the user, time, IP and details. You can filter by user, module, action and date. The audit log cannot be edited.

## Settings (Super Admin)

- **General**:
  - church name and contacts
  - logo (used on the screen, PDFs and letters)
  - ID formats
  - security: session timeout, sign-in attempts, lockout minutes
  - backup retention
  - sample data
- **Categories**: event categories, attendance services, finance categories, instruments and other lists.
- **Document templates** and **Signatories**.
- **Backup & restore**: see [BACKUP_RESTORE.md](BACKUP_RESTORE.md).
