# Installation guide

The system is a small PHP application with a built-in SQLite database. There is no separate database server to install.

## 1. Requirements

- One computer that stays on during church office hours: the **server**. Windows 10/11, Linux or macOS.
- **PHP 8.1 or newer**, with these extensions: `pdo_sqlite`, `mbstring`, `fileinfo`, `zip`, `gd`.
- Any modern browser on the other devices: Chrome, Edge, Firefox or Safari.

## 2. Install PHP on Windows

1. Download the latest **PHP 8.x "VS16 x64 Thread Safe" zip** from https://windows.php.net/download/.
2. Extract it to `C:\php`, so that `C:\php\php.exe` exists.
3. In `C:\php`, copy `php.ini-production` and rename the copy to `php.ini`.
4. Open `php.ini` in Notepad.
   - Find `;extension_dir = "ext"` and remove the leading `;`.
   - Remove the `;` in front of each of these lines:
     ```
     extension=fileinfo
     extension=gd
     extension=mbstring
     extension=pdo_sqlite
     extension=zip
     ```
   - Optionally raise the upload limits:
     ```
     upload_max_filesize = 12M
     post_max_size = 40M
     ```
5. Optional: add `C:\php` to the Windows PATH. `start-server.bat` also finds `C:\php` on its own.

> **Alternative:** if XAMPP is already installed, its PHP works. Run `start-server.bat` after adding `C:\xampp\php` to PATH, or see section 6.

## 3. Install the system

1. Copy the `rbcms` folder to a permanent place, for example `C:\ChurchSystem\rbcms`.
   Do **not** use the Desktop or Downloads folder.
2. Double-click `start-server.bat`. It runs a system check first; every line should say `OK`.
3. Keep the black window open. Closing it stops the system.

To start the system automatically when the server PC turns on:

1. Press `Win+R` and type `shell:startup`.
2. Put a shortcut to `start-server.bat` in that folder.

## 4. First-time setup: create the Super Admin

1. On the server, open **http://localhost:8080**.
2. The first-time setup page appears, because no account exists yet. Enter your name, a username and a strong password: at least 10 characters, with both letters and numbers.
3. Sign in. The setup page is now disabled permanently.
4. Go to **Settings → General** and fill in the real church details:
   - church name, address, contact numbers, e-mail, logo
   - member ID prefix and format
   - session timeout and sign-in lockout limits
5. Go to **About the Church → Edit** and enter the history, beliefs, mission and vision. The system ships without invented church details: anything not yet entered shows as "Not set".
6. Go to **Settings → Signatories** and add the pastor, secretary and others, with signature images (transparent PNG works best).
7. Go to **Users & Roles** and create accounts for the secretary, treasurer, encoders and others. Give each person only the role they need.
8. Optional: **Settings → General → Sample data** loads clearly labelled sample records so people can practise. Remove them before real use with *Remove sample data*. Only records marked SAMPLE are deleted.

## 5. Open it from other computers and phones (local network)

1. On the server, open Command Prompt and run `ipconfig`. Note the **IPv4 Address**, for example `192.168.1.20`.
2. On other devices on the same Wi-Fi or LAN, open `http://192.168.1.20:8080`.
3. If it does not load, allow PHP through the Windows Firewall:
   1. Go to Windows Security → Firewall → Allow an app.
   2. Add `C:\php\php.exe` and tick **Private** only.
   3. Never tick Public.
4. Optional: give the server a fixed IP (a DHCP reservation in the router) so the address never changes.

**Do not** forward this port on the router or expose it to the internet. The system is designed for the church's private network.

## 6. Optional: run under Apache (XAMPP/WAMP)

The built-in server is enough for a church office. For Apache:

- **Recommended:** create a virtual host whose `DocumentRoot` is the `rbcms/public` folder. Turn on `mod_rewrite` and `AllowOverride All`.
- **Alternative:** put the whole `rbcms` folder inside `htdocs`. The included `.htaccess` files send requests to `public/` and block `app/`, `storage/`, `database/`, `bin/`, `docs/` and `tests/`. The address becomes `http://server/rbcms/`.
- If links come out wrong behind a proxy or alias, create `storage/config.php` and set the base path:
  ```php
  <?php return ['base_url' => '/rbcms/public'];
  ```
- Make sure the web server user can write to `storage/`.

## 7. Configuration file (optional)

`storage/config.php` can override these defaults:

```php
<?php
return [
    'timezone'      => 'Asia/Manila',
    'upload_max_mb' => 10,
    'debug'         => false,   // never true on the live system
    'base_url'      => '',      // auto-detected
];
```

## 8. Command-line tools

Run these from the `rbcms` folder:

```
php bin/console.php check                 system check
php bin/console.php backup                full backup now
php bin/console.php backups               list backups
php bin/console.php restore <file.zip>    restore a backup
php bin/console.php users                 list accounts
php bin/console.php reset-admin <user>    set a new password and unlock the account
```

## 9. Updating to a newer version

1. Make a backup: Settings → Backup & restore → *Back up now*.
2. Stop the server.
3. Replace `app/`, `public/`, `database/`, `bin/` and `docs/` with the new version.
   **Keep `storage/`.**
4. Start the server. Database changes are applied automatically on the next page load.
